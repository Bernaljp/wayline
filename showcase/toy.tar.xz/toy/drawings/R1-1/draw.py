"""Drawing R1-1: R1 cites code, not data, so this script draws no plot.

It reads the two cited artifacts as text (it never imports or runs the project's code) and
records in numbers.json the values the drawing's prose refers to.
"""

import json
import os
import re

PROJECT = os.environ.get("WAYLINE_PROJECT", ".")
OUT = os.path.dirname(os.path.abspath(__file__))

test_src = open(os.path.join(PROJECT, "tests/test_generate.py"), encoding="utf-8").read()
gen_src = open(os.path.join(PROJECT, "src/toy/generate.py"), encoding="utf-8").read()

sha = re.search(r'DEFAULT_DRAW_SHA256 = "([0-9a-f]{64})"', test_src).group(1)
call = re.search(r"generate\((\d+), signal=([\d.]+), rows=(\d+)\)", test_src)
row_src = re.search(r"def row\(.*?\n\n\n", gen_src, re.S).group(0)

numbers = {
    "default_draw_sha256": sha,
    "default_draw_seed": int(call.group(1)),
    "default_draw_signal": float(call.group(2)),
    "default_draw_rows": int(call.group(3)),
    "row_draws_gauss_unconditionally": "rng.gauss" in row_src and "if strength" not in row_src,
    "plots_drawn": 0,
}

with open(os.path.join(OUT, "numbers.json"), "w", encoding="utf-8") as handle:
    json.dump(numbers, handle, indent=2, sort_keys=True)
    handle.write("\n")

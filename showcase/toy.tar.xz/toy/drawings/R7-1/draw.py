"""Drawing R7-1: the E2 gate (reproduction and convergence), from analysis/E2/checks.json only.

Reads the artifact's per-run final training losses at the pinned and doubled epoch counts,
recomputes each run's relative drop (loss_pinned - loss_double) / loss_pinned, checks it against
the stored drop, and draws two plots and two tables. Nothing random; CPU only.
"""

import csv
import json
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(os.environ.get("WAYLINE_PROJECT", "."), "analysis/E2/checks.json")
with open(SRC, encoding="utf-8") as fh:
    c = json.load(fh)

PAL = {"with": "#0072B2", "without": "#E69F00"}
LIMIT_C = "#000000"
plt.rcParams.update({"font.size": 10, "svg.hashsalt": "R7-1", "svg.fonttype": "none"})

runs = c["per_run"]
for r in runs:
    r["drop_re"] = (r["loss_pinned"] - r["loss_double"]) / r["loss_pinned"]
    assert abs(r["drop_re"] - r["drop"]) < 1e-9, r
    r["label"] = f"{r['arm']} seed {r['seed']}"

# --- Plot 1: relative drop per run vs the convergence limit --------------------------------
fig, ax = plt.subplots(figsize=(8.0, 3.6))
ys = list(range(len(runs)))[::-1]
for y, r in zip(ys, runs):
    ax.plot([r["drop"]], [y], "o", color=PAL[r["arm"]], ms=8)
ax.axvline(0, color="#56B4E9", lw=1, ls=":")
ax.axvline(c["convergence_limit"], color=LIMIT_C, lw=1.2, ls="--")
ax.axvline(-c["convergence_limit"], color=LIMIT_C, lw=1.2, ls="--")
ax.set_yticks(ys)
ax.set_yticklabels([r["label"] for r in runs])
ax.set_xlim(-0.012, 0.012)
ax.set_xlabel("relative loss drop, 30 to 60 epochs")
from matplotlib.lines import Line2D  # noqa: E402

ax.legend(handles=[Line2D([], [], marker="o", ls="", color=PAL["with"], label="with x3·x4"),
                   Line2D([], [], marker="o", ls="", color=PAL["without"], label="without x3·x4"),
                   Line2D([], [], ls="--", color=LIMIT_C, label="± convergence limit"),
                   Line2D([], [], ls=":", color="#56B4E9", label="zero (no change)")],
          loc="upper left", bbox_to_anchor=(1.01, 1.0), fontsize=8, frameon=False)
ax.grid(axis="x", color="#000000", alpha=0.15)
fig.tight_layout()
for ext in ("png", "svg"):
    fig.savefig(os.path.join(HERE, f"convergence_drop.{ext}"), dpi=150, metadata={"Date": None} if ext == "svg" else None)
plt.close(fig)

# --- Plot 2: final loss at 30 and 60 epochs, one panel per arm -----------------------------
fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.6))
markers = {1: "o", 2: "s", 3: "^"}
for ax, arm in zip(axes, ("with", "without")):
    sub = [r for r in runs if r["arm"] == arm]
    for r in sub:
        ax.plot([r["epochs_pinned"], r["epochs_double"]], [r["loss_pinned"], r["loss_double"]],
                marker=markers[r["seed"]], color=PAL[arm], lw=1.2, ms=7, label=f"seed {r['seed']}")
    lo = min(min(r["loss_pinned"], r["loss_double"]) for r in sub)
    hi = max(max(r["loss_pinned"], r["loss_double"]) for r in sub)
    pad = (hi - lo) * 0.25
    ax.set_ylim(lo - pad, hi + pad)
    ax.set_xticks([30, 60])
    ax.set_xlim(22, 68)
    ax.set_xlabel("training epochs")
    ax.set_title(f"{arm} x3·x4", fontsize=10)
    ax.legend(fontsize=8, frameon=False, loc="best")
    ax.grid(axis="y", color="#000000", alpha=0.15)
axes[0].set_ylabel("final training loss")
fig.tight_layout()
for ext in ("png", "svg"):
    fig.savefig(os.path.join(HERE, f"loss_pinned_vs_double.{ext}"), dpi=150, metadata={"Date": None} if ext == "svg" else None)
plt.close(fig)

# --- Tables ---------------------------------------------------------------------------------
with open(os.path.join(HERE, "gate_checks.csv"), "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh)
    w.writerow(["check", "observed", "limit", "passed"])
    w.writerow(["reproduction: |run_auroc_with_seed1 - b3_auroc|", c["reproduction_gap"], c["reproduction_limit"], c["reproduction_passed"]])
    w.writerow(["convergence: max relative loss drop at doubled epochs", c["convergence_drop"], c["convergence_limit"], c["convergence_passed"]])

with open(os.path.join(HERE, "per_run.csv"), "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh)
    w.writerow(["arm", "seed", "epochs_pinned", "loss_pinned", "epochs_double", "loss_double", "relative_drop"])
    for r in runs:
        w.writerow([r["arm"], r["seed"], r["epochs_pinned"], r["loss_pinned"], r["epochs_double"], r["loss_double"], r["drop"]])

# --- Numbers --------------------------------------------------------------------------------
def arm_mean(arm, key):
    v = [r[key] for r in runs if r["arm"] == arm]
    return sum(v) / len(v)


drops = [r["drop"] for r in runs]
max_abs = max(abs(d) for d in drops)
mean_with = arm_mean("with", "loss_pinned")
mean_without = arm_mean("without", "loss_pinned")
numbers = {
    "b3_auroc": c["b3_auroc"],
    "run_auroc_with_seed1": c["run_auroc_with_seed1"],
    "reproduction_gap": c["reproduction_gap"],
    "reproduction_limit": c["reproduction_limit"],
    "convergence_drop": c["convergence_drop"],
    "convergence_limit": c["convergence_limit"],
    "n_runs": len(runs),
    "n_negative_drops": sum(1 for d in drops if d < 0),
    "min_drop": min(drops),
    "max_abs_drop": max_abs,
    "max_abs_drop_share_of_limit": max_abs / c["convergence_limit"],
    "convergence_drop_share_of_limit": c["convergence_drop"] / c["convergence_limit"],
    "mean_drop": sum(drops) / len(drops),
    "epochs_pinned": runs[0]["epochs_pinned"],
    "epochs_double": runs[0]["epochs_double"],
    "mean_loss_pinned_with": mean_with,
    "mean_loss_pinned_without": mean_without,
    "mean_loss_pinned_gap_without_minus_with": mean_without - mean_with,
    "max_abs_loss_change": max(abs(r["loss_pinned"] - r["loss_double"]) for r in runs),
    "worst_loss_pinned": c["worst_run"]["loss_pinned"],
    "worst_loss_double": c["worst_run"]["loss_double"],
    "max_recompute_error": max(abs(r["drop_re"] - r["drop"]) for r in runs),
}
for r in runs:
    numbers[f"drop_{r['arm']}_seed{r['seed']}"] = r["drop"]
with open(os.path.join(HERE, "numbers.json"), "w", encoding="utf-8") as fh:
    json.dump(numbers, fh, indent=2, sort_keys=True)
print(json.dumps(numbers, indent=2, sort_keys=True))

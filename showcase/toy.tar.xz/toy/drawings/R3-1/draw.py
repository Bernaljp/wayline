"""Drawing R3-1: reads the result's one artifact, tests/test_stats_scipy.py, as text.

The artifact is a test source file, not a data file: it holds the comparisons toy.stats is held
to, their tolerances and their case counts, but no computed values. This script parses those
from the file's text with the ast module (it never imports or runs the file or toy.stats) and
writes one table, checks.csv, and numbers.json. No plot is drawn; drawing.json says why.
"""

import ast
import csv
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(os.environ.get("WAYLINE_PROJECT", "."), "tests/test_stats_scipy.py")

with open(SRC, encoding="utf-8") as fh:
    text = fh.read()
tree = ast.parse(text)
lines = text.splitlines()


def method(cls, name):
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == cls:
            for f in node.body:
                if isinstance(f, ast.FunctionDef) and f.name == name:
                    return f
    raise KeyError((cls, name))


def kw_values(fn, kw):
    out = []
    for node in ast.walk(fn):
        if isinstance(node, ast.Call):
            for k in node.keywords:
                if k.arg == kw and isinstance(k.value, ast.Constant):
                    out.append((node.lineno, k.value.value))
    return sorted(out)


def range_count(fn):
    for node in ast.walk(fn):
        if isinstance(node, ast.For) and isinstance(node.iter, ast.Call):
            c = node.iter
            if getattr(c.func, "id", None) == "range" and len(c.args) == 1:
                return c.args[0].value
    return 1


def float_consts(fn):
    return sorted({n.value for n in ast.walk(fn) if isinstance(n, ast.Constant) and isinstance(n.value, float)})


rows = []

f = method("SignedRank", "test_exact_without_ties")
places = [v for ln, v in kw_values(f, "places") if ln == 38]
rows.append(dict(finding="t5-a3-f1", quantity="exact signed-rank p (no ties)", reference="scipy.stats.wilcoxon exact",
                 cases=range_count(f), tolerance_kind="decimal places", tolerance=places[0], line="L38"))

f = method("SignedRank", "test_ties_against_exhaustive_permutation")
places = [v for ln, v in kw_values(f, "places") if ln == 43]
nres = [v for ln, v in kw_values(f, "n_resamples")]
d_node = next(n for n in ast.walk(f) if isinstance(n, ast.Assign))
d_vals = [abs(e.value if isinstance(e, ast.Constant) else e.operand.value) for e in d_node.value.elts]
n_tied = len(d_vals)
n_distinct_abs = len(set(d_vals))
rows.append(dict(finding="t5-a3-f2", quantity="exact signed-rank p (tied)", reference="scipy wilcoxon PermutationMethod",
                 cases=1, tolerance_kind="decimal places", tolerance=places[0], line="L42-L43"))

f = method("TInterval", "test_interval")
places = sorted({v for ln, v in kw_values(f, "places") if ln in (29, 30)})
assert len(places) == 1
rows.append(dict(finding="t5-a3-f3", quantity="95% t-interval bounds", reference="scipy.stats.t.interval",
                 cases=range_count(f), tolerance_kind="decimal places", tolerance=places[0], line="L29-L30"))

f = method("DeLong", "test_against_pairwise_kernel_and_mann_whitney")
atol = sorted({v for ln, v in kw_values(f, "atol") if ln in (68, 69)})
assert len(atol) == 1
rows.append(dict(finding="t5-a3-f4", quantity="DeLong AUROCs and covariance (tied)", reference="literal pairwise DeLong kernel",
                 cases=range_count(f), tolerance_kind="absolute", tolerance=atol[0], line="L68-L69"))

f = method("Spearman", "test_against_spearmanr")
places = [v for ln, v in kw_values(f, "places") if ln == 84]
loop = next(n for n in ast.walk(f) if isinstance(n, ast.For))
rows.append(dict(finding="t5-a3-f5", quantity="Spearman rho (tied integers)", reference="scipy.stats.spearmanr",
                 cases=loop.iter.args[0].value, tolerance_kind="decimal places", tolerance=places[0], line="L84"))

f = method("PairedBootstrap", "test_percentile_interval_against_scipy")
width_frac = [c for c in float_consts(f) if c == 0.05]
assert width_frac
boot_res = sorted({v for ln, v in kw_values(f, "resamples") + kw_values(f, "n_resamples")})
assert len(boot_res) == 1
rows.append(dict(finding="t5-a3-f6", quantity="paired percentile bootstrap CI, ratio of means",
                 reference="scipy.stats.bootstrap paired percentile", cases=1,
                 tolerance_kind="fraction of CI width", tolerance=width_frac[0], line="L98-L106"))

with open(os.path.join(HERE, "checks.csv"), "w", newline="", encoding="utf-8") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0]))
    w.writeheader()
    w.writerows(rows)

numbers = {
    "n_checks": len(rows),
    "total_cases": sum(r["cases"] for r in rows),
    "deterministic_checks": sum(1 for r in rows if r["tolerance_kind"] != "fraction of CI width"),
    "deterministic_cases": sum(r["cases"] for r in rows if r["tolerance_kind"] != "fraction of CI width"),
    "signed_rank_no_ties_cases": rows[0]["cases"],
    "signed_rank_no_ties_places": rows[0]["tolerance"],
    "signed_rank_tied_places": rows[1]["tolerance"],
    "signed_rank_tied_n": n_tied,
    "signed_rank_tied_distinct_abs": n_distinct_abs,
    "permutation_n_resamples": nres[0],
    "t_interval_cases": rows[2]["cases"],
    "t_interval_places": rows[2]["tolerance"],
    "delong_cases": rows[3]["cases"],
    "delong_atol": rows[3]["tolerance"],
    "spearman_cases": rows[4]["cases"],
    "spearman_places": rows[4]["tolerance"],
    "bootstrap_width_fraction": rows[5]["tolerance"],
    "bootstrap_resamples": boot_res[0],
    "max_decimal_places": max(r["tolerance"] for r in rows if r["tolerance_kind"] == "decimal places"),
    "min_decimal_places": min(r["tolerance"] for r in rows if r["tolerance_kind"] == "decimal places"),
}
with open(os.path.join(HERE, "numbers.json"), "w", encoding="utf-8") as fh:
    json.dump(numbers, fh, indent=2, sort_keys=True)
print(json.dumps(numbers, indent=2, sort_keys=True))

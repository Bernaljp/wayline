"""Drawing R2-1: R2's one artifact is a test file, so this script reads its recorded constants as text (it never
imports or runs the project's code) and writes them as one table and numbers.json. No plot: the result holds no
series, distribution, or comparison of values to draw."""

import ast
import csv
import json
import os

import matplotlib  # noqa: F401  (the drawing's library; no plot is drawn)

PROJECT = os.environ.get("WAYLINE_PROJECT", ".")
HERE = os.path.dirname(os.path.abspath(__file__))
SOURCE = "tests/test_train.py"


def constants(path):
    tree = ast.parse(open(path, encoding="utf-8").read())
    found = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            try:
                found[node.targets[0].id] = ast.literal_eval(node.value)
            except ValueError:
                pass
    return found


def main():
    found = constants(os.path.join(PROJECT, SOURCE))
    small = found["SMALL"]
    flags = {small[i].lstrip("-"): small[i + 1] for i in range(0, len(small), 2)}
    base = float(found["BASE_AUROC"])
    numbers = {
        "base_auroc": base,
        "base_auroc_rounded": round(base, 4),
        "seed": int(flags["seed"]),
        "rows": int(flags["rows"]),
        "epochs": int(flags["epochs"]),
        "device": flags["device"],
        "interaction_weight_index": 4,
    }
    with open(os.path.join(HERE, "regression_anchor.csv"), "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["finding", "quantity", "value", "source"])
        writer.writerow(["t3-a1-f1", "seed", numbers["seed"], SOURCE + "#SMALL"])
        writer.writerow(["t3-a1-f1", "rows", numbers["rows"], SOURCE + "#SMALL"])
        writer.writerow(["t3-a1-f1", "epochs", numbers["epochs"], SOURCE + "#SMALL"])
        writer.writerow(["t3-a1-f1", "device", numbers["device"], SOURCE + "#SMALL"])
        writer.writerow(["t3-a1-f1", "held-out AUROC at base commit and after change", repr(base), SOURCE + "#BASE_AUROC"])
        writer.writerow(["t3-a1-f2", "without-arm interaction weight: final equals initial", "asserted",
                         SOURCE + "#test_arms_share_initial_weights_and_without_never_moves_the_interaction_weight"])
        writer.writerow(["t3-a1-f2", "both arms: identical initial weights", "asserted",
                         SOURCE + "#test_arms_share_initial_weights_and_without_never_moves_the_interaction_weight"])
    with open(os.path.join(HERE, "numbers.json"), "w", encoding="utf-8") as handle:
        json.dump(numbers, handle, indent=2, sort_keys=True)


if __name__ == "__main__":
    main()

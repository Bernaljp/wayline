"""Drawing R11-1: E1's planted interaction, additive gap and Bayes ceiling on D2.

Reads results/E1/oracle.json and analysis/E1/summary.json (never the project's code), draws
three plots and one table, and writes every quoted number into numbers.json.
"""

import csv
import json
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.environ.get("WAYLINE_PROJECT", ".")
ORACLE = "results/E1/oracle.json"
SUMMARY = "analysis/E1/summary.json"

with open(os.path.join(ROOT, ORACLE), encoding="utf-8") as fh:
    o = json.load(fh)
with open(os.path.join(ROOT, SUMMARY), encoding="utf-8") as fh:
    s = json.load(fh)

# house palette, figures/style.json "categorical" (copied: the clean room holds only the inputs)
C = ["#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7"]
BLACK, ORANGE, SKY, GREEN, BLUE, VERM = C[0], C[1], C[2], C[3], C[5], C[6]

plt.rcParams.update({"font.size": 10, "axes.titlesize": 11, "axes.labelsize": 10,
                     "xtick.labelsize": 9, "ytick.labelsize": 9, "legend.fontsize": 9,
                     "svg.hashsalt": "R11-1", "svg.fonttype": "path"})


def save(fig, name):
    fig.tight_layout()
    fig.savefig(os.path.join(HERE, name + ".png"), dpi=150)
    fig.savefig(os.path.join(HERE, name + ".svg"), metadata={"Date": None})
    plt.close(fig)


lim = o.get("limits") or s["limits"]
goal = lim["goal"]
add_auc = o["additive_auroc"]
orc_auc = o["oracle_auroc_second_half"]
bayes = o["bayes_auroc"]
hw = o["bayes_auroc_halfwidth"]
gap = o["additive_gap"]

# ---- plot 1: AUROC ladder -------------------------------------------------------------
fig, ax = plt.subplots(figsize=(6.4, 3.0))
rows = [("additive logistic (x1..x4)", add_auc, None, BLUE),
        ("oracle, scored half", orc_auc, None, ORANGE),
        ("Bayes ceiling (full D2)", bayes, hw, BLACK)]
for i, (lab, v, e, col) in enumerate(rows):
    ax.errorbar(v, i, xerr=e, fmt="o", color=col, ms=7, capsize=4)
ax.axvline(goal, color=VERM, ls="--", lw=1.2, label=f"O2 goal {goal:.2f}")
ax.annotate("", xy=(orc_auc, 0.5), xytext=(add_auc, 0.5),
            arrowprops=dict(arrowstyle="<->", color=GREEN, lw=1.3))
ax.text(0.794, 0.62, f"gap {gap:.4f}", ha="center", color=GREEN, fontsize=9)
ax.set_yticks(range(len(rows)))
ax.set_yticklabels([r[0] for r in rows])
ax.set_ylim(-0.6, 2.6)
ax.set_xlim(0.75, 0.87)
ax.set_xlabel("held-out AUROC on D2")
ax.legend(loc="lower right", frameon=False)
save(fig, "auroc_ladder")

# ---- plot 2: additive coefficients ----------------------------------------------------
names = ["intercept", "x1", "x2", "x3", "x4"]
coefs = o["additive_coefficients"]
fig, ax = plt.subplots(figsize=(6.0, 3.8))
cols = [SKY, BLUE, BLUE, ORANGE, ORANGE]
ax.axhline(0, color=BLACK, lw=0.8)
for i, v in enumerate(coefs):
    ax.vlines(i, 0, v, color=cols[i], lw=2)
    ax.plot(i, v, "o", color=cols[i], ms=8, mec=BLACK, mew=0.6)
    ax.text(i, v + (0.12 if v >= 0 else -0.12), f"{v:.4f}" if abs(v) < 0.01 else f"{v:.2f}",
            ha="center", va="bottom" if v >= 0 else "top", fontsize=9)
ax.set_xticks(range(len(names)))
ax.set_xticklabels(names)
ax.set_xlim(-0.6, len(names) - 0.4)
ax.set_ylim(-1.45, 2.0)
ax.set_ylabel("coefficient (log-odds)")
ax.set_xlabel("term of the additive logistic model")
save(fig, "additive_coefficients")

# ---- plot 3: reliability diagram + signed residual -----------------------------------
bins = o["calibration_bins"]
mp = [b["mean_probability"] for b in bins]
ml = [b["mean_label"] for b in bins]
signed = [b["mean_label"] - b["mean_probability"] for b in bins]
fig, (a1, a2) = plt.subplots(1, 2, figsize=(9.0, 3.8))
a1.plot([0, 1], [0, 1], color=BLACK, lw=0.8, ls=":", label="perfect calibration")
a1.plot(mp, ml, "o", color=BLUE, ms=5, label="equal-count bin")
a1.set_xlabel("oracle mean predicted probability")
a1.set_ylabel("observed positive rate")
a1.set_title("Reliability, 20 bins")
a1.legend(loc="upper left", frameon=False)
idx = list(range(1, len(bins) + 1))
a2.axhline(0, color=BLACK, lw=0.8)
a2.axhspan(-lim["calibration_error"], lim["calibration_error"], color=SKY, alpha=0.25,
           label=f"±{lim['calibration_error']:.2f} limit")
a2.vlines(idx, 0, signed, color=BLUE, lw=1.4)
a2.plot(idx, signed, "o", color=BLUE, ms=5, label="observed − predicted")
worst = max(range(len(bins)), key=lambda i: abs(signed[i]))
a2.plot(idx[worst], signed[worst], "o", color=VERM, ms=7, label="largest gap")
a2.set_xticks([1, 5, 10, 15, 20])
a2.set_xlabel("bin (by predicted probability)")
a2.set_ylabel("observed − predicted")
a2.set_title("Signed calibration residual")
a2.set_ylim(-0.0125, 0.0125)
a2.legend(loc="lower left", frameon=False, ncol=1)
save(fig, "calibration")

# ---- table: criteria ------------------------------------------------------------------
crit = [
    dict(criterion="C1", quantity="interaction_weight", value=o["interaction_weight"], limit="!= 0",
         passes=o["interaction_weight"] != 0),
    dict(criterion="C1", quantity="additive_gap", value=round(gap, 4), limit=f"> {lim['additive_gap']}",
         passes=gap > lim["additive_gap"]),
    dict(criterion="C1, C2", quantity="calibration_error", value=round(o["calibration_error"], 4),
         limit=f"<= {lim['calibration_error']}", passes=o["calibration_error"] <= lim["calibration_error"]),
    dict(criterion="C2", quantity="bayes_auroc_halfwidth", value=round(hw, 5),
         limit=f"<= {lim['bayes_auroc_halfwidth']}", passes=hw <= lim["bayes_auroc_halfwidth"]),
    dict(criterion="A6", quantity="bayes_auroc - goal", value=round(bayes - goal, 4), limit="< 0 for A6",
         passes=(bayes - goal) < 0),
]
with open(os.path.join(HERE, "criteria.csv"), "w", newline="", encoding="utf-8") as fh:
    w = csv.DictWriter(fh, fieldnames=list(crit[0]))
    w.writeheader()
    w.writerows(crit)

numbers = {
    "additive_auroc": round(add_auc, 4),
    "oracle_auroc_second_half": round(orc_auc, 4),
    "bayes_auroc": round(bayes, 4),
    "bayes_ci_low": round(bayes - hw, 4),
    "bayes_ci_high": round(bayes + hw, 4),
    "bayes_auroc_halfwidth": round(hw, 5),
    "halfwidth_limit": lim["bayes_auroc_halfwidth"],
    "additive_gap": round(gap, 4),
    "additive_gap_limit": lim["additive_gap"],
    "gap_over_limit_ratio": round(gap / lim["additive_gap"], 1),
    "goal": goal,
    "ceiling_minus_goal": round(bayes - goal, 4),
    "goal_minus_additive": round(goal - add_auc, 4),
    "oracle_minus_bayes": round(orc_auc - bayes, 4),
    "share_of_ceiling_gap_closed_by_goal": round((goal - add_auc) / (bayes - add_auc), 2),
    "coef_intercept": round(coefs[0], 4),
    "coef_x1": round(coefs[1], 2),
    "coef_x2": round(coefs[2], 2),
    "coef_x3": round(coefs[3], 4),
    "coef_x4": round(coefs[4], 4),
    "coef_ratio_x1_x2": round(coefs[1] / coefs[2], 2),
    "generator_ratio_x1_x2": round(o["linear_weights"][0] / o["linear_weights"][1], 2),
    "interaction_weight": o["interaction_weight"],
    "calibration_error": round(o["calibration_error"], 4),
    "calibration_limit": lim["calibration_error"],
    "calibration_worst_bin": worst + 1,
    "calibration_bin_count": len(bins),
    "calibration_rows_per_bin": bins[0]["rows"],
    "calibration_median_abs_gap": round((sorted(abs(x) for x in signed)[len(signed) // 2 - 1]
                                         + sorted(abs(x) for x in signed)[len(signed) // 2]) / 2, 4),
    "calibration_bins_above_zero": sum(1 for x in signed if x > 0),
    "lowest_bin_probability": round(mp[0], 3),
    "highest_bin_probability": round(mp[-1], 3),
    "rows": o["rows"],
    "seed": o["seed"],
    "strength": o["strength"],
    "signal": o["signal"],
    "fit_rows": o["additive_fit_rows"],
    "scored_rows": o["additive_scored_rows"],
}
with open(os.path.join(HERE, "numbers.json"), "w", encoding="utf-8") as fh:
    json.dump(numbers, fh, indent=2, sort_keys=True)
print(json.dumps(numbers, indent=2, sort_keys=True))

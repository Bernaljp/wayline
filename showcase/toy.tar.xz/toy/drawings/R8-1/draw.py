"""Drawing R8-1: toy.paired's statistics of one sweep point against the oracle ceiling.

Reads the one manifested output of toy.paired at a real sweep point, analysis/E2/paired.json
(strength 1, 20 paired seeds), and redraws its per-seed records; the project's code is never run.
"""

import csv
import json
import math
import os

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

PROJECT = os.environ.get("WAYLINE_PROJECT", ".")
HERE = os.path.dirname(os.path.abspath(__file__))
INPUT = "analysis/E2/paired.json"

# The house palette, figures/style.json "categorical" (copied: the clean room holds only the manifested inputs).
PAL = ["#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7"]
C_WITHOUT, C_WITH, C_ORACLE, C_RED = PAL[1], PAL[5], PAL[0], PAL[6]
GREY = "#808080"

plt.rcParams.update({"font.size": 10, "axes.titlesize": 11, "axes.labelsize": 10, "xtick.labelsize": 9,
                     "ytick.labelsize": 9.5, "legend.fontsize": 9, "legend.frameon": False, "svg.fonttype": "none",
                     "font.family": "DejaVu Sans", "axes.spines.top": False, "axes.spines.right": False,
                     "svg.hashsalt": "R8-1", "path.simplify": False})

# Outputs of an earlier draft that this script no longer draws.
for stale in ("roc_per_seed.png", "roc_per_seed.svg", "refusal_cases.csv", "shortfall_by_arm.png",
              "shortfall_by_arm.svg"):
    if os.path.exists(os.path.join(HERE, stale)):
        os.remove(os.path.join(HERE, stale))

point = json.load(open(os.path.join(PROJECT, INPUT), encoding="utf-8"))
recs = sorted(point["per_seed"], key=lambda r: r["seed"])
SEEDS = [r["seed"] for r in recs]
N = len(recs)
w = np.array([r["auroc_with"] for r in recs])
o = np.array([r["auroc_without"] for r in recs])
b = np.array([r["bayes_auroc"] for r in recs])
d = w - o
g = b - o
z = np.array([r["delong_z"] for r in recs])
pvals = np.array([r["delong_p"] for r in recs])
shortfall = b - w


def gap_closed_of(dd, gg):
    """Ratio of the mean gain to the mean gap the without arm left."""
    return float(np.mean(dd) / np.mean(gg))


def bootstrap_ratio(dd, gg, draws, seed):
    """Paired bootstrap: resample seeds with replacement, keep each seed's (d, gap) together."""
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(dd), size=(draws, len(dd)))
    return dd[idx].mean(axis=1) / gg[idx].mean(axis=1)


BOOT_DRAWS, BOOT_SEED = 10000, 20261025
boot = bootstrap_ratio(d, g, BOOT_DRAWS, BOOT_SEED)
boot_lo, boot_hi = float(np.percentile(boot, 2.5)), float(np.percentile(boot, 97.5))

gain = float(d.mean())
sd_d = float(d.std(ddof=1))
half = (point["paired_gain_hi"] - point["paired_gain_lo"]) / 2
gc = gap_closed_of(d, g)
tol = 1e-9
matches = (abs(gain - point["paired_gain"]) < tol and abs(sd_d - point["sd_d"]) < tol
           and abs(gc - point["gap_closed"]) < tol and abs(float(w.mean()) - point["mean_auroc_with"]) < tol
           and abs(float(o.mean()) - point["mean_auroc_without"]) < tol
           and abs(float(b.mean()) - point["mean_bayes_auroc"]) < tol)

numbers = {
    "n_pairs": N, "seed_first": SEEDS[0], "seed_last": SEEDS[-1],
    "strength": point["strength"], "signal": point["signal"], "rows": point["rows"],
    "train_rows": point["train_rows"], "heldout_rows": recs[0]["heldout_rows"],
    "mean_auroc_with": float(w.mean()), "mean_auroc_without": float(o.mean()), "mean_bayes_auroc": float(b.mean()),
    "paired_gain": gain, "sd_d": sd_d, "paired_gain_lo": point["paired_gain_lo"], "paired_gain_hi": point["paired_gain_hi"],
    "t_half_width": half, "t_critical_implied": half * math.sqrt(N) / sd_d, "ci_level_percent": 95,
    "d_min": float(d.min()), "d_max": float(d.max()), "seeds_with_positive_d": int((d > 0).sum()),
    "gap_denominator": float(g.mean()), "gap_closed": gc,
    "gap_closed_lo_reported": point["gap_closed_lo"], "gap_closed_hi_reported": point["gap_closed_hi"],
    "bootstrap_draws": BOOT_DRAWS, "bootstrap_seed": BOOT_SEED,
    "bootstrap_q_lo_percent": 2.5, "bootstrap_q_hi_percent": 97.5,
    "gap_closed_lo_redrawn": boot_lo, "gap_closed_hi_redrawn": boot_hi,
    "bootstrap_ci_max_endpoint_diff": max(abs(boot_lo - point["gap_closed_lo"]), abs(boot_hi - point["gap_closed_hi"])),
    "ratio_min": float((d / g).min()), "ratio_max": float((d / g).max()),
    "shortfall_with_mean": float(shortfall.mean()), "shortfall_with_min": float(shortfall.min()),
    "shortfall_with_max": float(shortfall.max()), "seeds_with_above_ceiling": int((shortfall < 0).sum()),
    "shortfall_without_mean": float(g.mean()),
    "delong_z_min": float(z.min()), "delong_z_max": float(z.max()), "delong_p_max": float(pvals.max()),
    "delong_rejections": int((pvals < 0.05).sum()), "delong_rejections_reported": point["delong_rejections"],
    "delong_alpha": 0.05, "z_crit": 1.959963984540054,
    "signed_rank_p": point["signed_rank_p"],
    "recomputed_matches_file": bool(matches),
}


def save(fig, name):
    fig.savefig(os.path.join(HERE, name + ".png"), dpi=200, bbox_inches="tight", metadata={"Software": None})
    fig.savefig(os.path.join(HERE, name + ".svg"), bbox_inches="tight", metadata={"Date": None, "Creator": None})
    plt.close(fig)


xs = np.arange(N)

# 1. Each seed's two arms against its Bayes ceiling.
fig, ax = plt.subplots(figsize=(8.4, 3.8))
for x in xs:
    ax.plot([x, x], [o[x], w[x]], color=GREY, lw=1.2, zorder=1)
    ax.plot([x - 0.35, x + 0.35], [b[x]] * 2, color=C_ORACLE, lw=1.6, zorder=2)
ax.scatter(xs, o, color=C_WITHOUT, s=30, marker="o", label="without the interaction column", zorder=3)
ax.scatter(xs, w, color=C_WITH, s=30, marker="s", label="with the interaction column", zorder=3)
ax.plot([], [], color=C_ORACLE, lw=1.6, label="Bayes ceiling (oracle)")
ax.set_xticks(xs, [str(s) for s in SEEDS])
ax.set_xlabel("seed")
ax.set_ylabel("held-out AUROC")
ax.set_title("Each seed's arms and its Bayes ceiling")
ax.legend(loc="upper left", bbox_to_anchor=(0, -0.18), ncol=3)
save(fig, "arms_per_seed")

# 2. Paired differences with the mean and its t-interval.
fig, ax = plt.subplots(figsize=(6.0, 2.8))
jit = np.random.default_rng(1).uniform(-0.12, 0.12, N)
ax.scatter(d, 1 + jit, color=C_WITH, s=28, zorder=3, label="d = with − without, one seed")
ax.errorbar([gain], [0], xerr=[[gain - point["paired_gain_lo"]], [point["paired_gain_hi"] - gain]], fmt="D",
            color=C_RED, ms=7, capsize=5, lw=2, label="mean gain, 95% t-interval (toy.paired)")
ax.set_yticks([1, 0], ["seeds", "mean"])
ax.set_ylim(-0.6, 1.6)
ax.set_xlabel("AUROC difference (with − without)")
ax.set_title("Paired differences over the seeds")
ax.legend(loc="upper left", bbox_to_anchor=(0, -0.3), ncol=1)
save(fig, "paired_differences")

# 3. Gain against the gap it could close.
fig, ax = plt.subplots(figsize=(5.4, 4.2))
lo_ax, hi_ax = min(g.min(), d.min()) * 0.97, max(g.max(), d.max()) * 1.02
ax.plot([lo_ax, hi_ax], [lo_ax, hi_ax], color=GREY, lw=1, ls=":", label="d = gap (gap fully closed)")
ax.plot([lo_ax, hi_ax], [gc * lo_ax, gc * hi_ax], color=C_RED, lw=1.6, label="slope = gap_closed (ratio of means)")
ax.scatter(g, d, color=C_WITH, s=30, zorder=3, label="one seed")
ax.set_xlim(lo_ax, hi_ax)
ax.set_ylim(lo_ax, hi_ax)
ax.set_aspect("equal")
ax.set_xlabel("gap left: Bayes − without")
ax.set_ylabel("gain d: with − without")
ax.set_title("Gain against the gap it could close")
ax.legend(loc="upper left")
save(fig, "gain_vs_gap")

# 5. Bootstrap distribution of gap_closed.
fig, ax = plt.subplots(figsize=(6.0, 3.4))
ax.hist(boot, bins=40, color=C_WITH, edgecolor="#FFFFFF", lw=0.4, label="bootstrap ratios (redrawn)")
ax.axvline(gc, color=C_RED, lw=2, label="gap_closed")
ax.axvline(boot_lo, color=C_ORACLE, lw=1.5, ls="--", label="2.5% and 97.5% quantiles (redrawn)")
ax.axvline(boot_hi, color=C_ORACLE, lw=1.5, ls="--")
ax.axvline(point["gap_closed_lo"], color=C_WITHOUT, lw=1.5, ls=":", label="CI toy.paired reported")
ax.axvline(point["gap_closed_hi"], color=C_WITHOUT, lw=1.5, ls=":")
ax.set_xlabel("ratio of mean gain to mean gap")
ax.set_ylabel("resamples")
ax.set_title("Paired-bootstrap distribution of gap_closed")
ax.legend(loc="upper left", bbox_to_anchor=(0, -0.2), ncol=2)
save(fig, "bootstrap_gap_closed")

# 6. Per-seed DeLong z.
fig, ax = plt.subplots(figsize=(6.0, 2.6))
ax.axvline(numbers["z_crit"], color=GREY, lw=1, ls="--", label="z = 1.96 (two-sided 0.05)")
ax.scatter(z, jit, color=C_WITH, s=28, zorder=3, label="DeLong z, one seed")
ax.set_yticks([])
ax.spines["left"].set_visible(False)
ax.set_ylim(-0.6, 0.6)
ax.set_xlim(0, z.max() * 1.08)
ax.set_xlabel("DeLong z of the paired AUROC difference")
ax.set_title("Per-seed DeLong tests")
ax.legend(loc="upper left", bbox_to_anchor=(0, -0.35), ncol=2)
save(fig, "delong_z")

with open(os.path.join(HERE, "per_seed.csv"), "w", newline="", encoding="utf-8") as fh:
    wr = csv.writer(fh)
    wr.writerow(["seed", "auroc_without", "auroc_with", "bayes_auroc", "d", "gap_without", "shortfall_with",
                 "ratio_d_over_gap", "delong_z", "delong_p"])
    for i, r in enumerate(recs):
        wr.writerow([r["seed"], "%.6f" % o[i], "%.6f" % w[i], "%.6f" % b[i], "%.6f" % d[i], "%.6f" % g[i],
                     "%.6f" % shortfall[i], "%.6f" % (d[i] / g[i]), "%.4f" % z[i], "%.3e" % pvals[i]])

with open(os.path.join(HERE, "numbers.json"), "w", encoding="utf-8") as fh:
    json.dump(numbers, fh, indent=2, sort_keys=True)

# paper-r7-supplement: notes

## Generator

`figures/paper-r7-supplement/paper-r7-supplement.py`, run from the project root as
`python3 figures/paper-r7-supplement/paper-r7-supplement.py`. It reads only
`analysis/E2/checks.json` (run t104-a2) and `figures/style.json`, resolving each from the cwd,
the project root, or beside the script, and writes the PDF, the PNG (400 dpi), and the SVG beside
itself. Nothing is random. `pdf.fonttype` is 42, `svg.fonttype` is `none`, `svg.hashsalt` is
fixed, and the date metadata is removed so reruns produce the same output.

The page is 180 x 66 mm (no `bbox_inches="tight"`, so the width is exact). Base text is 7 pt,
ticks 6 pt, and value labels and reference-line labels 5.5 pt, the smallest text in the figure.

## Register

Quantitative result figure. Plot R7.1 is panel (a). Plot R7.2 is panel (b), which has two axes
(one per arm). Both of the panel (b) axes carry `panel:b` and `plot:R7.2`, and the axes of panel
(a) carries `panel:a` and `plot:R7.1`. Both panels are finished from `drawings/R7-1/draw.py` and
redrawn from the data. No images are pasted in.

## Load-bearing choices, with measurements

- **The drop is recomputed and asserted.** The generator recomputes (loss_pinned − loss_double) /
  loss_pinned for every run and asserts that it matches the stored `drop` to 1e-9. It also asserts
  that the largest drop equals `convergence_drop` (0.0034411).
- **The gate is one-sided.** The gate tests only the largest drop against +0.01. The +0.01 line is
  black dashed and labeled "gate limit". The −0.01 line is lighter gray, labeled "mirror", and
  the caption says it is drawn for scale only. The drawing had drawn the two lines identically.
- **The x-range of (a) is fixed** at ±0.013, so both limit lines show. The largest drop, 0.0034,
  is 0.34 of the limit. The most negative drop is −0.0024. The mean drop is 0.00025, and 3 of 6
  drops are negative.
- **The y-span is shared in (b).** The drawing scaled each arm's axis to its own runs, so a slope
  meant different changes in the two axes. Here both axes span 1.3 x the larger arm range: the
  without arm's range is 0.008732 and the with arm's is 0.005356, so the span is 0.01135. Each
  axis is centered on its own runs. Slopes are therefore comparable across arms, and the levels
  are read from the ticks (with 0.4744, without 0.5765, mean at 30 epochs, gap 0.1021).
- **Within-arm seed spread is larger than any change.** The largest absolute change is 0.00164
  (with, seed 2: 0.4777 to 0.4761). At 30 epochs the seed spread is 0.00536 (with) and 0.00873
  (without).
- **The overlap at 60 epochs is a fact of the data.** Without-arm seeds 1 and 3 end at 0.574361
  and 0.574349 (difference 1.3e-5), so their markers overlap. They are not jittered, and the
  caption says so.
- **Color.** The arm colors are house categorical colors, #0072B2 (with) and #E69F00 (without),
  and they are the same in both panels. Seed is shown by marker shape, never by color. Reference
  lines, the stems, the grid, and the seed legend are black or gray. The drawing's light-blue
  zero line spent a data color on structure, so it is now a gray dotted line.
- **No subset.** All 6 reruns are shown, so there is no selection statistic.
- **One dataset.** Both panels draw the same file, so there is no mixed-data disclosure.

## Schematic elements

None.

## Traps hit

- Matplotlib tick labels use the Unicode minus (U+2212), but f-string value labels produce an
  ASCII hyphen, which mixed two minus glyphs in panel (a). The value labels now replace "-" with
  U+2212.
- The drawing's x label for (a), "relative drop in final training loss, 30 to 60 epochs"
  (53 characters), failed the 40-character axis-label check. It is now "relative loss drop, 30
  to 60 epochs" (34 characters), and the caption defines the drop in full.
- The first composition clipped the long row labels of (a) and the "(a)" tag at the left edge,
  and the seed legend overlapped the seed-2 line in (b). The fix was a wider left margin and
  moving the legend to the empty center-right area.

Pitfalls read: the plot index lists no `index_entries` for R7.1 or R7.2, so there were no
pitfalls to read.

## Not drawn

The reproduction check (gap 0.0 against 0.002) is in the gate table (R7.T1), not in this figure:
two identical AUROCs would collapse to one mark.

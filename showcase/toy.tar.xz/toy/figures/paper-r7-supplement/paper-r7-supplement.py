"""Figure paper-r7-supplement: the E2 convergence gate, from analysis/E2/checks.json only.

Panel (a), plot R7.1: relative drop in final training loss from 30 to 60 epochs, one row per
rerun, against the gate's convergence limit. Panel (b), plot R7.2: the final training losses
behind those drops, 30 and 60 epochs joined per rerun, one axes per arm.

Finished from drawings/R7-1/draw.py. Nothing random. Run from the project root:
    python3 figures/paper-r7-supplement/paper-r7-supplement.py
"""

import json
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402
from matplotlib.ticker import FormatStrFormatter, MultipleLocator  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
FIG_ID = "paper-r7-supplement"


def find(rel):
    """Resolve a project-relative path from the cwd, the project root, or beside this file."""
    for cand in (rel, os.path.join(HERE, "..", "..", rel), os.path.join(HERE, os.path.basename(rel))):
        if os.path.exists(cand):
            return cand
    raise FileNotFoundError(rel)


with open(find("analysis/E2/checks.json"), encoding="utf-8") as fh:
    c = json.load(fh)
with open(find("figures/style.json"), encoding="utf-8") as fh:
    style = json.load(fh)

# House palette: the two arms are categorical colors from the budget; structure is grey.
CAT = style["categorical"]
ARM_C = {"with": CAT[5], "without": CAT[1]}  # #0072B2, #E69F00
ARM_LABEL = {"with": "with x3·x4", "without": "without x3·x4"}
SEED_M = {1: "o", 2: "s", 3: "^"}
INK = "#000000"
GREY = "#7F7F7F"
GRID = "#D9D9D9"

MM = 1 / 25.4
W_MM, H_MM = 180.0, 66.0

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 7.0,
    "axes.titlesize": 7.0,
    "axes.labelsize": 7.0,
    "xtick.labelsize": 6.0,
    "ytick.labelsize": 6.0,
    "legend.fontsize": 6.0,
    "axes.linewidth": 0.6,
    "xtick.major.width": 0.6,
    "ytick.major.width": 0.6,
    "xtick.major.size": 2.5,
    "ytick.major.size": 2.5,
    "axes.edgecolor": INK,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
    "svg.hashsalt": FIG_ID,
})

runs = c["per_run"]
for r in runs:
    # The drop the gate tests: (loss_pinned - loss_double) / loss_pinned, recomputed and checked.
    r["drop_re"] = (r["loss_pinned"] - r["loss_double"]) / r["loss_pinned"]
    assert abs(r["drop_re"] - r["drop"]) < 1e-9, r
assert abs(max(r["drop"] for r in runs) - c["convergence_drop"]) < 1e-12
LIMIT = c["convergence_limit"]

fig = plt.figure(figsize=(W_MM * MM, H_MM * MM))
gs = fig.add_gridspec(1, 3, width_ratios=[1.35, 1.0, 1.0], wspace=0.40,
                      left=0.175, right=0.985, bottom=0.17, top=0.88)

# ---------------------------------------------------------------- panel (a): R7.1 dot plot
ax = fig.add_subplot(gs[0, 0])
ax.set_gid("panel:a")
ax.patch.set_gid("plot:R7.1")
ys = list(range(len(runs)))[::-1]
ax.axvline(0, color=GREY, lw=0.6, ls=":", zorder=1)
# +limit is what the gate tests; -limit is a mirror drawn for scale only, so it is lighter.
ax.axvline(LIMIT, color=INK, lw=0.8, ls="--", zorder=1)
ax.axvline(-LIMIT, color=GREY, lw=0.6, ls="--", zorder=1)
for y, r in zip(ys, runs):
    ax.plot([0, r["drop"]], [y, y], color=GRID, lw=0.6, zorder=2)
    ax.plot([r["drop"]], [y], marker=SEED_M[r["seed"]], ls="", color=ARM_C[r["arm"]],
            ms=4.5, mec=INK, mew=0.3, zorder=3)
    off = 0.0006 if r["drop"] >= 0 else -0.0006
    ax.text(r["drop"] + off, y, f"{r['drop']:+.4f}".replace("-", "−"),ha="left" if off > 0 else "right",
            va="center", fontsize=5.5, color=INK)
ax.set_yticks(ys)
ax.set_yticklabels([f"{ARM_LABEL[r['arm']]}, seed {r['seed']}" for r in runs])
ax.set_ylim(-0.7, len(runs) - 0.3)
ax.set_xlim(-0.013, 0.013)
ax.set_xticks([-0.01, -0.005, 0, 0.005, 0.01])
ax.set_xticklabels(["−0.01", "−0.005", "0", "0.005", "0.01"])
ax.set_xlabel("relative loss drop, 30 to 60 epochs")
ax.text(LIMIT, len(runs) - 0.3, "gate limit", ha="center", va="bottom", fontsize=5.5, color=INK)
ax.text(-LIMIT, len(runs) - 0.3, "mirror", ha="center", va="bottom", fontsize=5.5, color=GREY)
ax.text(0.0005, -0.62, "loss fell →", ha="left", va="bottom", fontsize=5.5, color=GREY)
ax.text(-0.0005, -0.62, "← loss rose", ha="right",va="bottom", fontsize=5.5, color=GREY)
for s in ("top", "right"):
    ax.spines[s].set_visible(False)
ax.text(-0.66, 1.07, "(a)", transform=ax.transAxes, fontsize=8, fontweight="bold", va="bottom")

# ---------------------------------------------------------------- panel (b): R7.2 slope chart
# Both arms' axes span the same loss range, so a slope means the same change in both; the
# levels differ (each axis is offset to its own runs) and are read from the tick values.
ranges = {}
for arm in ("with", "without"):
    sub = [r for r in runs if r["arm"] == arm]
    vals = [v for r in sub for v in (r["loss_pinned"], r["loss_double"])]
    ranges[arm] = (min(vals), max(vals))
span = max(hi - lo for lo, hi in ranges.values()) * 1.3

axes_b = []
for k, arm in enumerate(("with", "without")):
    axb = fig.add_subplot(gs[0, 1 + k])
    axb.set_gid("panel:b")
    axb.patch.set_gid("plot:R7.2")
    axes_b.append(axb)
    sub = [r for r in runs if r["arm"] == arm]
    for r in sub:
        axb.plot([r["epochs_pinned"], r["epochs_double"]], [r["loss_pinned"], r["loss_double"]],
                 color=ARM_C[arm], lw=0.9, marker=SEED_M[r["seed"]], ms=4.0, mec=INK,
                 mew=0.3, zorder=3)
    lo, hi = ranges[arm]
    mid = (lo + hi) / 2
    axb.set_ylim(mid - span / 2, mid + span / 2)
    axb.set_xlim(22, 68)
    axb.set_xticks([30, 60])
    axb.set_xlabel("training epochs")
    axb.set_title(ARM_LABEL[arm], color=INK, pad=3)
    axb.yaxis.set_major_formatter(FormatStrFormatter("%.3f"))
    axb.yaxis.set_major_locator(MultipleLocator(0.002))
    axb.grid(axis="y", color=GRID, lw=0.5, zorder=0)
    for s in ("top", "right"):
        axb.spines[s].set_visible(False)
axes_b[0].set_ylabel("final training loss")
axes_b[0].text(-0.42, 1.07, "(b)", transform=axes_b[0].transAxes, fontsize=8,
               fontweight="bold", va="bottom")
axes_b[1].legend(handles=[Line2D([], [], marker=SEED_M[s], ls="", color=GREY, mec=INK, mew=0.3,
                                 ms=4.0, label=f"seed {s}") for s in (1, 2, 3)],
                 loc="center right", frameon=False, handletextpad=0.2, borderaxespad=0.2)

out = os.path.join(HERE, FIG_ID)
fig.savefig(out + ".pdf", metadata={"CreationDate": None, "ModDate": None})
fig.savefig(out + ".png", dpi=400)
fig.savefig(out + ".svg", metadata={"Date": None})
plt.close(fig)

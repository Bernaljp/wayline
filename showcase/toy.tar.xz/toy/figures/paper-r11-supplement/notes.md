# paper-r11-supplement: notes

- **Generator.** `figures/paper-r11-supplement/paper-r11-supplement.py`, run from the project root
  as `python3 figures/paper-r11-supplement/paper-r11-supplement.py`. It reads
  `results/E1/oracle.json`, `analysis/E1/summary.json`, and `figures/style.json`, resolving each
  from the cwd, the project root, or beside itself, so it also runs in a clean room. Nothing is
  random. It writes the PDF, PNG (400 dpi), and SVG beside itself. Matplotlib 3.6.3, DejaVu Sans,
  `pdf.fonttype` 42 (the PDF embeds CID TrueType fonts, no Type 3), `svg.fonttype` none, fixed
  `svg.hashsalt`.
- **Target.** 180 x 118 mm (MediaBox 510.24 x 334.49 pt), below the 170 mm limit. Text is 5.5 to
  8 pt, so nothing is under 5.0 pt.
- **Register.** Quantitative result figure. Tick values and value labels are kept.
- **Composition.** All three planned plots are in one figure. (a) R11.1 is the top left, (b) R11.2
  the top right, and (c) R11.3 the bottom row as two axes, reliability and signed residual. Each
  axes has the gid `panel:<letter>`, and its background patch has `plot:R11.1`, `plot:R11.2`, or
  `plot:R11.3`. Each panel is redrawn from `drawings/R11-1/draw.py` and the data, not pasted in.
- **Pitfalls read.** The plot index listed no pitfall entries for these candidates
  (`index_entries` is empty in `drawings/R11-1/drawing.json`), so there were none to read.

## Data per panel

- (a) reads `analysis/E1/summary.json` only: the three AUROCs, the CI bounds `bayes_auroc_ci95`,
  the additive gap, and the goal from `limits`.
- (b) reads `results/E1/oracle.json` only: `additive_coefficients` and `linear_weights` (for the
  ratio label).
- (c) reads `results/E1/oracle.json` (`calibration_bins`) and `analysis/E1/summary.json`
  (`limits.calibration_error`), so it is mixed data. The caption says so in its header and
  carries the `[[mixed-data]]` marker on the (c) entry.
- The generator asserts that the two files agree on every shared value: the three AUROCs, the
  gap, the calibration error, and the coefficients.

## Load-bearing choices and measurements

- (a) **The gap arrow runs from the additive model to the oracle on the scored half (0.0882), not
  to the Bayes ceiling.** That is how `additive_gap` is defined, and the generator rechecks it
  (oracle minus additive, within 1e-12). Measured to the ceiling, the distance is 0.0874; the
  caption gives both. The claim's wording ("0.0882 AUROC below a ... Bayes ceiling of 0.8555")
  conflates the two, and this is returned as a finding for the text.
- (a) The ceiling's 95% interval (half-width 0.00072) is drawn, although it is narrower than the
  marker, so the figure does not hide it. It is labeled numerically.
- (a) The oracle's scored-half AUROC, 0.85629, lies 0.00008 above the ceiling's upper bound,
  0.85620. The figure shows both as they are, and the caption names it.
- (a) Goal to additive model: 0.0519. Ceiling to goal: 0.0355. The goal sits at 0.594 of the
  distance from the additive model to the ceiling.
- (b) No generator weights are plotted beside the fitted coefficients. The generator's latent
  scale (signal 4.0, noise sd 1.0) is not the logistic model's log-odds scale, so putting them on
  one axis would be a false comparison. Only the scale-free ratio x1/x2 is shown: fitted -1.503
  against generator -1.500.
- (c) All 20 bins are shown, so there is no selection. Signed residual = mean_label minus
  mean_probability. The generator asserts that its absolute value equals each bin's `gap`, and
  that the largest equals `calibration_error` (0.0039, bin 13). Ten of the 20 residuals are
  positive. The median absolute residual is 0.00087. The largest is 0.39 of the 0.01 limit.
- **Color.** All colors come from the house categorical palette: blue `#0072B2`, orange
  `#E69F00`, sky `#56B4E9`, green `#009E73`, vermilion `#D55E00`, and black. Grey is structure
  only (gridlines, the diagonal, the limit lines, annotations). There is no colormapped artist,
  so there is no ramp. The worst bin is vermilion in both plots of (c).
- **Equations.** None are typeset.

## Schematic elements

None. Every mark is plotted from the data.

## Traps hit

- The mixed-data check looks for the literal `[[mixed-data]]` marker in the caption. A sentence
  that names both files is not enough.

- The drawing's ceiling label, placed on one line, ran across the dashed goal line in (a). It is
  now split: the point estimate goes above the dot, and the CI goes below it, right-aligned inside
  the axes.
- At 180 mm, the drawing's long row labels in (a) were clipped at the left edge. They are
  shortened ("additive logistic", "oracle, scored half", "Bayes ceiling, all D2"), and the caption
  carries the full description.

"""Figure paper-r11-supplement: E1's planted x3*x4 interaction on D2, additive gap and ceiling.

Panel (a), plot R11.1: AUROC of the additive model, the oracle on the scored half, and the Bayes
ceiling with its 95% interval, against the goal. Drawn from analysis/E1/summary.json only.
Panel (b), plot R11.2: the additive logistic model's five fitted coefficients. Drawn from
results/E1/oracle.json only.
Panel (c), plot R11.3: the oracle's reliability in 20 equal-count bins and the signed residual
per bin against the calibration limit. Bins from results/E1/oracle.json, the limit from
analysis/E1/summary.json (two data files, disclosed in the caption).

Finished from drawings/R11-1/draw.py. Nothing random. Run from the project root:
    python3 figures/paper-r11-supplement/paper-r11-supplement.py
"""

import json
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.ticker import MultipleLocator  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
FIG_ID = "paper-r11-supplement"


def find(rel):
    """Resolve a project-relative path from the cwd, the project root, or beside this file."""
    for cand in (rel, os.path.join(HERE, "..", "..", rel), os.path.join(HERE, os.path.basename(rel))):
        if os.path.exists(cand):
            return cand
    raise FileNotFoundError(rel)


with open(find("results/E1/oracle.json"), encoding="utf-8") as fh:
    o = json.load(fh)
with open(find("analysis/E1/summary.json"), encoding="utf-8") as fh:
    s = json.load(fh)
with open(find("figures/style.json"), encoding="utf-8") as fh:
    style = json.load(fh)

# The summary restates the oracle's numbers; check they agree before drawing either.
for key in ("additive_auroc", "oracle_auroc_second_half", "bayes_auroc", "additive_gap",
            "calibration_error", "additive_coefficients"):
    assert o[key] == s[key], key

# House palette (figures/style.json "categorical"); structure is black or grey.
CAT = style["categorical"]
INK, ORANGE, SKY, GREEN, BLUE, VERM = CAT[0], CAT[1], CAT[2], CAT[3], CAT[5], CAT[6]
GREY = "#7F7F7F"
GRID = "#D9D9D9"

MM = 1 / 25.4
W_MM, H_MM = 180.0, 118.0

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 7.0,
    "axes.titlesize": 7.0,
    "axes.labelsize": 7.0,
    "xtick.labelsize": 6.0,
    "ytick.labelsize": 6.0,
    "legend.fontsize": 6.0,
    "axes.linewidth": 0.6,
    "xtick.major.width": 0.6,
    "ytick.major.width": 0.6,
    "xtick.major.size": 2.5,
    "ytick.major.size": 2.5,
    "axes.edgecolor": INK,
    "axes.unicode_minus": True,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
    "svg.hashsalt": FIG_ID,
})


def num(v, fmt):
    """Format a number with a true minus sign, as the tick labels have."""
    return format(v, fmt).replace("-", "−")


def tidy(ax):
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)


def letter(ax, text, x):
    ax.text(x, 1.04, text, transform=ax.transAxes, fontsize=8, fontweight="bold", va="bottom")


fig = plt.figure(figsize=(W_MM * MM, H_MM * MM))
outer = fig.add_gridspec(2, 1, height_ratios=[1.0, 1.0], hspace=0.42,
                         left=0.15, right=0.985, bottom=0.085, top=0.95)
top = outer[0].subgridspec(1, 2, width_ratios=[1.55, 1.0], wspace=0.30)
bot = outer[1].subgridspec(1, 2, width_ratios=[1.0, 1.75], wspace=0.30)

# ---------------------------------------------------------------- panel (a): R11.1 AUROC ladder
lim = s["limits"]
goal = lim["goal"]
add_auc = s["additive_auroc"]
orc_auc = s["oracle_auroc_second_half"]
bayes = s["bayes_auroc"]
ci_lo, ci_hi = s["bayes_auroc_ci95"]
gap = s["additive_gap"]
# The gap the criterion tests is oracle minus additive on the scored half, recomputed here.
assert abs((orc_auc - add_auc) - gap) < 1e-12

ax = fig.add_subplot(top[0, 0])
ax.set_gid("panel:a")
ax.patch.set_gid("plot:R11.1")
rows = [("additive logistic", add_auc, BLUE),
        ("oracle, scored half", orc_auc, ORANGE),
        ("Bayes ceiling, all D2", bayes, INK)]
for i, (_, v, col) in enumerate(rows):
    ax.plot([0.75, v], [i, i], color=GRID, lw=0.6, zorder=1)
# The ceiling's 95% interval (half-width 0.00072) is drawn although it is narrower than its dot.
ax.errorbar(bayes, 2, xerr=[[bayes - ci_lo], [ci_hi - bayes]], fmt="none", ecolor=INK,
            elinewidth=0.8, capsize=2.5, capthick=0.8, zorder=3)
for i, (_, v, col) in enumerate(rows):
    ax.plot([v], [i], "o", color=col, ms=5.0, mec=INK, mew=0.3, zorder=4)
ax.text(add_auc, 0.17, num(add_auc, ".4f"), ha="center", va="bottom", fontsize=5.5, color=INK)
ax.text(orc_auc, 1.17, num(orc_auc, ".4f"), ha="center", va="bottom", fontsize=5.5, color=INK)
ax.text(bayes, 2.17, num(bayes, ".4f"), ha="center", va="bottom", fontsize=5.5, color=INK)
ax.text(0.8695, 1.83, f"95% CI {num(ci_lo, '.4f')} to {num(ci_hi, '.4f')}", ha="right", va="top",
        fontsize=5.5, color=INK)
ax.axvline(goal, color=VERM, ls="--", lw=0.9, zorder=2)
ax.text(goal + 0.0012, 2.62, f"goal {num(goal, '.2f')}", ha="left", va="center", fontsize=5.5,
        color=VERM)
ax.annotate("", xy=(orc_auc, 0.55), xytext=(add_auc, 0.55),
            arrowprops=dict(arrowstyle="<->", color=GREEN, lw=0.9, shrinkA=0, shrinkB=0))
ax.text((add_auc + goal) / 2, 0.62, f"additive gap {num(gap, '.4f')}", ha="center", va="bottom",
        fontsize=5.5, color=GREEN)
ax.set_yticks(range(len(rows)))
ax.set_yticklabels([r[0] for r in rows])
ax.set_ylim(-0.45, 2.85)
ax.set_xlim(0.755, 0.87)
ax.xaxis.set_major_locator(MultipleLocator(0.02))
ax.set_xlabel("held-out AUROC on D2")
ax.tick_params(axis="y", length=0)
tidy(ax)
letter(ax, "(a)", -0.25)

# ---------------------------------------------------------------- panel (b): R11.2 coefficients
coefs = o["additive_coefficients"]
names = ["intercept", "x1", "x2", "x3", "x4"]
cols = [SKY, BLUE, BLUE, ORANGE, ORANGE]
ratio_fit = coefs[1] / coefs[2]
ratio_gen = o["linear_weights"][0] / o["linear_weights"][1]

axb = fig.add_subplot(top[0, 1])
axb.set_gid("panel:b")
axb.patch.set_gid("plot:R11.2")
axb.axhline(0, color=INK, lw=0.6, zorder=1)
for i, v in enumerate(coefs):
    axb.vlines(i, 0, v, color=cols[i], lw=1.4, zorder=2)
    axb.plot([i], [v], "o", color=cols[i], ms=5.0, mec=INK, mew=0.3, zorder=3)
    lab = num(v, ".4f") if abs(v) < 0.01 else num(v, ".2f")
    axb.text(i, v + (0.1 if v >= 0 else -0.1), lab, ha="center",
             va="bottom" if v >= 0 else "top", fontsize=5.5, color=INK)
axb.text(3.5, -0.62, "in the label only\nas the product x3·x4", ha="center", va="top",
         fontsize=5.5, color=GREY, linespacing=1.1)
axb.text(4.4, 1.95, f"x1 / x2 fitted {num(ratio_fit, '.2f')}\ngenerator {num(ratio_gen, '.2f')}",
         ha="right", va="top", fontsize=5.5, color=INK, linespacing=1.1)
axb.set_xticks(range(len(names)))
axb.set_xticklabels(names)
axb.set_xlim(-0.6, len(names) - 0.4)
axb.set_ylim(-1.45, 2.0)
axb.yaxis.set_major_locator(MultipleLocator(1.0))
axb.set_ylabel("coefficient (log-odds)")
axb.set_xlabel("term of the additive logistic model")
tidy(axb)
letter(axb, "(b)", -0.27)

# ---------------------------------------------------------------- panel (c): R11.3 calibration
bins = o["calibration_bins"]
mp = [b["mean_probability"] for b in bins]
ml = [b["mean_label"] for b in bins]
signed = [b["mean_label"] - b["mean_probability"] for b in bins]
for b, d in zip(bins, signed):
    assert abs(abs(d) - b["gap"]) < 1e-12
worst = max(range(len(bins)), key=lambda i: abs(signed[i]))
assert abs(abs(signed[worst]) - o["calibration_error"]) < 1e-12
cal_lim = lim["calibration_error"]

axc = fig.add_subplot(bot[0, 0])
axc.set_gid("panel:c")
axc.patch.set_gid("plot:R11.3")
axc.plot([0, 1], [0, 1], color=GREY, lw=0.6, ls=":", zorder=1)
axc.plot(mp, ml, "o", color=BLUE, ms=3.2, mec=INK, mew=0.25, zorder=3)
axc.plot([mp[worst]], [ml[worst]], "o", color=VERM, ms=3.6, mec=INK, mew=0.25, zorder=4)
axc.text(0.55, 0.42, "perfect\ncalibration", ha="left", va="top", fontsize=5.5, color=GREY,
         linespacing=1.1)
axc.set_xlim(-0.02, 1.02)
axc.set_ylim(-0.02, 1.02)
axc.set_aspect("equal")
axc.xaxis.set_major_locator(MultipleLocator(0.25))
axc.yaxis.set_major_locator(MultipleLocator(0.25))
axc.set_xlabel("oracle mean predicted probability")
axc.set_ylabel("observed positive rate")
tidy(axc)
letter(axc, "(c)", -0.47)

axr = fig.add_subplot(bot[0, 1])
axr.set_gid("panel:c")
axr.patch.set_gid("plot:R11.3")
idx = list(range(1, len(bins) + 1))
axr.axhspan(-cal_lim, cal_lim, color=SKY, alpha=0.22, lw=0, zorder=0)
axr.axhline(cal_lim, color=GREY, lw=0.5, ls="--", zorder=1)
axr.axhline(-cal_lim, color=GREY, lw=0.5, ls="--", zorder=1)
axr.axhline(0, color=INK, lw=0.6, zorder=1)
axr.vlines(idx, 0, signed, color=BLUE, lw=1.0, zorder=2)
axr.plot(idx, signed, "o", color=BLUE, ms=3.2, mec=INK, mew=0.25, zorder=3)
axr.plot([idx[worst]], [signed[worst]], "o", color=VERM, ms=3.6, mec=INK, mew=0.25, zorder=4)
axr.text(idx[worst] + 0.45, signed[worst], f"largest {num(signed[worst], '+.4f')}",
         ha="left", va="center", fontsize=5.5, color=VERM)
axr.text(20.4, cal_lim + 0.0004, f"limit ±{cal_lim:.2f}", ha="right", va="bottom",
         fontsize=5.5, color=GREY)
axr.set_xticks([1, 5, 10, 15, 20])
axr.set_xlim(0.3, 20.7)
axr.set_ylim(-0.0125, 0.0125)
axr.yaxis.set_major_locator(MultipleLocator(0.005))
axr.set_xlabel("bin, ordered by predicted probability")
axr.set_ylabel("observed − predicted")
tidy(axr)

out = os.path.join(HERE, FIG_ID)
fig.savefig(out + ".pdf", metadata={"CreationDate": None, "ModDate": None})
fig.savefig(out + ".png", dpi=400)
fig.savefig(out + ".svg", metadata={"Date": None})
plt.close(fig)

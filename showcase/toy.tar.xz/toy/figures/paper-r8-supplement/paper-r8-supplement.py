"""Figure paper-r8-supplement: toy.paired's statistics at one sweep point against the Bayes ceiling.

Reads analysis/E2/paired.json (run t120-a1; strength 1.0, 20 paired seeds) and figures/style.json
only. Finished from drawings/R8-1/draw.py; every panel is redrawn here from the per-seed records.

    (a) plot R8.1  each seed's two arms and its Bayes ceiling (dumbbell with a reference tick)
    (b) plot R8.2  the paired differences d and toy.paired's mean gain with its 95% t-interval
    (c) plot R8.3  each seed's gain d against the gap its without arm left, with reference lines
    (d) plot R8.4  a redrawn paired-bootstrap distribution of gap_closed against the reported CI
    (e) plot R8.5  each seed's DeLong z against the two-sided 0.05 critical value

All 20 seeds are drawn in every panel: no subset is selected. The only randomness is the
vertical jitter of the strips in (b) and (e) and the redrawn bootstrap in (d), both seeded.

Run from the project root:
    python3 figures/paper-r8-supplement/paper-r8-supplement.py
"""

import json
import os

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
FIG_ID = "paper-r8-supplement"


def find(rel):
    """Resolve a project-relative path from the cwd, the project root, or beside this file."""
    for cand in (rel, os.path.join(HERE, "..", "..", rel), os.path.join(HERE, os.path.basename(rel))):
        if os.path.exists(cand):
            return cand
    raise FileNotFoundError(rel)


with open(find("analysis/E2/paired.json"), encoding="utf-8") as fh:
    point = json.load(fh)
with open(find("figures/style.json"), encoding="utf-8") as fh:
    style = json.load(fh)

# ------------------------------------------------------------------ house style
CAT = style["categorical"]
C_WITHOUT = CAT[1]   # #E69F00  the arm without the interaction column
C_WITH = CAT[5]      # #0072B2  the arm with it
C_CEIL = CAT[0]      # #000000  the seed's Bayes AUROC (oracle)
C_SEED = CAT[3]      # #009E73  one seed's paired statistic (d, gap pair, DeLong z)
C_REP = CAT[6]       # #D55E00  a summary toy.paired reported (mean gain, gap_closed and their CIs)
C_BOOT = CAT[2]      # #56B4E9  the redrawn bootstrap resamples
GREY = "#7F7F7F"     # structure: stems, reference lines
INK = "#000000"

MM = 1 / 25.4
W_MM, H_MM = 180.0, 150.0

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 7.0,
    "axes.labelsize": 7.0,
    "xtick.labelsize": 6.0,
    "ytick.labelsize": 6.0,
    "legend.fontsize": 6.0,
    "legend.frameon": False,
    "axes.linewidth": 0.6,
    "xtick.major.width": 0.6,
    "ytick.major.width": 0.6,
    "xtick.major.size": 2.5,
    "ytick.major.size": 2.5,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.edgecolor": INK,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
    "svg.hashsalt": FIG_ID,
    "path.simplify": False,
})

# ------------------------------------------------------------------ data
recs = sorted(point["per_seed"], key=lambda r: r["seed"])
SEEDS = [r["seed"] for r in recs]
N = len(recs)
w = np.array([r["auroc_with"] for r in recs])
o = np.array([r["auroc_without"] for r in recs])
b = np.array([r["bayes_auroc"] for r in recs])
z = np.array([r["delong_z"] for r in recs])
d = w - o            # toy.paired: d = AUROC_with - AUROC_without
g = b - o            # toy.paired: gap_without = bayes - AUROC_without
gc = point["gap_closed"]

# The drawn values must be the ones toy.paired summarized: recompute and assert.
TOL = 1e-9
assert np.allclose(d, [r["d"] for r in recs], atol=TOL, rtol=0)
assert np.allclose(g, [r["gap_without"] for r in recs], atol=TOL, rtol=0)
assert abs(d.mean() - point["paired_gain"]) < TOL
assert abs(d.std(ddof=1) - point["sd_d"]) < TOL
assert abs(d.mean() / g.mean() - gc) < TOL
assert abs(w.mean() - point["mean_auroc_with"]) < TOL
assert abs(o.mean() - point["mean_auroc_without"]) < TOL
assert abs(b.mean() - point["mean_bayes_auroc"]) < TOL
assert sum(r["delong_rejects"] for r in recs) == point["delong_rejections"]

# Redrawn paired bootstrap of gap_closed (numpy, its own seed; toy.paired's own draws are not saved).
BOOT_DRAWS, BOOT_SEED = 10000, 20261025
idx = np.random.default_rng(BOOT_SEED).integers(0, N, size=(BOOT_DRAWS, N))
boot = d[idx].mean(axis=1) / g[idx].mean(axis=1)
boot_lo, boot_hi = (float(v) for v in np.percentile(boot, [2.5, 97.5]))

# Seeded vertical jitter, only so the strip dots in (b) and (e) separate.
jit = np.random.default_rng(1).uniform(-0.18, 0.18, N)
Z_CRIT = 1.959963984540054  # two-sided 0.05 normal quantile, toy.paired's DELONG_ALPHA


def minus(s):
    """Typographic minus for formatted numbers, to match matplotlib's tick labels."""
    return s.replace("-", "−")


fig = plt.figure(figsize=(W_MM * MM, H_MM * MM))


def axes_mm(left, bottom, width, height):
    return fig.add_axes([left / W_MM, bottom / H_MM, width / W_MM, height / H_MM])


def letter(x_mm, y_mm, s):
    fig.text(x_mm / W_MM, y_mm / H_MM, s, fontsize=8, fontweight="bold", ha="left", va="top")


def mark(ax, panel, plot):
    ax.set_gid("panel:" + panel)
    ax.patch.set_gid("plot:" + plot)


# ------------------------------------------------------------------ (a) R8.1 arms per seed
ax = axes_mm(16, 101, 161, 40)
mark(ax, "a", "R8.1")
xs = np.arange(N)
for x in xs:
    ax.plot([x, x], [o[x], w[x]], color=GREY, lw=0.8, zorder=1)
    ax.plot([x - 0.36, x + 0.36], [b[x]] * 2, color=C_CEIL, lw=1.2, zorder=2, solid_capstyle="butt")
ax.scatter(xs, o, color=C_WITHOUT, s=14, marker="o", lw=0, zorder=3)
ax.scatter(xs, w, color=C_WITH, s=12, marker="s", lw=0, zorder=4)
ax.set_xticks(xs, [str(s) for s in SEEDS])
ax.set_xlim(-0.7, N - 0.3)
ax.set_xlabel("seed", labelpad=2)
ax.set_ylabel("held-out AUROC")
ax.legend(handles=[
    Line2D([], [], color=C_WITHOUT, marker="o", ls="", ms=3.8, mew=0, label="without the interaction column"),
    Line2D([], [], color=C_WITH, marker="s", ls="", ms=3.5, mew=0, label="with the interaction column"),
    Line2D([], [], color=C_CEIL, lw=1.2, label="Bayes AUROC of the seed (oracle)"),
], loc="lower left", bbox_to_anchor=(0.0, 1.0), ncol=3, borderaxespad=0.2, handletextpad=0.4,
    columnspacing=1.6)
letter(1.5, 148.5, "(a)")

# ------------------------------------------------------------------ (b) R8.2 paired differences
ax = axes_mm(24, 37, 33, 45)
mark(ax, "b", "R8.2")
ax.scatter(d, 1 + jit, color=C_SEED, s=10, lw=0, zorder=3)
ax.errorbar([point["paired_gain"]], [0],
            xerr=[[point["paired_gain"] - point["paired_gain_lo"]], [point["paired_gain_hi"] - point["paired_gain"]]],
            fmt="D", color=C_REP, ms=4, capsize=2.5, lw=1.1, capthick=1.0, zorder=3)
ax.set_yticks([1, 0], ["one seed\neach", "mean and\n95% t-interval"])
ax.tick_params(axis="y", length=0)
ax.spines["left"].set_visible(False)
ax.set_ylim(-0.6, 1.6)
ax.set_xlim(0.074, 0.101)
ax.set_xticks([0.08, 0.09, 0.10])
ax.set_xlabel("gain d = with − without")
letter(1.5, 87, "(b)")

# ------------------------------------------------------------------ (c) R8.3 gain against gap
ax = axes_mm(76, 37, 45, 45)
mark(ax, "c", "R8.3")
lo_ax, hi_ax = 0.075, 0.102
ax.plot([lo_ax, hi_ax], [lo_ax, hi_ax], color=GREY, lw=0.8, ls=":", zorder=1)
ax.plot([lo_ax, hi_ax], [gc * lo_ax, gc * hi_ax], color=C_REP, lw=1.0, zorder=2)
ax.scatter(g, d, color=C_SEED, s=10, lw=0, zorder=3)
ax.set_xlim(lo_ax, hi_ax)
ax.set_ylim(lo_ax, hi_ax)
ax.set_aspect("equal")
ax.set_xticks([0.08, 0.09, 0.10])
ax.set_yticks([0.08, 0.09, 0.10])
ax.set_xlabel("gap = Bayes − without")
ax.set_ylabel("gain d = with − without")
ax.legend(handles=[
    Line2D([], [], color=GREY, lw=0.8, ls=":", label="d = gap (full closure)"),
    Line2D([], [], color=C_REP, lw=1.0, label="slope gap_closed"),
    Line2D([], [], color=C_SEED, marker="o", ls="", ms=3.2, mew=0, label="one seed"),
], loc="upper left", borderaxespad=0.2, handlelength=1.6, handletextpad=0.4)
letter(61, 87, "(c)")

# ------------------------------------------------------------------ (d) R8.4 bootstrap of gap_closed
ax = axes_mm(135, 37, 41, 45)
mark(ax, "d", "R8.4")
counts, _, _ = ax.hist(boot, bins=np.linspace(0.980, 0.998, 46), color=C_BOOT, lw=0, zorder=2)
top = counts.max()
ax.axvline(1.0, color=GREY, lw=0.8, ls=":", ymax=0.62, zorder=1)
ax.axvline(boot_lo, color=INK, lw=0.8, ls="--", ymax=0.62, zorder=3)
ax.axvline(boot_hi, color=INK, lw=0.8, ls="--", ymax=0.62, zorder=3)
y_ci = top * 1.12
ax.errorbar([gc], [y_ci], xerr=[[gc - point["gap_closed_lo"]], [point["gap_closed_hi"] - gc]],
            fmt="D", color=C_REP, ms=4, capsize=2.5, lw=1.1, capthick=1.0, zorder=4)
ax.text(point["gap_closed_hi"] + 0.0006, y_ci, "reported\nCI", ha="left", va="center", fontsize=6,
        color=INK, linespacing=1.0)
ax.text(0.9995, top * 0.5, "full\nclosure", ha="right", va="center", fontsize=6, color=GREY)
diff_lo = boot_lo - point["gap_closed_lo"]
diff_hi = boot_hi - point["gap_closed_hi"]
ax.text(0.02, 0.99, "dashed: redrawn quantiles\nredrawn − reported\nlow {}, high {}".format(
        minus("%+.5f" % diff_lo), minus("%+.5f" % diff_hi)),
        transform=ax.transAxes, ha="left", va="top", fontsize=5.5, color=INK, linespacing=1.15)
ax.set_xlim(0.978, 1.001)
ax.set_xticks([0.98, 0.99, 1.00])
ax.set_ylim(0, top * 1.62)
ax.set_xlabel("gap_closed = mean d / mean gap")
ax.set_ylabel("bootstrap resamples")
letter(121, 87, "(d)")

# ------------------------------------------------------------------ (e) R8.5 per-seed DeLong z
ax = axes_mm(16, 8, 161, 14)
mark(ax, "e", "R8.5")
ax.axvline(Z_CRIT, color=GREY, lw=0.8, ls="--", zorder=1)
ax.text(Z_CRIT + 0.15, 0.62, "z = 1.96, two-sided 0.05", ha="left", va="top", fontsize=6, color=GREY)
ax.scatter(z, jit * 1.6, color=C_SEED, s=10, lw=0, zorder=3)
ax.set_yticks([])
ax.spines["left"].set_visible(False)
ax.set_ylim(-0.65, 0.65)
ax.set_xlim(0, 19)
ax.set_xticks(range(0, 20, 2))
ax.set_xlabel("DeLong z, with vs. without, per seed", labelpad=2)
letter(1.5, 27, "(e)")

out = os.path.join(HERE, FIG_ID)
fig.savefig(out + ".pdf", metadata={"CreationDate": None, "ModDate": None})
fig.savefig(out + ".png", dpi=400)
fig.savefig(out + ".svg", metadata={"Date": None})
plt.close(fig)

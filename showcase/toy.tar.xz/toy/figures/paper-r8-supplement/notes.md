# paper-r8-supplement: notes

## Generator

`figures/paper-r8-supplement/paper-r8-supplement.py`, run from the project root as
`python3 figures/paper-r8-supplement/paper-r8-supplement.py`. It reads only
`analysis/E2/paired.json` (run t120-a1) and `figures/style.json`, and finds each one from the cwd,
from the project root, or beside the script, so it also runs in the clean room. It writes the PDF,
the PNG (400 dpi), and the SVG beside itself. `pdf.fonttype` is 42, `svg.fonttype` is `none`, and
`svg.hashsalt` is fixed. Date metadata is removed. The page is set to exactly 180 x 150 mm, with
no `bbox_inches="tight"`, and the axes are placed in millimeters. Base text is 7 pt and ticks and
legends are 6 pt. The smallest text, the difference annotation in (d), is 5.5 pt.

Randomness: the strip jitter in (b) and (e) uses `default_rng(1)`, and the redrawn bootstrap in
(d) uses `default_rng(20261025)` with 10000 resamples. Both are seeded.

## Register

Quantitative result figure with five panels, all finished from `drawings/R8-1/draw.py` and redrawn
from the data. No images are pasted in. Panel (a) is plot R8.1, (b) is R8.2, (c) is R8.3, (d) is
R8.4, and (e) is R8.5. Each axes carries `panel:<letter>`, and its background patch carries
`plot:<id>`. Layout: (a) spans the full width because it has 20 seed categories. (b), (c), and (d)
share the middle row, with (c) square on equal axes. (e) spans the full width because z = 1.96
has to show alongside z values of 13.7 to 17.8.

## Load-bearing choices, with measurements

- **The values are recomputed and asserted.** The generator recomputes d and gap from the per-seed
  AUROCs and asserts that they match toy.paired's per-seed `d` and `gap_without` to 1e-9. It also
  asserts paired_gain (0.0871654), sd_d (0.0060322), gap_closed (0.9896174 = mean d / mean gap),
  the three mean AUROCs (0.76806, 0.85522, 0.85614), and delong_rejections (20).
- **No subset.** All 20 seeds appear in every panel, so there is no selection statistic.
- **One dataset.** Every panel draws `analysis/E2/paired.json`, so there is no mixed-data
  disclosure.
- **Color meanings, one per thing.** Without arm #E69F00, with arm #0072B2, Bayes ceiling #000000,
  one seed's paired statistic (d, the gap pair, DeLong z) #009E73, a summary toy.paired reported
  (mean gain and t-interval, gap_closed slope, gap_closed and its CI) #D55E00, and the redrawn
  bootstrap resamples #56B4E9. All six are house categorical colors. The drawing colored d and z
  with the with-arm blue. Here they get their own hue, because d is a property of the pair and
  not of the with arm. Stems and reference lines are gray or black, and no colormap is used.
- **(d): the change is shown rather than the pair.** The redrawn quantiles (0.985542, 0.993538) and
  the reported CI (0.985502, 0.993529) differ by +0.0000404 and +0.0000084. At 41 mm across a
  0.023 range, that is at most 0.07 mm, so the two pairs of lines would coincide. The reported CI
  is drawn as a point-and-interval above the histogram (the same mark as in (b)), the redrawn
  quantiles are dashed lines, and the panel prints the two differences.
- **(d): full closure is in range.** The x-axis runs to 1.001, so the 1.0 line shows that the
  whole bootstrap distribution sits below it. Its largest resample is about 0.996.
- **(e): the axis starts at 0**, so the 1.96 bound and the 13.7 to 17.8 spread are drawn on one
  scale. The smallest z is 7.0 times the bound.
- **(c): equal axes** from 0.075 to 0.102. The caption discloses that the without term is shared:
  both axes subtract AUROC without, so part of the line-up is built in.
- **(b): the x-axis is zoomed** to 0.074 to 0.101 and does not include zero. The distance from
  zero is carried by the numbers (interval 0.084 to 0.090, signed-rank p 1.9e-06). It is a strip
  plot, not a bar, so no zero baseline is implied.
- **The seed above its ceiling.** Seed 16 has a shortfall of −0.000091 (ratio 1.00109). It is
  invisible in (a) and named in the caption.

## Schematic elements

None.

## Traps hit

- `%`-formatting a label string that contains literal percent signs ("2.5%, 97.5%") raised
  `ValueError: unsupported format character`. Fixed with `str.format`.
- A descriptive x-axis label carried over from the drawing for (e) ("DeLong z of the paired AUROC
  difference", over 40 characters) would fail the axis-label length check. It was shortened to
  "DeLong z, with vs. without, per seed".
- Formatted value labels use U+2212 for minus, through `minus()`, to match the tick labels.

Pitfalls read: the plot index gave no entries for these five chart types (`index_entries` is empty
in `drawings/R8-1/drawing.json`), so no listed pitfalls applied.

## Not verified in this session

The shell refused `ruff` and `pdffonts` and `pdfinfo` here. Imports were checked by hand, and every
import is used. Fonts are set by `pdf.fonttype` 42, and the page size is fixed by `figsize`
without tight bounding. The harness checks confirm both.

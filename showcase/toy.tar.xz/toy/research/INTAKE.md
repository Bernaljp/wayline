# Intake

What the owner handed over, normalized by `wayline intake`. `harness.json` holds the same autonomy, radius, fallback consent, budgets, and human-only classes, and is the copy the conductor reads.

What the research sets out to answer is not here: each objective, and each goal (an objective with a measure), is recorded with `wayline objective add` and listed in `research/OBJECTIVES.md`.

## Intent

I'm starting a small project from zero. The question is whether adding feature interaction terms improves held-out AUROC on a synthetic two-class set. The generator and the training code are in src/toy/: generate.py makes the data, train.py trains on the GPU and writes a summary, and eval.py prints 'auroc: <value>' from a summary. Beyond the number I want the real answer: do the interaction terms help, and by how much.

## References

- PDF: `materials/paper-a.pdf`
  - No DOI or arXiv id could be read from it; hand over its DOI or its title.
- PDF: `materials/paper-b.pdf`
  - No DOI or arXiv id could be read from it; hand over its DOI or its title.

## Data

- `research/intake/paper-c-source.tar.gz` (a file, 632 bytes)
- The synthetic two-class set is made by src/toy/generate.py from one seeded stream; the held-out split is the last fifth of the rows drawn (HELD_OUT_FRACTION = 0.2) and is used for evaluation only

## Code

None.

## Constraints

- train.py trains on the GPU
- Assumed: 'run on its own overnight once it is set up' means autonomy autonomous
- Assumed: the code repository released with the paper in materials/paper-c-source.tar.gz is a reference the work may build on, not the project's own code

## Autonomy

`autonomous`: the decider resolves every open question, every decision ticket not in a human-only class, and every parked proposal, and never anything on the irreversible list.

Fallback consent `auto`: while Fable's weekly window is spent, Fable work falls back to Opus without asking.

Ladder consent `ask`: a proposed change to the rung ladder (`tiers` or `difficulty`) is a human-only decision ticket of class `ladder` under every autonomy.

## Radius

`moderate`: they may also add follow-ups that directly probe a claim's failure.

## Budgets

- GPU hours: 4
- Wall clock: 12 hours

## Decisions that stay human-only

The decider never resolves these; they wait for the owner.

- `objective`: a decision that adds, reframes, or reopens an objective, or changes a goal's measure (its metric, target, splits, or the command that measures it).
- `data`: a decision that changes the data: what is used, what is held out, or what may leave the machine.

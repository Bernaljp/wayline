# Position

Rendered by `wayline position` from `research/position.json`: the claude-opus-5-5 critic's memo, read from the dossiers, `INTAKE.md`, and `OBJECTIVES.md` only.

**Intent.** Find out whether giving a classifier explicit feature-interaction terms raises its held-out AUROC on the synthetic two-class set made by src/toy/generate.py, and by how much, using the existing train.py (GPU) and eval.py.

## Closest prior work

No reference the scout verified bears on the intent.

Dropped, because the scout did not verify them:

- *paper-a*: research/refs/paper-a/dossier.json says existence: unresolved.
- *paper-b*: research/refs/paper-b/dossier.json says existence: unresolved.

### What the references lack

Work the critic expected beside these and did not find among the dossiers. It named these from what it knows; the scout searched the literature for each at setup, and what the search found is listed under it, checked by no one yet: the first `lit` tickets take them up, and `wayline absorb` adds one now.

- Friedman & Popescu (2008), 'Predictive learning via rule ensembles': the H-statistic for detecting and measuring feature interactions.
  - found by the search: *Predictive learning via rule ensembles* (Jerome H. Friedman, Bogdan E. Popescu, 2008); scout it as `doi:10.1214/07-aoas148`
  - found by the search: *Neural Rule Ensembles: Encoding Sparse Feature Interactions into Neural Networks* (Gitesh Dawer, Yangzi Guo, Sida Liu et al., 2020); scout it as `doi:10.1109/ijcnn48605.2020.9206956`
  - found by the search: *KGRLFF: Detecting Drug-Drug Interactions Based on Knowledge Graph Representation Learning and Feature Fusion_supp1-3434992.docx* (Xiaoli Lin); scout it as `doi:10.1109/tcbb.2024.3434992/mm1`
  - found by the search: *Are They Learning? Measuring Preservice of Teachers&amp;#39; Skills at Detecting Effective Teaching Interactions* (Peter D. Wiens); scout it as `doi:10.18130/v3wp1n`
  - found by the search: *Maximum likelihood rule ensembles* (Krzysztof Dembczyński, Wojciech Kotłowski, Roman Słowiński, 2008); scout it as `doi:10.1145/1390156.1390185`
  - found by the search: *Predictive case-based feature importance and interaction* (Sejong Oh, 2022); scout it as `doi:10.1016/j.ins.2022.02.003`
  - found by the search: *Measuring Swing Voters with a Supervised Machine Learning Ensemble* (Christopher Hare, Mikayla Kutsuris, 2022); scout it as `doi:10.1017/pan.2022.24`
  - found by the search: *Machine learning algorithms to infer trait‐matching and predict species interactions in ecological networks* (Maximilian Pichler, Virginie Boreux, Alexandra‐Maria Klein et al., 2019); scout it as `doi:10.1111/2041-210x.13329`
  - found by the search: *Iterative random forests to discover predictive and stable high-order interactions* (Sumanta Basu, Karl Kumbier, James B. Brown et al., 2018); scout it as `doi:10.1073/pnas.1711236115`
  - found by the search: *Feature Interaction Interpretability: A Case for Explaining Ad-Recommendation Systems via Neural Interaction Detection* (Tsang, Michael, Dehua Cheng, Hanpeng Liu et al., 2020); scout it as `doi:10.48550/arxiv.2006.10966`
- Lou, Caruana, Gehrke & Hooker (2013), 'Accurate intelligible models with pairwise interactions' (GA2M/FAST): a competing way to choose and add pairwise interaction terms.
  - found by the search: *Accurate intelligible models with pairwise interactions* (Yin Lou, Rich Caruana, Johannes Gehrke et al., 2013); scout it as `doi:10.1145/2487575.2487579`
  - found by the search: *Intelligible models for classification and regression* (Yin Lou, Rich Caruana, Johannes Gehrke, 2012); scout it as `doi:10.1145/2339530.2339556`
  - found by the search: *Source code 14. Estimates logistic L-V pairwise model interaction parameters for communities of two species competing for an environmental resource while engaging in an additional interaction, and compares community dynamics from pairwise and mechanistic models (Figure 6).*; scout it as `doi:10.7554/elife.25051.047`
  - found by the search: *Intelligible Models for HealthCare* (Rich Caruana, Yin Lou, Johannes Gehrke et al., 2015); scout it as `doi:10.1145/2783258.2788613`
  - found by the search: *Fast and accurate estimation of the covariance between pairwise maximum likelihood distances* (Manuel Gil, 2014); scout it as `doi:10.7287/peerj.preprints.387v1`
  - found by the search: *A Unified and Fast Interpretable Model for Predictive Analytics* (Jiang, Yuanyuan, Rui Ding, Tianchi Qiao et al., 2021); scout it as `doi:10.48550/arxiv.2111.08255`
  - found by the search: *Consensus Regularized Selection Based Prediction* (Ping Wang, 2016); scout it as `Consensus Regularized Selection Based Prediction`
- Bien, Taylor & Tibshirani (2013), 'A lasso for hierarchical interactions': sparse selection of interaction terms with a penalty, the standard alternative to adding all pairwise products.
  - found by the search: *A lasso for hierarchical interactions* (Jacob Bien, Jonathan Taylor, Robert Tibshirani, 2013); scout it as `doi:10.1214/13-aos1096`
  - found by the search: *hierNet: A Lasso for Hierarchical Interactions* (Jacob Bien, Rob Tibshirani, 2012); scout it as `doi:10.32614/cran.package.hiernet`
  - found by the search: *Strong Rules for Discarding Predictors in Lasso-Type Problems* (Robert Tibshirani, Jacob Bien, Jerome Friedman et al., 2011); scout it as `doi:10.1111/j.1467-9868.2011.01004.x`
  - found by the search: *Improved Selection of Pairwise Interaction Effects via Automated Calibration of Hierarchical Group-LASSO Regularization in a Stability Selection Framework.* (Ruben Julius Colindres Zuehlke, Julien Chiquet, Marc Chadeau Hyam, 2024); scout it as `doi:10.1289/isee.2024.1421`
  - found by the search: *Standardization and the Group Lasso Penalty* (Noah Simon, Robert Tibshirani, 2012); scout it as `doi:10.5705/ss.2011.075`
  - found by the search: *Machine Learning Techniques for Detecting Hierarchical Interactions in Insurance Claims Models* (Sandra Maria Nawar, 2016); scout it as `Machine Learning Techniques for Detecting Hierarchical Interactions in Insurance Claims Models`
  - found by the search: *On the Sensitivity of the Lasso to the Number of Predictor Variables* (Cheryl J. Flynn, Clifford M. Hurvich, Jeffrey S. Simonoff, 2017); scout it as `doi:10.1214/16-sts586`
  - found by the search: *Favoring the hierarchical constraint in penalized survival models for randomized trials in precision medicine* (Shaima Belhechmi, Gwénaël Le Teuff, Riccardo De Bin et al., 2023); scout it as `doi:10.1186/s12859-023-05162-x`
  - found by the search: *A first-order optimization algorithm for statistical learning with hierarchical sparsity structure* (Dewei Zhang, Yin Liu, Sam Davanloo Tajbakhsh, 2020); scout it as `doi:10.48550/arxiv.2001.03322`
  - found by the search: *Reluctant Interaction Modeling* (Guo Yu, Jacob Bien, Ryan J. Tibshirani, 2019); scout it as `doi:10.48550/arxiv.1907.08414`
- Rendle (2010), 'Factorization Machines': learns pairwise interactions implicitly, a competing method for the same task.
  - found by the search: *Factorization Machines* (Steffen Rendle, 2010); scout it as `doi:10.1109/icdm.2010.127`
  - found by the search: *Pairwise interaction tensor factorization for personalized tag recommendation* (Steffen Rendle, Lars Schmidt-Thieme, 2010); scout it as `doi:10.1145/1718487.1718498`
  - found by the search: *Factorization Models* (Steffen Rendle, 2010); scout it as `doi:10.1007/978-3-642-16898-7_5`
  - found by the search: *One-Class Matrix Factorization* (Steffen Rendle, 2010); scout it as `doi:10.1007/978-3-642-16898-7_10`
  - found by the search: *Scaling factorization machines to relational data* (Steffen Rendle, 2013); scout it as `doi:10.14778/2535573.2488340`
  - found by the search: *GraphFM: Graph Factorization Machines for Feature Interaction Modelling* (Shu Wu, Zekun Li, Yunyue Su et al., 2025); scout it as `doi:10.1007/s11633-024-1505-5`
  - found by the search: *Adaptive Factorization Network: Learning Adaptive-Order Feature Interactions* (Weiyu Cheng, Yanyan Shen, Linpeng Huang, 2020); scout it as `doi:10.1609/aaai.v34i04.5768`
  - found by the search: *biDeepFM: A multi-objective deep factorization machine for reciprocal recommendation* (Ezgi Yıldırım, Payam Azad, Şule Gündüz Öğüdücü, 2021); scout it as `doi:10.1016/j.jestch.2021.03.010`
  - found by the search: *Toward Memory-Efficient and Interpretable Factorization Machines via Data and Model Binarization* (Yu Geng, Liang Lan, William K. Cheung, 2023); scout it as `doi:10.1109/access.2023.3330779`
  - found by the search: *Hyperbolic matrix factorization improves prediction of drug-target associations* (Aleksandar Poleksić, 2023); scout it as `doi:10.1038/s41598-023-27995-5`
- Tsang, Cheng & Liu (2018), 'Detecting statistical interactions from neural network weights': shows flexible models learn interactions without explicit terms.
  - found by the search: *Discovering epistatic feature interactions from neural network models of regulatory DNA sequences* (Peyton Greenside, Tyler Shimko, Polly Fordyce et al., 2018); scout it as `doi:10.1101/302711`
  - found by the search: *Detecting global influence of transcription factor interactions on gene expression in lymphoblastoid cells using neural network models* (Neel Patel, William S. Bush, 2021); scout it as `doi:10.1101/2021.06.18.449031`
  - found by the search: *Explicit Representation of Cation Interactions in Force Fields with 1/r4 Nonbonded Terms*; scout it as `doi:10.1021/acs.jctc.0c00847.s001`
  - found by the search: *Learning From Noisy Labels With Deep Neural Networks: A Survey* (Hwanjun Song, Minseok Kim, Dongmin Park et al., 2022); scout it as `doi:10.1109/tnnls.2022.3152527`
  - found by the search: *Feature Interaction Interpretability: A Case for Explaining Ad-Recommendation Systems via Neural Interaction Detection* (Tsang, Michael, Dehua Cheng, Hanpeng Liu et al., 2020); scout it as `doi:10.48550/arxiv.2006.10966`
  - found by the search: *Video Summarization Using Deep Neural Networks: A Survey* (Evlampios Apostolidis, Eleni Adamantidou, Alexandros I. Metsai et al., 2021); scout it as `doi:10.1109/jproc.2021.3117472`
  - found by the search: *SmoothHess: ReLU Network Feature Interactions via Stein's Lemma* (Max Torop, Aria Masoomi, Davin Hill et al., 2023); scout it as `doi:10.52202/075280-2206`
  - found by the search: *Generating Bit-Rock Interaction Forces for Drilling Vibration Simulation: An Artificial Neural Network-Based Approach* (Sampath Liyanarachchi, Geoff Rideout, 2026); scout it as `doi:10.3390/modelling7010011`
- Chen & Guestrin (2016), 'XGBoost': gradient-boosted trees, the usual tabular baseline that captures interactions through its splits.
  - found by the search: *gbts: Hyperparameter Search for Gradient Boosted Trees* (Waley W. J. Liang, 2016); scout it as `doi:10.32614/cran.package.gbts`
  - found by the search: *XGBoost* (Tianqi Chen, Carlos Guestrin, 2016); scout it as `doi:10.1145/2939672.2939785`
  - found by the search: *Figure 2: XOR-like synthetic example, Gradient Boosted Decision Trees.*; scout it as `doi:10.7717/peerjcs.274/fig-2`
  - found by the search: *Geographical-XGBoost: a new ensemble model for spatially local regression based on gradient-boosted trees* (George Grekousis, 2025); scout it as `doi:10.1007/s10109-025-00465-4`
  - found by the search: *Resolving Interpretability Conflicts of Gradient Boosted Decision Trees (XGBoost) in Credit Risk Assessment* (Ci Zhang, Haiyu Chen, Xin Zhang et al., 2026); scout it as `doi:10.4018/joeuc.402038`
  - found by the search: *A stacked Gradient Boosting–XGBoost ensemble with ridge meta-learner for accurate short-term solar PV power forecasting in smart grids* (G. Rohini, T. Mariprasth, Seif Al Bustanji et al., 2026); scout it as `doi:10.1038/s41598-026-47042-3`
  - found by the search: *Functional ANOVA for Inherently Interpretable Gradient Boosting in PD Modelling* (Sara Kopelman, 2026); scout it as `Functional ANOVA for Inherently Interpretable Gradient Boosting in PD Modelling`
  - found by the search: *AR-LRX: Robustness of Adaptive Residual Linear Regression-XGBoost Forecasting Across Pharmaceutical and Retail Demand Regimes* (Wahyu Ramadhan, Edi Noersasongko, Abdul Syukur et al., 2026); scout it as `doi:10.22266/ijies2026.1130.54`
  - found by the search: *A gradient boosting machine for rawlsian subgroup fairness* (Jansen Silva de Brito Pereira, 2025); scout it as `doi:10.47749/t/unicamp.2025.1506502`
  - found by the search: *Cardiovascular Risk Prediction Using Extreme Gradient Boosting: A Machine Learning Approach* (Ch. Sathwika, 2026); scout it as `doi:10.22214/ijraset.2026.81709`
- DeLong, DeLong & Clarke-Pearson (1988): a test for comparing two correlated AUROCs measured on the same held-out set.
  - found by the search: *Comparing the Areas under Two or More Correlated Receiver Operating Characteristic Curves: A Nonparametric Approach* (Elizabeth R. DeLong, David M. DeLong, Daniel L. Clarke-Pearson, 1988); scout it as `doi:10.2307/2531595`
  - found by the search: *Table 5: DeLong test comparing the effectiveness of the three models.*; scout it as `doi:10.7717/peerj.17164/table-5`
  - found by the search: *Table S5: Comparison of performance on the independent test set between CDMPred and other general-purpose predictors using the Delong test*; scout it as `doi:10.7717/peerj.17991/supp-6`
  - found by the search: *Table S4: Comparison of performance on the independent test set between CDMPred and other methods designed to predict single nucleotide driver variants in cancer using the Delong test*; scout it as `doi:10.7717/peerj.17991/supp-5`
  - found by the search: *Table 25: DeLong test results for ROC-AUC differences.*; scout it as `doi:10.7717/peerj-cs.4118/table-25`
  - found by the search: *Published benchmark AUROC does not predict generalisation: an independent evaluation of protein solubility predictors on native and heterologous E. coli proteins* (Jakob Oeschey, 2026); scout it as `doi:10.21203/rs.3.rs-10471634/v1`
  - found by the search: *Subgroup AUROC-gap tests are not evidence of unfairness in clinical prediction models: case-mix differences make the equal-discrimination null false* (Rohith Reddy Bellibatlu, Manpreet Singh, Yash Jajoo et al., 2026); scout it as `doi:10.21203/rs.3.rs-10718552/v1`
  - found by the search: *Evaluation and Diagnosis of Nonalcoholic Fatty Liver Disease/Steatohepatitis by K-Fold Validation Based on Pathology, Including Real-Time Shear Wave Elastography and Noninvasive Biomarkers* (Jie Zhou, Feng Yan, Jinshun Xu et al., 2020); scout it as `doi:10.21203/rs.3.rs-113257/v1`
  - found by the search: *Liver function and portal‐systemic shunting quantified by the oral cholate challenge test and risk for large oesophageal varices* (Tarek Hassanein, Andrew Paul Keaveny, Parvez Mantry et al., 2024); scout it as `doi:10.1111/apt.18054`
  - found by the search: *Are open set classification methods effective on large-scale datasets?* (Ryne Roady, Tyler L. Hayes, Ronald Kemker et al., 2020); scout it as `doi:10.1371/journal.pone.0238302`
- Dietterich (1998), 'Approximate statistical tests for comparing supervised classification learning algorithms': variance and paired testing when comparing two models.
  - found by the search: *Approximate Statistical Tests for Comparing Supervised Classification Learning Algorithms* (Thomas G. Dietterich, 1998); scout it as `doi:10.1162/089976698300017197`
  - found by the search: *Statistical Significance Hypothesis Testing When Comparing Two Means* (2006); scout it as `doi:10.4135/9781412983693.n7`
  - found by the search: *Multivariate Statistical Tests for Comparing Classification Algorithms* (Olcay Taner Yıldız, Özlem Aslan, Ethem Alpaydın, 2011); scout it as `doi:10.1007/978-3-642-25566-3_1`
  - found by the search: *From equations to algorithms: comparing statistical and supervised machine learning models to predict the rate of influenza incidence in Arizona* (Demelash Areda, 2025); scout it as `doi:10.1016/j.annepidem.2025.07.038`
  - found by the search: *Significance Tests for Comparing Paired Measurements* (2009); scout it as `doi:10.1002/9780470749296.ch9`
  - found by the search: *Evaluating the Replicability of Significance Tests for Comparing Learning Algorithms* (Remco Bouckaert, Eibe Frank, 2004); scout it as `doi:10.1007/978-3-540-24775-3_3`
  - found by the search: *Model Evaluation, Model Selection, and Algorithm Selection in Machine Learning* (Sebastian Raschka, 2018); scout it as `doi:10.48550/arxiv.1811.12808`
  - found by the search: *On evaluating stream learning algorithms* (João Manuel Portela da Gama, Raquel Sebastião, Pedro Pereira Rodrigues, 2012); scout it as `doi:10.1007/s10994-012-5320-9`
  - found by the search: *Land cover and land use classification performance of machine learning algorithms in a boreal landscape using Sentinel-2 data* (Abdulhakim M. Abdi, 2019); scout it as `doi:10.1080/15481603.2019.1650447`
  - found by the search: *Block-regularized 5$\times$2 Cross-validated McNemar's Test for Comparing Two Classification Algorithms* (Yang, Jing, Ruibo Wang, Song, Yijun et al., 2023); scout it as `doi:10.48550/arxiv.2304.03990`

## Feasibility

**Feasible with changes.** The comparison can be run with the code in hand: train with and without interaction terms, then read 'auroc: <value>' from eval.py. It needs three changes before the answer means anything.

1. Replicate over generator and training seeds, and report the paired difference in AUROC with a confidence interval. A single held-out number cannot say 'by how much'.
2. Keep a validation split, separate from the held-out fifth, for any tuning or term selection. Otherwise the held-out set is no longer used for evaluation only.
3. Establish what the generator plants. If the label is built from a product of features, the gain is true by construction. If it is not, a null result is equally predetermined.

The intake leaves several things unsaid:

- the GPU and wall-clock budgets;
- the model class train.py fits (a linear/logistic model cannot represent a product term, but a tree ensemble or MLP can learn it unaided);
- which interaction terms are added (all pairs, or chosen ones) and how;
- the row and feature counts;
- whether the generator's interaction strength and noise can be set;
- whether train.py takes a seed and an interactions flag;
- what the archived source research/intake/paper-c-source.tar.gz contains, which is outside the paths I may read.

Both references are unresolved, and their PDFs call themselves test fixtures, so no published baseline anchors the expected effect size.

- compute: The intake says only that train.py trains on the GPU; it gives no GPU-hour or wall-clock budget. A synthetic two-class tabular comparison is cheap. Even a few dozen seeded replicates of two models, plus a sweep over interaction strength, should fit in an overnight run on one GPU. The real cost depends on the model class and row count in train.py, and the intake states neither.
- data: The data is synthetic and comes from src/toy/generate.py on one seeded stream, with the last 20% held out for evaluation only. Because new data can be drawn at will, sample size and replicates are limited only by compute. This data can answer whether interaction terms help *on this generator*. Whether they help in general depends entirely on how the generator makes its labels, and the intake does not describe that.

## Objectives

### O1 Do the interaction terms help, and by how much? (whether adding feature interaction terms improves held-out AUROC on a synthetic two-class set)

An objective without a measure.

**Reachable.** O1 has no measure, so it is answered by an estimate rather than a target. The answer would be the paired difference in held-out AUROC (with interaction terms minus without), averaged over enough independent generator and training seeds to give a 95% confidence interval. It should be reported together with the AUROC of each arm, a DeLong or paired-bootstrap test on each split, and the Bayes-optimal AUROC computed from the generator, which is the ceiling against which 'by how much' is read.

It is within reach because the data is synthetic and unlimited, the train/eval pipeline exists, and the compute needed is small. The open risk is interpretive, not practical. If generate.py plants a product term and the base model is linear, the answer is fixed in advance. To make 'do they help' a real finding, the work should also run a control with no planted interaction, where the gain should be about zero and could be negative from overfitting, and a stronger base model that can learn interactions itself. The dossiers give no numbers: paper-a says only 'several points', and its dossier is unresolved.

## The hostile reviewer

1. The effect is planted. A synthetic generator whose label is built from a product of two features will always reward a model that is handed that product, so 'interaction terms help' restates the generator rather than finding anything.
2. The comparison is weak. If the base model is linear, the comparison is against a model that cannot represent the interaction at all; without a tree ensemble, an MLP, factorization machines or GA2M as competitors, the paper cannot say explicit terms beat methods that learn interactions themselves.
3. 'By how much' comes from one seeded stream and one held-out fifth, with no variance across seeds and no paired test. With a fixed seed, a difference of a point or two of AUROC may be noise.
4. There is a leakage risk. If which interaction terms to add, the regularisation, or the stopping point is chosen by looking at the held-out AUROC, the held-out set is being tuned on. No validation split is described.
5. There is no null control. Without a run where the generator plants no interaction, the work cannot show that added terms are harmless when they are not needed, or measure how much spurious pairwise terms cost through overfitting.
6. There is no ceiling. Without the generator's Bayes-optimal AUROC, a gain cannot be read as a fraction of the gap that was available to close.
7. Generality is unsupported. One generator setting (one signal strength, sample size, feature count and noise level) cannot support a general claim about interaction terms on tabular data.
8. The cited support is unusable. Both references are unresolved, and their own abstracts say they were written for a test fixture and never submitted, so the work has no real prior work to stand on.

## Three directions, by distance from the intent

Nearest first, none farther than the radius `moderate`. The objectives each direction names are proposals: the grill's first tier asks the owner which the project takes, open or parked.

1. **Replicated paired comparison on the generator as is** (strict): Train the existing model with and without interaction terms on N independent seeds of generate.py, with any tuning done on a validation split cut from the training rows, and score each on its held-out fifth with eval.py. Report the mean paired AUROC difference with a 95% CI and a per-split DeLong test, next to the generator's Bayes-optimal AUROC. This answers 'do they help, and by how much' for this generator, with honest variance.
   - would pursue O1: Do the interaction terms help, and by how much? (whether adding feature interaction terms improves held-out AUROC on a synthetic two-class set)
   - proposes a new objective: Does generate.py plant a feature interaction in the label, and what is the Bayes-optimal held-out AUROC it allows?
2. **Probe the failure: null and strength sweep** (moderate): Repeat the paired comparison while sweeping the generator's planted interaction strength from zero upward, and the training-set size, so the gain becomes a curve rather than one number. At zero strength the gain should vanish, or turn negative from overfitting on spurious terms; this directly probes where the claim fails.
   - would pursue O1: Do the interaction terms help, and by how much? (whether adding feature interaction terms improves held-out AUROC on a synthetic two-class set)
   - proposes a new objective: Does the AUROC gain from interaction terms vanish when the generator plants no interaction, and how does it grow with interaction strength and shrink with sample size?
3. **Against models that learn interactions unaided** (moderate): Add competitors that capture interactions without explicit terms (gradient-boosted trees and an MLP), alongside the linear model with and without product terms, all on the same seeded splits with paired tests. This shows whether explicit terms still add anything once the model can find the interaction itself, which is the objection a reviewer would raise first.
   - would pursue O1: Do the interaction terms help, and by how much? (whether adding feature interaction terms improves held-out AUROC on a synthetic two-class set)
   - proposes a new objective: Do explicit interaction terms still raise held-out AUROC over models that can learn interactions unaided, such as gradient-boosted trees or an MLP?

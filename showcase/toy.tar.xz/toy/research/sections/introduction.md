<!-- wayline:render {"section": "introduction", "rendered_at": "2026-10-24T20:59:15.609Z", "last": "P33", "sha256": "6ac3c3f26c815bf288ce4a8d1a54deb29267f9d70a98b9b4c5a2dec9712e625d"} -->
# Introduction

## No verified prior work anchors the effect size

<!-- wayline:passage P1 -->
The first reference handed over at intake, materials/paper-a.pdf, could not be resolved to a DOI or a title, so it cannot say what gain to expect {ref:paper-a#existence}. The second, materials/paper-b.pdf, is in the same state {ref:paper-b#existence}. So the project takes no expected effect size from prior work. Experiment E6 scouts the works the position memo found by search, on detecting and selecting interactions and on paired AUROC tests. This passage should be rewritten against their dossiers once those are resolved.

## Interaction detection and selection: what the literature offers

<!-- wayline:passage P20 -->
Rule ensembles give techniques for identifying which variables interact with others, and the strength and degree of those interactions {ref:friedman-2008-predictive-learning-rule-ensembles#abstract}. Generalized additive models that sum univariate terms are reported to be significantly less accurate than more complex models that permit interactions {ref:lou-2013-accurate-intelligible-models-pairwise-interactions#abstract}. The lasso with a hierarchy constraint selects sparse interaction models, including an interaction only if one or both of its variables are marginally important, and the paper reports an empirical study of the method {ref:bien-2013-lasso-hierarchical-interactions#abstract}. The abstract of the rule-ensemble work states no gain over a no-interaction control {ref:friedman-2008-predictive-learning-rule-ensembles#abstract}. The abstract of the hierarchical lasso likewise states no such gain, nor the cost of added terms when none is needed {ref:bien-2013-lasso-hierarchical-interactions#abstract}.

## Paired tests of two classifiers

<!-- wayline:passage P21 -->
For two or more AUROCs computed on the same individuals, a nonparametric approach based on generalized U-statistics gives an estimated covariance matrix that accounts for the correlation {ref:delong-1988-comparing-areas-under-two-more#abstract}. A paired-differences t test over several random train-test splits is reported to have a high probability of type I error and should never be used {ref:dietterich-1998-approximate-statistical-tests-comparing-supervised#abstract}. McNemar's test has low type I error, and the 5x2 cv test also has acceptable type I error and directly measures variation due to the choice of training set {ref:dietterich-1998-approximate-statistical-tests-comparing-supervised#abstract}.

## The Bayes-optimal ceiling for AUROC

<!-- wayline:passage P31 -->
Work on bipartite ranking asks which scorer is Bayes-optimal for a ranking risk, and shows that the answer is non-trivial in general but easily determined in special cases through the theory of proper losses; it ties minimising a suitable class-probability estimation risk to minimising bipartite ranking risks {ref:menon-2014-bayes-optimal-scorers-bipartite-ranking#abstract}. The ranking problem has also been put in a statistical framework in which the natural risk estimates are U-statistics {ref:cl-men-on-2008-ranking-empirical-minimization-u-statistics#abstract}. For a task where soft labels (true class probabilities) and the class prior are known, soft-label-based estimators of the optimal AUC have been proposed, so that the irreducible part of the error can be told from a model's deficiency and the room left for improvement read off {ref:ushio-2026-bayes-optimal-ber-auc-estimation#abstract}.

## Precision of an AUROC estimate

<!-- wayline:passage P32 -->
The area under an ROC curve is the probability that a randomly chosen diseased subject is ranked above a randomly chosen non-diseased one, and equals the Wilcoxon statistic; this gives closed-form approximate standard errors, guidance on the sample size needed for a reliable area, and on the size needed to detect differences between techniques {ref:hanley-1982-meaning-use-area-under-receiver#abstract}. For AUROCs computed on the same individuals, a generalized U-statistics approach gives a covariance matrix that accounts for the correlation {ref:delong-1988-comparing-areas-under-two-more#abstract}.

## Reusing a held-out set and tuning on a validation split

<!-- wayline:passage P33 -->
Statistical inference theory assumes the hypotheses or learning algorithms are selected before the data are gathered, whereas in practice data are reused and new analyses are generated from the outcomes of earlier ones {ref:dwork-2014-preserving-statistical-validity-adaptive-data#abstract}. The same line of work names parameter tuning on the basis of obtained results as part of this adaptive practice, and gives a method for reusing a holdout set to validate the accuracy of hypotheses a learning algorithm produces adaptively {ref:dwork-2017-guilt-free-data-reuse#abstract}. A review of model evaluation covers the holdout method for evaluation and selection, k-fold and nested cross-validation, and the bias-variance trade-off in choosing k {ref:raschka-2018-model-evaluation-model-selection-algorithm#abstract}. Another review separates model assessment from model selection and presents cross-validation as the generic way to estimate the quantities needed for selection {ref:emmert-streib-2019-evaluation-regression-models-model-assessment#abstract}. These abstracts state no size for the upward bias of a held-out score chosen over several reads {ref:dwork-2017-guilt-free-data-reuse#abstract} {ref:raschka-2018-model-evaluation-model-selection-algorithm#abstract}.

<!-- wayline:render {"section": "results", "rendered_at": "2026-10-25T13:46:37.784Z", "last": "t144-a1-f4", "sha256": "a32e4d73f2ae774ee048b593ab088807602d845fa9068bac22e1feaae4a1e2cc"} -->
# Results

## Adding the interaction flags leaves the default training run unchanged

<!-- wayline:passage t3-a1-f1 -->
At the base commit 4a72047, `toy.train --seed 1 --rows 2000 --epochs 2 --device cpu` gives held-out auroc 0.8352720450281426.{res:t3-a1/tests/test_train.py#BASE_AUROC} After this change the same command with no new flag gives exactly the same value on CPU.{res:t3-a1/tests/test_train.py#BASE_AUROC}

<!-- wayline:passage t3-a1-f2 -->
In the without arm (--no-interaction), the weight on the zeroed x3*x4 column keeps its initial value through training (Adam with zero gradient and weight_decay 0).{res:t3-a1/tests/test_train.py#test_arms_share_initial_weights_and_without_never_moves_the_interaction_weight} Both arms draw identical initial weights from the shared seed.{res:t3-a1/tests/test_train.py#test_arms_share_initial_weights_and_without_never_moves_the_interaction_weight}

## The statistics code agrees with independent reference implementations

<!-- wayline:passage t5-a3-f1 -->
toy.stats's exact two-sided signed-rank p agrees with scipy.stats.wilcoxon(method='exact') to 12 decimal places on ten 20-replicate draws without ties.{res:t5-a3/tests/test_stats_scipy.py#L38}

<!-- wayline:passage t5-a3-f2 -->
On tied differences, toy.stats's exact signed-rank p agrees to 12 decimal places with scipy.stats.wilcoxon under an exhaustive PermutationMethod (n_resamples=10000).{res:t5-a3/tests/test_stats_scipy.py#L42-L43}

<!-- wayline:passage t5-a3-f3 -->
toy.stats's 95% t-interval bounds agree with scipy.stats.t.interval to 10 decimal places.{res:t5-a3/tests/test_stats_scipy.py#L29-L30}

<!-- wayline:passage t5-a3-f4 -->
On tied scores, toy.stats's midrank DeLong AUROCs and covariance agree with a literal pairwise DeLong kernel to an absolute tolerance of 1e-12.{res:t5-a3/tests/test_stats_scipy.py#L68-L69}

<!-- wayline:passage t5-a3-f5 -->
toy.stats's Spearman rho agrees with scipy.stats.spearmanr on tied integer data to 12 decimal places.{res:t5-a3/tests/test_stats_scipy.py#L84}

<!-- wayline:passage t5-a3-f6 -->
toy.stats's paired percentile bootstrap CI for a ratio of means lies within 0.05 times the interval's width of scipy.stats.bootstrap(paired=True, method='percentile'), each with 10000 resamples.{res:t5-a3/tests/test_stats_scipy.py#L98-L106}

<!-- wayline:passage t136-a1-f1 -->
R3's 5 deterministic checks hold toy.stats to between 10 and 12 decimal places (or an absolute 1e-12) on 26 cases.{res:t136-a1/drawings/R3-1/numbers.json#deterministic_checks,deterministic_cases,min_decimal_places,max_decimal_places,delong_atol,bootstrap_width_fraction} The sixth check, the paired bootstrap interval, is held only to 0.05 of the interval's width.{res:t136-a1/drawings/R3-1/numbers.json#deterministic_checks,deterministic_cases,min_decimal_places,max_decimal_places,delong_atol,bootstrap_width_fraction} The artifact records that each assertion passed, not how large the observed differences were.{res:t136-a1/drawings/R3-1/numbers.json#deterministic_checks,deterministic_cases,min_decimal_places,max_decimal_places,delong_atol,bootstrap_width_fraction}

<!-- wayline:passage t136-a1-f2 -->
The tie-handling checks are small: the tied signed-rank p is checked on a single vector of 10 differences with 5 distinct magnitudes, and DeLong and Spearman on ties are checked on 5 draws each.{res:t136-a1/drawings/R3-1/numbers.json#signed_rank_tied_n,signed_rank_tied_distinct_abs,delong_cases,spearman_cases}

## The oracle's true class probability matches the generator

<!-- wayline:passage t6-a1-f1 -->
generate.py builds the latent log-odds as signal times (0.6 x1 - 0.4 x2 + 1.1 strength x3 x4), adds Gaussian noise with mean 0.0 and sd NOISE_SD = 1.0, and draws the label as a coin flip with the logistic of that latent as its probability.{res:t2-a3/src/toy/generate.py#L23-L39} Because the noise enters before the logistic, P(y=1|x) is the logistic-normal integral E[sigmoid(mu(x) + e)], not sigmoid(mu(x)).{res:t2-a3/src/toy/generate.py#L23-L39}

<!-- wayline:passage t6-a1-f2 -->
Run at its defaults, the oracle's CLI reports interaction_weight 4.4 and interaction_coefficient 1.1 for the log-odds weight the generator puts on x3·x4.{res:t6-a1/tests/test_oracle.py#L186-L204}

<!-- wayline:passage t6-a1-f3 -->
Leaving out the latent noise miscalibrates the oracle: on 200,000 rows at seed 101, the 20-bin calibration error is at most 0.02 for true_prob, while sigmoid(mu(x)) exceeds 0.03.{res:t6-a1/tests/test_oracle.py#Calibration.test_calibration_error_on_200000_rows_and_a_miscalibrated_control}

<!-- wayline:passage t6-a1-f4 -->
At 20,000 rows the 20-bin calibration error is mostly sampling noise, even for the exact P(y=1|x).{res:t6-a1/tests/test_oracle.py#Calibration.test_oracle_is_calibrated_on_20000_rows} With about 1,000 rows per bin, a bin's mean label has an SE of up to about 0.016, and seed 7 gives a largest gap of 0.034.{res:t6-a1/tests/test_oracle.py#Calibration.test_oracle_is_calibrated_on_20000_rows} The bins' chi-square on 20 df stays below 45.31, its 0.999 quantile, so a 0.02 threshold on the largest gap is not a test at that size.{res:t6-a1/tests/test_oracle.py#Calibration.test_oracle_is_calibrated_on_20000_rows} At E1's 10^6 rows (50,000 per bin, SE <= 0.0023), the spec's <= 0.01 threshold is about 4 SE and is a meaningful test.{res:t6-a1/tests/test_oracle.py#Calibration.test_oracle_is_calibrated_on_20000_rows}

<!-- wayline:passage t6-a1-f5 -->
true_prob matches labels drawn by generate.row itself at fixed features to within 4 binomial SEs over 10^5 draws each.{res:t6-a1/tests/test_oracle.py#Transcription.test_true_prob_matches_generate_row_by_monte_carlo} The test covers six (x, m) cases, including m = 0 and m = 2.5.{res:t6-a1/tests/test_oracle.py#Transcription.test_true_prob_matches_generate_row_by_monte_carlo} At m = 0 the probability does not change with x3·x4.{res:t6-a1/tests/test_oracle.py#Transcription.test_true_prob_matches_generate_row_by_monte_carlo}

<!-- wayline:passage t52-a1-f1 -->
At seed 7 with 20,000 rows (1,000 per bin), the oracle's 20-bin calibration error is 0.034 to within 0.0005.{res:t6-a1/tests/test_oracle.py#Calibration.test_largest_gap_at_20000_rows_is_sampling_noise} That is above 0.02 but below three times the largest possible per-bin standard error, 0.5/sqrt(1000) ≈ 0.0158.{res:t6-a1/tests/test_oracle.py#Calibration.test_largest_gap_at_20000_rows_is_sampling_noise} The worst bin's gap is below sqrt(45.31) of its own standard errors.{res:t6-a1/tests/test_oracle.py#Calibration.test_largest_gap_at_20000_rows_is_sampling_noise} So at this size the largest gap is sampling noise, not miscalibration.{res:t6-a1/tests/test_oracle.py#Calibration.test_largest_gap_at_20000_rows_is_sampling_noise}

<!-- wayline:passage t52-a1-f2 -->
The oracle's interaction_weight is the unrounded product signal·(1.1·m).{res:t6-a1/tests/test_oracle.py#Cli.test_interaction_weight_is_the_unrounded_product} With signal 3.0 it is 3.3000000000000003, not 3.3.{res:t6-a1/tests/test_oracle.py#Cli.test_interaction_weight_is_the_unrounded_product}

<!-- wayline:passage t52-a4-f1 -->
At eight values of mu from -20 to 20, the 48-node Gauss-Hermite estimate of the logistic-normal integral agrees with the 96-node estimate within QUADRATURE_TOLERANCE = 1e-10.{res:t6-a1/tests/test_oracle.py#Quadrature.test_logistic_normal_integral_is_converged} It agrees with a trapezoid rule of step 0.002 over ±12 sd within 1e-9.{res:t6-a1/tests/test_oracle.py#Quadrature.test_logistic_normal_integral_is_converged}

## The convergence check flags only a training loss that still falls

<!-- wayline:passage t8-a2-f1 -->
toy.converge's convergence_drop is the maximum signed relative drop, so a run whose training loss rose at doubled epochs counts as a negative drop and cannot trip the 0.01 gate; only a loss that still falls by more than 1% does.{res:t8-a2/src/toy/converge.py#convergence} On the fixture the maximum is 0.05, from the without arm at seed 2.{res:t8-a2/src/toy/converge.py#convergence}

<!-- wayline:passage t8-a2-f2 -->
toy.converge needs `epochs` in each run's config.json and `final_train_loss` in each summary.json, in both the pinned point and the converge dir.{res:t8-a2/src/toy/converge.py#_epochs} Ticket 3 (train.py run directory) and ticket 16 (E2) must write those key names, or converge exits 2.{res:t8-a2/src/toy/converge.py#_epochs}

## E2 gate: reproduction and convergence

<!-- wayline:passage t104-a2-f1 -->
The first replicate's with-arm run_auroc is 0.8502984862625299. {res:t104-a2/analysis/E2/checks.json#run_auroc_with_seed1}

<!-- wayline:passage t104-a2-f2 -->
The owner's B3 auroc is 0.8502984862625299, so the reproduction gap from the first replicate's with-arm run_auroc is 0.0, within the reproduction limit of 0.002, and the reproduction check passes. {res:t104-a2/analysis/E2/checks.json#b3_auroc} {res:t104-a2/analysis/E2/checks.json#reproduction_gap} {res:t104-a2/analysis/E2/checks.json#reproduction_limit} {res:t104-a2/analysis/E2/checks.json#reproduction_passed}

<!-- wayline:passage t104-a2-f3 -->
The with arm, seed 2 rerun at 60 epochs, twice the pinned count, ends with final training loss 0.47609663009643555. {res:t104-a2/analysis/E2/checks.json#worst_run}

<!-- wayline:passage t104-a2-f4 -->
The with arm, seed 2 run at the pinned 30 epochs ends with final training loss 0.4777405858039856. {res:t104-a2/analysis/E2/checks.json#worst_run}

<!-- wayline:passage t104-a2-f5 -->
convergence_drop, the largest relative final-training-loss drop at doubled epochs over the 6 reruns, is 0.0034411053956896914, from the with arm at seed 2, within the convergence limit of 0.01, so the convergence check passes. {res:t104-a2/analysis/E2/checks.json#convergence_drop} {res:t104-a2/analysis/E2/checks.json#n_runs} {res:t104-a2/analysis/E2/checks.json#convergence_limit} {res:t104-a2/analysis/E2/checks.json#convergence_passed} {res:t104-a2/analysis/E2/checks.json#worst_run}

<!-- wayline:passage t104-a2-f6 -->
3 of the 6 reruns have a negative drop, meaning their final training loss rose slightly at doubled epochs: with seed 1 (-9.576918490834106e-05), with seed 3 (-0.0011270855050454275) and without seed 3 (-0.0023886381464950255). {res:t104-a2/analysis/E2/checks.json#n_negative_drops} {res:t104-a2/analysis/E2/checks.json#n_runs} {res:t104-a2/analysis/E2/checks.json#negative_drop_runs}

<!-- wayline:passage t140-a1-f1 -->
Doubling epochs changes the final training loss by noise, not by a steady fall: the 6 relative drops average 0.00025, 3 of them are negative, and the largest is 0.34 of the 0.01 convergence limit. {res:t140-a1/drawings/R7-1/numbers.json#n_runs,mean_drop,n_negative_drops,max_abs_drop_share_of_limit,convergence_limit}

<!-- wayline:passage t140-a1-f2 -->
The largest absolute change in final training loss from 30 to 60 epochs, 0.0016, is small next to the 0.1021 gap in mean final training loss at 30 epochs between the without arm (0.5765) and the with arm (0.4744). {res:t140-a1/drawings/R7-1/numbers.json#epochs_pinned,epochs_double,max_abs_loss_change,mean_loss_pinned_gap_without_minus_with,mean_loss_pinned_without,mean_loss_pinned_with}

## The paired statistics of a sweep point, checked by hand and against their records

<!-- wayline:passage t76-a1-f1 -->
On the hand-worked fixture (three replicates, 10 held-out rows each), toy.paired reproduces every hand-derived answer: paired_gain 2/15 with a t-interval half-width of t(0.975, 2)·sqrt(79)/75, sd_d sqrt(237)/75, signed_rank_p 0.5, delong_rejections 1 (seed 2 only), mean Bayes AUROC 2.8/3, and gap_closed 10/17 with a paired-bootstrap CI of exactly (-1/3, 0.9).{res:t76-a1/tests/test_paired.py#HandWorkedAnswers}

<!-- wayline:passage t116-a2-f1 -->
toy.paired refuses, with exit 2, a point whose two arms ran different seeds, a seed whose arms disagree on the draw (seed, strength, signal, rows, train_rows), arms that scored different labels, labels that are not the held-out rows the recorded settings draw, a summary auroc that is not the AUROC of its own saved scores, a run filed under the wrong arm, missing or out-of-order scores, and a point whose replicates disagree on any compared setting.{res:t76-a1/tests/test_paired.py#Refusals}

<!-- wayline:passage t115-a1-f1 -->
toy.paired exposes point_stats(point_dir) as its one-point entry point, with paired kept as an alias of the same function, and its command line writes the printed JSON to --out PATH when given.{res:t115-a1/src/toy/paired.py#point_stats}

<!-- wayline:passage t115-a1-f2 -->
When the gap left by the without arm is at most 0.005, summarize sets gap_closed and its CI to null and fills gap_closed_reason with a sentence; when gap_closed is reported, gap_closed_reason is null.{res:t115-a1/src/toy/paired.py#summarize}

<!-- wayline:passage t116-a2-f2 -->
toy.paired refuses a seed whose arms disagree on any training setting train.py records (val_fraction, epochs, lr, minibatch, the pinned config's content) and names that key.{res:t76-a1/tests/test_paired.py#PinnedSettings} It refuses a with run without the interaction column, a without run that kept it, and a run whose config.json lacks any compared key or features.{res:t76-a1/tests/test_paired.py#PinnedSettings} It still pairs arms that differ only in batch_size, dataloader_workers, device or the config path, and their statistics come out unchanged.{res:t76-a1/tests/test_paired.py#PinnedSettings}

<!-- wayline:passage t141-a1-f1 -->
Recomputed from toy.paired's own per-seed records at this sweep point, the paired gain, its sd, gap_closed and the mean AUROCs of both arms and the oracle all equal the summary values toy.paired reported.{res:t141-a1/drawings/R8-1/numbers.json#recomputed_matches_file}

<!-- wayline:passage t141-a1-f2 -->
A seeded paired bootstrap of gap_closed, redrawn from the point's per-seed records, gives percentile bounds within 0.00004 of the CI toy.paired reported.{res:t141-a1/drawings/R8-1/numbers.json#bootstrap_ci_max_endpoint_diff}

<!-- wayline:passage t141-a1-f3 -->
At this sweep point the with arm's held-out AUROC falls short of the Bayes ceiling by 0.0009 on average over the seeds.{res:t141-a1/drawings/R8-1/numbers.json#shortfall_with_mean}

## The evaluation command never reads the held-out score when selecting on validation

<!-- wayline:passage t95-a1-f1 -->
toy.eval keeps O2's goal command unchanged.{res:t95-a1/tests/test_eval.py#Eval.test_o2_command_reads_wayline_artifact_unchanged} With no --summary, `--split held_out` reads the summary named by WAYLINE_ARTIFACT and prints `auroc: 0.8502984862625299` for owner/sample-summary.json, the same value that `--summary owner/sample-summary.json` prints.{res:t95-a1/tests/test_eval.py#Eval.test_o2_command_reads_wayline_artifact_unchanged}

<!-- wayline:passage t95-a1-f2 -->
`toy.eval --split val` prints a summary's `val_auroc` and fails if the summary has none, without falling back to the held-out `auroc`.{res:t95-a1/tests/test_eval.py#Eval.test_val_split_never_falls_back_to_held_out} Likewise, `--split held_out` fails on a --val-fraction summary, which has no `auroc`.{res:t95-a1/tests/test_eval.py#Eval.test_val_split_never_falls_back_to_held_out} Selecting by validation score therefore never reads the held-out metric through this command.{res:t95-a1/tests/test_eval.py#Eval.test_val_split_never_falls_back_to_held_out}

<!-- wayline:passage t117-a1-f1 -->
toy.eval accepts a run directory from every summary source, not only from --summary: read_metric passes every artifact through summary_path, so a positional path or a WAYLINE_ARTIFACT that names a directory has its summary.json read.{res:t117-a1/src/toy/eval.py#read_metric} The module docstring and the positional argument's help now say so.{res:t117-a1/src/toy/eval.py#read_metric}

## How a prior work counts as settled in the literature placement

<!-- wayline:passage t98-a1-f1 -->
toy.placement counts an entry toward resolved_refs only when its dossier says existence 'verified' and its measures_paired_gain is true or false.{res:t98-a1/src/toy/placement.py#place} An entry whose measures_paired_gain is null counts toward neither number, and its slug is listed under 'unsettled'.{res:t98-a1/src/toy/placement.py#place}

<!-- wayline:passage t98-a1-f2 -->
An entry with no dossier agrees only when its existence is 'missing', and it then counts as unresolved.{res:t98-a1/src/toy/placement.py#check_entry} 'verified' or 'unresolved' with no dossier, or 'missing' when a dossier exists, is a mismatch and makes the command exit 1.{res:t98-a1/src/toy/placement.py#check_entry}

## E6: literature placement of C3-C6 (C8)

<!-- wayline:passage t112-a2-f1 -->
Every one of the five placement entries agrees with its dossier's existence ('verified') and DOI, so toy.placement lists no mismatches.{res:t112-a1/analysis/E6/placement_summary.json#mismatches}

<!-- wayline:passage t112-a1-f2 -->
Only two of the five works can be settled from their level-0 dossiers (abstracts): DeLong 1988 (a test for correlated ROC areas) and Dietterich 1998 (tests for comparing learning algorithms).{res:t112-a1/analysis/E6/placement_summary.json#resolved_refs} Neither measures a held-out AUROC gain from an explicit product column, so resolved_refs is 2.{res:t112-a1/analysis/E6/placement_summary.json#resolved_refs}

<!-- wayline:passage t112-a1-f3 -->
No resolved work measures the paired gain against a no-interaction control (prior_measures_gain = 0), so A9 is not confirmed by the current reading.{res:t112-a1/analysis/E6/placement_summary.json#prior_measures_gain}

<!-- wayline:passage t112-a2-f2 -->
Friedman 2008, Lou 2013 and Bien 2013, the three works about interaction models, are still unsettled.{res:t112-a1/analysis/E6/placement_summary.json#unsettled} Their abstracts report no held-out AUROC against a no-interaction control.{res:t112-a1/analysis/E6/placement_summary.json#unsettled} Friedman's and Bien's dossiers are now at level 2 but still hold only the abstract, and Lou's is at level 0.{res:t112-a1/analysis/E6/placement_summary.json#unsettled}

<!-- wayline:passage t112-a1-f5 -->
With resolved_refs = 2 < 4, C8 is reported unresolved under SPEC E6's rule.{res:t112-a1/analysis/E6/placement_summary.json#c8_verdict} It is neither supported nor contradicted until the three interaction papers are read past their abstracts.{res:t112-a1/analysis/E6/placement_summary.json#c8_verdict}

## E2: paired AUROC gain of the x3*x4 column over 20 seeds

<!-- wayline:passage t121-a1-f1 -->
Over the 20 paired replicates of E2, each with 16000 training rows, adding the x3·x4 column raises held-out AUROC by a mean paired gain of 0.08716535526499543, with a t-interval at confidence 0.95 from 0.08434218983093059 to 0.08998852069906027. {res:t120-a1/analysis/E2/paired.json#paired_gain} {res:t120-a1/analysis/E2/paired.json#paired_gain_lo} {res:t120-a1/analysis/E2/paired.json#paired_gain_hi} {res:t120-a1/analysis/E2/paired.json#train_rows} {res:t120-a1/analysis/E2/paired.json#n_pairs} {res:t120-a1/analysis/E2/verdict.json#confidence}

<!-- wayline:passage t121-a1-f2 -->
The t-interval of the mean paired gain at confidence 0.95 runs from 0.08434218983093059 to 0.08998852069906027, wholly above zero, so A2 is not confirmed. {res:t120-a1/analysis/E2/paired.json#paired_gain_lo} {res:t120-a1/analysis/E2/paired.json#paired_gain_hi} {res:t120-a1/analysis/E2/verdict.json#confidence} {res:t120-a1/analysis/E2/verdict.json#a2_confirmed}

<!-- wayline:passage t121-a1-f3 -->
All 20 per-seed differences d_i are positive, the smallest being 0.07724309618943104 and the largest 0.09767053660183433. {res:t120-a1/analysis/E2/verdict.json#n_positive_d} {res:t120-a1/analysis/E2/verdict.json#n_pairs} {res:t120-a1/analysis/E2/verdict.json#min_d} {res:t120-a1/analysis/E2/verdict.json#max_d}

<!-- wayline:passage t121-a1-f4 -->
The exact two-sided Wilcoxon signed-rank p over the 20 per-seed differences is 1.9073486328125e-06. {res:t120-a1/analysis/E2/paired.json#signed_rank_p} {res:t120-a1/analysis/E2/paired.json#n_pairs}

<!-- wayline:passage t121-a1-f5 -->
The DeLong test of the two correlated AUROCs rejects at the level delong_alpha of 0.05 on 20 of the 20 replicates. {res:t120-a1/analysis/E2/paired.json#delong_rejections} {res:t120-a1/analysis/E2/verdict.json#delong_alpha} {res:t120-a1/analysis/E2/paired.json#n_pairs}

<!-- wayline:passage t121-a1-f6 -->
The column closes a fraction gap_closed of 0.9896174437934124 of the without arm's gap to the Bayes ceiling, with a paired bootstrap CI at confidence 0.95 from 0.9855017415149592 to 0.9935291766371139 over 10000 resamples. {res:t120-a1/analysis/E2/paired.json#gap_closed} {res:t120-a1/analysis/E2/paired.json#gap_closed_lo} {res:t120-a1/analysis/E2/paired.json#gap_closed_hi} {res:t120-a1/analysis/E2/verdict.json#confidence} {res:t120-a1/analysis/E2/verdict.json#bootstrap_resamples} The gap denominator, the mean over replicates of the oracle's AUROC minus the without arm's, is 0.08807984925050658, above the floor of 0.005 below which gap_closed is not reported. {res:t120-a1/analysis/E2/paired.json#gap_denominator} {res:t120-a1/analysis/E2/verdict.json#gap_denominator_min}

<!-- wayline:passage t121-a1-f7 -->
The with arm's mean held-out AUROC over the 20 paired replicates is 0.8552220917946025. {res:t120-a1/analysis/E2/paired.json#mean_auroc_with} {res:t120-a1/analysis/E2/paired.json#n_pairs}

<!-- wayline:passage t121-a1-f8 -->
The without arm's mean held-out AUROC over the 20 paired replicates is 0.768056736529607. {res:t120-a1/analysis/E2/paired.json#mean_auroc_without} {res:t120-a1/analysis/E2/paired.json#n_pairs}

<!-- wayline:passage t120-a1-f1 -->
Over the 20 paired replicates, the mean oracle (Bayes) AUROC on the same held-out rows is 0.8561365857801138. {res:t120-a1/analysis/E2/paired.json#mean_bayes_auroc} {res:t120-a1/analysis/E2/paired.json#n_pairs}

<!-- wayline:passage t121-a1-f9 -->
C3 is supported: the t-interval's lower bound of 0.08434218983093059 is above zero, the signed-rank p of 1.9073486328125e-06 is below the p limit of 0.05, and the E2 gate (reproduction and convergence) passed. {res:t120-a1/analysis/E2/verdict.json#c3_supported} {res:t120-a1/analysis/E2/paired.json#paired_gain_lo} {res:t120-a1/analysis/E2/paired.json#signed_rank_p} {res:t120-a1/analysis/E2/verdict.json#p_limit} {res:t120-a1/analysis/E2/verdict.json#gate_passed}

<!-- wayline:passage t120-a1-f2 -->
C2's bound part is supported: the oracle's mean AUROC lies 0.0009144939855112444 above the with arm's mean and 0.08807984925050671 above the without arm's mean, so neither arm's mean exceeds the oracle's by more than the bound slack of 0.002. {res:t120-a1/analysis/E2/verdict.json#c2_bound_supported} {res:t120-a1/analysis/E2/verdict.json#bayes_minus_with} {res:t120-a1/analysis/E2/verdict.json#bayes_minus_without} {res:t120-a1/analysis/E2/verdict.json#bound_slack}

<!-- wayline:passage t120-a1-f3 -->
1 of the 20 replicates has a with-arm AUROC above its own oracle AUROC, and the largest excess of a with-arm AUROC over its oracle AUROC is 9.051095182521784e-05. {res:t120-a1/analysis/E2/verdict.json#n_with_above_bayes} {res:t120-a1/analysis/E2/verdict.json#n_pairs} {res:t120-a1/analysis/E2/verdict.json#max_with_minus_bayes}

<!-- wayline:passage t120-a1-f4 -->
C2 is supported as a whole: its bound part holds on E2, and E1's ceiling part holds. {res:t120-a1/analysis/E2/verdict.json#c2_supported} {res:t120-a1/analysis/E2/verdict.json#c2_bound_supported} {res:t120-a1/analysis/E2/verdict.json#c2_ceiling_supported}

<!-- wayline:passage t121-a1-f10 -->
The SD of the 20 per-seed differences is 0.006032219084153099, not above Q15's SD rule of 0.02, so seeds 21 to 50 are not added. {res:t120-a1/analysis/E2/verdict.json#sd_d} {res:t120-a1/analysis/E2/verdict.json#sd_rule} {res:t120-a1/analysis/E2/verdict.json#q15_revisit} {res:t120-a1/analysis/E2/verdict.json#revisit_seed_first} {res:t120-a1/analysis/E2/verdict.json#revisit_seed_last} {res:t120-a1/analysis/E2/verdict.json#n_pairs}

<!-- wayline:passage t111-a1-f8 -->
A7 does not hold: E2's mean with-arm AUROC over 20 paired seeds is 0.8552220917946025, above the goal of 0.82, as the goal run is {res:t111-a1/analysis/E5/goal.json#a7} {res:t111-a1/analysis/E5/goal.json#mean_auroc_with_e2} {res:t111-a1/analysis/E5/goal.json#e2_n_pairs} {res:t111-a1/analysis/E5/goal.json#goal}.

## Evaluation command

<!-- wayline:passage t118-a1-f1 -->
Tests now cover the case where WAYLINE_ARTIFACT or the positional path names a run directory: toy.eval reads the summary.json inside it and prints its auroc.{res:t95-a1/tests/test_eval.py#Eval.test_wayline_artifact_run_directory_reads_its_summary_json} This pins the behavior that read_metric's use of summary_path gives every summary source.{res:t95-a1/tests/test_eval.py#Eval.test_wayline_artifact_run_directory_reads_its_summary_json}

## E5: the goal run against O2's 0.82 (C7)

<!-- wayline:passage t111-a1-f1 -->
O2's goal run, toy.train at its project-start defaults with seed 1, scores a held-out auroc of 0.8502984862625299, at or above the goal of 0.82, so the goal is met by its measure {res:t111-a1/analysis/E5/goal.json#goal_seed} {res:t111-a1/analysis/E5/goal.json#goal_run_auroc} {res:t111-a1/analysis/E5/goal.json#goal} {res:t111-a1/analysis/E5/goal.json#goal_met}.

<!-- wayline:passage t111-a1-f2 -->
The goal run lies 0.030298486262529956 above the goal of 0.82 {res:t111-a1/analysis/E5/goal.json#goal_run_minus_goal} {res:t111-a1/analysis/E5/goal.json#goal}.

<!-- wayline:passage t111-a1-f3 -->
The held-out fifth was read by 1 candidate, the unchanged start run, over 3 seeded scorings, within E5's limit of 6 held-out reads {res:t111-a1/analysis/E5/goal.json#heldout_reads} {res:t111-a1/analysis/E5/goal.json#heldout_scorings} {res:t111-a1/analysis/E5/goal.json#max_heldout_reads}.

<!-- wayline:passage t111-a1-f4 -->
Because the start run already meets the goal, E5 tried 0 candidate changes and kept none, so no setting was chosen on held-out data {res:t111-a1/analysis/E5/goal.json#candidates_tried} {res:t111-a1/analysis/E5/goal.json#kept_changes} {res:t111-a1/analysis/E5/goal.json#goal_met}.

<!-- wayline:passage t111-a1-f5 -->
At the default settings the start run's held-out auroc is 0.8502984862625299 at seed 1, 0.8487532141167736 at seed 2 and 0.8631549538738469 at seed 3, with a mean of 0.8540688847510501 {res:t111-a1/analysis/E5/goal.json#seed_aurocs.seed1} {res:t111-a1/analysis/E5/goal.json#seed_aurocs.seed2} {res:t111-a1/analysis/E5/goal.json#seed_aurocs.seed3} {res:t111-a1/analysis/E5/goal.json#start_mean_auroc}.

<!-- wayline:passage t111-a1-f6 -->
The conductor's keep-if-better judgment for O2 kept the start at an auroc of 0.8540688847510501, the mean of the three seeds, while O2's goal stays the single seed-1 run {res:t111-a1/analysis/E5/goal.json#harness_judgment.value} {res:t111-a1/analysis/E5/goal.json#harness_judgment.kept} {res:t111-a1/analysis/E5/goal.json#harness_judgment.value_equals_start_mean} {res:t111-a1/analysis/E5/goal.json#goal_seed}.

<!-- wayline:passage t111-a1-f7 -->
E1's Bayes ceiling of 0.8554855066431899 is not below the goal, so A6 does not hold, and the goal run lies 0.00518702038065999 below that ceiling {res:t111-a1/analysis/E5/goal.json#bayes_auroc} {res:t111-a1/analysis/E5/goal.json#ceiling_below_goal} {res:t111-a1/analysis/E5/goal.json#a6} {res:t111-a1/analysis/E5/goal.json#ceiling_minus_goal_run}.

<!-- wayline:passage t111-a1-f9 -->
C7 is supported: the goal run's auroc is at least 0.82, the held-out reads are within 6, and every kept change was chosen by val_auroc, which holds trivially because no change was kept {res:t111-a1/analysis/E5/goal.json#c7_supported} {res:t111-a1/analysis/E5/goal.json#c7_rule} {res:t111-a1/analysis/E5/goal.json#goal_met} {res:t111-a1/analysis/E5/goal.json#heldout_reads} {res:t111-a1/analysis/E5/goal.json#max_heldout_reads} {res:t111-a1/analysis/E5/goal.json#kept_chosen_by_val_auroc} {res:t111-a1/analysis/E5/goal.json#kept_changes}.

## Default draw stays fixed under the strength parameter

<!-- wayline:passage t2-a3-f1 -->
At strength 1.0, generate(1, signal=4.0, rows=20000) serialised as sorted-key JSON lines (train then held-out) has SHA-256 2ab2d229839a4c61ebe9c3b61c23bf04170f59e889c3839293acafd5a180ae55.{res:t2-a3/tests/test_generate.py#DEFAULT_DRAW_SHA256} This was measured on the code before the change and is unchanged after it.{res:t2-a3/tests/test_generate.py#DEFAULT_DRAW_SHA256}

<!-- wayline:passage t2-a3-f2 -->
The feature columns, the `interaction` column and the random stream do not depend on `strength`, because the Gaussian noise draw is made regardless.{res:t2-a3/src/toy/generate.py#row} Only the label can change, so sweep points share common random numbers.{res:t2-a3/src/toy/generate.py#row}

## Oracle audit cost on the 10^6-row draw D2

<!-- wayline:passage t53-a1-f1 -->
The committed test holds the audit of the default draw D2 (seed 10001, 1000000 rows) to a wall-clock limit of 3600 seconds and a peak child memory limit of 4.0 GB, and the audit passed both when the test was run.{res:t53-a1/tests/test_oracle_budget.py#TIME_LIMIT_SECONDS}

## E1: planted interaction, additive gap and Bayes ceiling on D2

<!-- wayline:passage t103-a1-f1 -->
On D2 (seed 10001, 10^6 rows, signal 4, strength 1), the label is built at src/toy/generate.py:36 as latent = signal·(0.6 x1 − 0.4 x2 + 1.1·strength·x3x4) plus N(0, 1) noise, so the log-odds weight on x3·x4 is interaction_weight = 4.4.{res:t102-a1/results/E1/oracle.json#interaction_weight}

<!-- wayline:passage t103-a1-f2 -->
The unpenalised additive logistic model on x1..x4 was fit to the first half of D2, 500000 rows.{res:t102-a1/results/E1/oracle.json#additive_fit_rows}

<!-- wayline:passage t103-a1-f3 -->
The additive model was scored on the second half of D2, 500000 rows.{res:t102-a1/results/E1/oracle.json#additive_scored_rows}

<!-- wayline:passage t103-a1-f4 -->
On the scored half of D2, the additive model's AUROC is 0.7681.{res:t102-a1/results/E1/oracle.json#additive_auroc}

<!-- wayline:passage t103-a1-f5 -->
On the same scored half of D2, the oracle's AUROC is 0.8563.{res:t102-a1/results/E1/oracle.json#oracle_auroc_second_half}

<!-- wayline:passage t103-a1-f6 -->
additive_gap, the oracle's AUROC on the scored half minus the additive model's, is 0.0882, far above C1's 0.005 threshold.{res:t102-a1/results/E1/oracle.json#additive_gap}

<!-- wayline:passage t103-a1-f7 -->
The additive model's coefficients on x3 and x4 are about zero (−0.0035 and 0.0020), against 1.61 and −1.07 on x1 and x2.{res:t102-a1/results/E1/oracle.json#additive_coefficients} The interaction has no marginal linear trace that an additive model could use.{res:t102-a1/results/E1/oracle.json#additive_coefficients}

<!-- wayline:passage t103-a1-f8 -->
The oracle's 20-bin calibration error on D2 is 0.0039, within the 0.01 limit.{res:t102-a1/results/E1/oracle.json#calibration_error}

<!-- wayline:passage t103-a1-f9 -->
Each equal-count calibration bin on D2 holds 50000 rows.{res:t102-a1/results/E1/oracle.json#calibration_bins}

<!-- wayline:passage t103-a1-f10 -->
The default generator's Bayes-optimal AUROC on D2 is 0.8555.{res:t102-a1/results/E1/oracle.json#bayes_auroc}

<!-- wayline:passage t103-a1-f11 -->
The DeLong 95% half-width of the Bayes AUROC on D2 is 0.00072, inside C2's ±0.002 precision.{res:t102-a1/results/E1/oracle.json#bayes_auroc_halfwidth}

<!-- wayline:passage t103-a1-f12 -->
C1 is supported: interaction_weight is not zero, additive_gap > 0.005, and calibration_error ≤ 0.01.{res:t103-a1/analysis/E1/summary.json#c1_supported} C2's ceiling part is supported: the half-width is ≤ 0.002 and calibration_error is ≤ 0.01.{res:t103-a1/analysis/E1/summary.json#c1_supported} Its bound part is left to E2.{res:t103-a1/analysis/E1/summary.json#c1_supported}

<!-- wayline:passage t103-a1-f13 -->
The Bayes ceiling (0.8555) lies 0.035 above O2's goal of 0.82, so A6 does not hold and the goal is not out of reach by construction.{res:t102-a1/results/E1/oracle.json#bayes_auroc}

<!-- wayline:passage t144-a1-f1 -->
Reaching O2's 0.82 goal on D2 requires closing 0.59 of the distance between the additive model's AUROC and the Bayes ceiling.{res:t144-a1/drawings/R11-1/numbers.json#share_of_ceiling_gap_closed_by_goal}

<!-- wayline:passage t144-a1-f2 -->
The 0.82 goal lies 0.0519 above the additive model's AUROC on D2, so no model that stays additive in x1..x4 reaches it on this generator.{res:t144-a1/drawings/R11-1/numbers.json#goal_minus_additive}

<!-- wayline:passage t144-a1-f3 -->
The additive fit keeps the generator's x1:x2 ratio of -1.5 and gives x3 and x4 no weight.{res:t144-a1/drawings/R11-1/numbers.json#coef_ratio_x1_x2} The interaction therefore costs it signal without biasing the linear terms' relative weights.{res:t144-a1/drawings/R11-1/numbers.json#coef_ratio_x1_x2}

<!-- wayline:passage t144-a1-f4 -->
The oracle's AUROC on the scored half of D2 and the Bayes AUROC on all of D2 differ by 0.0008.{res:t144-a1/drawings/R11-1/numbers.json#oracle_minus_bayes}

## E3: paired gain across interaction strengths (C4, C5)

<!-- wayline:passage t122-a2-f1 -->
At strength m = 0 (no planted interaction, 16000 training rows, 20 paired seeds), the mean paired gain of the x3*x4 column is -0.0003186665215305473, with a t-interval at confidence 0.95 of -0.0005967640897244911 to -4.056895333660356e-05 {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.m} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.train_rows} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.n_pairs} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.paired_gain} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.paired_gain_lo} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.paired_gain_hi} {res:t122-a2/analysis/E3/verdict.json#confidence}.

<!-- wayline:passage t122-a2-f2 -->
C4 is supported: at m = 0 the t-interval at confidence 0.95 of the mean paired gain lies inside -0.01 to 0.01 {res:t122-a2/analysis/E3/verdict.json#c4_supported} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.m} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.paired_gain_lo} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.paired_gain_hi} {res:t122-a2/analysis/E3/verdict.json#confidence} {res:t122-a2/analysis/E3/verdict.json#harmless_lo} {res:t122-a2/analysis/E3/verdict.json#harmless_hi}.

<!-- wayline:passage t122-a2-f3 -->
A4 does not hold: at m = 0 the lower bound of the t-interval at confidence 0.95 of the mean paired gain is above -0.01, so at the default training size of 16000 rows the unneeded column does not cost more than C4's tolerance {res:t122-a2/analysis/E3/verdict.json#a4} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.m} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.paired_gain_lo} {res:t122-a2/analysis/E3/verdict.json#confidence} {res:t122-a2/analysis/E3/verdict.json#harmless_lo} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.train_rows}.

<!-- wayline:passage t122-a2-f4 -->
At m = 0 the column's cost is small but detectable: 16 of the 20 per-seed differences are negative, and the exact signed-rank p is 0.00485992431640625 {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.m} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.n_negative_d} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.n_pairs} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.signed_rank_p}.

<!-- wayline:passage t122-a2-f5 -->
At m = 0 the column's mean paired gain is -0.0003186665215305473, a cost 31.38076743038538 times smaller in size than C4's tolerance of 0.01 {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.m} {res:t122-a2/analysis/E3/verdict.json#zero_cost.harmless_band} {res:t122-a2/analysis/E3/verdict.json#zero_cost.band_over_cost} {res:t122-a2/analysis/E3/verdict.json#zero_cost.paired_gain}.

<!-- wayline:passage t122-a2-f6 -->
At m = 0 the DeLong test rejects at 0.05 on 2 of the 20 replicates {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.m} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.delong_rejections} {res:t122-a2/analysis/E3/verdict.json#delong_alpha} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.n_pairs}.

<!-- wayline:passage t122-a2-f7 -->
At m = 0 gap_closed is not reported, because the without arm's mean gap to the Bayes ceiling, 0.0007995212426435416, is not above the floor of 0.005 {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.m} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.gap_closed} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.gap_closed_reason} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.gap_denominator} {res:t122-a2/analysis/E3/verdict.json#gap_denominator_min}. At m = 0 the with arm's mean held-out AUROC is 0.8128026089519119, the without arm's 0.8131212754734426, and the oracle's 0.8139207967160861 {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.m} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.mean_auroc_with} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.mean_auroc_without} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.mean_bayes_auroc}.

<!-- wayline:passage t123-a1-f1 -->
At m = 0.25 the mean paired gain is 0.006924435415007868, with a t-interval at confidence 0.95 from 0.0061247342470867674 to 0.0077241365829289685 {res:t122-a2/analysis/E3/verdict.json#by_strength.m0p25.m} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0p25.paired_gain} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0p25.paired_gain_lo} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0p25.paired_gain_hi} {res:t122-a2/analysis/E3/verdict.json#confidence}. At m = 0.25 gap_closed is 0.8697196427899274, with a CI from 0.8330004369188385 to 0.9053704618086735, and the DeLong test rejects on 20 of the 20 replicates {res:t122-a2/analysis/E3/verdict.json#by_strength.m0p25.m} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0p25.gap_closed} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0p25.gap_closed_lo} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0p25.gap_closed_hi} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0p25.delong_rejections} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0p25.n_pairs}.

<!-- wayline:passage t123-a1-f2 -->
At m = 0.5 the mean paired gain is 0.026716785955346812, with a t-interval at confidence 0.95 from 0.025427598893239502 to 0.02800597301745412, and gap_closed is 0.9589124322451849, with a CI from 0.9464932540108753 to 0.9708170401195537 {res:t122-a2/analysis/E3/verdict.json#by_strength.m0p5.m} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0p5.paired_gain} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0p5.paired_gain_lo} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0p5.paired_gain_hi} {res:t122-a2/analysis/E3/verdict.json#confidence} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0p5.gap_closed} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0p5.gap_closed_lo} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0p5.gap_closed_hi}.

<!-- wayline:passage t123-a1-f3 -->
At m = 1, which reuses E2's runs, the mean paired gain is 0.08716535526499543, with a t-interval at confidence 0.95 from 0.08434218983093059 to 0.08998852069906027, and gap_closed is 0.9896174437934124 {res:t122-a2/analysis/E3/verdict.json#by_strength.m1.m} {res:t122-a2/analysis/E3/verdict.json#by_strength.m1.dir} {res:t122-a2/analysis/E3/verdict.json#by_strength.m1.paired_gain} {res:t122-a2/analysis/E3/verdict.json#by_strength.m1.paired_gain_lo} {res:t122-a2/analysis/E3/verdict.json#by_strength.m1.paired_gain_hi} {res:t122-a2/analysis/E3/verdict.json#confidence} {res:t122-a2/analysis/E3/verdict.json#by_strength.m1.gap_closed}.

<!-- wayline:passage t123-a1-f4 -->
At m = 2 the mean paired gain is 0.20305977863815153, with a t-interval at confidence 0.95 from 0.19909965847175126 to 0.2070198988045518, and gap_closed is 0.996633827391132 {res:t122-a2/analysis/E3/verdict.json#by_strength.m2.m} {res:t122-a2/analysis/E3/verdict.json#by_strength.m2.paired_gain} {res:t122-a2/analysis/E3/verdict.json#by_strength.m2.paired_gain_lo} {res:t122-a2/analysis/E3/verdict.json#by_strength.m2.paired_gain_hi} {res:t122-a2/analysis/E3/verdict.json#confidence} {res:t122-a2/analysis/E3/verdict.json#by_strength.m2.gap_closed}.

<!-- wayline:passage t123-a1-f5 -->
At m = 4 the mean paired gain is 0.31434161002887523, with a t-interval at confidence 0.95 from 0.3109568572362925 to 0.31772636282145794, wholly above zero {res:t122-a2/analysis/E3/verdict.json#by_strength.m4.m} {res:t122-a2/analysis/E3/verdict.json#by_strength.m4.paired_gain} {res:t122-a2/analysis/E3/verdict.json#by_strength.m4.paired_gain_lo} {res:t122-a2/analysis/E3/verdict.json#by_strength.m4.paired_gain_hi} {res:t122-a2/analysis/E3/verdict.json#confidence}.

<!-- wayline:passage t123-a1-f6 -->
At m = 4 the with arm's mean held-out AUROC is 0.9569689362650855, against the oracle's 0.9573724403710034 and the without arm's 0.6426273262362103, and gap_closed is 0.9987179972371389 {res:t122-a2/analysis/E3/verdict.json#by_strength.m4.m} {res:t122-a2/analysis/E3/verdict.json#by_strength.m4.mean_auroc_with} {res:t122-a2/analysis/E3/verdict.json#by_strength.m4.mean_bayes_auroc} {res:t122-a2/analysis/E3/verdict.json#by_strength.m4.mean_auroc_without} {res:t122-a2/analysis/E3/verdict.json#by_strength.m4.gap_closed}.

<!-- wayline:passage t123-a1-f7 -->
strength_spearman, Spearman's correlation between m and the mean paired gain over the 6 points, is 1.0 {res:t122-a2/analysis/E3/verdict.json#strength_spearman} {res:t122-a2/analysis/E3/verdict.json#n_points}.

<!-- wayline:passage t123-a1-f8 -->
The mean paired gain rises strictly at every step of the strength grid {res:t122-a2/analysis/E3/verdict.json#gain_monotone_in_strength} {res:t122-a2/analysis/E3/verdict.json#strength_grid}.

<!-- wayline:passage t123-a1-f9 -->
C5 is supported: strength_spearman, 1.0, is at least spearman_min, 0.9, and at m = 4 the lower bound of the t-interval at confidence 0.95 of the mean paired gain, 0.3109568572362925, is above zero {res:t122-a2/analysis/E3/verdict.json#c5_supported} {res:t122-a2/analysis/E3/verdict.json#strength_spearman} {res:t122-a2/analysis/E3/verdict.json#spearman_min} {res:t122-a2/analysis/E3/verdict.json#by_strength.m4.m} {res:t122-a2/analysis/E3/verdict.json#by_strength.m4.paired_gain_lo} {res:t122-a2/analysis/E3/verdict.json#confidence}.

<!-- wayline:passage t123-a1-f10 -->
A3 is confirmed: the gain is about zero at strength 0 (C4 is supported) and rises with the planted strength (C5 is supported), so it only restates what generate.py plants and is not a finding about interaction terms apart from the generator {res:t122-a2/analysis/E3/verdict.json#a3} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.m} {res:t122-a2/analysis/E3/verdict.json#c4_supported} {res:t122-a2/analysis/E3/verdict.json#c5_supported}.

<!-- wayline:passage t123-a1-f11 -->
No point's SD of d_i exceeds Q15's SD rule of 0.02, so the list of points that exceed it is empty and seeds 21 to 50 are not added at any strength {res:t122-a2/analysis/E3/verdict.json#sd_rule} {res:t122-a2/analysis/E3/verdict.json#sd_rule_exceeded_at} {res:t122-a2/analysis/E3/verdict.json#revisit_seed_first} {res:t122-a2/analysis/E3/verdict.json#revisit_seed_last}.

<!-- wayline:passage t123-a1-f12 -->
The largest SD of d_i over the 6 points is 0.008461534756361957 {res:t122-a2/analysis/E3/verdict.json#max_sd_d} {res:t122-a2/analysis/E3/verdict.json#n_points}.

## E4: paired gain across training sizes (C6)

<!-- wayline:passage t110-a1-f1 -->
At m = 1 with 1000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is 0.08749872642030157, with a t-interval at confidence 0.95 from 0.08431674206762646 to 0.09068071077297668 {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.m} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.train_rows} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.n_pairs} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.paired_gain} {res:t110-a1/analysis/E4/verdict.json#confidence} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.paired_gain_lo} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.paired_gain_hi}.

<!-- wayline:passage t110-a1-f2 -->
At m = 1 with 2000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is 0.08718983653005144, with a t-interval at confidence 0.95 from 0.0841952933838717 to 0.09018437967623118 {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n2000.m} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n2000.train_rows} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n2000.n_pairs} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n2000.paired_gain} {res:t110-a1/analysis/E4/verdict.json#confidence} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n2000.paired_gain_lo} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n2000.paired_gain_hi}.

<!-- wayline:passage t110-a1-f3 -->
At m = 1 with 4000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is 0.08714270655297177, with a t-interval at confidence 0.95 from 0.08403431475983457 to 0.09025109834610896 {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n4000.m} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n4000.train_rows} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n4000.n_pairs} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n4000.paired_gain} {res:t110-a1/analysis/E4/verdict.json#confidence} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n4000.paired_gain_lo} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n4000.paired_gain_hi}.

<!-- wayline:passage t110-a1-f4 -->
At m = 1 with 8000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is 0.0872613248977486, with a t-interval at confidence 0.95 from 0.08431982835169771 to 0.09020282144379949 {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n8000.m} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n8000.train_rows} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n8000.n_pairs} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n8000.paired_gain} {res:t110-a1/analysis/E4/verdict.json#confidence} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n8000.paired_gain_lo} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n8000.paired_gain_hi}.

<!-- wayline:passage t110-a1-f5 -->
At m = 1 with 32000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is 0.08737781037867107, with a t-interval at confidence 0.95 from 0.08565401917246722 to 0.08910160158487491 {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n32000.m} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n32000.train_rows} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n32000.n_pairs} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n32000.paired_gain} {res:t110-a1/analysis/E4/verdict.json#confidence} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n32000.paired_gain_lo} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n32000.paired_gain_hi}.

<!-- wayline:passage t110-a1-f6 -->
At m = 1 with 64000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is 0.08786251131921252, with a t-interval at confidence 0.95 from 0.0863493599255909 to 0.08937566271283415 {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.m} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.train_rows} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.n_pairs} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.paired_gain} {res:t110-a1/analysis/E4/verdict.json#confidence} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.paired_gain_lo} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.paired_gain_hi}.

<!-- wayline:passage t110-a1-f7 -->
At m = 0 (no planted interaction) with 1000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is -0.00024655913274218013, with a t-interval at confidence 0.95 from -0.0005093556314718568 to 1.623736598749644e-05; 12 of the per-seed differences are negative and the exact signed-rank p is 0.0758514404296875 {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n1000.m} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n1000.train_rows} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n1000.n_pairs} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n1000.paired_gain} {res:t110-a1/analysis/E4/verdict.json#confidence} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n1000.paired_gain_lo} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n1000.paired_gain_hi} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n1000.n_negative_d} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n1000.signed_rank_p}.

<!-- wayline:passage t110-a1-f8 -->
At m = 0 (no planted interaction) with 2000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is -0.00012946543069410342, with a t-interval at confidence 0.95 from -0.00027598075101763843 to 1.7049889629431583e-05; 12 of the per-seed differences are negative and the exact signed-rank p is 0.0758514404296875 {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n2000.m} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n2000.train_rows} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n2000.n_pairs} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n2000.paired_gain} {res:t110-a1/analysis/E4/verdict.json#confidence} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n2000.paired_gain_lo} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n2000.paired_gain_hi} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n2000.n_negative_d} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n2000.signed_rank_p}.

<!-- wayline:passage t110-a1-f9 -->
At m = 0 (no planted interaction) with 4000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is -0.00011075740449061899, with a t-interval at confidence 0.95 from -0.00027394065031801035 to 5.2425841336772345e-05; 11 of the per-seed differences are negative and the exact signed-rank p is 0.3299827575683594 {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n4000.m} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n4000.train_rows} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n4000.n_pairs} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n4000.paired_gain} {res:t110-a1/analysis/E4/verdict.json#confidence} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n4000.paired_gain_lo} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n4000.paired_gain_hi} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n4000.n_negative_d} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n4000.signed_rank_p}.

<!-- wayline:passage t110-a1-f10 -->
At m = 0 (no planted interaction) with 8000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is -0.00015346134200449612, with a t-interval at confidence 0.95 from -0.00029105094290745866 to -1.5871741101533587e-05; 13 of the per-seed differences are negative and the exact signed-rank p is 0.069580078125 {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n8000.m} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n8000.train_rows} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n8000.n_pairs} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n8000.paired_gain} {res:t110-a1/analysis/E4/verdict.json#confidence} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n8000.paired_gain_lo} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n8000.paired_gain_hi} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n8000.n_negative_d} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n8000.signed_rank_p}.

<!-- wayline:passage t110-a1-f11 -->
At m = 0 (no planted interaction) with 32000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is -0.00015580299768552797, with a t-interval at confidence 0.95 from -0.00030200567076750495 to -9.60032460355095e-06; 14 of the per-seed differences are negative and the exact signed-rank p is 0.023950576782226562 {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n32000.m} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n32000.train_rows} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n32000.n_pairs} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n32000.paired_gain} {res:t110-a1/analysis/E4/verdict.json#confidence} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n32000.paired_gain_lo} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n32000.paired_gain_hi} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n32000.n_negative_d} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n32000.signed_rank_p}.

<!-- wayline:passage t110-a1-f12 -->
At m = 0 (no planted interaction) with 64000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is -0.00012215189815497073, with a t-interval at confidence 0.95 from -0.00023787628168152455 to -6.427514628416892e-06; 12 of the per-seed differences are negative and the exact signed-rank p is 0.0758514404296875 {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n64000.m} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n64000.train_rows} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n64000.n_pairs} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n64000.paired_gain} {res:t110-a1/analysis/E4/verdict.json#confidence} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n64000.paired_gain_lo} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n64000.paired_gain_hi} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n64000.n_negative_d} {res:t110-a1/analysis/E4/verdict.json#by_size.m0.n64000.signed_rank_p}.

<!-- wayline:passage t110-a1-f13 -->
At m = 1, gain_shrink, the mean over the 20 shared seeds of the per-seed gain at 1000 training rows minus the per-seed gain at 64000, is -0.0003637848989109571, with a paired t-interval at confidence 0.95 from -0.003671575350341559 to 0.0029440055525196446 {res:t110-a1/analysis/E4/verdict.json#strengths} {res:t110-a1/analysis/E4/verdict.json#m1_gain_shrink_n} {res:t110-a1/analysis/E4/verdict.json#smallest_train_rows} {res:t110-a1/analysis/E4/verdict.json#largest_train_rows} {res:t110-a1/analysis/E4/verdict.json#m1_gain_shrink} {res:t110-a1/analysis/E4/verdict.json#confidence} {res:t110-a1/analysis/E4/verdict.json#m1_gain_shrink_lo} {res:t110-a1/analysis/E4/verdict.json#m1_gain_shrink_hi}.

<!-- wayline:passage t110-a1-f14 -->
C6 is supported: at m = 1, gain_shrink, -0.0003637848989109571, is at most the limit of 0.005, and the upper bound of its t-interval at confidence 0.95, 0.0029440055525196446, is below that limit too {res:t110-a1/analysis/E4/verdict.json#c6_supported} {res:t110-a1/analysis/E4/verdict.json#strengths} {res:t110-a1/analysis/E4/verdict.json#m1_gain_shrink} {res:t110-a1/analysis/E4/verdict.json#shrink_limit} {res:t110-a1/analysis/E4/verdict.json#confidence} {res:t110-a1/analysis/E4/verdict.json#m1_gain_shrink_hi} {res:t110-a1/analysis/E4/verdict.json#m1_gain_shrink_ci_below_limit}.

<!-- wayline:passage t110-a1-f15 -->
A5 is not confirmed and C6's verdict is not unresolved: the lower bound of gain_shrink's t-interval, -0.003671575350341559, is not above 0.005, so the gain does not fall as training rows grow from 1000 to 64000 at m = 1 {res:t110-a1/analysis/E4/verdict.json#a5} {res:t110-a1/analysis/E4/verdict.json#unresolved} {res:t110-a1/analysis/E4/verdict.json#m1_gain_shrink_lo} {res:t110-a1/analysis/E4/verdict.json#shrink_limit} {res:t110-a1/analysis/E4/verdict.json#smallest_train_rows} {res:t110-a1/analysis/E4/verdict.json#largest_train_rows} {res:t110-a1/analysis/E4/verdict.json#strengths}.

<!-- wayline:passage t110-a1-f16 -->
At m = 1 the mean paired gain stays between 0.08714270655297177 and 0.08786251131921252 over all 7 training sizes from 1000 to 64000 rows, a range of 0.0007198047662407558, and it is neither strictly falling nor strictly rising with size {res:t110-a1/analysis/E4/verdict.json#strengths} {res:t110-a1/analysis/E4/verdict.json#m1_min_paired_gain} {res:t110-a1/analysis/E4/verdict.json#m1_max_paired_gain} {res:t110-a1/analysis/E4/verdict.json#n_sizes} {res:t110-a1/analysis/E4/verdict.json#smallest_train_rows} {res:t110-a1/analysis/E4/verdict.json#largest_train_rows} {res:t110-a1/analysis/E4/verdict.json#m1_gain_range} {res:t110-a1/analysis/E4/verdict.json#m1_gain_monotone_decreasing} {res:t110-a1/analysis/E4/verdict.json#m1_gain_monotone_increasing}.

<!-- wayline:passage t110-a1-f17 -->
At m = 1 with 1000 training rows the with arm's mean held-out AUROC is 0.8549796629676963, against the oracle's 0.8561365857801138 and the without arm's 0.7674809365473949, so the column closes a fraction gap_closed of 0.9869503768521246 of the without arm's gap to the Bayes ceiling {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.m} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.train_rows} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.mean_auroc_with} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.mean_bayes_auroc} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.mean_auroc_without} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.gap_closed}.

<!-- wayline:passage t110-a1-f18 -->
At m = 1 with 64000 training rows the with arm's mean held-out AUROC is 0.8539837723485484, against the oracle's 0.8548397780523894 and the without arm's 0.7661212610293358, so the column closes a fraction gap_closed of 0.9903514426011134 of the without arm's gap to the Bayes ceiling {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.m} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.train_rows} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.mean_auroc_with} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.mean_bayes_auroc} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.mean_auroc_without} {res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.gap_closed}.

<!-- wayline:passage t110-a1-f19 -->
At m = 0, gain_shrink between 1000 and 64000 training rows is -0.00012440723458720938, with a t-interval at confidence 0.95 from -0.0004162716103747647 to 0.00016745714120034596; it is reported, not claimed {res:t110-a1/analysis/E4/verdict.json#strengths} {res:t110-a1/analysis/E4/verdict.json#smallest_train_rows} {res:t110-a1/analysis/E4/verdict.json#largest_train_rows} {res:t110-a1/analysis/E4/verdict.json#m0_gain_shrink} {res:t110-a1/analysis/E4/verdict.json#confidence} {res:t110-a1/analysis/E4/verdict.json#m0_gain_shrink_lo} {res:t110-a1/analysis/E4/verdict.json#m0_gain_shrink_hi}.

<!-- wayline:passage t110-a1-f20 -->
At m = 0 the t-interval at confidence 0.95 of the mean paired gain lies inside -0.01 to 0.01 at all 7 of the 7 training sizes, so the unneeded column costs less than C4's tolerance at every size from 1000 to 64000 rows {res:t110-a1/analysis/E4/verdict.json#strengths} {res:t110-a1/analysis/E4/verdict.json#confidence} {res:t110-a1/analysis/E4/verdict.json#m0_cost.harmless_lo} {res:t110-a1/analysis/E4/verdict.json#m0_cost.harmless_hi} {res:t110-a1/analysis/E4/verdict.json#m0_cost.n_sizes_ci_inside_band} {res:t110-a1/analysis/E4/verdict.json#n_sizes} {res:t110-a1/analysis/E4/verdict.json#smallest_train_rows} {res:t110-a1/analysis/E4/verdict.json#largest_train_rows}.

<!-- wayline:passage t110-a1-f21 -->
At m = 0 the column's cost is small but detectable at some sizes: the t-interval at confidence 0.95 lies wholly below zero at 4 of the 7 sizes (8000, 16000, 32000, 64000 training rows) and wholly above zero at 0, and the most negative mean paired gain, -0.0003186665215305473, is at 16000 training rows {res:t110-a1/analysis/E4/verdict.json#strengths} {res:t110-a1/analysis/E4/verdict.json#confidence} {res:t110-a1/analysis/E4/verdict.json#m0_cost.n_sizes_ci_below_zero} {res:t110-a1/analysis/E4/verdict.json#n_sizes} {res:t110-a1/analysis/E4/verdict.json#m0_cost.sizes_ci_below_zero} {res:t110-a1/analysis/E4/verdict.json#m0_cost.n_sizes_ci_above_zero} {res:t110-a1/analysis/E4/verdict.json#m0_cost.most_negative_paired_gain} {res:t110-a1/analysis/E4/verdict.json#m0_cost.most_negative_paired_gain_at}.

<!-- wayline:passage t110-a1-f22 -->
No point of either size sweep has an SD of d_i above Q15's SD rule of 0.02, so seeds beyond 20 are not added; the largest SD over the 14 points is 0.006798902574422248 {res:t110-a1/analysis/E4/verdict.json#sd_rule} {res:t110-a1/analysis/E4/verdict.json#sd_rule_exceeded_at} {res:t110-a1/analysis/E4/verdict.json#seed_last} {res:t110-a1/analysis/E4/verdict.json#n_points} {res:t110-a1/analysis/E4/verdict.json#max_sd_d}.

## Documentation site for the toy package, with the docstrings its build checks for

<!-- wayline:passage t131-a1-f1 -->
train.py's module docstring and ready_interactions docstring on main claimed the batch_size x batch_size gram tensor is used to down-weight interaction terms for duplicate-looking rows.{res:t131-a1/src/toy/train.py#ready_interactions (train() calls it then `del gram` before the loop; DataLoader uses batch_size=DEFAULT_MINIBATCH)} The code allocates a tensor of zeros and deletes it before training without reading it, and the minibatch is fixed at DEFAULT_MINIBATCH (256).{res:t131-a1/src/toy/train.py#ready_interactions (train() calls it then `del gram` before the loop; DataLoader uses batch_size=DEFAULT_MINIBATCH)} So --batch-size changes neither the fit nor the scores.{res:t131-a1/src/toy/train.py#ready_interactions (train() calls it then `del gram` before the loop; DataLoader uses batch_size=DEFAULT_MINIBATCH)} Both docstrings now say this.{res:t131-a1/src/toy/train.py#ready_interactions (train() calls it then `del gram` before the loop; DataLoader uses batch_size=DEFAULT_MINIBATCH)}

<!-- wayline:passage t131-a1-f2 -->
No module in src/toy implements a keep rule. toy.goallog reads each candidate's `kept` field (true, false, or null), checks it is the same on every line of that candidate, and counts kept and discarded.{res:t131-a1/src/toy/goallog.py#summarise} Whatever decides keep-if-better lives outside the package.{res:t131-a1/src/toy/goallog.py#summarise}

# Spec: Do explicit feature-interaction terms raise held-out AUROC on the toy synthetic generator, and by how much?

Rendered by `wayline specify` from `research/spec.json`; change the spec by answering its confirmation with what to change, never by editing here.

## Summary

This project asks whether giving a classifier an explicit feature-interaction column, the product x3·x4, raises its held-out AUROC on the synthetic two-class data drawn by src/toy/generate.py, and by how much. It first reads the generator to learn whether that interaction is planted in the label and what the best achievable (Bayes-optimal) AUROC is. It then trains the same model with and without the column on 20 paired seeds. It reports the mean AUROC difference with a 95% confidence interval and paired tests, and also as a share of the gap to that ceiling. A run with no planted interaction, plus sweeps over interaction strength and training size, show whether the gain comes from the generator. Separately, it tries to reach the owner's goal of 0.82 held-out AUROC without tuning on held-out data.

## Question

src/toy/generate.py draws synthetic two-class data. On that data, does giving the model train.py fits an explicit x3·x4 column raise held-out AUROC over the same model without it (Q14), and by how much? The answer is a mean paired difference over 20 seeds with a 95% CI and paired tests (Q8, Q15), read against the generator's own Bayes-optimal ceiling (O3, Q11). Does the gain come from the generator? That is, does it vanish when nothing is planted, grow with the planted strength, and how does it move with training-set size (O4; Q6, Q10, Q12)? Can the default run reach the owner's goal of held-out AUROC 0.82 (O2) without anything being tuned on the held-out fifth (Q9)? The claims reach only as far as this generator and the grids it is swept over.

## Claims

- **C1.** The default generate.py plants a feature interaction in the label: the conditional class probability it draws labels from puts a nonzero weight on x3·x4, and on a large draw that term is worth more than 0.005 of AUROC over the best additive logistic model. (experiments: E1; objectives: O3; set aside: its objective O3 is closed)
- **C2.** The default generator's Bayes-optimal held-out AUROC is known to within ±0.002. It is computed from an oracle P(y=1|x) transcribed from generate.py and calibrated on a fresh draw, and neither trained arm's 20-seed mean held-out AUROC exceeds the oracle's mean on the same rows by more than 0.002. (experiments: E1, E2; objectives: O3; set aside: its objective O3 is closed)
- **C3.** On the default generator, adding the x3·x4 column to the same model raises held-out AUROC. Over the 20 paired seeds of Q15, the mean paired difference (with minus without) has a 95% CI wholly above zero and an exact signed-rank p below 0.05. The work reports its size in AUROC points and as the share of the no-column arm's gap to the Bayes ceiling that it closes. (experiments: E2; objectives: O1; set aside: its objective O1 is closed)
- **C4.** When the generator plants no interaction (strength multiplier 0), the x3·x4 column is harmless at the default training size: the 95% CI of the mean paired difference lies inside [-0.01, +0.01]. (experiments: E3; objectives: O4; set aside: its objective O4 is closed)
- **C5.** The paired gain grows with the planted interaction strength. Across the multipliers 0, 0.25, 0.5, 1, 2 and 4, the mean paired gain has a Spearman correlation of at least 0.9 with strength, and at multiplier 4 its 95% CI lies wholly above zero. (experiments: E3; objectives: O4; set aside: its objective O4 is closed)
- **C6.** At the default strength, the paired gain does not shrink toward zero as training rows grow, as expected if train.py's model is linear in its inputs and so cannot represent x3·x4 without the column. The mean gain at the smallest size on the grid exceeds the mean gain at 4·n0 by no more than 0.005. (experiments: E4; objectives: O4; set aside: its objective O4 is closed)
- **C7.** train.py's default with-term run reaches held-out AUROC of at least 0.82, as printed by `PYTHONPATH=src python3 -m toy.eval --split held_out`. It is changed only by settings chosen on a validation split cut from the training rows and kept under the goal's keep rule. (experiments: E5; objectives: O2; set aside: its objective O2 is closed)
- **C8.** None of the works the position memo found by search measures what C3–C6 measure: the paired held-out AUROC gain of an explicit product column over the same model without it, read against a known Bayes ceiling and a zero-strength control. Instead, the H-statistic (Friedman & Popescu 2008), GA2M/FAST (Lou et al. 2013) and the hierarchical lasso (Bien et al. 2013) detect or select interactions, while DeLong et al. (1988) and Dietterich (1998) supply the paired tests used here. (experiments: E6; objectives: O1; set aside: its objective O1 is closed)

## Anti-claims

- **A1.** Suppose the oracle's weight on x3·x4 is zero, or additive_gap is at most 0.005. Then the default generator plants no usable x3·x4 interaction and C1 is wrong. E2's default comparison is then itself a null control, and E3's strength axis switches to absolute weights. (confirmed by: E1)
- **A2.** If the 95% CI of E2's mean paired gain reaches zero or below, the project does not claim the column helps on this generator. It reports 'by how much' as the CI's bounds, not as a gain. (confirmed by: E2)
- **A3.** The project does not claim the gain is a finding about interaction terms apart from the generator (K1, Q6). If the gain is about zero at strength 0 and rises with the planted strength, it only restates what generate.py plants, and the report says so in those words. (confirmed by: E3)
- **A4.** If, at strength 0, the 95% CI of the paired difference reaches below -0.01, the column is not harmless when it is not needed, and C4 is wrong. The report then gives that overfitting cost (K4, Q10). (confirmed by: E3)
- **A5.** If gain_shrink's 95% CI lies wholly above 0.005, the gain falls as training rows grow. That means train.py's model is learning x3·x4 without the column, so C6 is wrong and C3's gain is partly a small-sample effect. (confirmed by: E4)
- **A6.** If E1's Bayes ceiling is below 0.82, no model can meet O2 on the default generator, and C7 is wrong by construction. The project then does not change the generator, the split or the goal to reach it: those choices belong to the owner (human-only objective and data classes). (confirmed by: E1)
- **A7.** The goal value comes from one seeded run, not the model's expected held-out AUROC (Q15). Suppose E2's 20-seed mean_auroc_with is below 0.82 while the goal run meets it. Then the report says the goal is met by its measure but the mean falls short. (confirmed by: E2)
- **A8.** The project does not claim the gain holds for tabular data in general, or at feature counts or noise levels other than the generator's defaults (K6, Q12). The claims reach only across E3's strength grid and E4's size grid. If the gain changes across those grids, that confirms one setting could not have spoken for others. (confirmed by: E4)
- **A9.** No claim rests on paper-a or paper-b, whose dossiers are unresolved. If a resolved work already measures this gain against a no-interaction control (prior_measures_gain ≥ 1), C8 is wrong. The report then cites that work as the closest prior work and sets its number beside C3's. (confirmed by: E6)

## Methods

- **Arms (Q14)**: The treatment arm `with` is train.py as it runs today: featurize() appends row['interaction'] (x3·x4) to x1..x4. The baseline arm `without` (B1) is the same run with the opt-in flag --no-interaction, so the model sees x1..x4 only. The two arms share the model, optimiser, epochs, learning rate, any regularisation, the generator seed, the training seed, the held-out fifth and eval.py. They differ only in that one column.
- **Pinned settings (Q14)**: Before any arm runs, the model class and train.py's settings as they stand at the project's start are recorded in configs/arms.json: optimiser, epochs, learning rate, regularisation and the seed list. Every arm run in E2–E4 passes that file explicitly, so a default that E5 later changes for the goal cannot move O1's or O4's arms. Nothing in E2–E4 is tuned.
- **Paired seeds (Q8, Q15)**: Replicate i, for i = 1..20, draws data with generator seed i and trains with training seed i; if train.py has one seed, i drives both. Both arms of replicate i share both seeds and are scored on that draw's last fifth. The seeds 1–20 are fixed here, before any result is read, and every sweep point reuses the same list. Every run is reported, and no seed is dropped or added because of how a result came out. If the 20 per-seed differences at a point have an SD above 0.02, seeds 21–50 are added there and all 50 are reported. That choice rests on the interval's width alone (Q15's revisit rule).
- **Statistics**: For replicate i, d_i = AUROC_with,i − AUROC_without,i on the same held-out rows. The work reports: - the mean of d_i, with a 95% t-interval on 19 degrees of freedom; - the exact two-sided Wilcoxon signed-rank p over the 20 d_i; - the DeLong test of the two correlated AUROCs on each replicate's held-out rows, as the count of replicates that reject at 0.05; - gap_closed = mean(d_i) / mean(bayes_i − AUROC_without,i), where bayes_i is the oracle's AUROC on replicate i's held-out rows. gap_closed is reported only when that denominator exceeds 0.005, with a 10,000-resample paired bootstrap CI over replicates.
- **Oracle and Bayes ceiling (O3, Q11)**: src/toy/oracle.py transcribes from generate.py the probability P(y=1 | x1..x4) that the generator draws each label from, at any strength multiplier m. It is checked by calibration on a 10^6-row draw: 20 equal-count bins, with the largest gap between mean label and mean probability at most 0.01. Its AUROC on held-out rows is the Bayes-optimal AUROC, the ceiling that 'by how much' is read against (K5). If the label is drawn through latent noise with no closed form, the oracle integrates that noise by Monte Carlo, using enough draws that the ceiling's half-width stays at or below 0.002.
- **Sweeps (O4; Q6, Q10, Q12)**: The strength multiplier m scales the weight on x3·x4 in generate.py's label, leaving every other part of the generator as it is; m = 1 is the default draw exactly. The training size n is the number of training rows, and n0 is the default. Sizes up to n0 cap the default draw's training rows at the first n, leaving the held-out fifth unchanged. Larger sizes draw n/0.8 rows and hold out the last fifth, which is the intake's rule. Both parameters are opt-in, and sweep draws are written only under runs/E3 and runs/E4.
- **Held-out discipline (Q9, K3)**: In E1–E4 the held-out fifth is only scored, never used to choose anything. The arms run pinned settings, and the seeds, grids and tests are fixed in this spec before any result is read. In E5, settings are chosen on a validation split: the last fifth of the training rows, set with --val-fraction 0.2. The held-out fifth is read only by the goal command under the keep rule, at most six times (the starting run plus five candidates), and each read is logged.
- **Goal keep rule (O2)**: A change to train.py's defaults is kept only if the goal command's held-out auroc beats the best value kept so far. A change that does not is journaled `discarded`, left on its branch and filed as a negative result. A discarded change comes back only as a new ticket that cites new evidence. The goal stays the single run its command measures; it is never redefined as a mean over seeds (Q15).
- **Literature placement (Q13, K7)**: The works the position memo found by search are scouted to resolved dossiers through literature tickets and read. Each one's relation to C3–C6 is recorded in results/placement.json. The report places C3–C6 against the resolved works and rests nothing on paper-a or paper-b.

## Experiments

### E1 (claims: C1, C2)

- design: Generator audit and Bayes ceiling (O3, K5). CPU only. 1. Read src/toy/generate.py. Write src/toy/oracle.py to compute P(y=1|x) for any row at any multiplier m. State, with file and line, how the label is built and the weight it puts on x3·x4 (interaction_weight). 2. Draw D2: 10^6 rows, seed 10001, default settings. 3. On D2, compute calibration_error: put the oracle probabilities into 20 equal-count bins and take the largest absolute gap between mean label and mean probability. 4. On D2, compute the oracle's AUROC with its DeLong 95% half-width (bayes_auroc, bayes_auroc_halfwidth). 5. Compute additive_gap (B4): fit an unpenalised logistic regression on x1..x4 to the first half of D2 and score the second half. additive_gap is the oracle's AUROC on that second half minus the additive model's AUROC. No model in E2–E5 sees D2. Nothing is repeated beyond the single large draw, whose size makes the half-width the precision.
- baselines: B2, B4
- data: D2
- metrics: interaction_weight, calibration_error, bayes_auroc, bayes_auroc_halfwidth, additive_gap
- success: C1 is supported when interaction_weight != 0, additive_gap > 0.005 and calibration_error <= 0.01. C2's ceiling part is supported when bayes_auroc_halfwidth <= 0.002 and calibration_error <= 0.01; its bound part is checked in E2.
- budget: CPU only; no GPU hours

### E2 (claims: C2, C3)

- design: Paired comparison on the default generator (O1, K2). Runs: for replicates i = 1..20 (generator seed i, training seed i), run train.py with --config configs/arms.json on the same D1 draw in both arms: - `with`: featurize() as today; - `without` (B1): --no-interaction. Each run writes summary.json and its held-out per-row scores to runs/E2/m1_n0/<arm>/seed<i>/. Each run is scored with eval.py (run_auroc), and the oracle (B2) scores the same held-out rows. Analysis: `toy.paired runs/E2/m1_n0` reports paired_gain with its 95% t-interval, signed_rank_p, delong_rejections, gap_closed, and the mean AUROC of each arm and of the oracle. Checks before the gain is read: - Reproduction: replicate 1's with-term run_auroc is within 0.002 of owner/sample-summary.json (B3). - Convergence: replicates 1–3 are rerun in both arms at twice the pinned epochs, under runs/E2/converge/. Final training loss must drop by at most 1% relative (convergence_drop <= 0.01). Otherwise a decision ticket revisits Q14 before E3 and E4 run. If the SD of the 20 d_i exceeds 0.02, seeds 21–50 are added (Q15's revisit rule). Nothing is tuned.
- baselines: B1, B2, B3
- data: D1
- metrics: run_auroc, paired_gain, paired_gain_lo, paired_gain_hi, signed_rank_p, delong_rejections, gap_closed, mean_auroc_with, mean_auroc_without, mean_bayes_auroc, convergence_drop
- success: C3 is supported when paired_gain_lo > 0 and signed_rank_p < 0.05. C2's bound part is supported when mean_bayes_auroc >= mean_auroc_with - 0.002 and mean_bayes_auroc >= mean_auroc_without - 0.002. Both are read only if the reproduction check (|run_auroc of with/seed1 − B3| <= 0.002) and the convergence check (convergence_drop <= 0.01) pass.
- budget: 46 train.py runs, about 4 GPU-minutes at 4.4 s per run

### E3 (claims: C4, C5)

- design: Strength sweep with null control, at the default training size n0 (O4, K1, K4). Points: multipliers m in {0, 0.25, 0.5, 1, 2, 4} scale the weight on x3·x4 found in E1; m = 1 reuses E2's runs. Runs: at each other m, E2's protocol (seeds 1–20, both arms, pinned settings) writes to runs/E3/m<m>_n0/, and the oracle at that m supplies the ceiling. Analysis: `toy.paired` reports the paired statistics at each point; `toy.sweep runs/E3 --axis strength` reports strength_spearman, the Spearman correlation between m and the mean paired gain over the six points. If E1 finds the default weight is zero (A1), the multipliers become absolute weights {0, 0.25, 0.5, 1, 2, 4} on standardised x3·x4 in the log-odds. They are added through an opt-in generator parameter whose default leaves the draw unchanged.
- baselines: B1, B2
- data: D1, D3
- metrics: paired_gain, paired_gain_lo, paired_gain_hi, signed_rank_p, gap_closed, strength_spearman
- success: C4 is supported when, at m = 0, paired_gain_lo >= -0.01 and paired_gain_hi <= 0.01. C5 is supported when strength_spearman >= 0.9 and paired_gain_lo > 0 at m = 4.
- budget: 200 new train.py runs, about 15 GPU-minutes

### E4 (claims: C6)

- design: Training-size sweep at m = 1 and at m = 0 (O4, K4, K6). Sizes: n in {n0/16, n0/8, n0/4, n0/2, n0, 2·n0, 4·n0}, dropping any size under 200 training rows. - Sizes up to n0 cap the D1 draw's training rows at the first n, leaving the held-out fifth unchanged. - 2·n0 and 4·n0 draw n/0.8 rows and hold out the last fifth. Runs: 20 paired replicates per point (seeds 1–20, both arms, pinned settings) under runs/E4/m<m>_n<n>/. The (m=1, n0) and (m=0, n0) points reuse E2's and E3's runs. Analysis: `toy.paired` reports the paired statistics at each point. `toy.sweep runs/E4 --axis rows --strength 1` reports gain_shrink, the mean over seeds of (gain at the smallest size − gain at 4·n0), with a paired 95% CI. At m = 0, the paired difference at each size is the overfitting cost K4 asks about; it is reported per size, not claimed.
- baselines: B1, B2
- data: D1, D4
- metrics: paired_gain, paired_gain_lo, paired_gain_hi, gain_shrink, gain_shrink_lo
- success: C6 is supported when gain_shrink <= 0.005 at m = 1. A5 is confirmed instead when gain_shrink_lo > 0.005. Any outcome between the two is reported as unresolved.
- budget: 480 new train.py runs, about 1 GPU-hour (the 2·n0 and 4·n0 points take most of it)

### E5 (claims: C7)

- design: Goal loop on the default run (O2, K3). 1. Run train.py as it stands at the project's start, with no flags: its default seed (D5) and its default summary path. Read auroc with the goal command. If it is >= 0.82, the goal is met and nothing changes. 2. Otherwise, if E1's bayes_auroc is >= 0.82, try candidate changes to train.py's defaults within the same model class: epochs and learning rate, an L2 penalty, and input columns drawn from x1..x4 and their six pairwise products. 3. Choose each candidate by val_auroc, on runs with --val-fraction 0.2 that never read the held-out fifth. 4. Make the chosen candidate the default, retrain on all training rows, and score it once with the goal command. Keep it only if it beats the best kept value. Otherwise journal it `discarded`, leave it on its branch and file it as a negative result. 5. Score at most five candidates on the held-out fifth, and log each scoring in results/E5/changes.jsonl. If E1's ceiling is below 0.82 (A6), no candidate is tried, and a decision ticket puts the goal to the owner. The report sets the goal run beside E2's 20-seed mean_auroc_with (A7).
- baselines: B3
- data: D5
- metrics: auroc, val_auroc, heldout_reads
- success: C7 is supported when the goal command `PYTHONPATH=src python3 -m toy.eval --split held_out` prints auroc >= 0.82, heldout_reads <= 6, and every kept change was chosen by val_auroc.
- budget: under 60 train.py runs, about 5 GPU-minutes

### E6 (claims: C8)

- design: Literature placement (O1, K7, Q13). 1. Scout the five works of D6 to dossiers through literature tickets (`wayline absorb`). 2. Read each resolved work. 3. Write results/placement.json with one entry per work: slug, DOI, existence as its dossier states, measures_paired_gain, and the locator of the passage that settles it. measures_paired_gain is true when the work reports a held-out AUROC gain of an explicit product column over the same model without it, measured against a no-interaction control. `toy.placement results/placement.json` reads those entries and the dossiers under research/refs/, and prints resolved_refs and prior_measures_gain. The report places C3–C6 against the resolved works.
- baselines: none
- data: D6
- metrics: resolved_refs, prior_measures_gain
- success: C8 is supported when resolved_refs >= 4 and prior_measures_gain == 0. A9 is confirmed when prior_measures_gain >= 1. With resolved_refs < 4, C8 is reported unresolved.
- budget: no GPU; literature tickets only

## Baselines

- **B1.** The `without` arm: the same train.py model, optimiser, epochs, regularisation and paired seeds as the `with` arm, trained on x1..x4 alone with no x3·x4 column (--no-interaction). (source: Q14; src/toy/train.py featurize())
- **B2.** The Bayes-optimal oracle: it scores each held-out row with the true P(y=1|x) the generator draws its label from, and gives the ceiling no model can beat in expectation. (source: Q11; src/toy/oracle.py, written in E1 from src/toy/generate.py)
- **B3.** The owner's sample run: one with-term train.py run at seed 1 (4.4 s on the GPU). It is the reproduction reference for E2's replicate 1 and the starting value of the goal loop. It is read-only. (source: owner/sample-summary.json)
- **B4.** The additive reference: an unpenalised logistic regression on x1..x4, fit on the first half of the audit draw D2 and scored on the second half. It is the best an additive model does at large sample size. (source: E1; scikit-learn on CPU)

## Data

- **D1.** Replicate draws: generate.py at its default settings with seeds 1–20, where seed i drives replicate i. The training rows are the first four-fifths; the held-out fifth is the last (HELD_OUT_FRACTION = 0.2) and is used only for evaluation. (source: src/toy/generate.py; INTAKE.md)
- **D2.** Audit draw: 10^6 rows from generate.py at default settings, with seed 10001, outside every replicate's seeds. The oracle uses it only for calibration, the population ceiling and the additive reference. (source: src/toy/generate.py, opt-in rows parameter)
- **D3.** Strength draws: generate.py with the interaction strength multiplier m in {0, 0.25, 0.5, 2, 4} (m = 1 is D1), at default rows and seeds 1–20. They are written under runs/E3/ only. (source: src/toy/generate.py, opt-in strength parameter)
- **D4.** Size draws at m = 1 and m = 0, seeds 1–20, written under runs/E4/ only. Training rows are capped at n0/16, n0/8, n0/4 and n0/2 of the D1 draw, with the held-out fifth unchanged. Larger draws of 2·n0/0.8 and 4·n0/0.8 rows hold out their last fifth. (source: src/toy/generate.py, opt-in rows parameter; train.py --train-rows)
- **D5.** Goal draw: generate.py at its default seed and settings. The default train.py run trains on it and the goal command scores it. No other experiment writes over its summary. (source: src/toy/generate.py; O2's eval command)
- **D6.** Literature: the five works the position memo found by search. - doi:10.1214/07-aoas148 (Friedman & Popescu 2008) - doi:10.1145/2487575.2487579 (Lou et al. 2013) - doi:10.1214/13-aos1096 (Bien et al. 2013) - doi:10.2307/2531595 (DeLong et al. 1988) - doi:10.1162/089976698300017197 (Dietterich 1998) (source: research/POSITION.md, What the references lack)

## Metrics

- **auroc**: O2's measure: the held-out AUROC of the default train.py run, as eval.py prints it ('auroc: <value>') from the default summary. (script: `PYTHONPATH=src python3 -m toy.eval --split held_out`)
- **run_auroc**: The held-out AUROC of one arm run, computed by eval.py from that run's summary. (script: `PYTHONPATH=src python3 -m toy.eval --split held_out --summary runs/<E>/<point>/<arm>/seed<i>/summary.json`)
- **val_auroc**: The validation AUROC of a run trained with --val-fraction 0.2, where the validation split is the last fifth of the training rows. E5 chooses candidates by it. (script: `PYTHONPATH=src python3 -m toy.eval --split val --summary <run-dir>/summary.json`)
- **paired_gain**: The mean over replicates of d_i = AUROC_with,i − AUROC_without,i at one sweep point. (script: `PYTHONPATH=src python3 -m toy.paired runs/<E>/<point>`)
- **paired_gain_lo**: The lower bound of the 95% t-interval of paired_gain. (script: `PYTHONPATH=src python3 -m toy.paired runs/<E>/<point>`)
- **paired_gain_hi**: The upper bound of the 95% t-interval of paired_gain. (script: `PYTHONPATH=src python3 -m toy.paired runs/<E>/<point>`)
- **signed_rank_p**: The exact two-sided Wilcoxon signed-rank p over the replicates' d_i. (script: `PYTHONPATH=src python3 -m toy.paired runs/<E>/<point>`)
- **delong_rejections**: The number of replicates whose DeLong test of the two correlated AUROCs on their shared held-out rows rejects at 0.05. (script: `PYTHONPATH=src python3 -m toy.paired runs/<E>/<point>`)
- **gap_closed**: mean(d_i) / mean(bayes_i − AUROC_without,i): the share of the no-column arm's gap to the oracle ceiling that the column closes, with a paired bootstrap CI. Reported only when the denominator exceeds 0.005. (script: `PYTHONPATH=src python3 -m toy.paired runs/<E>/<point>`)
- **mean_auroc_with**: The mean held-out AUROC of the `with` arm over the replicates at a point. (script: `PYTHONPATH=src python3 -m toy.paired runs/<E>/<point>`)
- **mean_auroc_without**: The mean held-out AUROC of the `without` arm over the replicates at a point. (script: `PYTHONPATH=src python3 -m toy.paired runs/<E>/<point>`)
- **mean_bayes_auroc**: The mean over replicates of the oracle's AUROC on each replicate's held-out rows. (script: `PYTHONPATH=src python3 -m toy.paired runs/<E>/<point>`)
- **bayes_auroc**: The oracle's AUROC on the 10^6-row audit draw D2: the population Bayes-optimal AUROC of the default generator. (script: `PYTHONPATH=src python3 -m toy.oracle --seed 10001 --rows 1000000`)
- **bayes_auroc_halfwidth**: The DeLong 95% half-width of bayes_auroc. (script: `PYTHONPATH=src python3 -m toy.oracle --seed 10001 --rows 1000000`)
- **calibration_error**: On D2, with oracle probabilities in 20 equal-count bins: the largest absolute gap between a bin's mean label and its mean oracle probability. (script: `PYTHONPATH=src python3 -m toy.oracle --seed 10001 --rows 1000000`)
- **interaction_weight**: The weight the default generator's log-odds (or label rule) puts on x3·x4, read from generate.py and reported with its file and line. (script: `PYTHONPATH=src python3 -m toy.oracle --seed 10001 --rows 1000000`)
- **additive_gap**: On the second half of D2: the oracle's AUROC minus the AUROC of an unpenalised logistic regression on x1..x4 fit on the first half. (script: `PYTHONPATH=src python3 -m toy.oracle --seed 10001 --rows 1000000`)
- **strength_spearman**: The Spearman correlation between the strength multiplier m and paired_gain over E3's six points. (script: `PYTHONPATH=src python3 -m toy.sweep runs/E3 --axis strength`)
- **gain_shrink**: At m = 1, the mean over seeds of (d_i at the smallest kept size − d_i at 4·n0). It is positive when the gain shrinks as training rows grow. (script: `PYTHONPATH=src python3 -m toy.sweep runs/E4 --axis rows --strength 1`)
- **gain_shrink_lo**: The lower bound of gain_shrink's paired 95% t-interval. (script: `PYTHONPATH=src python3 -m toy.sweep runs/E4 --axis rows --strength 1`)
- **convergence_drop**: For replicates 1–3 in both arms, take the relative drop in final training loss from the pinned epochs to twice the pinned epochs; convergence_drop is the largest of these. (script: `PYTHONPATH=src python3 -m toy.converge runs/E2/converge`)
- **heldout_reads**: The number of times E5 scored the held-out fifth: the starting run plus each candidate. (script: `PYTHONPATH=src python3 -m toy.goallog results/E5/changes.jsonl`)
- **resolved_refs**: The number of D6's five works whose dossier existence is no longer 'unresolved'. (script: `PYTHONPATH=src python3 -m toy.placement results/placement.json`)
- **prior_measures_gain**: The number of resolved works in results/placement.json marked measures_paired_gain = true. (script: `PYTHONPATH=src python3 -m toy.placement results/placement.json`)

## Success criteria

- O3 is answered. The default generator's label mechanism is written down with its weight on x3·x4, and the Bayes ceiling is reported with a 95% half-width no larger than 0.002, from an oracle calibrated to within 0.01. (experiments: E1)
- O1 is answered, whichever way it comes out. The mean paired held-out AUROC gain of the x3·x4 column over 20 paired seeds is reported with its 95% CI, the exact signed-rank p, the DeLong rejection count, the mean AUROC of each arm, and the share of the gap to the ceiling it closes. (experiments: E1, E2)
- O4 is answered. Paired gains with 95% CIs are reported at every strength point and every size point, including strength zero at every size, together with strength_spearman and gain_shrink. (experiments: E3, E4)
- O2 is met when the goal command prints auroc >= 0.82 and nothing was chosen on the held-out fifth beyond the keep rule. If E1's ceiling is below 0.82, the shortfall is reported instead and the goal goes to the owner. (experiments: E1, E5)
- K7 is met: C3–C6 are placed against at least four resolved works in the report. (experiments: E6)
- Every seed run of E2–E4 is reported, and none is dropped. (experiments: E2, E3, E4)

## Budgets

- GPU: not set
- wall clock: not set
- usage windows: not set
- notes: INTAKE.md states no GPU-hour or wall-clock budget, and no decision sets one, so none is set here. The planner's estimate uses the 4.4 s per run in owner/sample-summary.json, which is unverified: - E2: 46 runs (about 4 min) - E3: 200 new runs (about 15 min) - E4: 480 new runs (about 1 h; the 2·n0 and 4·n0 points take most of it) - E5: under 60 runs - E1 and E6: no GPU That is about 1.5 GPU hours in all, or under 4 if Q15's revisit rule raises the seeds to 50. It fits one overnight run, as POSITION.md's compute note expects.

## Out of scope

- Competitor models that learn interactions unaided: gradient-boosted trees, MLPs, factorization machines, GA2M, and the hierarchical lasso as a fitted model. O5 is parked (Q4) and objection 2 was rejected (Q7), so the claims compare explicit terms only with the same model without them.
- Treatment arms beyond the x3·x4 column for O1 and O4, such as all pairwise products or learned term selection. Q14 left this open, and the spec takes x3·x4 alone.
- Sweeps over feature count or noise level. Objection 7 names them, but O4 and Q12 limit the claims to interaction strength and sample size.
- Any claim about tabular data beyond this generator, and any real dataset.
- Changes that belong to the owner (human-only data and objective classes): generate.py's default draw, the held-out rule (the last fifth, used only for evaluation), the goal's metric, target, split or command, and what leaves the machine.
- Redefining O2 as a mean over seeds (Q15).
- Building on research/intake/paper-c-source.tar.gz: no experiment needs it, and its contents are unread.
- Any expected effect size taken from paper-a or paper-b, whose dossiers are unresolved.

## Risks

- Q15 left the seed values open. The spec takes seeds 1–20 at every point of E2–E4, with generator seed i and training seed i. Replicate 1 can then be checked against owner/sample-summary.json, and sweep points share common random numbers. Mitigation: The seeds are written into configs/arms.json before any run. If train.py has only one seed, i drives both, which still varies the seeded stream as Q8 requires.
- Q15 left O4's grid and the analysis open. The spec takes: - strength multipliers {0, 0.25, 0.5, 1, 2, 4}; - sizes {n0/16 … 4·n0}; - a t-interval, an exact signed-rank test and per-replicate DeLong tests. Mitigation: The grid and the tests are fixed in this spec before any result is read. Changing them is a spec revision, never a reaction to a result.
- Q14 left open whether the treatment adds terms beyond x3·x4. The spec takes x3·x4 alone, the column train.py adds today, so all-pairs arms are out of scope for O1 and O4. Mitigation: B1 stays x1..x4 either way (Q14). An all-pairs arm can come back as a follow-up that probes C4's failure, citing E3's result.
- Q14 is to be revisited if either arm has not converged at the shared number of epochs. Mitigation: E2 checks convergence_drop <= 0.01 on replicates 1–3 using training loss, never held-out AUROC. If the check fails, a decision ticket revisits Q14 before E3 and E4 run.
- Under Q15's revisit rule, a per-seed SD above 0.02, or too wide an interval at E4's m = 0 or smallest-size points, means 20 seeds cannot separate a one-point gain from zero. Mitigation: Seeds 21–50 are added at the affected points, all 50 are reported, and the choice rests only on the interval's width.
- The model class train.py fits is unverified (Q14 says so). C6's prediction, that the gain does not shrink with size, assumes a model linear in its inputs. Mitigation: configs/arms.json records the model class read from train.py before E2. If the model can learn x3·x4 unaided, C6 is revised before E4 runs, and A5 becomes the expected outcome.
- D3 and D4 need opt-in strength and row-count parameters in generate.py. The owner opened O4, which asks for those draws (Q3). But changing the default draw or the held-out rule would be a human-only data decision. Mitigation: Both parameters default to today's draw, checked by a hash test: the SHA-256 of the default draw at seed 1 must match before and after. Sweep draws go only under runs/E3 and runs/E4. If a parameter cannot be added without changing the default draw, a decision ticket pauses E3 and E4 for the owner.
- generate.py may draw labels through latent noise with no closed form, or plant the interaction as a rule rather than a log-odds weight. Either would leave the oracle or the meaning of m unclear. Mitigation: The oracle integrates the noise by Monte Carlo until bayes_auroc_halfwidth <= 0.002, and calibration_error <= 0.01 checks the transcription. If there is no log-odds weight, m becomes an opt-in absolute weight on standardised x3·x4 (A1).
- The goal's keep rule reads the held-out fifth once per candidate, so the best kept value is selected over several reads (K3). Mitigation: Candidates are chosen by val_auroc, at most five are scored on held-out, heldout_reads is reported, and the goal run is set beside E2's 20-seed mean (A7).
- E1's ceiling may fall below 0.82, which would make O2 unreachable on the default generator. Mitigation: Then no candidate is tried, and a decision ticket of the objective class puts the goal to the owner. The generator, split and goal are not changed (A6).
- train.py's summary may not carry per-row held-out scores, and the DeLong tests and the oracle pairing need them. Mitigation: train.py gets an opt-in --save-scores that writes heldout_scores.csv into the run directory. The default summary stays as it is.
- Some D6 DOIs may not resolve, or their full text may be unavailable. Mitigation: With resolved_refs < 4, C8 is reported unresolved rather than asserted, and the report says which works were read.
- GPU nondeterminism can keep replicate 1 from reproducing B3 exactly. Mitigation: The reproduction check allows 0.002 AUROC. A larger gap stops E2 until the cause is found and recorded.

## Seams

- **generate.py**: Gets opt-in parameters for the seed, the total rows and the interaction strength multiplier m. Called with no new arguments, it returns the same rows as today, checked by a test comparing the SHA-256 of the default draw at seed 1 before and after. Each row keeps x1..x4, 'interaction' (x3·x4) and the label.
- **train.py**: Flags: --seed i, --no-interaction (featurize() drops row['interaction']), --strength m, --rows N, --train-rows n, --val-fraction f, --config configs/arms.json, --out DIR and --save-scores. With no flags it runs exactly as today and writes the summary the goal command reads. With --out it writes only under DIR: never over that summary, and never into owner/.
- **Run directory**: runs/<E>/m<m>_n<n>/<with|without>/seed<i>/ holds three files: - summary.json, as train.py writes it, plus the final training loss; - heldout_scores.csv, with row index, label and score; - config.json, with the seeds, arm, m, rows and pinned settings. Every analysis module reads only this layout.
- **eval.py**: Gets an opt-in --summary PATH and a --split val. With neither, it reads the default summary and prints 'auroc: <value>' as today, so O2's command `PYTHONPATH=src python3 -m toy.eval --split held_out` is unchanged.
- **toy.oracle**: true_prob(rows, m) returns P(y=1|x). The CLI prints JSON with bayes_auroc, bayes_auroc_halfwidth, calibration_error, interaction_weight and additive_gap. toy.paired calls true_prob to score each replicate's held-out rows.
- **toy.paired, toy.sweep, toy.converge**: - `toy.paired <point-dir>` prints JSON with paired_gain, paired_gain_lo, paired_gain_hi, signed_rank_p, delong_rejections, gap_closed, mean_auroc_with, mean_auroc_without, mean_bayes_auroc and n_pairs. - `toy.sweep <exp-dir> --axis strength|rows` prints strength_spearman, or gain_shrink and gain_shrink_lo, with a table per point. - `toy.converge` prints convergence_drop. Each is tested on a fixture directory of known scores whose answers are worked out by hand.
- **configs/arms.json**: The pinned model class, optimiser, epochs, learning rate, regularisation and seed list, recorded from train.py before any arm runs. E2–E4 pass it explicitly. E5 never edits it.
- **results/E5/changes.jsonl and toy.goallog**: One line per held-out scoring in E5: the candidate, its val_auroc, its held-out auroc, and whether it was kept or discarded. toy.goallog prints heldout_reads.
- **results/placement.json and toy.placement**: One entry per D6 work: slug, doi, existence, measures_paired_gain and locator. toy.placement cross-checks each entry's existence against research/refs/<slug>/dossier.json and prints resolved_refs and prior_measures_gain.

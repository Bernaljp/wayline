# Report: toy

<!-- wayline:records -->
Code renders this general report from the ledger alone, after every integration and at the tick, and never reads it back: an edit of it is kept in git as it stood and is not taken in. It was rendered from `research/journal.jsonl` (5501 events), `findings.jsonl`, `results.json`, `objectives.json`, `concerns.json`, `passages.jsonl`, `spec.json`, and `manifest.json`. The provenance linter passed: 272 claim sentence(s), 272 tagged.

What wayline did, what it decided for you, and what waits on you are in [ACCOUNT.md](ACCOUNT.md).

The run-end gates failed these claims; each stays marked until its scope-down narrows it:

- At E1's 10^6 rows (50,000 per bin, SE <= 0.0023), the spec's <= 0.01 threshold is about 4 SE and is a meaningful test. (its sampled verdict failed; no scope-down is open for it)
- On the fixture the maximum is 0.05, from the without arm at seed 2. (its sampled verdict failed; no scope-down is open for it)
- At E1's 10^6 rows (50,000 per bin, SE <= 0.0023), the spec's <= 0.01 threshold is about 4 SE and is a meaningful test. (its sampled verdict failed; no scope-down is open for it)
- `t53-a1-f1` The committed test holds the audit of the default draw D2 (seed 10001, 1000000 rows) to a wall-clock limit of 3600 seconds and a peak child memory limit of 4.0 GB, and the audit passed both when the test was run. (its sampled verdict failed; no scope-down is open for it)
- `t131-a1-f2` (negative) No module in src/toy implements a keep rule. toy.goallog reads each candidate's `kept` field (true, false, or null), checks it is the same on every line of that candidate, and counts kept and discarded. (its sampled verdict failed; no scope-down is open for it)
<!-- /wayline:records -->

## 1. What the project is

<!-- wayline:records -->
This project asks whether giving a classifier an explicit feature-interaction column, the product x3·x4, raises its held-out AUROC on the synthetic two-class data drawn by src/toy/generate.py, and by how much. It first reads the generator to learn whether that interaction is planted in the label and what the best achievable (Bayes-optimal) AUROC is. It then trains the same model with and without the column on 20 paired seeds. It reports the mean AUROC difference with a 95% confidence interval and paired tests, and also as a share of the gap to that ceiling. A run with no planted interaction, plus sweeps over interaction strength and training size, show whether the gain comes from the generator. Separately, it tries to reach the owner's goal of 0.82 held-out AUROC without tuning on held-out data.
<!-- /wayline:records -->

## 2. Headlines

<!-- wayline:records -->
- R1 Default draw stays fixed under the strength parameter (supported): The feature columns, the `interaction` column and the random stream do not depend on `strength`, because the Gaussian noise draw is made regardless.[^1]
- R2 Adding the interaction flags leaves the default training run unchanged (supported): In the without arm (--no-interaction), the weight on the zeroed x3*x4 column keeps its initial value through training (Adam with zero gradient and weight_decay 0).[^2]
- R3 The statistics code agrees with independent reference implementations (supported): The tie-handling checks are small: the tied signed-rank p is checked on a single vector of 10 differences with 5 distinct magnitudes, and DeLong and Spearman on ties are checked on 5 draws each.[^3]
- R4 The oracle's true class probability matches the generator (mixed): At eight values of mu from -20 to 20, the 48-node Gauss-Hermite estimate of the logistic-normal integral agrees with the 96-node estimate within QUADRATURE_TOLERANCE = 1e-10.[^4]
- R5 The convergence check flags only a training loss that still falls (supported): toy.converge needs `epochs` in each run's config.json and `final_train_loss` in each summary.json, in both the pinned point and the converge dir.[^5]
- R6 Oracle audit cost on the 10^6-row draw D2 (supported): The committed test holds the audit of the default draw D2 (seed 10001, 1000000 rows) to a wall-clock limit of 3600 seconds and a peak child memory limit of 4.0 GB, and the audit passed both when the test was run.[^6]
- R7 E2 gate: reproduction and convergence (supported): The largest absolute change in final training loss from 30 to 60 epochs, 0.0016, is small next to the 0.1021 gap in mean final training loss at 30 epochs between the without arm (0.5765) and the with arm (0.4744).
- R8 The paired statistics of a sweep point, checked by hand and against their records (supported): At this sweep point the with arm's held-out AUROC falls short of the Bayes ceiling by 0.0009 on average over the seeds.[^7]
- R9 The evaluation command never reads the held-out score when selecting on validation (supported): toy.eval accepts a run directory from every summary source, not only from --summary: read_metric passes every artifact through summary_path, so a positional path or a WAYLINE_ARTIFACT that names a directory has its summary.json read.[^8]
- R10 How a prior work counts as settled in the literature placement (supported): An entry with no dossier agrees only when its existence is 'missing', and it then counts as unresolved.[^9]
- R11 E1: planted interaction, additive gap and Bayes ceiling on D2 (mixed): The oracle's AUROC on the scored half of D2 and the Bayes AUROC on all of D2 differ by 0.0008.[^10]
- R12 Evaluation command (supported): Tests now cover the case where WAYLINE_ARTIFACT or the positional path names a run directory: toy.eval reads the summary.json inside it and prints its auroc.[^11]
- R13 E6: literature placement of C3-C6 (C8) (mixed): Friedman 2008, Lou 2013 and Bien 2013, the three works about interaction models, are still unsettled.[^12]
- R14 E2: paired AUROC gain of the x3*x4 column over 20 seeds (mixed): A7 does not hold: E2's mean with-arm AUROC over 20 paired seeds is 0.8552220917946025, above the goal of 0.82, as the goal run is [^13] [^14] [^15] [^16].
- R15 E3: paired gain across interaction strengths (C4, C5) (mixed): The largest SD of d_i over the 6 points is 0.008461534756361957 [^17] [^18].
- R16 E4: paired gain across training sizes (C6) (mixed): No point of either size sweep has an SD of d_i above Q15's SD rule of 0.02, so seeds beyond 20 are not added; the largest SD over the 14 points is 0.006798902574422248 [^19] [^20] [^21] [^22] [^23].
- R17 E5: the goal run against O2's 0.82 (C7) (mixed): C7 is supported: the goal run's auroc is at least 0.82, the held-out reads are within 6, and every kept change was chosen by val_auroc, which holds trivially because no change was kept [^24] [^25] [^26] [^27] [^28] [^29] [^30].
- R18 Documentation site for the toy package, with the docstrings its build checks for (negative): No module in src/toy implements a keep rule.
<!-- /wayline:records -->

## 3. The results

| Result | Objectives | Standing | Findings | Current report | Last change |
|---|---|---|---|---|---|
| R1 Default draw stays fixed under the strength parameter | O3, O4 | supported | 2 current | [R1-1](reports/R1-1.md) | 2026-10-24 |
| R2 Adding the interaction flags leaves the default training run unchanged | O1, O2, O4 | supported | 2 current | [R2-1](reports/R2-1.md) | 2026-10-25 |
| R3 The statistics code agrees with independent reference implementations | O1, O3, O4 | supported | 8 current | [R3-1](reports/R3-1.md) | 2026-10-25 |
| R4 The oracle's true class probability matches the generator | O1, O3 | **mixed** | 8 current, 1 negative, 1 replaced | none yet | 2026-10-25 |
| R5 The convergence check flags only a training loss that still falls | O1 | supported | 2 current | none yet | 2026-10-25 |
| R6 Oracle audit cost on the 10^6-row draw D2 | O3 | supported | 1 current | none yet | 2026-10-24 |
| R7 E2 gate: reproduction and convergence | O1 | supported | 8 current, 6 replaced | [R7-1](reports/R7-1.md) | 2026-10-25 |
| R8 The paired statistics of a sweep point, checked by hand and against their records | O1, O3, O4 | supported | 8 current, 2 replaced | [R8-1](reports/R8-1.md) | 2026-10-25 |
| R9 The evaluation command never reads the held-out score when selecting on validation | O1, O2 | supported | 3 current | none yet | 2026-10-25 |
| R10 How a prior work counts as settled in the literature placement | O1 | supported | 2 current | none yet | 2026-10-25 |
| R11 E1: planted interaction, additive gap and Bayes ceiling on D2 | O3 | **mixed** | 17 current, 2 negative | [R11-1](reports/R11-1.md) | 2026-10-25 |
| R12 Evaluation command | O2 | supported | 1 current | none yet | 2026-10-24 |
| R13 E6: literature placement of C3-C6 (C8) | O1 | **mixed** | 5 current, 2 negative, 2 replaced | none yet | 2026-10-24 |
| R14 E2: paired AUROC gain of the x3*x4 column over 20 seeds | O1, O2, O3 | **mixed** | 15 current, 1 negative, 16 replaced | none yet | 2026-10-25 |
| R15 E3: paired gain across interaction strengths (C4, C5) | O4 | **mixed** | 19 current, 2 negative, 26 replaced | none yet | 2026-10-25 |
| R16 E4: paired gain across training sizes (C6) | O4 | **mixed** | 22 current, 4 negative | none yet | 2026-10-25 |
| R17 E5: the goal run against O2's 0.82 (C7) | O2 | **mixed** | 8 current, 1 negative | none yet | 2026-10-25 |
| R18 Documentation site for the toy package, with the docstrings its build checks for | none | **negative** | 2 current, 2 negative | none yet | 2026-10-25 |

## 4. Objectives

### O1. Do the interaction terms help, and by how much? (whether adding feature interaction terms improves held-out AUROC on a synthetic two-class set)

<!-- wayline:records -->
Status: answered. Answer: Yes. On this generator at its default settings, the x3·x4 interaction column raises held-out AUROC by about 0.087. Over 20 paired replicates, the same logistic model scores a mean held-out AUROC of 0.768056736529607 without the column and 0.8552220917946025 with it [^31] [^32] [^33]. The mean paired gain is 0.08716535526499543, and its t-interval at confidence 0.95 runs from 0.08434218983093059 to 0.08998852069906027 [^34] [^35] [^36] [^37]. The column helped on every seed: all 20 per-seed differences are positive, the exact signed-rank p is 1.9073486328125e-06, and C3 is supported [^38] [^39] [^40] [^41]. That gain closes a fraction 0.9896174437934124 of the gap between the model without the column and the Bayes ceiling, with a bootstrap interval from 0.9855017415149592 to 0.9935291766371139, against an oracle mean AUROC of 0.8561365857801138 [^42] [^43] [^44] [^45]. How much the column helps depends entirely on how strong an interaction generate.py plants. With no planted interaction (m = 0), the mean paired gain is -0.0003186665215305473, with an interval from -0.0005967640897244911 to -4.056895333660356e-05, which lies inside the harmlessness band of -0.01 to 0.01 [^46] [^47] [^48] [^49] [^50] [^51]. At m = 4 the gain is 0.31434161002887523, and it rises at every step of the strength grid, with a Spearman correlation of 1.0 [^52] [^53] [^54] [^55]. Training size barely changes the result. At the default strength, the gain stays between 0.08714270655297177 and 0.08786251131921252 across the 7 training sizes from 1000 to 64000 rows, and C6 is supported [^56] [^57] [^58] [^59] [^60] [^61]. The answer is therefore a yes for this generator only. The gain is about zero when nothing is planted and grows with the planted strength, so A3 is confirmed: the gain repeats what generate.py puts into the labels and says nothing about interaction terms on data outside this generator [^62].

Evidence: `res:t120-a1/analysis/E2/paired.json#mean_auroc_without`, `res:t120-a1/analysis/E2/paired.json#mean_auroc_with`, `res:t120-a1/analysis/E2/paired.json#n_pairs`, `res:t120-a1/analysis/E2/paired.json#paired_gain`, `res:t120-a1/analysis/E2/paired.json#paired_gain_lo`, `res:t120-a1/analysis/E2/paired.json#paired_gain_hi`, `res:t120-a1/analysis/E2/verdict.json#confidence`, `res:t120-a1/analysis/E2/verdict.json#n_positive_d`, `res:t120-a1/analysis/E2/verdict.json#n_pairs`, `res:t120-a1/analysis/E2/paired.json#signed_rank_p`, `res:t120-a1/analysis/E2/verdict.json#c3_supported`, `res:t120-a1/analysis/E2/paired.json#gap_closed`, `res:t120-a1/analysis/E2/paired.json#gap_closed_lo`, `res:t120-a1/analysis/E2/paired.json#gap_closed_hi`, `res:t120-a1/analysis/E2/paired.json#mean_bayes_auroc`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.m`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.paired_gain`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.paired_gain_lo`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.paired_gain_hi`, `res:t122-a2/analysis/E3/verdict.json#harmless_lo`, `res:t122-a2/analysis/E3/verdict.json#harmless_hi`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m4.m`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m4.paired_gain`, `res:t122-a2/analysis/E3/verdict.json#gain_monotone_in_strength`, `res:t122-a2/analysis/E3/verdict.json#strength_spearman`, `res:t110-a1/analysis/E4/verdict.json#m1_min_paired_gain`, `res:t110-a1/analysis/E4/verdict.json#m1_max_paired_gain`, `res:t110-a1/analysis/E4/verdict.json#n_sizes`, `res:t110-a1/analysis/E4/verdict.json#smallest_train_rows`, `res:t110-a1/analysis/E4/verdict.json#largest_train_rows`, `res:t110-a1/analysis/E4/verdict.json#c6_supported`, `res:t122-a2/analysis/E3/verdict.json#a3`.

Concerns:
- K2 (answered: O1: Yes. On this generator at its default settings, the x3·x4 interaction column raises held-out AUROC by about 0.087. Over 20 paired replicates, the same logistic model scores a mean held-out AUROC of 0.768056736529607 without the column and 0.8552220917946025 with it [^31] [^32] [^33]. The mean paired gain is 0.08716535526499543, and its t-interval at confidence 0.95 runs from 0.08434218983093059 to 0.08998852069906027 [^34] [^35] [^36] [^37]. The column helped on every seed: all 20 per-seed differences are positive, the exact signed-rank p is 1.9073486328125e-06, and C3 is supported [^38] [^39] [^40] [^41]. That gain closes a fraction 0.9896174437934124 of the gap between the model without the column and the Bayes ceiling, with a bootstrap interval from 0.9855017415149592 to 0.9935291766371139, against an oracle mean AUROC of 0.8561365857801138 [^42] [^43] [^44] [^45]. How much the column helps depends entirely on how strong an interaction generate.py plants. With no planted interaction (m = 0), the mean paired gain is -0.0003186665215305473, with an interval from -0.0005967640897244911 to -4.056895333660356e-05, which lies inside the harmlessness band of -0.01 to 0.01 [^46] [^47] [^48] [^49] [^50] [^51]. At m = 4 the gain is 0.31434161002887523, and it rises at every step of the strength grid, with a Spearman correlation of 1.0 [^52] [^53] [^54] [^55]. Training size barely changes the result. At the default strength, the gain stays between 0.08714270655297177 and 0.08786251131921252 across the 7 training sizes from 1000 to 64000 rows, and C6 is supported [^56] [^57] [^58] [^59] [^60] [^61]. The answer is therefore a yes for this generator only. The gain is about zero when nothing is planted and grows with the planted strength, so A3 is confirmed: the gain repeats what generate.py puts into the labels and says nothing about interaction terms on data outside this generator [^62].): 'By how much' comes from one seeded stream and one held-out fifth, with no variance across seeds and no paired test. With a fixed seed, a difference of a point or two of AUROC may be noise.
- K7 (answered: O1: Yes. On this generator at its default settings, the x3·x4 interaction column raises held-out AUROC by about 0.087. Over 20 paired replicates, the same logistic model scores a mean held-out AUROC of 0.768056736529607 without the column and 0.8552220917946025 with it [^31] [^32] [^33]. The mean paired gain is 0.08716535526499543, and its t-interval at confidence 0.95 runs from 0.08434218983093059 to 0.08998852069906027 [^34] [^35] [^36] [^37]. The column helped on every seed: all 20 per-seed differences are positive, the exact signed-rank p is 1.9073486328125e-06, and C3 is supported [^38] [^39] [^40] [^41]. That gain closes a fraction 0.9896174437934124 of the gap between the model without the column and the Bayes ceiling, with a bootstrap interval from 0.9855017415149592 to 0.9935291766371139, against an oracle mean AUROC of 0.8561365857801138 [^42] [^43] [^44] [^45]. How much the column helps depends entirely on how strong an interaction generate.py plants. With no planted interaction (m = 0), the mean paired gain is -0.0003186665215305473, with an interval from -0.0005967640897244911 to -4.056895333660356e-05, which lies inside the harmlessness band of -0.01 to 0.01 [^46] [^47] [^48] [^49] [^50] [^51]. At m = 4 the gain is 0.31434161002887523, and it rises at every step of the strength grid, with a Spearman correlation of 1.0 [^52] [^53] [^54] [^55]. Training size barely changes the result. At the default strength, the gain stays between 0.08714270655297177 and 0.08786251131921252 across the 7 training sizes from 1000 to 64000 rows, and C6 is supported [^56] [^57] [^58] [^59] [^60] [^61]. The answer is therefore a yes for this generator only. The gain is about zero when nothing is planted and grows with the planted strength, so A3 is confirmed: the gain repeats what generate.py puts into the labels and says nothing about interaction terms on data outside this generator [^62].): The cited support is unusable. Both references are unresolved, and their own abstracts say they were written for a test fixture and never submitted, so the work has no real prior work to stand on.
<!-- /wayline:records -->

#### R2. Adding the interaction flags leaves the default training run unchanged (supported)

- `t3-a1-f1` At the base commit 4a72047, `toy.train --seed 1 --rows 2000 --epochs 2 --device cpu` gives held-out auroc 0.8352720450281426.[^63] After this change the same command with no new flag gives exactly the same value on CPU.[^63]
- `t3-a1-f2` In the without arm (--no-interaction), the weight on the zeroed x3*x4 column keeps its initial value through training (Adam with zero gradient and weight_decay 0).[^2] Both arms draw identical initial weights from the shared seed.[^2]

<!-- wayline:records -->
Current report: [R2-1](reports/R2-1.md).

Synthesis: This result is a code change checked by tests, and its only artifact is the test file: it holds one recorded number, the held-out AUROC of a short smoke run, and two equality assertions on the model's weights. None of that is a series, a distribution, or a comparison across conditions, so there is nothing a plot would show that the table does not. The table gathers what the change guarantees: the default run reproduces its base-commit AUROC of 0.8353 exactly on cpu, and the without arm differs from the with arm only in that its interaction weight never moves from a shared starting point.
<!-- /wayline:records -->

#### R3. The statistics code agrees with independent reference implementations (supported)

- `t5-a3-f1` toy.stats's exact two-sided signed-rank p agrees with scipy.stats.wilcoxon(method='exact') to 12 decimal places on ten 20-replicate draws without ties.[^64]
- `t5-a3-f2` On tied differences, toy.stats's exact signed-rank p agrees to 12 decimal places with scipy.stats.wilcoxon under an exhaustive PermutationMethod (n_resamples=10000).[^65]
- `t5-a3-f3` toy.stats's 95% t-interval bounds agree with scipy.stats.t.interval to 10 decimal places.[^66]
- `t5-a3-f4` On tied scores, toy.stats's midrank DeLong AUROCs and covariance agree with a literal pairwise DeLong kernel to an absolute tolerance of 1e-12.[^67]
- `t5-a3-f5` toy.stats's Spearman rho agrees with scipy.stats.spearmanr on tied integer data to 12 decimal places.[^68]
- `t5-a3-f6` toy.stats's paired percentile bootstrap CI for a ratio of means lies within 0.05 times the interval's width of scipy.stats.bootstrap(paired=True, method='percentile'), each with 10000 resamples.[^69]
- `t136-a1-f1` R3's 5 deterministic checks hold toy.stats to between 10 and 12 decimal places (or an absolute 1e-12) on 26 cases.[^70] The sixth check, the paired bootstrap interval, is held only to 0.05 of the interval's width.[^70] The artifact records that each assertion passed, not how large the observed differences were.[^70]
- `t136-a1-f2` The tie-handling checks are small: the tied signed-rank p is checked on a single vector of 10 differences with 5 distinct magnitudes, and DeLong and Spearman on ties are checked on 5 draws each.[^3]

<!-- wayline:records -->
Current report: [R3-1](reports/R3-1.md).

Synthesis: R3 is a correctness result, and its only artifact is the test file that states the comparisons; it records no computed values, only assertions that passed. Read as a table, it says the deterministic statistics (t-interval, exact signed-rank p with and without ties, DeLong covariance on tied scores, Spearman on ties) match an independent reference to between 10 and 12 decimal places, while the bootstrap interval, random on both sides, is held to a looser 0.05 of its width. The tied cases matter for this project because AUROC scores and paired differences can tie; the ties checks are single-vector or few-draw checks (1 tied signed-rank vector, 5 DeLong and 5 Spearman draws).
<!-- /wayline:records -->

#### R4. The oracle's true class probability matches the generator (mixed)

- `t6-a1-f1` generate.py builds the latent log-odds as signal times (0.6 x1 - 0.4 x2 + 1.1 strength x3 x4), adds Gaussian noise with mean 0.0 and sd NOISE_SD = 1.0, and draws the label as a coin flip with the logistic of that latent as its probability.[^71] Because the noise enters before the logistic, P(y=1|x) is the logistic-normal integral E[sigmoid(mu(x) + e)], not sigmoid(mu(x)).[^71]
- `t6-a1-f2` Run at its defaults, the oracle's CLI reports interaction_weight 4.4 and interaction_coefficient 1.1 for the log-odds weight the generator puts on x3·x4.[^72]
- `t6-a1-f3` Leaving out the latent noise miscalibrates the oracle: on 200,000 rows at seed 101, the 20-bin calibration error is at most 0.02 for true_prob, while sigmoid(mu(x)) exceeds 0.03.[^73]
- `t6-a1-f4` (negative) At 20,000 rows the 20-bin calibration error is mostly sampling noise, even for the exact P(y=1|x).[^74] With about 1,000 rows per bin, a bin's mean label has an SE of up to about 0.016, and seed 7 gives a largest gap of 0.034.[^74] The bins' chi-square on 20 df stays below 45.31, its 0.999 quantile, so a 0.02 threshold on the largest gap is not a test at that size.[^74] At E1's 10^6 rows (50,000 per bin, SE <= 0.0023), the spec's <= 0.01 threshold is about 4 SE and is a meaningful test.[^74]
- `t6-a1-f5` true_prob matches labels drawn by generate.row itself at fixed features to within 4 binomial SEs over 10^5 draws each.[^75] The test covers six (x, m) cases, including m = 0 and m = 2.5.[^75] At m = 0 the probability does not change with x3·x4.[^75]
- `t52-a1-f1` At seed 7 with 20,000 rows (1,000 per bin), the oracle's 20-bin calibration error is 0.034 to within 0.0005.[^76] That is above 0.02 but below three times the largest possible per-bin standard error, 0.5/sqrt(1000) ≈ 0.0158.[^76] The worst bin's gap is below sqrt(45.31) of its own standard errors.[^76] So at this size the largest gap is sampling noise, not miscalibration.[^76]
- `t52-a1-f2` The oracle's interaction_weight is the unrounded product signal·(1.1·m).[^77] With signal 3.0 it is 3.3000000000000003, not 3.3.[^77]
- `t52-a4-f1` (replaces `t52-a1-f3`) At eight values of mu from -20 to 20, the 48-node Gauss-Hermite estimate of the logistic-normal integral agrees with the 96-node estimate within QUADRATURE_TOLERANCE = 1e-10.[^4] It agrees with a trapezoid rule of step 0.002 over ±12 sd within 1e-9.[^4]

#### R5. The convergence check flags only a training loss that still falls (supported)

- `t8-a2-f1` toy.converge's convergence_drop is the maximum signed relative drop, so a run whose training loss rose at doubled epochs counts as a negative drop and cannot trip the 0.01 gate; only a loss that still falls by more than 1% does.[^78] On the fixture the maximum is 0.05, from the without arm at seed 2.[^78]
- `t8-a2-f2` toy.converge needs `epochs` in each run's config.json and `final_train_loss` in each summary.json, in both the pinned point and the converge dir.[^5] Ticket 3 (train.py run directory) and ticket 16 (E2) must write those key names, or converge exits 2.[^5]

#### R7. E2 gate: reproduction and convergence (supported)

- `t104-a2-f1` (replaces `t65-a1-f1`) The first replicate's with-arm run_auroc is 0.8502984862625299. [^79]
- `t104-a2-f2` (replaces `t65-a1-f2`) The owner's B3 auroc is 0.8502984862625299, so the reproduction gap from the first replicate's with-arm run_auroc is 0.0, within the reproduction limit of 0.002, and the reproduction check passes. [^80] [^81] [^82] [^83]
- `t104-a2-f3` (replaces `t65-a1-f3`) The with arm, seed 2 rerun at 60 epochs, twice the pinned count, ends with final training loss 0.47609663009643555. [^84]
- `t104-a2-f4` (replaces `t65-a1-f4`) The with arm, seed 2 run at the pinned 30 epochs ends with final training loss 0.4777405858039856. [^84]
- `t104-a2-f5` (replaces `t65-a1-f5`) convergence_drop, the largest relative final-training-loss drop at doubled epochs over the 6 reruns, is 0.0034411053956896914, from the with arm at seed 2, within the convergence limit of 0.01, so the convergence check passes. [^85] [^86] [^87] [^88] [^84]
- `t104-a2-f6` (replaces `t65-a1-f6`) 3 of the 6 reruns have a negative drop, meaning their final training loss rose slightly at doubled epochs: with seed 1 (-9.576918490834106e-05), with seed 3 (-0.0011270855050454275) and without seed 3 (-0.0023886381464950255). [^89] [^86] [^90]
- `t140-a1-f1` Doubling epochs changes the final training loss by noise, not by a steady fall: the 6 relative drops average 0.00025, 3 of them are negative, and the largest is 0.34 of the 0.01 convergence limit. [^91]
- `t140-a1-f2` The largest absolute change in final training loss from 30 to 60 epochs, 0.0016, is small next to the 0.1021 gap in mean final training loss at 30 epochs between the without arm (0.5765) and the with arm (0.4744). [^92]

<!-- wayline:records -->
Current report: [R7-1](reports/R7-1.md).

Headline plot R7.1 (dot plot (Cleveland), one row per run, with reference lines):

![R7.1](../drawings/R7-1/convergence_drop.png)

- Purpose: Did any of the 6 reruns keep learning when its epochs were doubled, and by how much compared with the gate's convergence limit?
- Data: From analysis/E2/checks.json per_run: for each of the 6 reruns (3 seeds each for the with-x3·x4 arm, blue dots, and the without arm, orange dots), the relative drop (loss_pinned - loss_double) / loss_pinned, recomputed by the script from the two losses and matching the stored drop exactly (largest recompute error 0.0). Rows are categories, so dots are not joined. The black dashed lines mark ±0.01: the gate tests only the largest drop against +0.01; the line at -0.01 is drawn as a mirror for scale. The light-blue dotted line marks zero (no change).
- What it shows: Every dot sits near zero, well inside the dashed lines. The largest drop, 0.0034 for the with arm at seed 2, is 0.34 of the 0.01 limit; the most negative, -0.0024 for the without arm at seed 3, means its loss rose slightly at 60 epochs. 3 of the 6 drops are negative and the mean drop is 0.00025, so doubling epochs moves the final loss by noise-sized amounts in both directions rather than in a consistent downward direction.

Synthesis: R7 is a gate, and both of its checks pass with room to spare. On reproduction, the first replicate's with-arm AUROC equals the owner's B3 AUROC exactly (gap 0.0, limit 0.002), so the pipeline reproduces the owner's baseline number. On convergence, doubling training from 30 to 60 epochs changes final training loss by at most 0.0034 in relative terms (0.34 of the 0.01 limit), and the 6 drops are split in sign (3 negative, mean 0.00025): what is left at 30 epochs looks like run-to-run noise, not unfinished training. Next to these changes, the gap in final training loss between the arms (0.1021 in mean loss at 30 epochs) is far larger. That fits the interaction column being useful, but this artifact holds training loss only, not held-out AUROC.
<!-- /wayline:records -->

#### R8. The paired statistics of a sweep point, checked by hand and against their records (supported)

- `t76-a1-f1` On the hand-worked fixture (three replicates, 10 held-out rows each), toy.paired reproduces every hand-derived answer: paired_gain 2/15 with a t-interval half-width of t(0.975, 2)·sqrt(79)/75, sd_d sqrt(237)/75, signed_rank_p 0.5, delong_rejections 1 (seed 2 only), mean Bayes AUROC 2.8/3, and gap_closed 10/17 with a paired-bootstrap CI of exactly (-1/3, 0.9).[^93]
- `t115-a1-f1` toy.paired exposes point_stats(point_dir) as its one-point entry point, with paired kept as an alias of the same function, and its command line writes the printed JSON to --out PATH when given.[^94]
- `t115-a1-f2` When the gap left by the without arm is at most 0.005, summarize sets gap_closed and its CI to null and fills gap_closed_reason with a sentence; when gap_closed is reported, gap_closed_reason is null.[^95]
- `t116-a2-f1` (replaces `t76-a1-f2`) toy.paired refuses, with exit 2, a point whose two arms ran different seeds, a seed whose arms disagree on the draw (seed, strength, signal, rows, train_rows), arms that scored different labels, labels that are not the held-out rows the recorded settings draw, a summary auroc that is not the AUROC of its own saved scores, a run filed under the wrong arm, missing or out-of-order scores, and a point whose replicates disagree on any compared setting.[^96]
- `t116-a2-f2` (replaces `t116-a1-f1`) toy.paired refuses a seed whose arms disagree on any training setting train.py records (val_fraction, epochs, lr, minibatch, the pinned config's content) and names that key.[^97] It refuses a with run without the interaction column, a without run that kept it, and a run whose config.json lacks any compared key or features.[^97] It still pairs arms that differ only in batch_size, dataloader_workers, device or the config path, and their statistics come out unchanged.[^97]
- `t141-a1-f1` Recomputed from toy.paired's own per-seed records at this sweep point, the paired gain, its sd, gap_closed and the mean AUROCs of both arms and the oracle all equal the summary values toy.paired reported.[^98]
- `t141-a1-f2` A seeded paired bootstrap of gap_closed, redrawn from the point's per-seed records, gives percentile bounds within 0.00004 of the CI toy.paired reported.[^99]
- `t141-a1-f3` At this sweep point the with arm's held-out AUROC falls short of the Bayes ceiling by 0.0009 on average over the seeds.[^7]

<!-- wayline:records -->
Current report: [R8-1](reports/R8-1.md).

Headline plot R8.1 (paired dot plot (dumbbell) with a reference tick):

![R8.1](../drawings/R8-1/arms_per_seed.png)

- Purpose: How far does each arm get on each seed, and how close does the with arm come to the oracle ceiling?
- Data: toy.paired's per-seed records in analysis/E2/paired.json (strength 1.0, signal 4.0, 20 paired seeds, 4000 held-out rows each). Orange circles: held-out AUROC without the interaction column. Blue squares: with it. Grey segment: joins one seed's two arms. Black tick: that seed's Bayes AUROC from the oracle. Seeds are categories, so no line runs across them.
- What it shows: On every seed the with arm sits just under its own ceiling, while the without arm lies far below it. The mean AUROCs are 0.768 without, 0.855 with and 0.856 for the ceiling.

Headline plot R8.2 (strip plot with a point-and-interval summary):

![R8.2](../drawings/R8-1/paired_differences.png)

- Purpose: How large and how consistent is the paired gain from the interaction column?
- Data: Blue dots: d = AUROC(with) − AUROC(without) for each of the 20 seeds, jittered vertically with a seeded draw only so the dots separate. Red diamond and bar: the mean gain and the 95% t-interval toy.paired reported.
- What it shows: Every seed gains, from 0.077 to 0.098. The mean gain is 0.087 with sd 0.006, and its interval runs from 0.084 to 0.09, far from zero. The exact signed-rank p toy.paired reported is 1.9e-06.

Headline plot R8.3 (scatter with reference lines):

![R8.3](../drawings/R8-1/gain_vs_gap.png)

- Purpose: What share of the gap to the Bayes ceiling does the interaction column close, seed by seed?
- Data: Blue dots: one seed each, x = Bayes AUROC − AUROC(without), y = d. Red line through the origin: slope gap_closed, the ratio of the mean gain to the mean gap. Grey dotted line: d equal to the gap (gap fully closed). Both axes subtract the same without-arm AUROC, so part of their tight association is built in: a weaker without arm both widens the gap and leaves more to gain.
- What it shows: The seeds lie close to the full-closure line. The mean gap is 0.088, gap_closed is 0.99, and the per-seed ratio runs from 0.969 to 1.001. On one seed the with arm scores just above its finite-sample Bayes AUROC. Part of the points' line-up comes from the shared without term.

Synthesis: At the one sweep point toy.paired has summarized (strength 1.0, 20 paired seeds), adding the interaction column raises held-out AUROC on every seed, by a mean of 0.087 (t-interval 0.084 to 0.09). Every seed's DeLong test rejects on its own. The with arm reaches a mean of 0.855 against a mean Bayes ceiling of 0.856, so it closes 0.99 of the gap the without arm leaves, with a bootstrap CI of 0.986 to 0.994. Recomputing from the per-seed records reproduces the reported gain, sd, gap_closed and mean AUROCs. A seeded bootstrap redrawn here lands within 0.00004 of the reported CI. These views show toy.paired's statistics and the ceiling on real runs. They do not show its hand-worked fixture or its refusals: the test file that holds them has changed since the manifest recorded it.
<!-- /wayline:records -->

#### R9. The evaluation command never reads the held-out score when selecting on validation (supported)

- `t95-a1-f1` toy.eval keeps O2's goal command unchanged.[^100] With no --summary, `--split held_out` reads the summary named by WAYLINE_ARTIFACT and prints `auroc: 0.8502984862625299` for owner/sample-summary.json, the same value that `--summary owner/sample-summary.json` prints.[^100]
- `t95-a1-f2` `toy.eval --split val` prints a summary's `val_auroc` and fails if the summary has none, without falling back to the held-out `auroc`.[^101] Likewise, `--split held_out` fails on a --val-fraction summary, which has no `auroc`.[^101] Selecting by validation score therefore never reads the held-out metric through this command.[^101]
- `t117-a1-f1` toy.eval accepts a run directory from every summary source, not only from --summary: read_metric passes every artifact through summary_path, so a positional path or a WAYLINE_ARTIFACT that names a directory has its summary.json read.[^8] The module docstring and the positional argument's help now say so.[^8]

#### R10. How a prior work counts as settled in the literature placement (supported)

- `t98-a1-f1` toy.placement counts an entry toward resolved_refs only when its dossier says existence 'verified' and its measures_paired_gain is true or false.[^102] An entry whose measures_paired_gain is null counts toward neither number, and its slug is listed under 'unsettled'.[^102]
- `t98-a1-f2` An entry with no dossier agrees only when its existence is 'missing', and it then counts as unresolved.[^9] 'verified' or 'unresolved' with no dossier, or 'missing' when a dossier exists, is a mismatch and makes the command exit 1.[^9]

#### R13. E6: literature placement of C3-C6 (C8) (mixed)

- `t112-a1-f2` Only two of the five works can be settled from their level-0 dossiers (abstracts): DeLong 1988 (a test for correlated ROC areas) and Dietterich 1998 (tests for comparing learning algorithms).[^103] Neither measures a held-out AUROC gain from an explicit product column, so resolved_refs is 2.[^103]
- `t112-a1-f3` (negative) No resolved work measures the paired gain against a no-interaction control (prior_measures_gain = 0), so A9 is not confirmed by the current reading.[^104]
- `t112-a1-f5` (negative) With resolved_refs = 2 < 4, C8 is reported unresolved under SPEC E6's rule.[^105] It is neither supported nor contradicted until the three interaction papers are read past their abstracts.[^105]
- `t112-a2-f1` (replaces `t112-a1-f1`) Every one of the five placement entries agrees with its dossier's existence ('verified') and DOI, so toy.placement lists no mismatches.[^106]
- `t112-a2-f2` (replaces `t112-a1-f4`) Friedman 2008, Lou 2013 and Bien 2013, the three works about interaction models, are still unsettled.[^12] Their abstracts report no held-out AUROC against a no-interaction control.[^12] Friedman's and Bien's dossiers are now at level 2 but still hold only the abstract, and Lou's is at level 0.[^12]

#### R14. E2: paired AUROC gain of the x3*x4 column over 20 seeds (mixed)

- `t120-a1-f1` (replaces `t108-a1-f9`) Over the 20 paired replicates, the mean oracle (Bayes) AUROC on the same held-out rows is 0.8561365857801138. [^45] [^33]
- `t120-a1-f2` (replaces `t108-a1-f11`) C2's bound part is supported: the oracle's mean AUROC lies 0.0009144939855112444 above the with arm's mean and 0.08807984925050671 above the without arm's mean, so neither arm's mean exceeds the oracle's by more than the bound slack of 0.002. [^107] [^108] [^109] [^110]
- `t120-a1-f3` (replaces `t108-a1-f12`) 1 of the 20 replicates has a with-arm AUROC above its own oracle AUROC, and the largest excess of a with-arm AUROC over its oracle AUROC is 9.051095182521784e-05. [^111] [^39] [^112]
- `t120-a1-f4` (replaces `t108-a1-f13`) C2 is supported as a whole: its bound part holds on E2, and E1's ceiling part holds. [^113] [^107] [^114]
- `t121-a1-f1` (replaces `t108-a1-f1`) Over the 20 paired replicates of E2, each with 16000 training rows, adding the x3·x4 column raises held-out AUROC by a mean paired gain of 0.08716535526499543, with a t-interval at confidence 0.95 from 0.08434218983093059 to 0.08998852069906027. [^34] [^35] [^36] [^115] [^33] [^37]
- `t121-a1-f2` (replaces `t108-a1-f2`) The t-interval of the mean paired gain at confidence 0.95 runs from 0.08434218983093059 to 0.08998852069906027, wholly above zero, so A2 is not confirmed. [^35] [^36] [^37] [^116]
- `t121-a1-f3` (replaces `t108-a1-f3`) All 20 per-seed differences d_i are positive, the smallest being 0.07724309618943104 and the largest 0.09767053660183433. [^38] [^39] [^117] [^118]
- `t121-a1-f4` (replaces `t108-a1-f4`) The exact two-sided Wilcoxon signed-rank p over the 20 per-seed differences is 1.9073486328125e-06. [^40] [^33]
- `t121-a1-f5` (replaces `t108-a1-f5`) The DeLong test of the two correlated AUROCs rejects at the level delong_alpha of 0.05 on 20 of the 20 replicates. [^119] [^120] [^33]
- `t121-a1-f6` (replaces `t108-a1-f6`) The column closes a fraction gap_closed of 0.9896174437934124 of the without arm's gap to the Bayes ceiling, with a paired bootstrap CI at confidence 0.95 from 0.9855017415149592 to 0.9935291766371139 over 10000 resamples. [^42] [^43] [^44] [^37] [^121] The gap denominator, the mean over replicates of the oracle's AUROC minus the without arm's, is 0.08807984925050658, above the floor of 0.005 below which gap_closed is not reported. [^122] [^123]
- `t121-a1-f7` (replaces `t108-a1-f7`) The with arm's mean held-out AUROC over the 20 paired replicates is 0.8552220917946025. [^32] [^33]
- `t121-a1-f8` (replaces `t108-a1-f8`) The without arm's mean held-out AUROC over the 20 paired replicates is 0.768056736529607. [^31] [^33]
- `t121-a1-f9` (replaces `t108-a1-f10`) C3 is supported: the t-interval's lower bound of 0.08434218983093059 is above zero, the signed-rank p of 1.9073486328125e-06 is below the p limit of 0.05, and the E2 gate (reproduction and convergence) passed. [^41] [^35] [^40] [^124] [^125]
- `t121-a1-f10` (negative) (replaces `t108-a1-f14`) The SD of the 20 per-seed differences is 0.006032219084153099, not above Q15's SD rule of 0.02, so seeds 21 to 50 are not added. [^126] [^127] [^128] [^129] [^130] [^39]
- `t111-a1-f8` (replaces `t120-a1-f5`) A7 does not hold: E2's mean with-arm AUROC over 20 paired seeds is 0.8552220917946025, above the goal of 0.82, as the goal run is [^13] [^14] [^15] [^16].

### O2. held-out AUROC of at least 0.82, measured on the held-out split with src/toy/eval.py

<!-- wayline:records -->
Status: answered. Answer: reached: the best kept auroc is 0.854069 against the target 0.82 (up), measured by code on t107-a1.

Goal: `auroc`, direction up, target 0.82, on the held-out split `held_out`.

Kept values: 0.8541 from run `t107-a1` (ticket 107).

Concerns:
- K3 (answered: O2: reached: the best kept auroc is 0.854069 against the target 0.82 (up), measured by code on t107-a1): There is a leakage risk. If which interaction terms to add, the regularisation, or the stopping point is chosen by looking at the held-out AUROC, the held-out set is being tuned on. No validation split is described.
<!-- /wayline:records -->

#### R2. Adding the interaction flags leaves the default training run unchanged (supported)

- `t3-a1-f1` At the base commit 4a72047, `toy.train --seed 1 --rows 2000 --epochs 2 --device cpu` gives held-out auroc 0.8352720450281426.[^63] After this change the same command with no new flag gives exactly the same value on CPU.[^63]
- `t3-a1-f2` In the without arm (--no-interaction), the weight on the zeroed x3*x4 column keeps its initial value through training (Adam with zero gradient and weight_decay 0).[^2] Both arms draw identical initial weights from the shared seed.[^2]

<!-- wayline:records -->
Current report: [R2-1](reports/R2-1.md).

Synthesis: This result is a code change checked by tests, and its only artifact is the test file: it holds one recorded number, the held-out AUROC of a short smoke run, and two equality assertions on the model's weights. None of that is a series, a distribution, or a comparison across conditions, so there is nothing a plot would show that the table does not. The table gathers what the change guarantees: the default run reproduces its base-commit AUROC of 0.8353 exactly on cpu, and the without arm differs from the with arm only in that its interaction weight never moves from a shared starting point.
<!-- /wayline:records -->

#### R9. The evaluation command never reads the held-out score when selecting on validation (supported)

- `t95-a1-f1` toy.eval keeps O2's goal command unchanged.[^100] With no --summary, `--split held_out` reads the summary named by WAYLINE_ARTIFACT and prints `auroc: 0.8502984862625299` for owner/sample-summary.json, the same value that `--summary owner/sample-summary.json` prints.[^100]
- `t95-a1-f2` `toy.eval --split val` prints a summary's `val_auroc` and fails if the summary has none, without falling back to the held-out `auroc`.[^101] Likewise, `--split held_out` fails on a --val-fraction summary, which has no `auroc`.[^101] Selecting by validation score therefore never reads the held-out metric through this command.[^101]
- `t117-a1-f1` toy.eval accepts a run directory from every summary source, not only from --summary: read_metric passes every artifact through summary_path, so a positional path or a WAYLINE_ARTIFACT that names a directory has its summary.json read.[^8] The module docstring and the positional argument's help now say so.[^8]

#### R12. Evaluation command (supported)

- `t118-a1-f1` Tests now cover the case where WAYLINE_ARTIFACT or the positional path names a run directory: toy.eval reads the summary.json inside it and prints its auroc.[^11] This pins the behavior that read_metric's use of summary_path gives every summary source.[^11]

#### R14. E2: paired AUROC gain of the x3*x4 column over 20 seeds (mixed)

- `t120-a1-f1` (replaces `t108-a1-f9`) Over the 20 paired replicates, the mean oracle (Bayes) AUROC on the same held-out rows is 0.8561365857801138. [^45] [^33]
- `t120-a1-f2` (replaces `t108-a1-f11`) C2's bound part is supported: the oracle's mean AUROC lies 0.0009144939855112444 above the with arm's mean and 0.08807984925050671 above the without arm's mean, so neither arm's mean exceeds the oracle's by more than the bound slack of 0.002. [^107] [^108] [^109] [^110]
- `t120-a1-f3` (replaces `t108-a1-f12`) 1 of the 20 replicates has a with-arm AUROC above its own oracle AUROC, and the largest excess of a with-arm AUROC over its oracle AUROC is 9.051095182521784e-05. [^111] [^39] [^112]
- `t120-a1-f4` (replaces `t108-a1-f13`) C2 is supported as a whole: its bound part holds on E2, and E1's ceiling part holds. [^113] [^107] [^114]
- `t121-a1-f1` (replaces `t108-a1-f1`) Over the 20 paired replicates of E2, each with 16000 training rows, adding the x3·x4 column raises held-out AUROC by a mean paired gain of 0.08716535526499543, with a t-interval at confidence 0.95 from 0.08434218983093059 to 0.08998852069906027. [^34] [^35] [^36] [^115] [^33] [^37]
- `t121-a1-f2` (replaces `t108-a1-f2`) The t-interval of the mean paired gain at confidence 0.95 runs from 0.08434218983093059 to 0.08998852069906027, wholly above zero, so A2 is not confirmed. [^35] [^36] [^37] [^116]
- `t121-a1-f3` (replaces `t108-a1-f3`) All 20 per-seed differences d_i are positive, the smallest being 0.07724309618943104 and the largest 0.09767053660183433. [^38] [^39] [^117] [^118]
- `t121-a1-f4` (replaces `t108-a1-f4`) The exact two-sided Wilcoxon signed-rank p over the 20 per-seed differences is 1.9073486328125e-06. [^40] [^33]
- `t121-a1-f5` (replaces `t108-a1-f5`) The DeLong test of the two correlated AUROCs rejects at the level delong_alpha of 0.05 on 20 of the 20 replicates. [^119] [^120] [^33]
- `t121-a1-f6` (replaces `t108-a1-f6`) The column closes a fraction gap_closed of 0.9896174437934124 of the without arm's gap to the Bayes ceiling, with a paired bootstrap CI at confidence 0.95 from 0.9855017415149592 to 0.9935291766371139 over 10000 resamples. [^42] [^43] [^44] [^37] [^121] The gap denominator, the mean over replicates of the oracle's AUROC minus the without arm's, is 0.08807984925050658, above the floor of 0.005 below which gap_closed is not reported. [^122] [^123]
- `t121-a1-f7` (replaces `t108-a1-f7`) The with arm's mean held-out AUROC over the 20 paired replicates is 0.8552220917946025. [^32] [^33]
- `t121-a1-f8` (replaces `t108-a1-f8`) The without arm's mean held-out AUROC over the 20 paired replicates is 0.768056736529607. [^31] [^33]
- `t121-a1-f9` (replaces `t108-a1-f10`) C3 is supported: the t-interval's lower bound of 0.08434218983093059 is above zero, the signed-rank p of 1.9073486328125e-06 is below the p limit of 0.05, and the E2 gate (reproduction and convergence) passed. [^41] [^35] [^40] [^124] [^125]
- `t121-a1-f10` (negative) (replaces `t108-a1-f14`) The SD of the 20 per-seed differences is 0.006032219084153099, not above Q15's SD rule of 0.02, so seeds 21 to 50 are not added. [^126] [^127] [^128] [^129] [^130] [^39]
- `t111-a1-f8` (replaces `t120-a1-f5`) A7 does not hold: E2's mean with-arm AUROC over 20 paired seeds is 0.8552220917946025, above the goal of 0.82, as the goal run is [^13] [^14] [^15] [^16].

#### R17. E5: the goal run against O2's 0.82 (C7) (mixed)

- `t111-a1-f1` O2's goal run, toy.train at its project-start defaults with seed 1, scores a held-out auroc of 0.8502984862625299, at or above the goal of 0.82, so the goal is met by its measure [^131] [^132] [^16] [^26].
- `t111-a1-f2` The goal run lies 0.030298486262529956 above the goal of 0.82 [^133] [^16].
- `t111-a1-f3` The held-out fifth was read by 1 candidate, the unchanged start run, over 3 seeded scorings, within E5's limit of 6 held-out reads [^27] [^134] [^28].
- `t111-a1-f4` (negative) Because the start run already meets the goal, E5 tried 0 candidate changes and kept none, so no setting was chosen on held-out data [^135] [^30] [^26].
- `t111-a1-f5` At the default settings the start run's held-out auroc is 0.8502984862625299 at seed 1, 0.8487532141167736 at seed 2 and 0.8631549538738469 at seed 3, with a mean of 0.8540688847510501 [^136] [^137] [^138] [^139].
- `t111-a1-f6` The conductor's keep-if-better judgment for O2 kept the start at an auroc of 0.8540688847510501, the mean of the three seeds, while O2's goal stays the single seed-1 run [^140] [^141] [^142] [^131].
- `t111-a1-f7` E1's Bayes ceiling of 0.8554855066431899 is not below the goal, so A6 does not hold, and the goal run lies 0.00518702038065999 below that ceiling [^143] [^144] [^145] [^146].
- `t111-a1-f9` C7 is supported: the goal run's auroc is at least 0.82, the held-out reads are within 6, and every kept change was chosen by val_auroc, which holds trivially because no change was kept [^24] [^25] [^26] [^27] [^28] [^29] [^30].

### O3. Does generate.py plant a feature interaction in the label, and what is the Bayes-optimal held-out AUROC it allows?

<!-- wayline:records -->
Status: answered. Answer: Yes, generate.py plants the interaction. Its label rule adds a term of INTERACTION_WEIGHT times strength times the x3·x4 product to the latent log-odds, adds Gaussian noise with sd 1.0, and then draws the label. At the default signal of 4.0 and strength of 1.0, the log-odds weight on x3·x4, interaction_weight, is 4.4, from an interaction_coefficient of 1.1 [^147] [^148] [^149] [^150] [^151] [^152]. The test used D2, a draw of 1000000 rows at seed 10001. An unpenalised additive logistic model was fit on the base features to 500000 of those rows and scored on the other 500000. It reaches an AUROC of 0.7680934093271913 there, while the oracle reaches 0.8562883146569809 on the same rows. That is an additive_gap of 0.08819490532978957, far above C1's limit of 0.005 [^153] [^154] [^155] [^156] [^157] [^158] [^159] [^160]. The additive model puts almost no weight on the two features that form the product, so the interaction leaves no straight-line trace that a model without the product column could use [^161]. The oracle's probabilities fit D2's labels: its calibration error over equal-count bins is 0.0039007499357845976, inside the limit of 0.01 [^162] [^163]. At the default settings, the generator's Bayes-optimal AUROC on D2 is 0.8554855066431899. Its DeLong half-width is 0.0007185628495650293, inside C2's precision of 0.002 [^164] [^165] [^166]. Both C1 (the interaction is planted) and the ceiling part of C2 are therefore supported [^167] [^168]. E2's held-out rows give a matching figure: over its 20 paired replicates, the oracle's mean AUROC is 0.8561365857801138 [^45] [^33]. The ceiling is set by the planted strength. In E3's sweep, the oracle's mean held-out AUROC is 0.8139207967160861 at m = 0 and 0.9573724403710034 at m = 4, so the figure above holds only for the default strength [^46] [^169] [^52] [^170]. At the default settings, the ceiling sits 0.035485506643189946 above O2's goal of 0.82, so the generator itself does not put that goal out of reach [^171] [^172].

Evidence: `res:t102-a1/results/E1/oracle.json#label_rule`, `res:t102-a1/results/E1/oracle.json#noise_sd`, `res:t102-a1/results/E1/oracle.json#signal`, `res:t102-a1/results/E1/oracle.json#strength`, `res:t102-a1/results/E1/oracle.json#interaction_weight`, `res:t102-a1/results/E1/oracle.json#interaction_coefficient`, `res:t102-a1/results/E1/oracle.json#rows`, `res:t102-a1/results/E1/oracle.json#seed`, `res:t102-a1/results/E1/oracle.json#additive_fit_rows`, `res:t102-a1/results/E1/oracle.json#additive_scored_rows`, `res:t102-a1/results/E1/oracle.json#additive_auroc`, `res:t102-a1/results/E1/oracle.json#oracle_auroc_second_half`, `res:t102-a1/results/E1/oracle.json#additive_gap`, `res:t103-a1/analysis/E1/summary.json#limits.additive_gap`, `res:t102-a1/results/E1/oracle.json#additive_coefficients`, `res:t102-a1/results/E1/oracle.json#calibration_error`, `res:t103-a1/analysis/E1/summary.json#limits.calibration_error`, `res:t102-a1/results/E1/oracle.json#bayes_auroc`, `res:t102-a1/results/E1/oracle.json#bayes_auroc_halfwidth`, `res:t103-a1/analysis/E1/summary.json#limits.bayes_auroc_halfwidth`, `res:t103-a1/analysis/E1/summary.json#c1_supported`, `res:t103-a1/analysis/E1/summary.json#c2_ceiling_supported`, `res:t120-a1/analysis/E2/paired.json#mean_bayes_auroc`, `res:t120-a1/analysis/E2/paired.json#n_pairs`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.m`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.mean_bayes_auroc`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m4.m`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m4.mean_bayes_auroc`, `res:t103-a1/analysis/E1/summary.json#ceiling_minus_goal`, `res:t103-a1/analysis/E1/summary.json#limits.goal`.

Concerns:
- K5 (answered: O3: Yes, generate.py plants the interaction. Its label rule adds a term of INTERACTION_WEIGHT times strength times the x3·x4 product to the latent log-odds, adds Gaussian noise with sd 1.0, and then draws the label. At the default signal of 4.0 and strength of 1.0, the log-odds weight on x3·x4, interaction_weight, is 4.4, from an interaction_coefficient of 1.1 [^147] [^148] [^149] [^150] [^151] [^152]. The test used D2, a draw of 1000000 rows at seed 10001. An unpenalised additive logistic model was fit on the base features to 500000 of those rows and scored on the other 500000. It reaches an AUROC of 0.7680934093271913 there, while the oracle reaches 0.8562883146569809 on the same rows. That is an additive_gap of 0.08819490532978957, far above C1's limit of 0.005 [^153] [^154] [^155] [^156] [^157] [^158] [^159] [^160]. The additive model puts almost no weight on the two features that form the product, so the interaction leaves no straight-line trace that a model without the product column could use [^161]. The oracle's probabilities fit D2's labels: its calibration error over equal-count bins is 0.0039007499357845976, inside the limit of 0.01 [^162] [^163]. At the default settings, the generator's Bayes-optimal AUROC on D2 is 0.8554855066431899. Its DeLong half-width is 0.0007185628495650293, inside C2's precision of 0.002 [^164] [^165] [^166]. Both C1 (the interaction is planted) and the ceiling part of C2 are therefore supported [^167] [^168]. E2's held-out rows give a matching figure: over its 20 paired replicates, the oracle's mean AUROC is 0.8561365857801138 [^45] [^33]. The ceiling is set by the planted strength. In E3's sweep, the oracle's mean held-out AUROC is 0.8139207967160861 at m = 0 and 0.9573724403710034 at m = 4, so the figure above holds only for the default strength [^46] [^169] [^52] [^170]. At the default settings, the ceiling sits 0.035485506643189946 above O2's goal of 0.82, so the generator itself does not put that goal out of reach [^171] [^172].): There is no ceiling. Without the generator's Bayes-optimal AUROC, a gain cannot be read as a fraction of the gap that was available to close.
<!-- /wayline:records -->

#### R1. Default draw stays fixed under the strength parameter (supported)

- `t2-a3-f1` At strength 1.0, generate(1, signal=4.0, rows=20000) serialised as sorted-key JSON lines (train then held-out) has SHA-256 2ab2d229839a4c61ebe9c3b61c23bf04170f59e889c3839293acafd5a180ae55.[^173] This was measured on the code before the change and is unchanged after it.[^173]
- `t2-a3-f2` The feature columns, the `interaction` column and the random stream do not depend on `strength`, because the Gaussian noise draw is made regardless.[^1] Only the label can change, so sweep points share common random numbers.[^1]

<!-- wayline:records -->
Current report: [R1-1](reports/R1-1.md).

Synthesis: R1 is a reproducibility guarantee, not a measurement. Its two findings cite a hash constant (tests/test_generate.py#DEFAULT_DRAW_SHA256) and the generator's row function (src/toy/generate.py#row). Neither has a distribution, a series, or a comparison to plot. The first fixes the default draw to one digest. The second is a code property: the Gaussian noise draw is made whatever the strength, so the features and the random stream are shared across strengths and only the label can change. No artifact here holds a per-row or per-strength dataset, and drawing one would mean running the project's code, which this drawing may not do. So no plot is drawn.
<!-- /wayline:records -->

#### R3. The statistics code agrees with independent reference implementations (supported)

- `t5-a3-f1` toy.stats's exact two-sided signed-rank p agrees with scipy.stats.wilcoxon(method='exact') to 12 decimal places on ten 20-replicate draws without ties.[^64]
- `t5-a3-f2` On tied differences, toy.stats's exact signed-rank p agrees to 12 decimal places with scipy.stats.wilcoxon under an exhaustive PermutationMethod (n_resamples=10000).[^65]
- `t5-a3-f3` toy.stats's 95% t-interval bounds agree with scipy.stats.t.interval to 10 decimal places.[^66]
- `t5-a3-f4` On tied scores, toy.stats's midrank DeLong AUROCs and covariance agree with a literal pairwise DeLong kernel to an absolute tolerance of 1e-12.[^67]
- `t5-a3-f5` toy.stats's Spearman rho agrees with scipy.stats.spearmanr on tied integer data to 12 decimal places.[^68]
- `t5-a3-f6` toy.stats's paired percentile bootstrap CI for a ratio of means lies within 0.05 times the interval's width of scipy.stats.bootstrap(paired=True, method='percentile'), each with 10000 resamples.[^69]
- `t136-a1-f1` R3's 5 deterministic checks hold toy.stats to between 10 and 12 decimal places (or an absolute 1e-12) on 26 cases.[^70] The sixth check, the paired bootstrap interval, is held only to 0.05 of the interval's width.[^70] The artifact records that each assertion passed, not how large the observed differences were.[^70]
- `t136-a1-f2` The tie-handling checks are small: the tied signed-rank p is checked on a single vector of 10 differences with 5 distinct magnitudes, and DeLong and Spearman on ties are checked on 5 draws each.[^3]

<!-- wayline:records -->
Current report: [R3-1](reports/R3-1.md).

Synthesis: R3 is a correctness result, and its only artifact is the test file that states the comparisons; it records no computed values, only assertions that passed. Read as a table, it says the deterministic statistics (t-interval, exact signed-rank p with and without ties, DeLong covariance on tied scores, Spearman on ties) match an independent reference to between 10 and 12 decimal places, while the bootstrap interval, random on both sides, is held to a looser 0.05 of its width. The tied cases matter for this project because AUROC scores and paired differences can tie; the ties checks are single-vector or few-draw checks (1 tied signed-rank vector, 5 DeLong and 5 Spearman draws).
<!-- /wayline:records -->

#### R4. The oracle's true class probability matches the generator (mixed)

- `t6-a1-f1` generate.py builds the latent log-odds as signal times (0.6 x1 - 0.4 x2 + 1.1 strength x3 x4), adds Gaussian noise with mean 0.0 and sd NOISE_SD = 1.0, and draws the label as a coin flip with the logistic of that latent as its probability.[^71] Because the noise enters before the logistic, P(y=1|x) is the logistic-normal integral E[sigmoid(mu(x) + e)], not sigmoid(mu(x)).[^71]
- `t6-a1-f2` Run at its defaults, the oracle's CLI reports interaction_weight 4.4 and interaction_coefficient 1.1 for the log-odds weight the generator puts on x3·x4.[^72]
- `t6-a1-f3` Leaving out the latent noise miscalibrates the oracle: on 200,000 rows at seed 101, the 20-bin calibration error is at most 0.02 for true_prob, while sigmoid(mu(x)) exceeds 0.03.[^73]
- `t6-a1-f4` (negative) At 20,000 rows the 20-bin calibration error is mostly sampling noise, even for the exact P(y=1|x).[^74] With about 1,000 rows per bin, a bin's mean label has an SE of up to about 0.016, and seed 7 gives a largest gap of 0.034.[^74] The bins' chi-square on 20 df stays below 45.31, its 0.999 quantile, so a 0.02 threshold on the largest gap is not a test at that size.[^74] At E1's 10^6 rows (50,000 per bin, SE <= 0.0023), the spec's <= 0.01 threshold is about 4 SE and is a meaningful test.[^74]
- `t6-a1-f5` true_prob matches labels drawn by generate.row itself at fixed features to within 4 binomial SEs over 10^5 draws each.[^75] The test covers six (x, m) cases, including m = 0 and m = 2.5.[^75] At m = 0 the probability does not change with x3·x4.[^75]
- `t52-a1-f1` At seed 7 with 20,000 rows (1,000 per bin), the oracle's 20-bin calibration error is 0.034 to within 0.0005.[^76] That is above 0.02 but below three times the largest possible per-bin standard error, 0.5/sqrt(1000) ≈ 0.0158.[^76] The worst bin's gap is below sqrt(45.31) of its own standard errors.[^76] So at this size the largest gap is sampling noise, not miscalibration.[^76]
- `t52-a1-f2` The oracle's interaction_weight is the unrounded product signal·(1.1·m).[^77] With signal 3.0 it is 3.3000000000000003, not 3.3.[^77]
- `t52-a4-f1` (replaces `t52-a1-f3`) At eight values of mu from -20 to 20, the 48-node Gauss-Hermite estimate of the logistic-normal integral agrees with the 96-node estimate within QUADRATURE_TOLERANCE = 1e-10.[^4] It agrees with a trapezoid rule of step 0.002 over ±12 sd within 1e-9.[^4]

#### R6. Oracle audit cost on the 10^6-row draw D2 (supported)

- `t53-a1-f1` The committed test holds the audit of the default draw D2 (seed 10001, 1000000 rows) to a wall-clock limit of 3600 seconds and a peak child memory limit of 4.0 GB, and the audit passed both when the test was run.[^6]

#### R8. The paired statistics of a sweep point, checked by hand and against their records (supported)

- `t76-a1-f1` On the hand-worked fixture (three replicates, 10 held-out rows each), toy.paired reproduces every hand-derived answer: paired_gain 2/15 with a t-interval half-width of t(0.975, 2)·sqrt(79)/75, sd_d sqrt(237)/75, signed_rank_p 0.5, delong_rejections 1 (seed 2 only), mean Bayes AUROC 2.8/3, and gap_closed 10/17 with a paired-bootstrap CI of exactly (-1/3, 0.9).[^93]
- `t115-a1-f1` toy.paired exposes point_stats(point_dir) as its one-point entry point, with paired kept as an alias of the same function, and its command line writes the printed JSON to --out PATH when given.[^94]
- `t115-a1-f2` When the gap left by the without arm is at most 0.005, summarize sets gap_closed and its CI to null and fills gap_closed_reason with a sentence; when gap_closed is reported, gap_closed_reason is null.[^95]
- `t116-a2-f1` (replaces `t76-a1-f2`) toy.paired refuses, with exit 2, a point whose two arms ran different seeds, a seed whose arms disagree on the draw (seed, strength, signal, rows, train_rows), arms that scored different labels, labels that are not the held-out rows the recorded settings draw, a summary auroc that is not the AUROC of its own saved scores, a run filed under the wrong arm, missing or out-of-order scores, and a point whose replicates disagree on any compared setting.[^96]
- `t116-a2-f2` (replaces `t116-a1-f1`) toy.paired refuses a seed whose arms disagree on any training setting train.py records (val_fraction, epochs, lr, minibatch, the pinned config's content) and names that key.[^97] It refuses a with run without the interaction column, a without run that kept it, and a run whose config.json lacks any compared key or features.[^97] It still pairs arms that differ only in batch_size, dataloader_workers, device or the config path, and their statistics come out unchanged.[^97]
- `t141-a1-f1` Recomputed from toy.paired's own per-seed records at this sweep point, the paired gain, its sd, gap_closed and the mean AUROCs of both arms and the oracle all equal the summary values toy.paired reported.[^98]
- `t141-a1-f2` A seeded paired bootstrap of gap_closed, redrawn from the point's per-seed records, gives percentile bounds within 0.00004 of the CI toy.paired reported.[^99]
- `t141-a1-f3` At this sweep point the with arm's held-out AUROC falls short of the Bayes ceiling by 0.0009 on average over the seeds.[^7]

<!-- wayline:records -->
Current report: [R8-1](reports/R8-1.md).

Headline plot R8.1 (paired dot plot (dumbbell) with a reference tick):

![R8.1](../drawings/R8-1/arms_per_seed.png)

- Purpose: How far does each arm get on each seed, and how close does the with arm come to the oracle ceiling?
- Data: toy.paired's per-seed records in analysis/E2/paired.json (strength 1.0, signal 4.0, 20 paired seeds, 4000 held-out rows each). Orange circles: held-out AUROC without the interaction column. Blue squares: with it. Grey segment: joins one seed's two arms. Black tick: that seed's Bayes AUROC from the oracle. Seeds are categories, so no line runs across them.
- What it shows: On every seed the with arm sits just under its own ceiling, while the without arm lies far below it. The mean AUROCs are 0.768 without, 0.855 with and 0.856 for the ceiling.

Headline plot R8.2 (strip plot with a point-and-interval summary):

![R8.2](../drawings/R8-1/paired_differences.png)

- Purpose: How large and how consistent is the paired gain from the interaction column?
- Data: Blue dots: d = AUROC(with) − AUROC(without) for each of the 20 seeds, jittered vertically with a seeded draw only so the dots separate. Red diamond and bar: the mean gain and the 95% t-interval toy.paired reported.
- What it shows: Every seed gains, from 0.077 to 0.098. The mean gain is 0.087 with sd 0.006, and its interval runs from 0.084 to 0.09, far from zero. The exact signed-rank p toy.paired reported is 1.9e-06.

Headline plot R8.3 (scatter with reference lines):

![R8.3](../drawings/R8-1/gain_vs_gap.png)

- Purpose: What share of the gap to the Bayes ceiling does the interaction column close, seed by seed?
- Data: Blue dots: one seed each, x = Bayes AUROC − AUROC(without), y = d. Red line through the origin: slope gap_closed, the ratio of the mean gain to the mean gap. Grey dotted line: d equal to the gap (gap fully closed). Both axes subtract the same without-arm AUROC, so part of their tight association is built in: a weaker without arm both widens the gap and leaves more to gain.
- What it shows: The seeds lie close to the full-closure line. The mean gap is 0.088, gap_closed is 0.99, and the per-seed ratio runs from 0.969 to 1.001. On one seed the with arm scores just above its finite-sample Bayes AUROC. Part of the points' line-up comes from the shared without term.

Synthesis: At the one sweep point toy.paired has summarized (strength 1.0, 20 paired seeds), adding the interaction column raises held-out AUROC on every seed, by a mean of 0.087 (t-interval 0.084 to 0.09). Every seed's DeLong test rejects on its own. The with arm reaches a mean of 0.855 against a mean Bayes ceiling of 0.856, so it closes 0.99 of the gap the without arm leaves, with a bootstrap CI of 0.986 to 0.994. Recomputing from the per-seed records reproduces the reported gain, sd, gap_closed and mean AUROCs. A seeded bootstrap redrawn here lands within 0.00004 of the reported CI. These views show toy.paired's statistics and the ceiling on real runs. They do not show its hand-worked fixture or its refusals: the test file that holds them has changed since the manifest recorded it.
<!-- /wayline:records -->

#### R11. E1: planted interaction, additive gap and Bayes ceiling on D2 (mixed)

- `t103-a1-f1` On D2 (seed 10001, 10^6 rows, signal 4, strength 1), the label is built at src/toy/generate.py:36 as latent = signal·(0.6 x1 − 0.4 x2 + 1.1·strength·x3x4) plus N(0, 1) noise, so the log-odds weight on x3·x4 is interaction_weight = 4.4.[^151]
- `t103-a1-f2` The unpenalised additive logistic model on x1..x4 was fit to the first half of D2, 500000 rows.[^155]
- `t103-a1-f3` The additive model was scored on the second half of D2, 500000 rows.[^156]
- `t103-a1-f4` On the scored half of D2, the additive model's AUROC is 0.7681.[^157]
- `t103-a1-f5` On the same scored half of D2, the oracle's AUROC is 0.8563.[^158]
- `t103-a1-f6` additive_gap, the oracle's AUROC on the scored half minus the additive model's, is 0.0882, far above C1's 0.005 threshold.[^159]
- `t103-a1-f7` (negative) The additive model's coefficients on x3 and x4 are about zero (−0.0035 and 0.0020), against 1.61 and −1.07 on x1 and x2.[^161] The interaction has no marginal linear trace that an additive model could use.[^161]
- `t103-a1-f8` The oracle's 20-bin calibration error on D2 is 0.0039, within the 0.01 limit.[^162]
- `t103-a1-f9` Each equal-count calibration bin on D2 holds 50000 rows.[^174]
- `t103-a1-f10` The default generator's Bayes-optimal AUROC on D2 is 0.8555.[^164]
- `t103-a1-f11` The DeLong 95% half-width of the Bayes AUROC on D2 is 0.00072, inside C2's ±0.002 precision.[^165]
- `t103-a1-f12` C1 is supported: interaction_weight is not zero, additive_gap > 0.005, and calibration_error ≤ 0.01.[^167] C2's ceiling part is supported: the half-width is ≤ 0.002 and calibration_error is ≤ 0.01.[^167] Its bound part is left to E2.[^167]
- `t103-a1-f13` (negative) The Bayes ceiling (0.8555) lies 0.035 above O2's goal of 0.82, so A6 does not hold and the goal is not out of reach by construction.[^164]
- `t144-a1-f1` Reaching O2's 0.82 goal on D2 requires closing 0.59 of the distance between the additive model's AUROC and the Bayes ceiling.[^175]
- `t144-a1-f2` The 0.82 goal lies 0.0519 above the additive model's AUROC on D2, so no model that stays additive in x1..x4 reaches it on this generator.[^176]
- `t144-a1-f3` The additive fit keeps the generator's x1:x2 ratio of -1.5 and gives x3 and x4 no weight.[^177] The interaction therefore costs it signal without biasing the linear terms' relative weights.[^177]
- `t144-a1-f4` The oracle's AUROC on the scored half of D2 and the Bayes AUROC on all of D2 differ by 0.0008.[^10]

<!-- wayline:records -->
Current report: [R11-1](reports/R11-1.md).

Headline plot R11.1 (dot plot with interval and reference line):

![R11.1](../drawings/R11-1/auroc_ladder.png)

- Purpose: How far is an additive model (no x3·x4 column) from the best achievable AUROC on D2, and where does the 0.82 goal sit between them?
- Data: Three AUROCs from results/E1/oracle.json: the additive logistic model on x1..x4 (blue dot, 0.7681) and the generator's oracle (orange dot, 0.8563), both scored on the second half of D2 (500000 rows), and the Bayes ceiling on all of D2 (black dot, 0.8555) with its DeLong 95% interval as the black error bar (0.8548 to 0.8562, half-width 0.00072, narrower than the dot). The green double arrow is the additive gap, oracle minus additive on the scored half (0.0882). The vermilion dashed line is O2's goal of 0.82 (limit from analysis/E1/summary.json).
- What it shows: The additive model sits 0.0882 below the oracle, 17.6 times C1's 0.005 threshold, so the planted interaction carries a large share of what is learnable. The goal line falls between them: it lies 0.0519 above the additive model and 0.0355 below the ceiling, so reaching it requires closing 0.59 of the additive-to-ceiling distance. The oracle on the scored half and the Bayes ceiling on all of D2 differ by only 0.0008, and the ceiling's interval is too narrow to see at this scale.

Headline plot R11.2 (lollipop (coefficient dot plot)):

![R11.2](../drawings/R11-1/additive_coefficients.png)

- Purpose: Does the planted x3·x4 interaction leave any marginal linear trace an additive model can use?
- Data: The five coefficients (log-odds scale) of the unpenalised additive logistic model fit on the first 500000 rows of D2, from results/E1/oracle.json#additive_coefficients. Light blue: intercept; dark blue: x1 and x2, the terms the generator weights linearly; orange: x3 and x4, which enter the label only through their product. Stems run from zero to each value; labels give the value.
- What it shows: x1 (1.61) and x2 (-1.07) carry all the additive model's weight, in the generator's own ratio (-1.5 fitted against -1.5 in the generator's linear weights), while x3 (-0.0035) and x4 (0.0020) sit at zero, like the intercept (-0.0032). The additive model therefore sees nothing of the interaction, whose generator weight is 4.4, the largest in the label rule.

Synthesis: The generator plants a strong interaction: x3·x4 enters the label with weight 4.4, yet the additive model fitted to half of D2 gives x3 and x4 coefficients of -0.0035 and 0.0020, so the interaction is invisible to it. That blindness costs 0.0882 AUROC against the oracle (0.7681 against 0.8563), 17.6 times C1's threshold. The oracle is calibrated to within 0.0039 in every bin, so its AUROC can serve as the ceiling, and the Bayes ceiling on all of D2 (0.8555, half-width 0.00072) agrees with the oracle on the scored half to 0.0008. The 0.82 goal lies between the additive model and the ceiling, 0.0355 under the ceiling: it is reachable in principle but needs 0.59 of the additive-to-ceiling distance, which in this generator only the interaction can supply.
<!-- /wayline:records -->

#### R14. E2: paired AUROC gain of the x3*x4 column over 20 seeds (mixed)

- `t120-a1-f1` (replaces `t108-a1-f9`) Over the 20 paired replicates, the mean oracle (Bayes) AUROC on the same held-out rows is 0.8561365857801138. [^45] [^33]
- `t120-a1-f2` (replaces `t108-a1-f11`) C2's bound part is supported: the oracle's mean AUROC lies 0.0009144939855112444 above the with arm's mean and 0.08807984925050671 above the without arm's mean, so neither arm's mean exceeds the oracle's by more than the bound slack of 0.002. [^107] [^108] [^109] [^110]
- `t120-a1-f3` (replaces `t108-a1-f12`) 1 of the 20 replicates has a with-arm AUROC above its own oracle AUROC, and the largest excess of a with-arm AUROC over its oracle AUROC is 9.051095182521784e-05. [^111] [^39] [^112]
- `t120-a1-f4` (replaces `t108-a1-f13`) C2 is supported as a whole: its bound part holds on E2, and E1's ceiling part holds. [^113] [^107] [^114]
- `t121-a1-f1` (replaces `t108-a1-f1`) Over the 20 paired replicates of E2, each with 16000 training rows, adding the x3·x4 column raises held-out AUROC by a mean paired gain of 0.08716535526499543, with a t-interval at confidence 0.95 from 0.08434218983093059 to 0.08998852069906027. [^34] [^35] [^36] [^115] [^33] [^37]
- `t121-a1-f2` (replaces `t108-a1-f2`) The t-interval of the mean paired gain at confidence 0.95 runs from 0.08434218983093059 to 0.08998852069906027, wholly above zero, so A2 is not confirmed. [^35] [^36] [^37] [^116]
- `t121-a1-f3` (replaces `t108-a1-f3`) All 20 per-seed differences d_i are positive, the smallest being 0.07724309618943104 and the largest 0.09767053660183433. [^38] [^39] [^117] [^118]
- `t121-a1-f4` (replaces `t108-a1-f4`) The exact two-sided Wilcoxon signed-rank p over the 20 per-seed differences is 1.9073486328125e-06. [^40] [^33]
- `t121-a1-f5` (replaces `t108-a1-f5`) The DeLong test of the two correlated AUROCs rejects at the level delong_alpha of 0.05 on 20 of the 20 replicates. [^119] [^120] [^33]
- `t121-a1-f6` (replaces `t108-a1-f6`) The column closes a fraction gap_closed of 0.9896174437934124 of the without arm's gap to the Bayes ceiling, with a paired bootstrap CI at confidence 0.95 from 0.9855017415149592 to 0.9935291766371139 over 10000 resamples. [^42] [^43] [^44] [^37] [^121] The gap denominator, the mean over replicates of the oracle's AUROC minus the without arm's, is 0.08807984925050658, above the floor of 0.005 below which gap_closed is not reported. [^122] [^123]
- `t121-a1-f7` (replaces `t108-a1-f7`) The with arm's mean held-out AUROC over the 20 paired replicates is 0.8552220917946025. [^32] [^33]
- `t121-a1-f8` (replaces `t108-a1-f8`) The without arm's mean held-out AUROC over the 20 paired replicates is 0.768056736529607. [^31] [^33]
- `t121-a1-f9` (replaces `t108-a1-f10`) C3 is supported: the t-interval's lower bound of 0.08434218983093059 is above zero, the signed-rank p of 1.9073486328125e-06 is below the p limit of 0.05, and the E2 gate (reproduction and convergence) passed. [^41] [^35] [^40] [^124] [^125]
- `t121-a1-f10` (negative) (replaces `t108-a1-f14`) The SD of the 20 per-seed differences is 0.006032219084153099, not above Q15's SD rule of 0.02, so seeds 21 to 50 are not added. [^126] [^127] [^128] [^129] [^130] [^39]
- `t111-a1-f8` (replaces `t120-a1-f5`) A7 does not hold: E2's mean with-arm AUROC over 20 paired seeds is 0.8552220917946025, above the goal of 0.82, as the goal run is [^13] [^14] [^15] [^16].

### O4. Does the AUROC gain from interaction terms vanish when the generator plants no interaction, and how does it grow with interaction strength and shrink with sample size?

<!-- wayline:records -->
Status: answered. Answer: With no planted interaction (m = 0) and 16000 training rows, the product column's mean paired gain over 20 seeds is -0.0003186665215305473 AUROC. Its t-interval at confidence 0.95 runs from -0.0005967640897244911 to -4.056895333660356e-05, inside the harmlessness band of -0.01 to 0.01, so C4 is supported and the gain vanishes for practical purposes [^46] [^178] [^179] [^47] [^180] [^48] [^49] [^50] [^51] [^181]. It does not vanish exactly: the unneeded column costs a little, with 16 of the 20 per-seed differences negative and an exact signed-rank p of 0.00485992431640625, but that cost is 31.38076743038538 times smaller than the tolerance of 0.01 [^182] [^179] [^183] [^184] [^185]. The same holds at every training size tried: with no planted interaction, the gain's t-interval lies inside the band at 7 of the 7 sizes from 1000 to 64000 rows, and wholly below zero at 4 of them [^186] [^58] [^59] [^60] [^187]. The gain grows with the planted strength: at 16000 training rows it is 0.006924435415007868 at m = 0.25, 0.026716785955346812 at m = 0.5, 0.08716535526499543 at m = 1, 0.20305977863815153 at m = 2 and 0.31434161002887523 at m = 4 [^188] [^189] [^190] [^191] [^192] [^193] [^194] [^195] [^196] [^52] [^53]. It rises strictly at every step of the strength grid, its Spearman correlation with strength over the 6 points is 1.0, and the lower bound of its interval at m = 4, 0.3109568572362925, is above zero, so C5 is supported [^54] [^197] [^55] [^18] [^52] [^198] [^199]. At the strongest setting the column recovers almost all that the generator allows: at m = 4 the with arm's mean AUROC is 0.9569689362650855 against an oracle ceiling of 0.9573724403710034, a gap_closed of 0.9987179972371389 [^52] [^200] [^170] [^201]. The gain does not shrink with sample size: at m = 1 the mean paired gain stays between 0.08714270655297177 and 0.08786251131921252 across the 7 training sizes from 1000 to 64000 rows, and it neither strictly falls nor strictly rises [^202] [^56] [^57] [^58] [^59] [^60] [^203] [^204]. gain_shrink is the per-seed gain at 1000 rows minus the gain at 64000, averaged over 20 seeds. It is -0.0003637848989109571, with a t-interval at confidence 0.95 from -0.003671575350341559 to 0.0029440055525196446, wholly below the limit of 0.005, so C6 is supported and A5, the expectation that the gain falls as rows grow, is not confirmed [^59] [^60] [^205] [^206] [^207] [^208] [^209] [^210] [^61] [^211]. Already at 1000 rows the column closes a fraction 0.9869503768521246 of the gap to the Bayes ceiling, so there is little left for more data to change [^212] [^59]. These readings describe what this one generator plants, not interaction terms in general. A3 is confirmed. The strength sweep was run at a single training size of 16000 rows. The size sweep was run only at m = 1 and m = 0 [^62] [^188] [^202] [^213].

Evidence: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.m`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.train_rows`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.n_pairs`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.paired_gain`, `res:t122-a2/analysis/E3/verdict.json#confidence`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.paired_gain_lo`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.paired_gain_hi`, `res:t122-a2/analysis/E3/verdict.json#harmless_lo`, `res:t122-a2/analysis/E3/verdict.json#harmless_hi`, `res:t122-a2/analysis/E3/verdict.json#c4_supported`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.n_negative_d`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.signed_rank_p`, `res:t122-a2/analysis/E3/verdict.json#zero_cost.band_over_cost`, `res:t122-a2/analysis/E3/verdict.json#zero_cost.harmless_band`, `res:t110-a1/analysis/E4/verdict.json#m0_cost.n_sizes_ci_inside_band`, `res:t110-a1/analysis/E4/verdict.json#n_sizes`, `res:t110-a1/analysis/E4/verdict.json#smallest_train_rows`, `res:t110-a1/analysis/E4/verdict.json#largest_train_rows`, `res:t110-a1/analysis/E4/verdict.json#m0_cost.n_sizes_ci_below_zero`, `res:t122-a2/analysis/E3/verdict.json#train_rows`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m0p25.m`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m0p25.paired_gain`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m0p5.m`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m0p5.paired_gain`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m1.m`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m1.paired_gain`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m2.m`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m2.paired_gain`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m4.m`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m4.paired_gain`, `res:t122-a2/analysis/E3/verdict.json#gain_monotone_in_strength`, `res:t122-a2/analysis/E3/verdict.json#strength_grid`, `res:t122-a2/analysis/E3/verdict.json#strength_spearman`, `res:t122-a2/analysis/E3/verdict.json#n_points`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m4.paired_gain_lo`, `res:t122-a2/analysis/E3/verdict.json#c5_supported`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m4.mean_auroc_with`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m4.mean_bayes_auroc`, `res:t122-a2/analysis/E3/verdict.json#by_strength.m4.gap_closed`, `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.m`, `res:t110-a1/analysis/E4/verdict.json#m1_min_paired_gain`, `res:t110-a1/analysis/E4/verdict.json#m1_max_paired_gain`, `res:t110-a1/analysis/E4/verdict.json#m1_gain_monotone_decreasing`, `res:t110-a1/analysis/E4/verdict.json#m1_gain_monotone_increasing`, `res:t110-a1/analysis/E4/verdict.json#m1_gain_shrink_n`, `res:t110-a1/analysis/E4/verdict.json#m1_gain_shrink`, `res:t110-a1/analysis/E4/verdict.json#confidence`, `res:t110-a1/analysis/E4/verdict.json#m1_gain_shrink_lo`, `res:t110-a1/analysis/E4/verdict.json#m1_gain_shrink_hi`, `res:t110-a1/analysis/E4/verdict.json#shrink_limit`, `res:t110-a1/analysis/E4/verdict.json#c6_supported`, `res:t110-a1/analysis/E4/verdict.json#a5`, `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.gap_closed`, `res:t122-a2/analysis/E3/verdict.json#a3`, `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n1000.m`.

Concerns:
- K1 (answered: O4: With no planted interaction (m = 0) and 16000 training rows, the product column's mean paired gain over 20 seeds is -0.0003186665215305473 AUROC. Its t-interval at confidence 0.95 runs from -0.0005967640897244911 to -4.056895333660356e-05, inside the harmlessness band of -0.01 to 0.01, so C4 is supported and the gain vanishes for practical purposes [^46] [^178] [^179] [^47] [^180] [^48] [^49] [^50] [^51] [^181]. It does not vanish exactly: the unneeded column costs a little, with 16 of the 20 per-seed differences negative and an exact signed-rank p of 0.00485992431640625, but that cost is 31.38076743038538 times smaller than the tolerance of 0.01 [^182] [^179] [^183] [^184] [^185]. The same holds at every training size tried: with no planted interaction, the gain's t-interval lies inside the band at 7 of the 7 sizes from 1000 to 64000 rows, and wholly below zero at 4 of them [^186] [^58] [^59] [^60] [^187]. The gain grows with the planted strength: at 16000 training rows it is 0.006924435415007868 at m = 0.25, 0.026716785955346812 at m = 0.5, 0.08716535526499543 at m = 1, 0.20305977863815153 at m = 2 and 0.31434161002887523 at m = 4 [^188] [^189] [^190] [^191] [^192] [^193] [^194] [^195] [^196] [^52] [^53]. It rises strictly at every step of the strength grid, its Spearman correlation with strength over the 6 points is 1.0, and the lower bound of its interval at m = 4, 0.3109568572362925, is above zero, so C5 is supported [^54] [^197] [^55] [^18] [^52] [^198] [^199]. At the strongest setting the column recovers almost all that the generator allows: at m = 4 the with arm's mean AUROC is 0.9569689362650855 against an oracle ceiling of 0.9573724403710034, a gap_closed of 0.9987179972371389 [^52] [^200] [^170] [^201]. The gain does not shrink with sample size: at m = 1 the mean paired gain stays between 0.08714270655297177 and 0.08786251131921252 across the 7 training sizes from 1000 to 64000 rows, and it neither strictly falls nor strictly rises [^202] [^56] [^57] [^58] [^59] [^60] [^203] [^204]. gain_shrink is the per-seed gain at 1000 rows minus the gain at 64000, averaged over 20 seeds. It is -0.0003637848989109571, with a t-interval at confidence 0.95 from -0.003671575350341559 to 0.0029440055525196446, wholly below the limit of 0.005, so C6 is supported and A5, the expectation that the gain falls as rows grow, is not confirmed [^59] [^60] [^205] [^206] [^207] [^208] [^209] [^210] [^61] [^211]. Already at 1000 rows the column closes a fraction 0.9869503768521246 of the gap to the Bayes ceiling, so there is little left for more data to change [^212] [^59]. These readings describe what this one generator plants, not interaction terms in general. A3 is confirmed. The strength sweep was run at a single training size of 16000 rows. The size sweep was run only at m = 1 and m = 0 [^62] [^188] [^202] [^213].): The effect is planted. A synthetic generator whose label is built from a product of two features will always reward a model that is handed that product, so 'interaction terms help' restates the generator rather than finding anything.
- K4 (answered: O4: With no planted interaction (m = 0) and 16000 training rows, the product column's mean paired gain over 20 seeds is -0.0003186665215305473 AUROC. Its t-interval at confidence 0.95 runs from -0.0005967640897244911 to -4.056895333660356e-05, inside the harmlessness band of -0.01 to 0.01, so C4 is supported and the gain vanishes for practical purposes [^46] [^178] [^179] [^47] [^180] [^48] [^49] [^50] [^51] [^181]. It does not vanish exactly: the unneeded column costs a little, with 16 of the 20 per-seed differences negative and an exact signed-rank p of 0.00485992431640625, but that cost is 31.38076743038538 times smaller than the tolerance of 0.01 [^182] [^179] [^183] [^184] [^185]. The same holds at every training size tried: with no planted interaction, the gain's t-interval lies inside the band at 7 of the 7 sizes from 1000 to 64000 rows, and wholly below zero at 4 of them [^186] [^58] [^59] [^60] [^187]. The gain grows with the planted strength: at 16000 training rows it is 0.006924435415007868 at m = 0.25, 0.026716785955346812 at m = 0.5, 0.08716535526499543 at m = 1, 0.20305977863815153 at m = 2 and 0.31434161002887523 at m = 4 [^188] [^189] [^190] [^191] [^192] [^193] [^194] [^195] [^196] [^52] [^53]. It rises strictly at every step of the strength grid, its Spearman correlation with strength over the 6 points is 1.0, and the lower bound of its interval at m = 4, 0.3109568572362925, is above zero, so C5 is supported [^54] [^197] [^55] [^18] [^52] [^198] [^199]. At the strongest setting the column recovers almost all that the generator allows: at m = 4 the with arm's mean AUROC is 0.9569689362650855 against an oracle ceiling of 0.9573724403710034, a gap_closed of 0.9987179972371389 [^52] [^200] [^170] [^201]. The gain does not shrink with sample size: at m = 1 the mean paired gain stays between 0.08714270655297177 and 0.08786251131921252 across the 7 training sizes from 1000 to 64000 rows, and it neither strictly falls nor strictly rises [^202] [^56] [^57] [^58] [^59] [^60] [^203] [^204]. gain_shrink is the per-seed gain at 1000 rows minus the gain at 64000, averaged over 20 seeds. It is -0.0003637848989109571, with a t-interval at confidence 0.95 from -0.003671575350341559 to 0.0029440055525196446, wholly below the limit of 0.005, so C6 is supported and A5, the expectation that the gain falls as rows grow, is not confirmed [^59] [^60] [^205] [^206] [^207] [^208] [^209] [^210] [^61] [^211]. Already at 1000 rows the column closes a fraction 0.9869503768521246 of the gap to the Bayes ceiling, so there is little left for more data to change [^212] [^59]. These readings describe what this one generator plants, not interaction terms in general. A3 is confirmed. The strength sweep was run at a single training size of 16000 rows. The size sweep was run only at m = 1 and m = 0 [^62] [^188] [^202] [^213].): There is no null control. Without a run where the generator plants no interaction, the work cannot show that added terms are harmless when they are not needed, or measure how much spurious pairwise terms cost through overfitting.
- K6 (answered: O4: With no planted interaction (m = 0) and 16000 training rows, the product column's mean paired gain over 20 seeds is -0.0003186665215305473 AUROC. Its t-interval at confidence 0.95 runs from -0.0005967640897244911 to -4.056895333660356e-05, inside the harmlessness band of -0.01 to 0.01, so C4 is supported and the gain vanishes for practical purposes [^46] [^178] [^179] [^47] [^180] [^48] [^49] [^50] [^51] [^181]. It does not vanish exactly: the unneeded column costs a little, with 16 of the 20 per-seed differences negative and an exact signed-rank p of 0.00485992431640625, but that cost is 31.38076743038538 times smaller than the tolerance of 0.01 [^182] [^179] [^183] [^184] [^185]. The same holds at every training size tried: with no planted interaction, the gain's t-interval lies inside the band at 7 of the 7 sizes from 1000 to 64000 rows, and wholly below zero at 4 of them [^186] [^58] [^59] [^60] [^187]. The gain grows with the planted strength: at 16000 training rows it is 0.006924435415007868 at m = 0.25, 0.026716785955346812 at m = 0.5, 0.08716535526499543 at m = 1, 0.20305977863815153 at m = 2 and 0.31434161002887523 at m = 4 [^188] [^189] [^190] [^191] [^192] [^193] [^194] [^195] [^196] [^52] [^53]. It rises strictly at every step of the strength grid, its Spearman correlation with strength over the 6 points is 1.0, and the lower bound of its interval at m = 4, 0.3109568572362925, is above zero, so C5 is supported [^54] [^197] [^55] [^18] [^52] [^198] [^199]. At the strongest setting the column recovers almost all that the generator allows: at m = 4 the with arm's mean AUROC is 0.9569689362650855 against an oracle ceiling of 0.9573724403710034, a gap_closed of 0.9987179972371389 [^52] [^200] [^170] [^201]. The gain does not shrink with sample size: at m = 1 the mean paired gain stays between 0.08714270655297177 and 0.08786251131921252 across the 7 training sizes from 1000 to 64000 rows, and it neither strictly falls nor strictly rises [^202] [^56] [^57] [^58] [^59] [^60] [^203] [^204]. gain_shrink is the per-seed gain at 1000 rows minus the gain at 64000, averaged over 20 seeds. It is -0.0003637848989109571, with a t-interval at confidence 0.95 from -0.003671575350341559 to 0.0029440055525196446, wholly below the limit of 0.005, so C6 is supported and A5, the expectation that the gain falls as rows grow, is not confirmed [^59] [^60] [^205] [^206] [^207] [^208] [^209] [^210] [^61] [^211]. Already at 1000 rows the column closes a fraction 0.9869503768521246 of the gap to the Bayes ceiling, so there is little left for more data to change [^212] [^59]. These readings describe what this one generator plants, not interaction terms in general. A3 is confirmed. The strength sweep was run at a single training size of 16000 rows. The size sweep was run only at m = 1 and m = 0 [^62] [^188] [^202] [^213].): Generality is unsupported. One generator setting (one signal strength, sample size, feature count and noise level) cannot support a general claim about interaction terms on tabular data.
<!-- /wayline:records -->

#### R1. Default draw stays fixed under the strength parameter (supported)

- `t2-a3-f1` At strength 1.0, generate(1, signal=4.0, rows=20000) serialised as sorted-key JSON lines (train then held-out) has SHA-256 2ab2d229839a4c61ebe9c3b61c23bf04170f59e889c3839293acafd5a180ae55.[^173] This was measured on the code before the change and is unchanged after it.[^173]
- `t2-a3-f2` The feature columns, the `interaction` column and the random stream do not depend on `strength`, because the Gaussian noise draw is made regardless.[^1] Only the label can change, so sweep points share common random numbers.[^1]

<!-- wayline:records -->
Current report: [R1-1](reports/R1-1.md).

Synthesis: R1 is a reproducibility guarantee, not a measurement. Its two findings cite a hash constant (tests/test_generate.py#DEFAULT_DRAW_SHA256) and the generator's row function (src/toy/generate.py#row). Neither has a distribution, a series, or a comparison to plot. The first fixes the default draw to one digest. The second is a code property: the Gaussian noise draw is made whatever the strength, so the features and the random stream are shared across strengths and only the label can change. No artifact here holds a per-row or per-strength dataset, and drawing one would mean running the project's code, which this drawing may not do. So no plot is drawn.
<!-- /wayline:records -->

#### R2. Adding the interaction flags leaves the default training run unchanged (supported)

- `t3-a1-f1` At the base commit 4a72047, `toy.train --seed 1 --rows 2000 --epochs 2 --device cpu` gives held-out auroc 0.8352720450281426.[^63] After this change the same command with no new flag gives exactly the same value on CPU.[^63]
- `t3-a1-f2` In the without arm (--no-interaction), the weight on the zeroed x3*x4 column keeps its initial value through training (Adam with zero gradient and weight_decay 0).[^2] Both arms draw identical initial weights from the shared seed.[^2]

<!-- wayline:records -->
Current report: [R2-1](reports/R2-1.md).

Synthesis: This result is a code change checked by tests, and its only artifact is the test file: it holds one recorded number, the held-out AUROC of a short smoke run, and two equality assertions on the model's weights. None of that is a series, a distribution, or a comparison across conditions, so there is nothing a plot would show that the table does not. The table gathers what the change guarantees: the default run reproduces its base-commit AUROC of 0.8353 exactly on cpu, and the without arm differs from the with arm only in that its interaction weight never moves from a shared starting point.
<!-- /wayline:records -->

#### R3. The statistics code agrees with independent reference implementations (supported)

- `t5-a3-f1` toy.stats's exact two-sided signed-rank p agrees with scipy.stats.wilcoxon(method='exact') to 12 decimal places on ten 20-replicate draws without ties.[^64]
- `t5-a3-f2` On tied differences, toy.stats's exact signed-rank p agrees to 12 decimal places with scipy.stats.wilcoxon under an exhaustive PermutationMethod (n_resamples=10000).[^65]
- `t5-a3-f3` toy.stats's 95% t-interval bounds agree with scipy.stats.t.interval to 10 decimal places.[^66]
- `t5-a3-f4` On tied scores, toy.stats's midrank DeLong AUROCs and covariance agree with a literal pairwise DeLong kernel to an absolute tolerance of 1e-12.[^67]
- `t5-a3-f5` toy.stats's Spearman rho agrees with scipy.stats.spearmanr on tied integer data to 12 decimal places.[^68]
- `t5-a3-f6` toy.stats's paired percentile bootstrap CI for a ratio of means lies within 0.05 times the interval's width of scipy.stats.bootstrap(paired=True, method='percentile'), each with 10000 resamples.[^69]
- `t136-a1-f1` R3's 5 deterministic checks hold toy.stats to between 10 and 12 decimal places (or an absolute 1e-12) on 26 cases.[^70] The sixth check, the paired bootstrap interval, is held only to 0.05 of the interval's width.[^70] The artifact records that each assertion passed, not how large the observed differences were.[^70]
- `t136-a1-f2` The tie-handling checks are small: the tied signed-rank p is checked on a single vector of 10 differences with 5 distinct magnitudes, and DeLong and Spearman on ties are checked on 5 draws each.[^3]

<!-- wayline:records -->
Current report: [R3-1](reports/R3-1.md).

Synthesis: R3 is a correctness result, and its only artifact is the test file that states the comparisons; it records no computed values, only assertions that passed. Read as a table, it says the deterministic statistics (t-interval, exact signed-rank p with and without ties, DeLong covariance on tied scores, Spearman on ties) match an independent reference to between 10 and 12 decimal places, while the bootstrap interval, random on both sides, is held to a looser 0.05 of its width. The tied cases matter for this project because AUROC scores and paired differences can tie; the ties checks are single-vector or few-draw checks (1 tied signed-rank vector, 5 DeLong and 5 Spearman draws).
<!-- /wayline:records -->

#### R8. The paired statistics of a sweep point, checked by hand and against their records (supported)

- `t76-a1-f1` On the hand-worked fixture (three replicates, 10 held-out rows each), toy.paired reproduces every hand-derived answer: paired_gain 2/15 with a t-interval half-width of t(0.975, 2)·sqrt(79)/75, sd_d sqrt(237)/75, signed_rank_p 0.5, delong_rejections 1 (seed 2 only), mean Bayes AUROC 2.8/3, and gap_closed 10/17 with a paired-bootstrap CI of exactly (-1/3, 0.9).[^93]
- `t115-a1-f1` toy.paired exposes point_stats(point_dir) as its one-point entry point, with paired kept as an alias of the same function, and its command line writes the printed JSON to --out PATH when given.[^94]
- `t115-a1-f2` When the gap left by the without arm is at most 0.005, summarize sets gap_closed and its CI to null and fills gap_closed_reason with a sentence; when gap_closed is reported, gap_closed_reason is null.[^95]
- `t116-a2-f1` (replaces `t76-a1-f2`) toy.paired refuses, with exit 2, a point whose two arms ran different seeds, a seed whose arms disagree on the draw (seed, strength, signal, rows, train_rows), arms that scored different labels, labels that are not the held-out rows the recorded settings draw, a summary auroc that is not the AUROC of its own saved scores, a run filed under the wrong arm, missing or out-of-order scores, and a point whose replicates disagree on any compared setting.[^96]
- `t116-a2-f2` (replaces `t116-a1-f1`) toy.paired refuses a seed whose arms disagree on any training setting train.py records (val_fraction, epochs, lr, minibatch, the pinned config's content) and names that key.[^97] It refuses a with run without the interaction column, a without run that kept it, and a run whose config.json lacks any compared key or features.[^97] It still pairs arms that differ only in batch_size, dataloader_workers, device or the config path, and their statistics come out unchanged.[^97]
- `t141-a1-f1` Recomputed from toy.paired's own per-seed records at this sweep point, the paired gain, its sd, gap_closed and the mean AUROCs of both arms and the oracle all equal the summary values toy.paired reported.[^98]
- `t141-a1-f2` A seeded paired bootstrap of gap_closed, redrawn from the point's per-seed records, gives percentile bounds within 0.00004 of the CI toy.paired reported.[^99]
- `t141-a1-f3` At this sweep point the with arm's held-out AUROC falls short of the Bayes ceiling by 0.0009 on average over the seeds.[^7]

<!-- wayline:records -->
Current report: [R8-1](reports/R8-1.md).

Headline plot R8.1 (paired dot plot (dumbbell) with a reference tick):

![R8.1](../drawings/R8-1/arms_per_seed.png)

- Purpose: How far does each arm get on each seed, and how close does the with arm come to the oracle ceiling?
- Data: toy.paired's per-seed records in analysis/E2/paired.json (strength 1.0, signal 4.0, 20 paired seeds, 4000 held-out rows each). Orange circles: held-out AUROC without the interaction column. Blue squares: with it. Grey segment: joins one seed's two arms. Black tick: that seed's Bayes AUROC from the oracle. Seeds are categories, so no line runs across them.
- What it shows: On every seed the with arm sits just under its own ceiling, while the without arm lies far below it. The mean AUROCs are 0.768 without, 0.855 with and 0.856 for the ceiling.

Headline plot R8.2 (strip plot with a point-and-interval summary):

![R8.2](../drawings/R8-1/paired_differences.png)

- Purpose: How large and how consistent is the paired gain from the interaction column?
- Data: Blue dots: d = AUROC(with) − AUROC(without) for each of the 20 seeds, jittered vertically with a seeded draw only so the dots separate. Red diamond and bar: the mean gain and the 95% t-interval toy.paired reported.
- What it shows: Every seed gains, from 0.077 to 0.098. The mean gain is 0.087 with sd 0.006, and its interval runs from 0.084 to 0.09, far from zero. The exact signed-rank p toy.paired reported is 1.9e-06.

Headline plot R8.3 (scatter with reference lines):

![R8.3](../drawings/R8-1/gain_vs_gap.png)

- Purpose: What share of the gap to the Bayes ceiling does the interaction column close, seed by seed?
- Data: Blue dots: one seed each, x = Bayes AUROC − AUROC(without), y = d. Red line through the origin: slope gap_closed, the ratio of the mean gain to the mean gap. Grey dotted line: d equal to the gap (gap fully closed). Both axes subtract the same without-arm AUROC, so part of their tight association is built in: a weaker without arm both widens the gap and leaves more to gain.
- What it shows: The seeds lie close to the full-closure line. The mean gap is 0.088, gap_closed is 0.99, and the per-seed ratio runs from 0.969 to 1.001. On one seed the with arm scores just above its finite-sample Bayes AUROC. Part of the points' line-up comes from the shared without term.

Synthesis: At the one sweep point toy.paired has summarized (strength 1.0, 20 paired seeds), adding the interaction column raises held-out AUROC on every seed, by a mean of 0.087 (t-interval 0.084 to 0.09). Every seed's DeLong test rejects on its own. The with arm reaches a mean of 0.855 against a mean Bayes ceiling of 0.856, so it closes 0.99 of the gap the without arm leaves, with a bootstrap CI of 0.986 to 0.994. Recomputing from the per-seed records reproduces the reported gain, sd, gap_closed and mean AUROCs. A seeded bootstrap redrawn here lands within 0.00004 of the reported CI. These views show toy.paired's statistics and the ceiling on real runs. They do not show its hand-worked fixture or its refusals: the test file that holds them has changed since the manifest recorded it.
<!-- /wayline:records -->

#### R15. E3: paired gain across interaction strengths (C4, C5) (mixed)

- `t122-a2-f1` (replaces `t122-a1-f1`) At strength m = 0 (no planted interaction, 16000 training rows, 20 paired seeds), the mean paired gain of the x3*x4 column is -0.0003186665215305473, with a t-interval at confidence 0.95 of -0.0005967640897244911 to -4.056895333660356e-05 [^46] [^178] [^179] [^47] [^48] [^49] [^180].
- `t122-a2-f2` (replaces `t122-a1-f2`) C4 is supported: at m = 0 the t-interval at confidence 0.95 of the mean paired gain lies inside -0.01 to 0.01 [^181] [^46] [^48] [^49] [^180] [^50] [^51].
- `t122-a2-f3` (negative) (replaces `t122-a1-f3`) A4 does not hold: at m = 0 the lower bound of the t-interval at confidence 0.95 of the mean paired gain is above -0.01, so at the default training size of 16000 rows the unneeded column does not cost more than C4's tolerance [^214] [^46] [^48] [^180] [^50] [^178].
- `t122-a2-f4` (replaces `t122-a1-f4`) At m = 0 the column's cost is small but detectable: 16 of the 20 per-seed differences are negative, and the exact signed-rank p is 0.00485992431640625 [^46] [^182] [^179] [^183].
- `t122-a2-f5` (replaces `t122-a1-f5`) At m = 0 the column's mean paired gain is -0.0003186665215305473, a cost 31.38076743038538 times smaller in size than C4's tolerance of 0.01 [^46] [^185] [^184] [^215].
- `t122-a2-f6` (replaces `t122-a1-f6`) At m = 0 the DeLong test rejects at 0.05 on 2 of the 20 replicates [^46] [^216] [^217] [^179].
- `t122-a2-f7` (replaces `t122-a1-f7`) At m = 0 gap_closed is not reported, because the without arm's mean gap to the Bayes ceiling, 0.0007995212426435416, is not above the floor of 0.005 [^46] [^218] [^219] [^220] [^221]. At m = 0 the with arm's mean held-out AUROC is 0.8128026089519119, the without arm's 0.8131212754734426, and the oracle's 0.8139207967160861 [^46] [^222] [^223] [^169].
- `t123-a1-f1` (replaces `t109-a1-f8`) At m = 0.25 the mean paired gain is 0.006924435415007868, with a t-interval at confidence 0.95 from 0.0061247342470867674 to 0.0077241365829289685 [^189] [^190] [^224] [^225] [^180]. At m = 0.25 gap_closed is 0.8697196427899274, with a CI from 0.8330004369188385 to 0.9053704618086735, and the DeLong test rejects on 20 of the 20 replicates [^189] [^226] [^227] [^228] [^229] [^230].
- `t123-a1-f2` (replaces `t109-a1-f9`) At m = 0.5 the mean paired gain is 0.026716785955346812, with a t-interval at confidence 0.95 from 0.025427598893239502 to 0.02800597301745412, and gap_closed is 0.9589124322451849, with a CI from 0.9464932540108753 to 0.9708170401195537 [^191] [^192] [^231] [^232] [^180] [^233] [^234] [^235].
- `t123-a1-f3` (replaces `t109-a1-f10`) At m = 1, which reuses E2's runs, the mean paired gain is 0.08716535526499543, with a t-interval at confidence 0.95 from 0.08434218983093059 to 0.08998852069906027, and gap_closed is 0.9896174437934124 [^193] [^236] [^194] [^237] [^238] [^180] [^239].
- `t123-a1-f4` (replaces `t109-a1-f11`) At m = 2 the mean paired gain is 0.20305977863815153, with a t-interval at confidence 0.95 from 0.19909965847175126 to 0.2070198988045518, and gap_closed is 0.996633827391132 [^195] [^196] [^240] [^241] [^180] [^242].
- `t123-a1-f5` (replaces `t109-a1-f12`) At m = 4 the mean paired gain is 0.31434161002887523, with a t-interval at confidence 0.95 from 0.3109568572362925 to 0.31772636282145794, wholly above zero [^52] [^53] [^198] [^243] [^180].
- `t123-a1-f6` (replaces `t109-a1-f13`) At m = 4 the with arm's mean held-out AUROC is 0.9569689362650855, against the oracle's 0.9573724403710034 and the without arm's 0.6426273262362103, and gap_closed is 0.9987179972371389 [^52] [^200] [^170] [^244] [^201].
- `t123-a1-f7` (replaces `t109-a1-f14`) strength_spearman, Spearman's correlation between m and the mean paired gain over the 6 points, is 1.0 [^55] [^18].
- `t123-a1-f8` (replaces `t109-a1-f15`) The mean paired gain rises strictly at every step of the strength grid [^54] [^197].
- `t123-a1-f9` (replaces `t109-a1-f16`) C5 is supported: strength_spearman, 1.0, is at least spearman_min, 0.9, and at m = 4 the lower bound of the t-interval at confidence 0.95 of the mean paired gain, 0.3109568572362925, is above zero [^199] [^55] [^245] [^52] [^198] [^180].
- `t123-a1-f10` (replaces `t109-a1-f17`) A3 is confirmed: the gain is about zero at strength 0 (C4 is supported) and rises with the planted strength (C5 is supported), so it only restates what generate.py plants and is not a finding about interaction terms apart from the generator [^62] [^46] [^181] [^199].
- `t123-a1-f11` (negative) (replaces `t109-a1-f18`) No point's SD of d_i exceeds Q15's SD rule of 0.02, so the list of points that exceed it is empty and seeds 21 to 50 are not added at any strength [^246] [^247] [^248] [^249].
- `t123-a1-f12` (replaces `t109-a1-f19`) The largest SD of d_i over the 6 points is 0.008461534756361957 [^17] [^18].

#### R16. E4: paired gain across training sizes (C6) (mixed)

- `t110-a1-f1` At m = 1 with 1000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is 0.08749872642030157, with a t-interval at confidence 0.95 from 0.08431674206762646 to 0.09068071077297668 [^202] [^250] [^251] [^252] [^207] [^253] [^254].
- `t110-a1-f2` At m = 1 with 2000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is 0.08718983653005144, with a t-interval at confidence 0.95 from 0.0841952933838717 to 0.09018437967623118 [^255] [^256] [^257] [^258] [^207] [^259] [^260].
- `t110-a1-f3` At m = 1 with 4000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is 0.08714270655297177, with a t-interval at confidence 0.95 from 0.08403431475983457 to 0.09025109834610896 [^261] [^262] [^263] [^264] [^207] [^265] [^266].
- `t110-a1-f4` At m = 1 with 8000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is 0.0872613248977486, with a t-interval at confidence 0.95 from 0.08431982835169771 to 0.09020282144379949 [^267] [^268] [^269] [^270] [^207] [^271] [^272].
- `t110-a1-f5` At m = 1 with 32000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is 0.08737781037867107, with a t-interval at confidence 0.95 from 0.08565401917246722 to 0.08910160158487491 [^273] [^274] [^275] [^276] [^207] [^277] [^278].
- `t110-a1-f6` At m = 1 with 64000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is 0.08786251131921252, with a t-interval at confidence 0.95 from 0.0863493599255909 to 0.08937566271283415 [^279] [^280] [^281] [^282] [^207] [^283] [^284].
- `t110-a1-f7` At m = 0 (no planted interaction) with 1000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is -0.00024655913274218013, with a t-interval at confidence 0.95 from -0.0005093556314718568 to 1.623736598749644e-05; 12 of the per-seed differences are negative and the exact signed-rank p is 0.0758514404296875 [^213] [^285] [^286] [^287] [^207] [^288] [^289] [^290] [^291].
- `t110-a1-f8` At m = 0 (no planted interaction) with 2000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is -0.00012946543069410342, with a t-interval at confidence 0.95 from -0.00027598075101763843 to 1.7049889629431583e-05; 12 of the per-seed differences are negative and the exact signed-rank p is 0.0758514404296875 [^292] [^293] [^294] [^295] [^207] [^296] [^297] [^298] [^299].
- `t110-a1-f9` At m = 0 (no planted interaction) with 4000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is -0.00011075740449061899, with a t-interval at confidence 0.95 from -0.00027394065031801035 to 5.2425841336772345e-05; 11 of the per-seed differences are negative and the exact signed-rank p is 0.3299827575683594 [^300] [^301] [^302] [^303] [^207] [^304] [^305] [^306] [^307].
- `t110-a1-f10` At m = 0 (no planted interaction) with 8000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is -0.00015346134200449612, with a t-interval at confidence 0.95 from -0.00029105094290745866 to -1.5871741101533587e-05; 13 of the per-seed differences are negative and the exact signed-rank p is 0.069580078125 [^308] [^309] [^310] [^311] [^207] [^312] [^313] [^314] [^315].
- `t110-a1-f11` At m = 0 (no planted interaction) with 32000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is -0.00015580299768552797, with a t-interval at confidence 0.95 from -0.00030200567076750495 to -9.60032460355095e-06; 14 of the per-seed differences are negative and the exact signed-rank p is 0.023950576782226562 [^316] [^317] [^318] [^319] [^207] [^320] [^321] [^322] [^323].
- `t110-a1-f12` At m = 0 (no planted interaction) with 64000 training rows, the mean paired gain of the x3*x4 column over the 20 paired seeds is -0.00012215189815497073, with a t-interval at confidence 0.95 from -0.00023787628168152455 to -6.427514628416892e-06; 12 of the per-seed differences are negative and the exact signed-rank p is 0.0758514404296875 [^324] [^325] [^326] [^327] [^207] [^328] [^329] [^330] [^331].
- `t110-a1-f13` At m = 1, gain_shrink, the mean over the 20 shared seeds of the per-seed gain at 1000 training rows minus the per-seed gain at 64000, is -0.0003637848989109571, with a paired t-interval at confidence 0.95 from -0.003671575350341559 to 0.0029440055525196446 [^332] [^205] [^59] [^60] [^206] [^207] [^208] [^209].
- `t110-a1-f14` C6 is supported: at m = 1, gain_shrink, -0.0003637848989109571, is at most the limit of 0.005, and the upper bound of its t-interval at confidence 0.95, 0.0029440055525196446, is below that limit too [^61] [^332] [^206] [^210] [^207] [^209] [^333].
- `t110-a1-f15` (negative) A5 is not confirmed and C6's verdict is not unresolved: the lower bound of gain_shrink's t-interval, -0.003671575350341559, is not above 0.005, so the gain does not fall as training rows grow from 1000 to 64000 at m = 1 [^211] [^334] [^208] [^210] [^59] [^60] [^332].
- `t110-a1-f16` (negative) At m = 1 the mean paired gain stays between 0.08714270655297177 and 0.08786251131921252 over all 7 training sizes from 1000 to 64000 rows, a range of 0.0007198047662407558, and it is neither strictly falling nor strictly rising with size [^332] [^56] [^57] [^58] [^59] [^60] [^335] [^203] [^204].
- `t110-a1-f17` At m = 1 with 1000 training rows the with arm's mean held-out AUROC is 0.8549796629676963, against the oracle's 0.8561365857801138 and the without arm's 0.7674809365473949, so the column closes a fraction gap_closed of 0.9869503768521246 of the without arm's gap to the Bayes ceiling [^202] [^250] [^336] [^337] [^338] [^212].
- `t110-a1-f18` At m = 1 with 64000 training rows the with arm's mean held-out AUROC is 0.8539837723485484, against the oracle's 0.8548397780523894 and the without arm's 0.7661212610293358, so the column closes a fraction gap_closed of 0.9903514426011134 of the without arm's gap to the Bayes ceiling [^279] [^280] [^339] [^340] [^341] [^342].
- `t110-a1-f19` (negative) At m = 0, gain_shrink between 1000 and 64000 training rows is -0.00012440723458720938, with a t-interval at confidence 0.95 from -0.0004162716103747647 to 0.00016745714120034596; it is reported, not claimed [^332] [^59] [^60] [^343] [^207] [^344] [^345].
- `t110-a1-f20` At m = 0 the t-interval at confidence 0.95 of the mean paired gain lies inside -0.01 to 0.01 at all 7 of the 7 training sizes, so the unneeded column costs less than C4's tolerance at every size from 1000 to 64000 rows [^332] [^207] [^346] [^347] [^186] [^58] [^59] [^60].
- `t110-a1-f21` At m = 0 the column's cost is small but detectable at some sizes: the t-interval at confidence 0.95 lies wholly below zero at 4 of the 7 sizes (8000, 16000, 32000, 64000 training rows) and wholly above zero at 0, and the most negative mean paired gain, -0.0003186665215305473, is at 16000 training rows [^332] [^207] [^187] [^58] [^348] [^349] [^350] [^351].
- `t110-a1-f22` (negative) No point of either size sweep has an SD of d_i above Q15's SD rule of 0.02, so seeds beyond 20 are not added; the largest SD over the 14 points is 0.006798902574422248 [^19] [^20] [^21] [^22] [^23].

### O5. Do explicit interaction terms still raise held-out AUROC over models that can learn interactions unaided, such as gradient-boosted trees or an MLP?

<!-- wayline:records -->
Status: parked. Why: the owner: "park Q4".

No result yet.
<!-- /wayline:records -->

## 5. Results beyond the objectives

### R18. Documentation site for the toy package, with the docstrings its build checks for (negative)

- `t131-a1-f1` (negative) train.py's module docstring and ready_interactions docstring on main claimed the batch_size x batch_size gram tensor is used to down-weight interaction terms for duplicate-looking rows.[^352] The code allocates a tensor of zeros and deletes it before training without reading it, and the minibatch is fixed at DEFAULT_MINIBATCH (256).[^352] So --batch-size changes neither the fit nor the scores.[^352] Both docstrings now say this.[^352]
- `t131-a1-f2` (negative) No module in src/toy implements a keep rule. toy.goallog reads each candidate's `kept` field (true, false, or null), checks it is the same on every line of that candidate, and counts kept and discarded.[^353] Whatever decides keep-if-better lives outside the package.[^353]

## 6. Inherited claims not yet checked

<!-- wayline:records -->
No inherited claim waits to be checked.
<!-- /wayline:records -->

## 7. What can and cannot be inferred

<!-- wayline:records -->
Can be inferred:
- R1 Default draw stays fixed under the strength parameter (supported): 2 current findings.
- R2 Adding the interaction flags leaves the default training run unchanged (supported): 2 current findings.
- R3 The statistics code agrees with independent reference implementations (supported): 8 current findings.
- R5 The convergence check flags only a training loss that still falls (supported): 2 current findings.
- R6 Oracle audit cost on the 10^6-row draw D2 (supported): 1 current finding.
- R7 E2 gate: reproduction and convergence (supported): 8 current findings.
- R8 The paired statistics of a sweep point, checked by hand and against their records (supported): 8 current findings.
- R9 The evaluation command never reads the held-out score when selecting on validation (supported): 3 current findings.
- R10 How a prior work counts as settled in the literature placement (supported): 2 current findings.
- R12 Evaluation command (supported): 1 current finding.

Cannot be inferred:
- R4 The oracle's true class probability matches the generator (mixed): 1 of its 8 current findings is negative.
- R11 E1: planted interaction, additive gap and Bayes ceiling on D2 (mixed): 2 of its 17 current findings are negative.
- R13 E6: literature placement of C3-C6 (C8) (mixed): 2 of its 5 current findings are negative.
- R14 E2: paired AUROC gain of the x3*x4 column over 20 seeds (mixed): 1 of its 15 current findings is negative.
- R15 E3: paired gain across interaction strengths (C4, C5) (mixed): 2 of its 19 current findings are negative.
- R16 E4: paired gain across training sizes (C6) (mixed): 4 of its 22 current findings are negative.
- R17 E5: the goal run against O2's 0.82 (C7) (mixed): 1 of its 8 current findings is negative.
- R18 Documentation site for the toy package, with the docstrings its build checks for (negative): its current findings are all negative.

Open questions:
- none: no objective and no concern is open.
<!-- /wayline:records -->

## Supplementary references

<!-- wayline:records -->
Each citation is a provenance tag: `res:<run-id>/<artifact>#<locator>` names a result in `research/manifest.json`, and `ref:<slug>#<locator>` a reference under `research/refs/<slug>/`.
<!-- /wayline:records -->

[^1]: `res:t2-a3/src/toy/generate.py#row`
[^2]: `res:t3-a1/tests/test_train.py#test_arms_share_initial_weights_and_without_never_moves_the_interaction_weight`
[^3]: `res:t136-a1/drawings/R3-1/numbers.json#signed_rank_tied_n,signed_rank_tied_distinct_abs,delong_cases,spearman_cases`
[^4]: `res:t6-a1/tests/test_oracle.py#Quadrature.test_logistic_normal_integral_is_converged`
[^5]: `res:t8-a2/src/toy/converge.py#_epochs`
[^6]: `res:t53-a1/tests/test_oracle_budget.py#TIME_LIMIT_SECONDS`
[^7]: `res:t141-a1/drawings/R8-1/numbers.json#shortfall_with_mean`
[^8]: `res:t117-a1/src/toy/eval.py#read_metric`
[^9]: `res:t98-a1/src/toy/placement.py#check_entry`
[^10]: `res:t144-a1/drawings/R11-1/numbers.json#oracle_minus_bayes`
[^11]: `res:t95-a1/tests/test_eval.py#Eval.test_wayline_artifact_run_directory_reads_its_summary_json`
[^12]: `res:t112-a1/analysis/E6/placement_summary.json#unsettled`
[^13]: `res:t111-a1/analysis/E5/goal.json#a7`
[^14]: `res:t111-a1/analysis/E5/goal.json#mean_auroc_with_e2`
[^15]: `res:t111-a1/analysis/E5/goal.json#e2_n_pairs`
[^16]: `res:t111-a1/analysis/E5/goal.json#goal`
[^17]: `res:t122-a2/analysis/E3/verdict.json#max_sd_d`
[^18]: `res:t122-a2/analysis/E3/verdict.json#n_points`
[^19]: `res:t110-a1/analysis/E4/verdict.json#sd_rule`
[^20]: `res:t110-a1/analysis/E4/verdict.json#sd_rule_exceeded_at`
[^21]: `res:t110-a1/analysis/E4/verdict.json#seed_last`
[^22]: `res:t110-a1/analysis/E4/verdict.json#n_points`
[^23]: `res:t110-a1/analysis/E4/verdict.json#max_sd_d`
[^24]: `res:t111-a1/analysis/E5/goal.json#c7_supported`
[^25]: `res:t111-a1/analysis/E5/goal.json#c7_rule`
[^26]: `res:t111-a1/analysis/E5/goal.json#goal_met`
[^27]: `res:t111-a1/analysis/E5/goal.json#heldout_reads`
[^28]: `res:t111-a1/analysis/E5/goal.json#max_heldout_reads`
[^29]: `res:t111-a1/analysis/E5/goal.json#kept_chosen_by_val_auroc`
[^30]: `res:t111-a1/analysis/E5/goal.json#kept_changes`
[^31]: `res:t120-a1/analysis/E2/paired.json#mean_auroc_without`
[^32]: `res:t120-a1/analysis/E2/paired.json#mean_auroc_with`
[^33]: `res:t120-a1/analysis/E2/paired.json#n_pairs`
[^34]: `res:t120-a1/analysis/E2/paired.json#paired_gain`
[^35]: `res:t120-a1/analysis/E2/paired.json#paired_gain_lo`
[^36]: `res:t120-a1/analysis/E2/paired.json#paired_gain_hi`
[^37]: `res:t120-a1/analysis/E2/verdict.json#confidence`
[^38]: `res:t120-a1/analysis/E2/verdict.json#n_positive_d`
[^39]: `res:t120-a1/analysis/E2/verdict.json#n_pairs`
[^40]: `res:t120-a1/analysis/E2/paired.json#signed_rank_p`
[^41]: `res:t120-a1/analysis/E2/verdict.json#c3_supported`
[^42]: `res:t120-a1/analysis/E2/paired.json#gap_closed`
[^43]: `res:t120-a1/analysis/E2/paired.json#gap_closed_lo`
[^44]: `res:t120-a1/analysis/E2/paired.json#gap_closed_hi`
[^45]: `res:t120-a1/analysis/E2/paired.json#mean_bayes_auroc`
[^46]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.m`
[^47]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.paired_gain`
[^48]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.paired_gain_lo`
[^49]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.paired_gain_hi`
[^50]: `res:t122-a2/analysis/E3/verdict.json#harmless_lo`
[^51]: `res:t122-a2/analysis/E3/verdict.json#harmless_hi`
[^52]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m4.m`
[^53]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m4.paired_gain`
[^54]: `res:t122-a2/analysis/E3/verdict.json#gain_monotone_in_strength`
[^55]: `res:t122-a2/analysis/E3/verdict.json#strength_spearman`
[^56]: `res:t110-a1/analysis/E4/verdict.json#m1_min_paired_gain`
[^57]: `res:t110-a1/analysis/E4/verdict.json#m1_max_paired_gain`
[^58]: `res:t110-a1/analysis/E4/verdict.json#n_sizes`
[^59]: `res:t110-a1/analysis/E4/verdict.json#smallest_train_rows`
[^60]: `res:t110-a1/analysis/E4/verdict.json#largest_train_rows`
[^61]: `res:t110-a1/analysis/E4/verdict.json#c6_supported`
[^62]: `res:t122-a2/analysis/E3/verdict.json#a3`
[^63]: `res:t3-a1/tests/test_train.py#BASE_AUROC`
[^64]: `res:t5-a3/tests/test_stats_scipy.py#L38`
[^65]: `res:t5-a3/tests/test_stats_scipy.py#L42-L43`
[^66]: `res:t5-a3/tests/test_stats_scipy.py#L29-L30`
[^67]: `res:t5-a3/tests/test_stats_scipy.py#L68-L69`
[^68]: `res:t5-a3/tests/test_stats_scipy.py#L84`
[^69]: `res:t5-a3/tests/test_stats_scipy.py#L98-L106`
[^70]: `res:t136-a1/drawings/R3-1/numbers.json#deterministic_checks,deterministic_cases,min_decimal_places,max_decimal_places,delong_atol,bootstrap_width_fraction`
[^71]: `res:t2-a3/src/toy/generate.py#L23-L39`
[^72]: `res:t6-a1/tests/test_oracle.py#L186-L204`
[^73]: `res:t6-a1/tests/test_oracle.py#Calibration.test_calibration_error_on_200000_rows_and_a_miscalibrated_control`
[^74]: `res:t6-a1/tests/test_oracle.py#Calibration.test_oracle_is_calibrated_on_20000_rows`
[^75]: `res:t6-a1/tests/test_oracle.py#Transcription.test_true_prob_matches_generate_row_by_monte_carlo`
[^76]: `res:t6-a1/tests/test_oracle.py#Calibration.test_largest_gap_at_20000_rows_is_sampling_noise`
[^77]: `res:t6-a1/tests/test_oracle.py#Cli.test_interaction_weight_is_the_unrounded_product`
[^78]: `res:t8-a2/src/toy/converge.py#convergence`
[^79]: `res:t104-a2/analysis/E2/checks.json#run_auroc_with_seed1`
[^80]: `res:t104-a2/analysis/E2/checks.json#b3_auroc`
[^81]: `res:t104-a2/analysis/E2/checks.json#reproduction_gap`
[^82]: `res:t104-a2/analysis/E2/checks.json#reproduction_limit`
[^83]: `res:t104-a2/analysis/E2/checks.json#reproduction_passed`
[^84]: `res:t104-a2/analysis/E2/checks.json#worst_run`
[^85]: `res:t104-a2/analysis/E2/checks.json#convergence_drop`
[^86]: `res:t104-a2/analysis/E2/checks.json#n_runs`
[^87]: `res:t104-a2/analysis/E2/checks.json#convergence_limit`
[^88]: `res:t104-a2/analysis/E2/checks.json#convergence_passed`
[^89]: `res:t104-a2/analysis/E2/checks.json#n_negative_drops`
[^90]: `res:t104-a2/analysis/E2/checks.json#negative_drop_runs`
[^91]: `res:t140-a1/drawings/R7-1/numbers.json#n_runs,mean_drop,n_negative_drops,max_abs_drop_share_of_limit,convergence_limit`
[^92]: `res:t140-a1/drawings/R7-1/numbers.json#epochs_pinned,epochs_double,max_abs_loss_change,mean_loss_pinned_gap_without_minus_with,mean_loss_pinned_without,mean_loss_pinned_with`
[^93]: `res:t76-a1/tests/test_paired.py#HandWorkedAnswers`
[^94]: `res:t115-a1/src/toy/paired.py#point_stats`
[^95]: `res:t115-a1/src/toy/paired.py#summarize`
[^96]: `res:t76-a1/tests/test_paired.py#Refusals`
[^97]: `res:t76-a1/tests/test_paired.py#PinnedSettings`
[^98]: `res:t141-a1/drawings/R8-1/numbers.json#recomputed_matches_file`
[^99]: `res:t141-a1/drawings/R8-1/numbers.json#bootstrap_ci_max_endpoint_diff`
[^100]: `res:t95-a1/tests/test_eval.py#Eval.test_o2_command_reads_wayline_artifact_unchanged`
[^101]: `res:t95-a1/tests/test_eval.py#Eval.test_val_split_never_falls_back_to_held_out`
[^102]: `res:t98-a1/src/toy/placement.py#place`
[^103]: `res:t112-a1/analysis/E6/placement_summary.json#resolved_refs`
[^104]: `res:t112-a1/analysis/E6/placement_summary.json#prior_measures_gain`
[^105]: `res:t112-a1/analysis/E6/placement_summary.json#c8_verdict`
[^106]: `res:t112-a1/analysis/E6/placement_summary.json#mismatches`
[^107]: `res:t120-a1/analysis/E2/verdict.json#c2_bound_supported`
[^108]: `res:t120-a1/analysis/E2/verdict.json#bayes_minus_with`
[^109]: `res:t120-a1/analysis/E2/verdict.json#bayes_minus_without`
[^110]: `res:t120-a1/analysis/E2/verdict.json#bound_slack`
[^111]: `res:t120-a1/analysis/E2/verdict.json#n_with_above_bayes`
[^112]: `res:t120-a1/analysis/E2/verdict.json#max_with_minus_bayes`
[^113]: `res:t120-a1/analysis/E2/verdict.json#c2_supported`
[^114]: `res:t120-a1/analysis/E2/verdict.json#c2_ceiling_supported`
[^115]: `res:t120-a1/analysis/E2/paired.json#train_rows`
[^116]: `res:t120-a1/analysis/E2/verdict.json#a2_confirmed`
[^117]: `res:t120-a1/analysis/E2/verdict.json#min_d`
[^118]: `res:t120-a1/analysis/E2/verdict.json#max_d`
[^119]: `res:t120-a1/analysis/E2/paired.json#delong_rejections`
[^120]: `res:t120-a1/analysis/E2/verdict.json#delong_alpha`
[^121]: `res:t120-a1/analysis/E2/verdict.json#bootstrap_resamples`
[^122]: `res:t120-a1/analysis/E2/paired.json#gap_denominator`
[^123]: `res:t120-a1/analysis/E2/verdict.json#gap_denominator_min`
[^124]: `res:t120-a1/analysis/E2/verdict.json#p_limit`
[^125]: `res:t120-a1/analysis/E2/verdict.json#gate_passed`
[^126]: `res:t120-a1/analysis/E2/verdict.json#sd_d`
[^127]: `res:t120-a1/analysis/E2/verdict.json#sd_rule`
[^128]: `res:t120-a1/analysis/E2/verdict.json#q15_revisit`
[^129]: `res:t120-a1/analysis/E2/verdict.json#revisit_seed_first`
[^130]: `res:t120-a1/analysis/E2/verdict.json#revisit_seed_last`
[^131]: `res:t111-a1/analysis/E5/goal.json#goal_seed`
[^132]: `res:t111-a1/analysis/E5/goal.json#goal_run_auroc`
[^133]: `res:t111-a1/analysis/E5/goal.json#goal_run_minus_goal`
[^134]: `res:t111-a1/analysis/E5/goal.json#heldout_scorings`
[^135]: `res:t111-a1/analysis/E5/goal.json#candidates_tried`
[^136]: `res:t111-a1/analysis/E5/goal.json#seed_aurocs.seed1`
[^137]: `res:t111-a1/analysis/E5/goal.json#seed_aurocs.seed2`
[^138]: `res:t111-a1/analysis/E5/goal.json#seed_aurocs.seed3`
[^139]: `res:t111-a1/analysis/E5/goal.json#start_mean_auroc`
[^140]: `res:t111-a1/analysis/E5/goal.json#harness_judgment.value`
[^141]: `res:t111-a1/analysis/E5/goal.json#harness_judgment.kept`
[^142]: `res:t111-a1/analysis/E5/goal.json#harness_judgment.value_equals_start_mean`
[^143]: `res:t111-a1/analysis/E5/goal.json#bayes_auroc`
[^144]: `res:t111-a1/analysis/E5/goal.json#ceiling_below_goal`
[^145]: `res:t111-a1/analysis/E5/goal.json#a6`
[^146]: `res:t111-a1/analysis/E5/goal.json#ceiling_minus_goal_run`
[^147]: `res:t102-a1/results/E1/oracle.json#label_rule`
[^148]: `res:t102-a1/results/E1/oracle.json#noise_sd`
[^149]: `res:t102-a1/results/E1/oracle.json#signal`
[^150]: `res:t102-a1/results/E1/oracle.json#strength`
[^151]: `res:t102-a1/results/E1/oracle.json#interaction_weight`
[^152]: `res:t102-a1/results/E1/oracle.json#interaction_coefficient`
[^153]: `res:t102-a1/results/E1/oracle.json#rows`
[^154]: `res:t102-a1/results/E1/oracle.json#seed`
[^155]: `res:t102-a1/results/E1/oracle.json#additive_fit_rows`
[^156]: `res:t102-a1/results/E1/oracle.json#additive_scored_rows`
[^157]: `res:t102-a1/results/E1/oracle.json#additive_auroc`
[^158]: `res:t102-a1/results/E1/oracle.json#oracle_auroc_second_half`
[^159]: `res:t102-a1/results/E1/oracle.json#additive_gap`
[^160]: `res:t103-a1/analysis/E1/summary.json#limits.additive_gap`
[^161]: `res:t102-a1/results/E1/oracle.json#additive_coefficients`
[^162]: `res:t102-a1/results/E1/oracle.json#calibration_error`
[^163]: `res:t103-a1/analysis/E1/summary.json#limits.calibration_error`
[^164]: `res:t102-a1/results/E1/oracle.json#bayes_auroc`
[^165]: `res:t102-a1/results/E1/oracle.json#bayes_auroc_halfwidth`
[^166]: `res:t103-a1/analysis/E1/summary.json#limits.bayes_auroc_halfwidth`
[^167]: `res:t103-a1/analysis/E1/summary.json#c1_supported`
[^168]: `res:t103-a1/analysis/E1/summary.json#c2_ceiling_supported`
[^169]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.mean_bayes_auroc`
[^170]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m4.mean_bayes_auroc`
[^171]: `res:t103-a1/analysis/E1/summary.json#ceiling_minus_goal`
[^172]: `res:t103-a1/analysis/E1/summary.json#limits.goal`
[^173]: `res:t2-a3/tests/test_generate.py#DEFAULT_DRAW_SHA256`
[^174]: `res:t102-a1/results/E1/oracle.json#calibration_bins`
[^175]: `res:t144-a1/drawings/R11-1/numbers.json#share_of_ceiling_gap_closed_by_goal`
[^176]: `res:t144-a1/drawings/R11-1/numbers.json#goal_minus_additive`
[^177]: `res:t144-a1/drawings/R11-1/numbers.json#coef_ratio_x1_x2`
[^178]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.train_rows`
[^179]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.n_pairs`
[^180]: `res:t122-a2/analysis/E3/verdict.json#confidence`
[^181]: `res:t122-a2/analysis/E3/verdict.json#c4_supported`
[^182]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.n_negative_d`
[^183]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.signed_rank_p`
[^184]: `res:t122-a2/analysis/E3/verdict.json#zero_cost.band_over_cost`
[^185]: `res:t122-a2/analysis/E3/verdict.json#zero_cost.harmless_band`
[^186]: `res:t110-a1/analysis/E4/verdict.json#m0_cost.n_sizes_ci_inside_band`
[^187]: `res:t110-a1/analysis/E4/verdict.json#m0_cost.n_sizes_ci_below_zero`
[^188]: `res:t122-a2/analysis/E3/verdict.json#train_rows`
[^189]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0p25.m`
[^190]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0p25.paired_gain`
[^191]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0p5.m`
[^192]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0p5.paired_gain`
[^193]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m1.m`
[^194]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m1.paired_gain`
[^195]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m2.m`
[^196]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m2.paired_gain`
[^197]: `res:t122-a2/analysis/E3/verdict.json#strength_grid`
[^198]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m4.paired_gain_lo`
[^199]: `res:t122-a2/analysis/E3/verdict.json#c5_supported`
[^200]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m4.mean_auroc_with`
[^201]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m4.gap_closed`
[^202]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.m`
[^203]: `res:t110-a1/analysis/E4/verdict.json#m1_gain_monotone_decreasing`
[^204]: `res:t110-a1/analysis/E4/verdict.json#m1_gain_monotone_increasing`
[^205]: `res:t110-a1/analysis/E4/verdict.json#m1_gain_shrink_n`
[^206]: `res:t110-a1/analysis/E4/verdict.json#m1_gain_shrink`
[^207]: `res:t110-a1/analysis/E4/verdict.json#confidence`
[^208]: `res:t110-a1/analysis/E4/verdict.json#m1_gain_shrink_lo`
[^209]: `res:t110-a1/analysis/E4/verdict.json#m1_gain_shrink_hi`
[^210]: `res:t110-a1/analysis/E4/verdict.json#shrink_limit`
[^211]: `res:t110-a1/analysis/E4/verdict.json#a5`
[^212]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.gap_closed`
[^213]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n1000.m`
[^214]: `res:t122-a2/analysis/E3/verdict.json#a4`
[^215]: `res:t122-a2/analysis/E3/verdict.json#zero_cost.paired_gain`
[^216]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.delong_rejections`
[^217]: `res:t122-a2/analysis/E3/verdict.json#delong_alpha`
[^218]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.gap_closed`
[^219]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.gap_closed_reason`
[^220]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.gap_denominator`
[^221]: `res:t122-a2/analysis/E3/verdict.json#gap_denominator_min`
[^222]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.mean_auroc_with`
[^223]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0.mean_auroc_without`
[^224]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0p25.paired_gain_lo`
[^225]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0p25.paired_gain_hi`
[^226]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0p25.gap_closed`
[^227]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0p25.gap_closed_lo`
[^228]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0p25.gap_closed_hi`
[^229]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0p25.delong_rejections`
[^230]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0p25.n_pairs`
[^231]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0p5.paired_gain_lo`
[^232]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0p5.paired_gain_hi`
[^233]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0p5.gap_closed`
[^234]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0p5.gap_closed_lo`
[^235]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m0p5.gap_closed_hi`
[^236]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m1.dir`
[^237]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m1.paired_gain_lo`
[^238]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m1.paired_gain_hi`
[^239]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m1.gap_closed`
[^240]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m2.paired_gain_lo`
[^241]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m2.paired_gain_hi`
[^242]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m2.gap_closed`
[^243]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m4.paired_gain_hi`
[^244]: `res:t122-a2/analysis/E3/verdict.json#by_strength.m4.mean_auroc_without`
[^245]: `res:t122-a2/analysis/E3/verdict.json#spearman_min`
[^246]: `res:t122-a2/analysis/E3/verdict.json#sd_rule`
[^247]: `res:t122-a2/analysis/E3/verdict.json#sd_rule_exceeded_at`
[^248]: `res:t122-a2/analysis/E3/verdict.json#revisit_seed_first`
[^249]: `res:t122-a2/analysis/E3/verdict.json#revisit_seed_last`
[^250]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.train_rows`
[^251]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.n_pairs`
[^252]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.paired_gain`
[^253]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.paired_gain_lo`
[^254]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.paired_gain_hi`
[^255]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n2000.m`
[^256]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n2000.train_rows`
[^257]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n2000.n_pairs`
[^258]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n2000.paired_gain`
[^259]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n2000.paired_gain_lo`
[^260]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n2000.paired_gain_hi`
[^261]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n4000.m`
[^262]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n4000.train_rows`
[^263]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n4000.n_pairs`
[^264]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n4000.paired_gain`
[^265]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n4000.paired_gain_lo`
[^266]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n4000.paired_gain_hi`
[^267]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n8000.m`
[^268]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n8000.train_rows`
[^269]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n8000.n_pairs`
[^270]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n8000.paired_gain`
[^271]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n8000.paired_gain_lo`
[^272]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n8000.paired_gain_hi`
[^273]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n32000.m`
[^274]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n32000.train_rows`
[^275]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n32000.n_pairs`
[^276]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n32000.paired_gain`
[^277]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n32000.paired_gain_lo`
[^278]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n32000.paired_gain_hi`
[^279]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.m`
[^280]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.train_rows`
[^281]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.n_pairs`
[^282]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.paired_gain`
[^283]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.paired_gain_lo`
[^284]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.paired_gain_hi`
[^285]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n1000.train_rows`
[^286]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n1000.n_pairs`
[^287]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n1000.paired_gain`
[^288]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n1000.paired_gain_lo`
[^289]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n1000.paired_gain_hi`
[^290]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n1000.n_negative_d`
[^291]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n1000.signed_rank_p`
[^292]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n2000.m`
[^293]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n2000.train_rows`
[^294]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n2000.n_pairs`
[^295]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n2000.paired_gain`
[^296]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n2000.paired_gain_lo`
[^297]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n2000.paired_gain_hi`
[^298]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n2000.n_negative_d`
[^299]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n2000.signed_rank_p`
[^300]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n4000.m`
[^301]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n4000.train_rows`
[^302]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n4000.n_pairs`
[^303]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n4000.paired_gain`
[^304]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n4000.paired_gain_lo`
[^305]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n4000.paired_gain_hi`
[^306]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n4000.n_negative_d`
[^307]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n4000.signed_rank_p`
[^308]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n8000.m`
[^309]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n8000.train_rows`
[^310]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n8000.n_pairs`
[^311]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n8000.paired_gain`
[^312]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n8000.paired_gain_lo`
[^313]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n8000.paired_gain_hi`
[^314]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n8000.n_negative_d`
[^315]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n8000.signed_rank_p`
[^316]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n32000.m`
[^317]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n32000.train_rows`
[^318]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n32000.n_pairs`
[^319]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n32000.paired_gain`
[^320]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n32000.paired_gain_lo`
[^321]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n32000.paired_gain_hi`
[^322]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n32000.n_negative_d`
[^323]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n32000.signed_rank_p`
[^324]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n64000.m`
[^325]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n64000.train_rows`
[^326]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n64000.n_pairs`
[^327]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n64000.paired_gain`
[^328]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n64000.paired_gain_lo`
[^329]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n64000.paired_gain_hi`
[^330]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n64000.n_negative_d`
[^331]: `res:t110-a1/analysis/E4/verdict.json#by_size.m0.n64000.signed_rank_p`
[^332]: `res:t110-a1/analysis/E4/verdict.json#strengths`
[^333]: `res:t110-a1/analysis/E4/verdict.json#m1_gain_shrink_ci_below_limit`
[^334]: `res:t110-a1/analysis/E4/verdict.json#unresolved`
[^335]: `res:t110-a1/analysis/E4/verdict.json#m1_gain_range`
[^336]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.mean_auroc_with`
[^337]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.mean_bayes_auroc`
[^338]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n1000.mean_auroc_without`
[^339]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.mean_auroc_with`
[^340]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.mean_bayes_auroc`
[^341]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.mean_auroc_without`
[^342]: `res:t110-a1/analysis/E4/verdict.json#by_size.m1.n64000.gap_closed`
[^343]: `res:t110-a1/analysis/E4/verdict.json#m0_gain_shrink`
[^344]: `res:t110-a1/analysis/E4/verdict.json#m0_gain_shrink_lo`
[^345]: `res:t110-a1/analysis/E4/verdict.json#m0_gain_shrink_hi`
[^346]: `res:t110-a1/analysis/E4/verdict.json#m0_cost.harmless_lo`
[^347]: `res:t110-a1/analysis/E4/verdict.json#m0_cost.harmless_hi`
[^348]: `res:t110-a1/analysis/E4/verdict.json#m0_cost.sizes_ci_below_zero`
[^349]: `res:t110-a1/analysis/E4/verdict.json#m0_cost.n_sizes_ci_above_zero`
[^350]: `res:t110-a1/analysis/E4/verdict.json#m0_cost.most_negative_paired_gain`
[^351]: `res:t110-a1/analysis/E4/verdict.json#m0_cost.most_negative_paired_gain_at`
[^352]: `res:t131-a1/src/toy/train.py#ready_interactions (train() calls it then `del gram` before the loop; DataLoader uses batch_size=DEFAULT_MINIBATCH)`
[^353]: `res:t131-a1/src/toy/goallog.py#summarise`

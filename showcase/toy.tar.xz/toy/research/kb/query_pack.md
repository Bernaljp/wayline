# Knowledge base

Relations only: the dossiers hold what each paper says. 17 node(s) (paper 17); 0 edge(s).

## Edges

- none yet

## Nodes

- `bien-2013-lasso-hierarchical-interactions` paper, L2, verified, 2013, doi 10.1214/13-aos1096 -- A lasso for hierarchical interactions
- `cl-men-on-2008-ranking-empirical-minimization-u-statistics` paper, L0, verified, 2008, doi 10.1214/009052607000000910 -- Ranking and Empirical Minimization of U-statistics
- `delong-1988-comparing-areas-under-two-more` paper, L0, verified, 1988, doi 10.2307/2531595 -- Comparing the Areas under Two or More Correlated Receiver Operating Characteristic Curves: A Nonparametric Approach
- `dietterich-1998-approximate-statistical-tests-comparing-supervised` paper, L0, verified, 1998, doi 10.1162/089976698300017197 -- Approximate Statistical Tests for Comparing Supervised Classification Learning Algorithms
- `dwork-2014-preserving-statistical-validity-adaptive-data` paper, L0, verified, 2014, arxiv_id 1411.2664 -- Preserving Statistical Validity in Adaptive Data Analysis
- `dwork-2017-guilt-free-data-reuse` paper, L0, verified, 2017, doi 10.1145/3051088 -- Guilt-free data reuse
- `emmert-streib-2019-evaluation-regression-models-model-assessment` paper, L0, verified, 2019, doi 10.3390/make1010032 -- Evaluation of Regression Models: Model Assessment, Model Selection and Generalization Error
- `friedman-2008-predictive-learning-rule-ensembles` paper, L2, verified, 2008, doi 10.1214/07-aoas148 -- Predictive learning via rule ensembles
- `hanley-1982-meaning-use-area-under-receiver` paper, L0, verified, 1982, doi 10.1148/radiology.143.1.7063747 -- The meaning and use of the area under a receiver operating characteristic (ROC) curve.
- `lou-2013-accurate-intelligible-models-pairwise-interactions` paper, L0, verified, 2013, doi 10.1145/2487575.2487579 -- Accurate intelligible models with pairwise interactions
- `menon-2014-bayes-optimal-scorers-bipartite-ranking` paper, L0, verified, 2014 -- Bayes-Optimal Scorers for Bipartite Ranking
- `paper-a` paper, L0, unresolved -- - PDF: `materials/paper-a.pdf`
- `paper-b` paper, L0, unresolved -- - PDF: `materials/paper-b.pdf`
- `raschka-2018-model-evaluation-model-selection-algorithm` paper, L0, verified, 2018, arxiv_id 1811.12808 -- Model Evaluation, Model Selection, and Algorithm Selection in Machine Learning
- `sun-2014-fast-implementation-delong-s-algorithm` paper, L0, verified, 2014, doi 10.1109/LSP.2014.2337313 -- Fast Implementation of DeLong’s Algorithm for Comparing the Areas Under Correlated Receiver Operating Characteristic Curves
- `ushio-2026-bayes-optimal-ber-auc-estimation` paper, L0, verified, 2026, arxiv_id 2609.02304 -- Bayes-Optimal BER and AUC: Estimation and Evaluation of Estimators
- `ziegel-1987-numerical-recipes-art-scientific-computing` paper, L0, verified, 1987, doi 10.1080/00401706.1987.10488304 -- Numerical Recipes: The Art of Scientific Computing

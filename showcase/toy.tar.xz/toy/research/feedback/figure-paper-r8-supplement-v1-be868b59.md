# Traps figure paper-r8-supplement would promote into the plot index

The figure role hit 1 library trap(s) the plot index did not name, recorded in `figures/paper-r8-supplement/figure_result.json` (version 1). Fold them into `figures/plot_index.json` with `wayline figures fold-traps figures/paper-r8-supplement/figure_result.json`, which matches each to its entry by chart type and library and adds it to that entry's `known_pitfalls`.

- matplotlib, histogram with reference lines: A redrawn bootstrap interval and the reported interval differ by at most 0.00004 on a 0.023-wide axis, so drawing both as vertical lines makes them coincide (at most 0.07 mm apart) and hides the comparison. Fix: Draw the reported CI as a point-and-interval above the bars, the redrawn quantiles as dashed lines, and print the endpoint differences in the panel.

# Traps figure paper-r11-supplement would promote into the plot index

The figure role hit 1 library trap(s) the plot index did not name, recorded in `figures/paper-r11-supplement/figure_result.json` (version 1). Fold them into `figures/plot_index.json` with `wayline figures fold-traps figures/paper-r11-supplement/figure_result.json`, which matches each to its entry by chart type and library and adds it to that entry's `known_pitfalls`.

- matplotlib, reliability diagram with signed residual stem plot: The mixed-data check looks for the literal [[mixed-data]] marker in the caption. A prose sentence naming both data files of a panel does not pass it. Fix: Put [[mixed-data]] in the caption entry of each panel drawn from two data files, next to the sentence that names them.

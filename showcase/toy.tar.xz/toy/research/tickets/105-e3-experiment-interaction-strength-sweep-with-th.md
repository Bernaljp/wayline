---
id: 105
title: "E3 experiment: interaction-strength sweep with the zero-strength null control"
kind: experiment
difficulty: 2
status: accepted
blocked_by: [3, 16]
touches: [experiments/E3/, results/runs/E3/, results/smoke/E3/]
role: experimenter
skills: []
resources: {cpu: 2, gpu: 1, ram_gb: 8, wallclock_minutes: 30}
inputs: [configs/arms.json, src/toy/train.py, src/toy/generate.py, experiments/E2/point.sh]
outputs: [results/runs/E3/m0_n0/without/seed20/heldout_scores.csv, results/runs/E3/m0.25_n0/without/seed20/heldout_scores.csv, results/runs/E3/m0.5_n0/without/seed20/heldout_scores.csv, results/runs/E3/m2_n0/without/seed20/heldout_scores.csv, results/runs/E3/m4_n0/without/seed20/heldout_scores.csv]
acceptance:
  machine: ["python3 -c \"import json; t = open('experiments/E3/jobs.json').read(); json.loads(t); assert all(('results/runs/E3/m%s_n0/%s/seed%d/heldout_scores.csv' % (m, a, i)) in t for m in ('0', '0.25', '0.5', '2', '4') for a in ('with', 'without') for i in range(1, 21)) and 'results/runs/E3/m1_n0/' not in t\"", "python3 -c \"import json, subprocess, sys; ms = json.load(open('experiments/E3/jobs.json'))['members']; st = lambda c: c[c.index('--strength') + 1]; assert len(ms) == 5 and {st(m['command']) for m in ms} == {'0', '0.25', '0.5', '2', '4'} and all(m['command'][:2] == ['/bin/bash', 'experiments/E2/point.sh'] and m['command'][2] == 'results/runs/E3/m%s_n0' % st(m['command']) and m['command'][3:5] == ['1', '20'] for m in ms); c = [a.replace('results/runs/E3/', 'results/smoke/E3/') for a in ms[0]['command']]; c[4] = '1'; sys.exit(subprocess.run(c + ['--epochs', '1', '--device', 'cpu']).returncode)\" && python3 -c \"import glob; assert glob.glob('results/smoke/E3/m*_n0/with/seed1/heldout_scores.csv') and glob.glob('results/smoke/E3/m*_n0/without/seed1/heldout_scores.csv')\""]
  quality: ["Do the jobs run exactly the strengths 0, 0.25, 0.5, 2 and 4 at the default size, seeds 1-20, both arms, with configs/arms.json and nothing tuned, leaving m = 1 to E2's runs and the default draw unchanged?"]
objectives: [O4]
sections: [methods]
context_pack: [configs/arms.json, experiments/E2/point.sh, experiments/E2/jobs.json:1-10, research/SPEC.md#e3-claims-c4-c5, research/SPEC.md#methods]
origin: research/SPEC.md#e3-claims-c4-c5
proposed_by: planner
demo: "`wayline status` shows the five E3 job members, one per strength 0, 0.25, 0.5, 2 and 4, each running 40 paired runs into results/runs/E3/m<m>_n0/."
retry:
  host_oom: []
  gpu_oom: [--batch-size=64, --batch-size=16]
---

## Demo

`wayline status` shows the five E3 job members, one per strength 0, 0.25, 0.5, 2 and 4, each running 40 paired runs into results/runs/E3/m<m>_n0/.

## Notes

Re-cut of #86, which never launched. It no longer waits on the E2 gate. The gate passed: analysis/E2/checks.json on main has gate_passed true, with reproduction_gap 0.0 and convergence_drop 0.0034411053956896914. The gate's re-cut only re-files its findings, so Q14 is not revisited. Reuse experiments/E2/point.sh, which takes <out-root> <first-seed> <last-seed> [extra train.py flags] and runs both arms with --config configs/arms.json and --save-scores. Write experiments/E3/jobs.json with the Write tool, in the form of experiments/E2/jobs.json, with one member per strength m in {0, 0.25, 0.5, 2, 4}. Each member's command is exactly ["/bin/bash", "experiments/E2/point.sh", "results/runs/E3/m<m>_n0", "1", "20", "--strength", "<m>"], with m written 0, 0.25, 0.5, 2 or 4. The second criterion reads that shape and smoke-runs the first member at seed 1 for one CPU epoch into results/smoke/E3/, so you need no smoke run of your own. bash and the venv's python are not on this role's allow list anyway. m = 1 is E2's results/runs/E2/m1_n0 and is not re-run. Each member's expected_outputs lists every run's summary.json, heldout_scores.csv and config.json literally, as E2's does. The retry ladder's --batch-size passes through point.sh to train.py. The multiplier scales generate.py's nonzero weight of 1.1 on x3*x4 (INTERACTION_WEIGHT; finding t6-a1-f2 gives 4.4 at signal 4). So A1's absolute-weight switch does not apply, and this ticket does not wait on E1. Finding t2-a3-f2: the features and the random stream do not depend on strength, so the sweep points share common random numbers. Nothing is tuned and no seed is dropped. Then run these, one per Bash call: `wayline accept`; `git add experiments/E3/jobs.json`; `git commit -m "E3: strength sweep jobs"`; `wayline job add experiments/E3/jobs.json`. Return running with the job ids, and commit nothing under results/. Bash: every part of a command must begin with python3, git add, git commit, git status, git diff, git log, ls, cat, wayline accept or wayline job add. mkdir, bash, heredocs, `>` redirects and `PYTHONPATH=` prefixes are refused, and those refusals blocked tickets 16, 76 and 83. Write files with the Write tool, and retry a refused command in an allowed form before you return blocked. Return one Methods passage. End every sentence with a provenance tag that resolves, and leave out any sentence you cannot tag. File no finding that states a number.

## Result

### Attempt 1

Five E3 jobs are written and waiting for the conductor: t105-1 to t105-5. Job k reruns E2's protocol at strength m = 0, 0.25, 0.5, 2 and 4 in that order. Each job calls experiments/E2/point.sh with results/runs/E3/m<m>_n0, seeds 1 to 20 and --strength m. That is 40 paired runs per job (both arms on every seed, pinned settings from configs/arms.json), 200 runs in all. m = 1 is not rerun because it reuses E2's runs. experiments/E3/make_jobs.py writes the spec, and both are committed on ticket/105. A CPU smoke test (m = 0, seed 1, 1 epoch) wrote both arms under results/smoke/E3/m0_n0/. The rejected result had no Methods passage; this one adds a passage describing the sweep. wayline accept passes again, and the code is unchanged.

Wrote: `experiments/E3/make_jobs.py`, `experiments/E3/jobs.json`, `results/smoke/E3/m0_n0/`

Ran: `python3 experiments/E3/make_jobs.py`, `wayline accept`, `git commit`, `wayline job add experiments/E3/jobs.json`

Jobs: `t105-1`, `t105-2`, `t105-3`, `t105-4`, `t105-5`

Passages:

- methods, Strength sweep: The E3 strength sweep reruns E2's paired protocol (seeds 1–20, both arms, the pinned settings in configs/arms.json, the default training size $n_0$) at each interaction strength multiplier $m \in \{0, 0.25, 0.5, 2, 4\}$, passing --strength $m$ to every run and writing each point to runs/E3/m<m>_n0/ {code:experiments/E3/make_jobs.py#L1-L23}. The point $m = 1$ is not rerun; it reuses E2's runs {code:experiments/E3/make_jobs.py#L1-L3}. The point $m = 0$ plants no interaction in the generator's label and serves as the null control {code:experiments/E3/make_jobs.py#L8}.

Not methods:

- `experiments/E3/make_jobs.py`: It only writes the job spec listing each sweep point's command and expected output paths; the method is E2's point.sh run with --strength.

Escalated one rung up: the next attempt launches on rung 6 (r6 opus high), in a new session.

### Attempt 2

Five E3 jobs are written again as t105-6 to t105-10. The earlier jobs, t105-1 to t105-5, were cancelled when the last attempt failed. Job k runs experiments/E2/point.sh at strength m = 0, 0.25, 0.5, 2 and 4 in that order, with results/runs/E3/m<m>_n0, seeds 1 to 20 and --strength m. Each job makes 40 paired runs (both arms, the pinned configs/arms.json), 200 in all. m = 1 reuses E2's runs and is not rerun. The script and spec were already committed on ticket/105 at 3a7ee11 and did not change. The earlier failure was not the job spec: both machine criteria passed. It was the Methods passage's provenance tag `code:experiments/E3/make_jobs.py#L1-L23`, which pointed past the end of a 21-line file. This passage's tags point at lines that exist (make_jobs.py has 21 lines, point.sh has 22) and at the function generate.row. wayline accept passes in the worktree.

Wrote: `experiments/E3/make_jobs.py`, `experiments/E3/jobs.json`, `results/smoke/E3/m0_n0/`

Ran: `git status`, `git log --oneline -5`, `python3 -c <acceptance criterion 1>`, `python3 -c <acceptance criterion 2 smoke run>`, `python3 -c <smoke output glob check>`, `wayline accept`, `wayline job add experiments/E3/jobs.json`

Jobs: `t105-6`, `t105-7`, `t105-8`, `t105-9`, `t105-10`

Passages:

- methods, Sweeps: The E3 strength sweep runs E2's paired runner once per interaction strength multiplier $m \in \{0, 0.25, 0.5, 2, 4\}$ over seeds 1–20, passing --strength $m$ and writing each point to results/runs/E3/m<m>_n0/ {code:experiments/E3/make_jobs.py#L7-L16}. For each seed, the runner trains the `with` arm and then the `without` arm with the pinned settings in configs/arms.json and saves each run's held-out scores, passing any extra flags on to toy.train {code:experiments/E2/point.sh#L1-L22}. The generator multiplies the log-odds weight on $x_3x_4$ by $m$, so $m = 0$ plants no interaction and serves as the null control {code:src/toy/generate.py#row}. The point $m = 1$ is not rerun, since it is E2's default draw {code:experiments/E3/make_jobs.py#L1-L3}.

Not methods:

- `experiments/E3/make_jobs.py`: It only writes the job spec, listing each sweep point's command and expected output paths; the method is E2's point.sh run with --strength.

Every job exited 0 and its outputs parsed: t105-6, t105-7, t105-8, t105-9, t105-10.

**Verdict (quality): passed** by claude-opus-5-5, session `52e06b2c-5df4-4db3-9d0e-0c6dd3700c1b`.

---
id: 159
title: Scope down a report claim its artifacts do not support
kind: writing
difficulty: 3
status: parked
blocked_by: []
touches: []
role: writer
skills: []
inputs: [research/REPORT.md, research/findings.jsonl#t8-a2-f1, src/toy/converge.py#convergence]
outputs: []
acceptance:
  machine: []
  quality: [Does every claim sentence the verifier could not support now say only what its cited artifacts do?]
context_pack: [research/REPORT.md, research/findings.jsonl#t8-a2-f1, src/toy/converge.py#convergence]
origin: research/REPORT.md#claim-2dfdd14e568392b5
proposed_by: verifier
demo: The general report renders the narrowed finding in place of `t8-a2-f1`, and the next run end samples it.
sections: [results]
---

## Demo

The general report renders the narrowed finding in place of `t8-a2-f1`, and the next run end samples it.

## The claim the verifier could not support

> On the fixture the maximum is 0.05, from the without arm at seed 2.{res:t8-a2/src/toy/converge.py#convergence}

Verifier session `a10d7317-2e4e-435f-bf4d-cf29cc70c4af` (claude-opus-5-5) opened the cited artifacts and found:

- [blocker] The sentence's only tag cites the function `convergence` in src/toy/converge.py (lines 71-91). That function holds no fixture, no number 0.05, no mention of the without arm and no seed 2. It only defines `convergence_drop` as the largest per-run relative drop. Nothing at the cited locator supports the figure, the arm or the seed the sentence gives. (src/toy/converge.py#convergence (lines 71-91))
- [major] The numbers do appear elsewhere, but that place is not cited. The docstring of tests/test_converge.py (lines 3-12) works the drop out by hand as 0.03/0.60 = 0.05 for the without arm at seed 2, the largest of the six runs. test_convergence_drop_is_the_largest_drop (lines 32-34) and test_per_run_carries_both_losses_and_epochs (lines 44-48) assert it. The tag should point at that test file or at its fixture under tests/fixtures/converge/E2, not at the source function. Note that the test asserts the value; the test file does not record that the test passed. (tests/test_converge.py lines 3-12, 27-34, 44-48)

The sentence is a finding as its ticket recorded it (`t8-a2-f1`), and the report renders findings as recorded. Return in the result the finding narrowed to what the artifacts support, with its provenance, naming the finding it narrows in its `replaces` (`t8-a2-f1`); the ledger records it in that finding's place and the next render reads it.

A finding's provenance is the artifact's path in the project and a locator, the form the manifest resolves (`analysis/ablation/signal-4.json#paired_gain`), never a report tag such as `{res:<run>/<path>}`: the ledger refuses a provenance it cannot find in `manifest.json` or on disk.

## The artifacts the verifier opened

- `src/toy/converge.py#convergence`

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 176, 177, 178, 179, 180, 181, 182, 183, 184, 185.

---
id: 62
title: "E1 experiment: oracle audit of the default generator on the 10^6-row draw D2"
kind: experiment
difficulty: 2
status: parked
blocked_by: [52]
touches: [experiments/E1/, results/E1/, results/smoke/E1/]
role: experimenter
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 4, wallclock_minutes: 60}
inputs: [src/toy/oracle.py, src/toy/generate.py]
outputs: [results/E1/oracle.json]
acceptance:
  machine: ["python3 -c \"import json; t = open('experiments/E1/jobs.json').read(); json.loads(t); assert 'toy.oracle' in t and '10001' in t and '1000000' in t and 'results/E1/oracle.json' in t\""]
  quality: ["Does the job run toy.oracle once on D2 (seed 10001, 10^6 rows, signal 4.0 and strength 1, CPU only) and write results/E1/oracle.json and nothing else?"]
objectives: [O3]
sections: [methods]
context_pack: [experiments/E2/jobs.json:1-10, src/toy/oracle.py:247-290, research/SPEC.md#e1-claims-c1-c2, research/SPEC.md#data]
origin: research/SPEC.md#e1-claims-c1-c2
proposed_by: planner
demo: "`wayline status` shows the E1 job running `toy.oracle --seed 10001 --rows 1000000` on one core; when it exits, results/E1/oracle.json holds the Bayes AUROC, its half-width, the calibration error, the weight on x3*x4 with its line, and the additive gap."
---

## Demo

`wayline status` shows the E1 job running `toy.oracle --seed 10001 --rows 1000000` on one core; when it exits, results/E1/oracle.json holds the Bayes AUROC, its half-width, the calibration error, the weight on x3*x4 with its line, and the additive gap.

## Notes

Re-cut of ticket 38, whose session was refused Bash for python3, wayline and git, so it never smoke-tested, committed or added its job. If that happens again, stop at once and return blocked naming the command. Write experiments/E1/jobs.json in the job-file form of experiments/E2/jobs.json: one job whose command runs `PYTHONPATH=src python3 -B -m toy.oracle --seed 10001 --rows 1000000 --out results/E1/oracle.json` (the CLI's default --signal 4.0 and --strength 1 are train.py's and configs/arms.json's defaults, i.e. D2's 'default settings'), with no GPU and expected_outputs ["results/E1/oracle.json"]. If the job form needs the environment set in a script, run it through a small experiments/E1/run.sh. toy.oracle is stdlib only, so the system python3 runs it; ticket 53 measured the 10^6-row audit at about 20 s and 0.7 GB. Smoke-test the same command at --rows 2000 into results/smoke/E1/ and commit nothing under results/. Then run `wayline job add experiments/E1/jobs.json` and return running. Seed 10001 lies outside every replicate's seeds, so no model of E2-E5 sees D2; nothing is repeated, since the draw's size gives the precision. Waits on #52 so the audit runs the oracle code as #52 leaves it. Return one Methods passage describing the audit, each claim sentence ending with a provenance tag ({code:src/toy/oracle.py#audit} and the like).

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93.

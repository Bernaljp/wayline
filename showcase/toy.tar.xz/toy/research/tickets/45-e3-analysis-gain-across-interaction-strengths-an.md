---
id: 45
title: "E3 analysis: gain across interaction strengths and at zero strength (C4, C5)"
kind: analysis
difficulty: 3
status: parked
blocked_by: [16, 32, 42]
touches: [analysis/E3/]
role: analyst
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 4, wallclock_minutes: 30}
inputs: [results/runs/E3/, results/runs/E2/m1_n0/]
outputs: [analysis/E3/sweep.json, analysis/E3/verdict.json]
acceptance:
  machine: ["python3 -c \"import json; s = json.load(open('analysis/E3/sweep.json')); v = json.load(open('analysis/E3/verdict.json')); pts = {float(p['strength']): p for p in s['points']}; assert sorted(pts) == [0.0, 0.25, 0.5, 1.0, 2.0, 4.0]; z = pts[0.0]; assert v['c4_supported'] == (z['paired_gain_lo'] >= -0.01 and z['paired_gain_hi'] <= 0.01) and v['c5_supported'] == (s['strength_spearman'] >= 0.9 and pts[4.0]['paired_gain_lo'] > 0) and v['a4'] == (z['paired_gain_lo'] < -0.01)\""]
  quality: ["Does every finding's number match the cited field of analysis/E3/sweep.json, and does the report say in A3's words that a gain near zero at m = 0 rising with m restates what generate.py plants?"]
objectives: [O4]
sections: [methods, results]
context_pack: [research/SPEC.md#e3-claims-c4-c5, research/SPEC.md#claims, research/SPEC.md#anti-claims]
origin: research/SPEC.md#e3-claims-c4-c5
proposed_by: planner
demo: analysis/E3/sweep.json and the findings show the paired gain with its 95% CI at each strength 0 to 4, strength_spearman, and C4's and C5's verdicts.
---

## Demo

analysis/E3/sweep.json and the findings show the paired gain with its 95% CI at each strength 0 to 4, strength_spearman, and C4's and C5's verdicts.

## Notes

Run `PYTHONPATH=code/src python3 -B -m toy.sweep "$WAYLINE_PROJECT/results/runs/E3" --axis strength --point "$WAYLINE_PROJECT/results/runs/E2/m1_n0" --out analysis/E3/sweep.json` (six points). Then write analysis/E3/verdict.py and the analysis/E3/verdict.json it writes, with these fields. c4_supported: at m = 0, paired_gain_lo >= -0.01 and paired_gain_hi <= 0.01. a4: paired_gain_lo < -0.01 at m = 0; when it holds, give the overfitting cost K4 asks about. c5_supported: strength_spearman >= 0.9 and paired_gain_lo > 0 at m = 4. When the gain is about zero at m = 0 and rises with m, say in A3's words that it only restates what generate.py plants (K1, Q6). Propose seeds 21-50 at any point whose sd_d exceeds 0.02, or whose m = 0 interval is too wide to bound the cost (Q15's revisit rule, decided on width alone). Keep every number in a finding equal to the field it cites. Return Methods and Results passages whose claim sentences each end with a provenance tag.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73.

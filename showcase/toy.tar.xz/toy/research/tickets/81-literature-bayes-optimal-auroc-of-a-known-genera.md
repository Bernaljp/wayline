---
id: 81
title: "Literature: Bayes-optimal AUROC of a known generator and the precision of an AUROC estimate (O3)"
kind: lit
difficulty: 2
status: parked
blocked_by: []
touches: []
role: surveyor
skills: []
acceptance:
  machine: []
  quality: []
objectives: [O3]
sections: [introduction]
context_pack: [research/sections/introduction.md, research/CONCERNS.md, research/SPEC.md#e1-claims-c1-c2, research/SPEC.md#methods, research/POSITION.md#what-the-references-lack]
origin: research/SPEC.md#e1-claims-c1-c2
proposed_by: planner
demo: "The Introduction holds passages tagged at resolved dossiers on three points: why ranking by the true P(y=1|x) gives the highest attainable ROC curve, how an AUROC's standard error is estimated, and why a gain is read as a share of the gap to that ceiling (K5)."
---

## Demo

The Introduction holds passages tagged at resolved dossiers on three points: why ranking by the true P(y=1|x) gives the highest attainable ROC curve, how an AUROC's standard error is estimated, and why a gain is read as a share of the gap to that ceiling (K5).

## Notes

Re-cut of ticket 60, which never launched. Search for four things. First, why ranking by the true class probability or the likelihood ratio gives the best ROC curve (Neyman-Pearson), so the Bayes classifier's AUROC is the ceiling no model beats in expectation. Second, the variance of an AUROC estimate: Hanley & McNeil 1982; DeLong et al. 1988, already verified as delong-1988-comparing-areas-under-two-more; and Sun & Xu 2014, verified as sun-2014-fast-implementation-delong-s-algorithm. Third, the logistic-normal integral that the generator's latent noise creates (finding t6-a1-f1: P(y=1|x) = E[sigmoid(mu(x) + e)]), for example the probit approximation, or Gauss-Hermite quadrature, which toy.oracle uses. Fourth, simulation studies that report a learned model's AUROC against the ceiling of a known generator. Check each cited work with `wayline scout`. Every sentence of a passage ends with a {ref:<slug>#...} tag at a dossier the scout verified; leave out a sentence you cannot tag. A passage that says what a current one says names it in `replaces`. Rest nothing on paper-a or paper-b.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113.

---
id: 152
title: tests/test_oracle_budget.py changed after run t53-a1 (commit 607722b...
kind: decision
difficulty: 1
status: open
blocked_by: []
blocking: subgraph
human_only: false
touches: []
role: decider
skills: []
acceptance: {}
context_pack: [research/tickets/139-draw-r6-oracle-audit-cost-on-the-10-6-row-draw-d.md]
origin: "ticket 139 attempt 1: decision request eed023acbf33"
proposed_by: worker:139
demo: "The owner or the decider answers: tests/test_oracle_budget.py changed after run t53-a1 (commit 607722b moved it to seed 20001), but the manifest still holds the old hash. Should the current file be registered again, or should drawing R6 be pinned to the t53-a1 version?"
---

## Decision

tests/test_oracle_budget.py changed after run t53-a1 (commit 607722b moved it to seed 20001), but the manifest still holds the old hash. Should the current file be registered again, or should drawing R6 be pinned to the t53-a1 version?

- options:
  - Register the current file again, and say in t53-a1-f1 that the audit ran on a stand-in draw at seed 20001
  - Keep the t53-a1 registration and restore or archive the old bytes as a registered artifact
  - Close the drawing without a table
- recommended: Register the current file again, and say in t53-a1-f1 that the audit ran on a stand-in draw at seed 20001
- evidence:
  - research/manifest.json line 1300-1307
  - git show 017f053:tests/test_oracle_budget.py (sha256 dea33416...)
  - tests/test_oracle_budget.py line 30 (SEED = 20001, sha256 a6204639...)
- blocking: `subgraph`, and no ticket waited on it when it was opened
- human-only: no, so under autonomy `autonomous` the decider may answer it
- asked by: ticket 139 attempt 1: decision request eed023acbf33

<!-- wayline:decision {"ticket":152,"question":"tests/test_oracle_budget.py changed after run t53-a1 (commit 607722b moved it to seed 20001), but the manifest still holds the old hash. Should the current file be registered again, or should drawing R6 be pinned to the t53-a1 version?","options":["Register the current file again, and say in t53-a1-f1 that the audit ran on a stand-in draw at seed 20001","Keep the t53-a1 registration and restore or archive the old bytes as a registered artifact","Close the drawing without a table"],"recommended":"Register the current file again, and say in t53-a1-f1 that the audit ran on a stand-in draw at seed 20001","evidence":["research/manifest.json line 1300-1307","git show 017f053:tests/test_oracle_budget.py (sha256 dea33416...)","tests/test_oracle_budget.py line 30 (SEED = 20001, sha256 a6204639...)"],"human_only":false,"reversible":true,"answer":null,"rationale":null,"confidence":null,"decided_by":null,"timestamp":null,"blocking":"subgraph"} -->

## How to answer

`wayline answer 152 "<answer>"`, from the command line or from a session; the answer form in the dashboard's decisions view; or the answer written under an `## Answer` heading at the end of this file. Each is journaled as the owner's decision, and the conductor closes this ticket at its next wave.

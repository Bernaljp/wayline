---
id: 50
title: "harness.json records a code repository (code_repository: a package..."
kind: decision
difficulty: 1
status: done
blocked_by: []
blocking: subgraph
human_only: true
touches: []
role: decider
skills: []
acceptance: {}
context_pack: [research/SPEC.md]
origin: "plan 7a42fb84fe55: research/SPEC.md#seams"
proposed_by: planner
demo: "The owner answers: harness.json records a code repository (code_repository: a package, MIT, private remote Bernaljp/toy), so the harness accepts a code ticket only when it writes under code/, the directory the code repository is cut from. But this project has no code/ directory. Its package lives at src/toy/ and its tests at tests/, and O2's goal command runs `PYTHONPATH=src python3 -m toy.eval --split held_out` from the project root. No ticket can move files from outside code/ into it. How does the project's code get under code/?"
---

## Decision

harness.json records a code repository (code_repository: a package, MIT, private remote Bernaljp/toy), so the harness accepts a code ticket only when it writes under code/, the directory the code repository is cut from. But this project has no code/ directory. Its package lives at src/toy/ and its tests at tests/, and O2's goal command runs `PYTHONPATH=src python3 -m toy.eval --split held_out` from the project root. No ticket can move files from outside code/ into it. How does the project's code get under code/?

- options:
  - Move, keeping the old paths: once tickets #6 and #8 have integrated and no job is running, the owner moves src/ to code/src/ and tests/ to code/tests/ in one commit on main, and leaves symlinks src -> code/src and tests -> code/tests. O2's command, configs/arms.json, experiments/E2/point.sh and every kept ticket's criterion keep working unchanged, and the code repository publishes code/. T1-T5 run as cut.
  - Move and change the paths: the owner moves src/ and tests/ under code/ with no symlinks, and changes O2's eval command to `PYTHONPATH=code/src python3 -m toy.eval --split held_out`. That is a change to a goal's measure, in the human-only objective class. experiments/E2/point.sh and the tickets that name src/ are then re-cut; T1-T5 run as cut.
  - Keep the old layout: the owner removes code_repository from harness.json, so the project keeps src/ and tests/ as a layout older than code/ and has no code repository for now. The planner re-cuts T1-T5 with touch sets under src/toy/ and tests/, as tickets #2, #3 and #5 had.
- recommended: Move, keeping the old paths: once tickets #6 and #8 have integrated and no job is running, the owner moves src/ to code/src/ and tests/ to code/tests/ in one commit on main, and leaves symlinks src -> code/src and tests -> code/tests. O2's command, configs/arms.json, experiments/E2/point.sh and every kept ticket's criterion keep working unchanged, and the code repository publishes code/. T1-T5 run as cut.
- evidence:
  - harness wayline/tickets.py:159-201: touch_problem refuses a code ticket's entry outside code/ whenever keeps_code(project), and keeps_code is true when harness.json has code_repository, even with no code/ directory
  - the plan-time checks refused this plan's first cut, whose code tickets touched src/toy/ and tests/: 'the touch set entry ... is not under code/, where everything the code repository publishes lives'
  - harness.json: code_repository {shape: package, license: MIT, remote Bernaljp/toy (new), visibility: private}; the project has no code/ directory
  - research/INTAKE.md, Code: None: intake absorbed no clone, so nothing created code/; the package was already at src/toy/
  - owner/measure.json and research/OBJECTIVES.md O2: eval_command `PYTHONPATH=src python3 -m toy.eval --split held_out`; changing it is in the human-only objective class (research/INTAKE.md, Decisions that stay human-only)
  - kept tickets #2, #3 and #5 wrote src/toy/ and tests/; #6 (src/toy/oracle.py) and #8 (src/toy/converge.py) are running there; #16's jobs run experiments/E2/point.sh with PYTHONPATH=src
  - harness wayline/code_repository.py: everything a project publishes lives under code/, cut by `git subtree split --prefix=code`; a symlink outside code/ is not published
- blocking: `subgraph`, so tickets 30, 31, 32, 33, 34 and whatever waits on them wait for the answer
- human-only: yes, only the owner answers it
- asked by: plan 7a42fb84fe55: research/SPEC.md#seams

<!-- wayline:decision {"ticket":50,"question":"harness.json records a code repository (code_repository: a package, MIT, private remote Bernaljp/toy), so the harness accepts a code ticket only when it writes under code/, the directory the code repository is cut from. But this project has no code/ directory. Its package lives at src/toy/ and its tests at tests/, and O2's goal command runs `PYTHONPATH=src python3 -m toy.eval --split held_out` from the project root. No ticket can move files from outside code/ into it. How does the project's code get under code/?","options":["Move, keeping the old paths: once tickets #6 and #8 have integrated and no job is running, the owner moves src/ to code/src/ and tests/ to code/tests/ in one commit on main, and leaves symlinks src -\u003e code/src and tests -\u003e code/tests. O2's command, configs/arms.json, experiments/E2/point.sh and every kept ticket's criterion keep working unchanged, and the code repository publishes code/. T1-T5 run as cut.","Move and change the paths: the owner moves src/ and tests/ under code/ with no symlinks, and changes O2's eval command to `PYTHONPATH=code/src python3 -m toy.eval --split held_out`. That is a change to a goal's measure, in the human-only objective class. experiments/E2/point.sh and the tickets that name src/ are then re-cut; T1-T5 run as cut.","Keep the old layout: the owner removes code_repository from harness.json, so the project keeps src/ and tests/ as a layout older than code/ and has no code repository for now. The planner re-cuts T1-T5 with touch sets under src/toy/ and tests/, as tickets #2, #3 and #5 had."],"recommended":"Move, keeping the old paths: once tickets #6 and #8 have integrated and no job is running, the owner moves src/ to code/src/ and tests/ to code/tests/ in one commit on main, and leaves symlinks src -\u003e code/src and tests -\u003e code/tests. O2's command, configs/arms.json, experiments/E2/point.sh and every kept ticket's criterion keep working unchanged, and the code repository publishes code/. T1-T5 run as cut.","evidence":["harness wayline/tickets.py:159-201: touch_problem refuses a code ticket's entry outside code/ whenever keeps_code(project), and keeps_code is true when harness.json has code_repository, even with no code/ directory","the plan-time checks refused this plan's first cut, whose code tickets touched src/toy/ and tests/: 'the touch set entry ... is not under code/, where everything the code repository publishes lives'","harness.json: code_repository {shape: package, license: MIT, remote Bernaljp/toy (new), visibility: private}; the project has no code/ directory","research/INTAKE.md, Code: None: intake absorbed no clone, so nothing created code/; the package was already at src/toy/","owner/measure.json and research/OBJECTIVES.md O2: eval_command `PYTHONPATH=src python3 -m toy.eval --split held_out`; changing it is in the human-only objective class (research/INTAKE.md, Decisions that stay human-only)","kept tickets #2, #3 and #5 wrote src/toy/ and tests/; #6 (src/toy/oracle.py) and #8 (src/toy/converge.py) are running there; #16's jobs run experiments/E2/point.sh with PYTHONPATH=src","harness wayline/code_repository.py: everything a project publishes lives under code/, cut by `git subtree split --prefix=code`; a symlink outside code/ is not published"],"human_only":true,"reversible":true,"answer":null,"rationale":null,"confidence":null,"decided_by":null,"timestamp":null,"blocking":"subgraph"} -->

## How to answer

`wayline answer 50 "<answer>"`, from the command line or from a session; the answer form in the dashboard's decisions view; or the answer written under an `## Answer` heading at the end of this file. Each is journaled as the owner's decision, and the conductor closes this ticket at its next wave.

## Answer

Keep the old layout: the owner removes code_repository from harness.json, so the project keeps src/ and tests/ as a layout older than code/ and has no code repository for now. The planner re-cuts T1-T5 with touch sets under src/toy/ and tests/, as tickets #2, #3 and #5 had.

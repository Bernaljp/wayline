---
id: 23
title: "E3 analysis: gain across interaction strengths and at zero strength (C4, C5)"
kind: analysis
difficulty: 3
status: parked
blocked_by: [9, 19]
touches: [analysis/E3/]
role: analyst
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 4, wallclock_minutes: 30}
inputs: [results/runs/E3/, results/runs/E2/m1_n0/]
outputs: [analysis/E3/sweep.json, analysis/E3/verdict.json]
acceptance:
  machine: ["python3 -c \"import json; d = json.load(open('analysis/E3/sweep.json')); assert 'strength_spearman' in d and len(d['points']) == 6\"", "python3 -c \"import json; d = json.load(open('analysis/E3/verdict.json')); assert {'c4_supported', 'c5_supported', 'a4'} <= set(d)\""]
  quality: ["Do C4's and C5's verdicts follow the spec's thresholds from analysis/E3/sweep.json, and do the findings say, in A3's words, that a gain that vanishes at zero strength and rises with it restates what generate.py plants?"]
objectives: [O4]
sections: [methods, results]
context_pack: [research/SPEC.md#e3-claims-c4-c5, research/SPEC.md#claims, research/SPEC.md#anti-claims]
origin: research/SPEC.md#e3-claims-c4-c5
proposed_by: planner
demo: analysis/E3/sweep.json and the findings show the paired gain with its 95% CI at each strength 0 to 4, strength_spearman, and C4's and C5's verdicts.
---

## Demo

analysis/E3/sweep.json and the findings show the paired gain with its 95% CI at each strength 0 to 4, strength_spearman, and C4's and C5's verdicts.

## Notes

Run `PYTHONPATH=src python3 -B -m toy.sweep "$WAYLINE_PROJECT/results/runs/E3" --axis strength --point "$WAYLINE_PROJECT/results/runs/E2/m1_n0" --out analysis/E3/sweep.json` (six points), then write analysis/E3/verdict.py and verdict.json: c4_supported = at m = 0, paired_gain_lo >= -0.01 and paired_gain_hi <= 0.01; a4 = paired_gain_lo < -0.01 at m = 0 (then give the overfitting cost K4 asks about); c5_supported = strength_spearman >= 0.9 and paired_gain_lo > 0 at m = 4. Say in A3's words that the gain only restates what generate.py plants when it is about zero at m = 0 and rises with m (K1, Q6). Propose seeds 21-50 at any point whose sd_d exceeds 0.02, or whose m = 0 interval is too wide to bound the cost (Q15's revisit rule, on width alone).

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49.

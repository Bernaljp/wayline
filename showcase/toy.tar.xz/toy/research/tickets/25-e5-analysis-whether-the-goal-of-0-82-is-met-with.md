---
id: 25
title: "E5 analysis: whether the goal of 0.82 is met without tuning on held-out data (C7)"
kind: analysis
difficulty: 2
status: parked
blocked_by: [10, 17, 21, 22]
touches: [analysis/E5/]
role: analyst
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 4, wallclock_minutes: 30}
inputs: [results/E5/changes.jsonl, results/E5/start/, analysis/E1/summary.json, analysis/E2/paired.json]
outputs: [analysis/E5/goal.json]
acceptance:
  machine: ["python3 -c \"import json; d = json.load(open('analysis/E5/goal.json')); assert {'heldout_reads', 'goal_run_auroc', 'goal_met', 'mean_auroc_with_e2', 'ceiling_below_goal', 'c7_supported'} <= set(d) and d['heldout_reads'] <= 6\""]
  quality: ["Is the goal reported as the seed-1 run its command measures, with the other seeds, the keep-if-better judgment, the ceiling and E2's 20-seed mean beside it, and never as a mean over seeds?"]
objectives: [O2]
sections: [methods, results]
context_pack: [owner/measure.json, research/SPEC.md#e5-claims-c7, research/SPEC.md#anti-claims]
origin: research/SPEC.md#e5-claims-c7
proposed_by: planner
demo: analysis/E5/goal.json and the findings give the goal run's auroc beside 0.82, heldout_reads, E1's ceiling and E2's 20-seed mean with-term AUROC, with C7's verdict.
---

## Demo

analysis/E5/goal.json and the findings give the goal run's auroc beside 0.82, heldout_reads, E1's ceiling and E2's 20-seed mean with-term AUROC, with C7's verdict.

## Notes

Run `PYTHONPATH=src python3 -B -m toy.goallog "$WAYLINE_PROJECT/results/E5/changes.jsonl"` and read the keep-if-better judgment the conductor journaled for the E5 ticket (progress events with goal O2 in research/journal.jsonl). Write analysis/E5/goal.py and analysis/E5/goal.json: heldout_reads; goal_run_auroc (seed 1, D5) and the three seeds' values; goal_met = goal_run_auroc >= 0.82; the harness's judgment; bayes_auroc and ceiling_below_goal from analysis/E1/summary.json (A6); mean_auroc_with_e2 from analysis/E2/paired.json and a7 = mean_auroc_with_e2 < 0.82 <= goal_run_auroc (then say the goal is met by its measure while the mean falls short); c7_supported = goal_met and heldout_reads <= 6 and every kept change chosen by val_auroc (none so far). If the start falls short of 0.82 and the ceiling is at least 0.82, propose E5's candidate changes (epochs and learning rate, an L2 penalty, input columns drawn from x1..x4 and their six pairwise products), each chosen by val_auroc on --val-fraction 0.2 runs, at most five, each its own goal ticket under the keep rule. Never redefine O2 as a mean over seeds (Q15).

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49.

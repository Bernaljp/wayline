---
id: 163
title: Give the plotter the tag grammar and the rule that every number sits at a cited key
kind: harness
difficulty: 2
status: open
blocked_by: []
touches: [.claude/agents/plotter.md, fixtures/role/plotter-tags-every-number/]
role: coder
skills: []
acceptance:
  machine: ["python3 -B -c \"import pathlib; t = pathlib.Path('.claude/agents/plotter.md').read_text(encoding='utf-8'); assert 'name: plotter' in t and '{res:t<ticket>-a<attempt>/drawings/' in t and '[res:' in t and 'one plain command' in t and 'wayline drawing check' in t\"", test -f fixtures/role/plotter-tags-every-number/fixture.json]
  quality: []
context_pack: [research/changes/004-give-the-plotter-the-tag-grammar-and-the.json, research/feedback/retro-20261025T065614444Z.md]
proposed_by: evolve
demo: "`.claude/agents/plotter.md` holds the harness's plotter words (roles/plotter/agent.md, with its frontmatter `name: plotter`) plus a section on tags, numbers and Bash."
origin: change 004-give-the-plotter-the-tag-grammar-and-the
---

## Demo

`.claude/agents/plotter.md` holds the harness's plotter words (roles/plotter/agent.md, with its frontmatter `name: plotter`) plus a section on tags, numbers and Bash. That section says:

1. A tag is written `{res:t<ticket>-a<attempt>/drawings/<drawing>/numbers.json#<key>}`, placed right after the sentence's full stop, one tag per key the sentence takes a number from. The run id is `t<ticket>-a<attempt>`, for example `t138-a1` for ticket 138's first attempt, and a drawing that has not been rerun is attempt 1. Never write `[res:...]` in square brackets, and never write a res tag without the run id: the linter reads neither.
2. Every claim sentence of a Methods passage ends with such a tag.
3. Every number a finding states sits unaltered at the key its provenance names, or at a tag ending that sentence. Counts (6 runs), settings (30 epochs), thresholds and limits (0.01) are numbers too, so draw.py writes each into numbers.json under its own key and the sentence cites it. A provenance names one key; never comma-join keys.
4. Leave `evidence` unset on findings and passages: it is for verification tickets.
5. Bash runs one plain command per call, beginning with python3, wayline tools run, wayline accept, git add, git commit, git status, git diff, git log, ls or cat. No cd, `;`, `&&`, `|`, echo, head, grep or `$(...)`. Read and search files with Read, Glob and Grep.
6. `wayline accept` runs `wayline drawing check` and `wayline numbers check` for you, so do not call them yourself.
7. A refused command is not a refused Bash. Run it again in an allowed form, and return blocked only when that form is refused too, naming it.

## Change record

`research/changes/004-give-the-plotter-the-tag-grammar-and-the.json` is the record this ticket makes real, in the project, in your worktree.

- observed: The plotter is never told what a provenance tag looks like or what its run id is. roles/plotter/agent.md and prompts/roles/plotter.md say only that a finding's provenance is "your numbers.json and the key it reads". The result schema line says "A claim sentence ends with its provenance tag". Only roles/writer/agent.md gives the form `{res:<run-id>/<artifact>#<locator>}`. Of the twelve drawing tickets opened at run_end, eight failed their first acceptance or verdict on this: - Ticket 137 wrote every tag as `[res:drawings/R4-1/numbers.json#...]`. The linter reads none of them, so its Methods sentences are untagged claims, and each finding is matched only against its one provenance key. It failed with next none (L4865, L4927, L4928). - Ticket 138 first stated 30, 6, 3 and 60 under one provenance key, `#convergence_drop`, and set `evidence: narrows`, which is only for verification tickets (L4875). Its resume fixed the numbers but wrote `{res:drawings/R5-1/numbers.json#...}` with no run id, which is malformed, and it also failed with next none (L4931, L4932). - Tickets 139, 140, 141, 142, 143 and 144 each had numbers-check blockers: a finding stating numbers that sit at keys it does not cite (L4882, L4952, L4957, L4964, L4974, L5046). The plotter also does not know its Bash limits: - Ticket 139 ran `wayline drawing check`, which its allow list refuses (L4934). - Ticket 145 ran one compound `cd ...; echo ...; grep ... | head` command, which was refused. It then returned blocked after 8 turns, saying "Bash is denied in this session" (L5053, L5054). The plotter role has 12 assignments and 2 first-time passes.
  - evidence: research/journal.jsonl#L4865
  - evidence: research/journal.jsonl#L4875
  - evidence: research/journal.jsonl#L4882
  - evidence: research/journal.jsonl#L4927
  - evidence: research/journal.jsonl#L4928
  - evidence: research/journal.jsonl#L4931
  - evidence: research/journal.jsonl#L4932
  - evidence: research/journal.jsonl#L4934
  - evidence: research/journal.jsonl#L4952
  - evidence: research/journal.jsonl#L4957
  - evidence: research/journal.jsonl#L4964
  - evidence: research/journal.jsonl#L4974
  - evidence: research/journal.jsonl#L5046
  - evidence: research/journal.jsonl#L5053
  - evidence: research/journal.jsonl#L5054
- desired: `.claude/agents/plotter.md` holds the harness's plotter words (roles/plotter/agent.md, with its frontmatter `name: plotter`) plus a section on tags, numbers and Bash. That section says: 1. A tag is written `{res:t<ticket>-a<attempt>/drawings/<drawing>/numbers.json#<key>}`, placed right after the sentence's full stop, one tag per key the sentence takes a number from. The run id is `t<ticket>-a<attempt>`, for example `t138-a1` for ticket 138's first attempt, and a drawing that has not been rerun is attempt 1. Never write `[res:...]` in square brackets, and never write a res tag without the run id: the linter reads neither. 2. Every claim sentence of a Methods passage ends with such a tag. 3. Every number a finding states sits unaltered at the key its provenance names, or at a tag ending that sentence. Counts (6 runs), settings (30 epochs), thresholds and limits (0.01) are numbers too, so draw.py writes each into numbers.json under its own key and the sentence cites it. A provenance names one key; never comma-join keys. 4. Leave `evidence` unset on findings and passages: it is for verification tickets. 5. Bash runs one plain command per call, beginning with python3, wayline tools run, wayline accept, git add, git commit, git status, git diff, git log, ls or cat. No cd, `;`, `&&`, `|`, echo, head, grep or `$(...)`. Read and search files with Read, Glob and Grep. 6. `wayline accept` runs `wayline drawing check` and `wayline numbers check` for you, so do not call them yourself. 7. A refused command is not a refused Bash. Run it again in an allowed form, and return blocked only when that form is refused too, naming it.
- mechanism: `role`, local, risk low
- target: `.claude/agents/plotter.md`
- notes: The override replaces the harness role's words, so start from the full text of roles/plotter/agent.md and add the section; do not write only the new paragraphs. Use the exact phrases the first acceptance command looks for. Record the fixture from session b0589db3-3bad-47f2-84b7-e4a93b434ce8: ticket 138, attempt 1, files in research/sessions/138/1, with drawings/R5-1/numbers.json as the session left it. Pin the harness's plotter as the old subject. Its first result failed at L4875 and its resume at L4931. Structural checks, each a `python` check run with cwd=root: - Every res tag in $.passages[*].text and $.findings[*].text parses with wayline.provenance.parse_tag as kind res with run_id t138-a1, and none is written `[res:` or `{res:drawings/`. - Every number wayline.numbers.numbers_in finds in a finding's text matches wayline.numbers.values_at at the finding's provenance key or at a tag in the same sentence, read from the run's drawings/R5-1/numbers.json. - path_absent_or_empty on each finding's evidence. Rubric line: "Does each finding state only numbers held at its provenance key or at a key tagged in the same sentence, and does every Methods sentence end with a {res:t138-a1/...} tag?" Ticket 137's session 5cef168c-59e4-431d-ae6a-1b0c2db9ccd4 (research/sessions/137/1, L4927) is a good second sample for the bracket form. The Bash part overlaps the global record that puts the role's allow list in the contract. This local copy takes effect now; that one makes it general once the owner applies it.

## The fixture

The change ships with the fixture `role/plotter-tags-every-number`, under `fixtures/role/plotter-tags-every-number/`. It encodes the desired behaviour: record it from the journaled session that showed the observed one (`wayline fixture record --session <id> --kind role --slug plotter-tags-every-number --root . --no-baseline`), then prune its structural checks and write the checks or the rubric that say what must now hold. Before this ticket is integrated the conductor runs it twice: it passes on your change, and it fails on the subject as it is today. A fixture that passes on both proves nothing, and the ticket fails on it.

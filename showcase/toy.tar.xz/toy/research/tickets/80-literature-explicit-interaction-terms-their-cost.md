---
id: 80
title: "Literature: explicit interaction terms, their cost when unneeded, and paired tests of two classifiers (O1, O4)"
kind: lit
difficulty: 2
status: parked
blocked_by: []
touches: []
role: surveyor
skills: []
acceptance:
  machine: []
  quality: []
objectives: [O1, O4]
sections: [introduction]
context_pack: [research/sections/introduction.md, research/CONCERNS.md, research/SPEC.md#e6-claims-c8, research/POSITION.md#what-the-references-lack]
origin: research/SPEC.md#e6-claims-c8
proposed_by: planner
demo: The Introduction holds passages tagged at resolved dossiers. They place the paired-gain question (O1), and the null and strength/size probes (O4), against interaction detection and selection and against paired tests. research/refs/ holds a dossier for each of D6's five DOIs.
---

## Demo

The Introduction holds passages tagged at resolved dossiers. They place the paired-gain question (O1), and the null and strength/size probes (O4), against interaction detection and selection and against paired tests. research/refs/ holds a dossier for each of D6's five DOIs.

## Notes

Re-cut of ticket 59, which never launched. First check each of D6's five works with `wayline scout`, whether or not a passage cites it, because E6's placement analysis reads their dossiers: doi:10.1214/07-aoas148 (Friedman & Popescu 2008), doi:10.1145/2487575.2487579 (Lou et al. 2013), doi:10.1214/13-aos1096 (Bien et al. 2013), doi:10.2307/2531595 (DeLong et al. 1988; already verified as delong-1988-comparing-areas-under-two-more), and doi:10.1162/089976698300017197 (Dietterich 1998). Then search for work that measures the held-out gain from giving a linear or logistic model an explicit product term, against the same model without it (O1). Also search for the cost of spurious interaction terms and how it moves with sample size and interaction strength (O4; K1, K4, K6). Passage P1 of research/sections/introduction.md asks to be rewritten against these dossiers once they resolve: a passage that rewrites it names P1 in `replaces`. Every sentence of a passage ends with a {ref:<slug>#...} tag at a dossier the scout verified; leave out a sentence you cannot tag. Rest nothing on paper-a or paper-b (unresolved fixtures, K7). Tree ensembles, MLPs, factorization machines and GA2M as fitted competitors are out of scope (O5 parked, Q7 rejected): cite them only as what this project does not compare against.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113.

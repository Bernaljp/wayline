---
id: 155
title: Re-file toy.paired's five findings (R8) against the current paired.py and test_paired.py, so the manifest takes their current hashes
kind: analysis
difficulty: 2
status: parked
blocked_by: []
touches: [analysis/refile/paired.json]
role: analyst
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 2, wallclock_minutes: 15}
inputs: [tests/test_paired.py, src/toy/paired.py, tests/fixtures/paired/, research/findings.jsonl]
outputs: [analysis/refile/paired.json]
acceptance:
  machine: ["python3 -c \"import hashlib, json, re; d = json.load(open('analysis/refile/paired.json')); fs = {f['path']: f['sha256'] for f in d['files']}; need = {'tests/test_paired.py', 'src/toy/paired.py'}; assert need <= set(fs) and all(hashlib.sha256(open(p, 'rb').read()).hexdigest() == h for p, h in fs.items()); fd = d['findings']; assert sorted(f['replaces'] for f in fd) == ['t115-a1-f1', 't115-a1-f2', 't116-a2-f1', 't116-a2-f2', 't76-a1-f1']; tags = [re.findall(r'\\{res:(t[0-9]+-a[0-9]+)/([^#{}]+)#[^{}]+\\}', f['text']) for f in fd]; runs = {r for t in tags for r, p in t}; cited = {p for t in tags for r, p in t}; assert all(tags) and len(runs) == 1 and not runs & {'t76-a1', 't115-a1', 't116-a1', 't116-a2'} and need <= cited <= set(fs); assert all(f['provenance'].partition('#')[0] in fs for f in fd) and all(f['negative'] is False for f in fd)\"", "ids=$(python3 -c \"import json; d = json.load(open('analysis/refile/paired.json')); t = {f['replaces']: set(f.get('tests') or []) for f in d['findings']}; p = 'tests.test_paired.'; assert p + 'HandWorkedAnswers' in t['t76-a1-f1'] and p + 'Interface' in t['t115-a1-f1'] and t['t115-a1-f2'] and p + 'Refusals' in t['t116-a2-f1'] and p + 'PinnedSettings' in t['t116-a2-f2']; print(' '.join(sorted(set().union(*t.values()))))\") && test -n \"$ids\" && PYTHONPATH=src python3 -B -m unittest $ids"]
  quality: ["Does each re-filed finding state only what src/toy/paired.py and tests/test_paired.py show as they are now? It should keep the replaced finding's wording wherever that still holds, and every number, including t76-a1-f1's hand-worked answers, should sit on lines that one of its sentence's own-run res tags names."]
objectives: []
sections: [methods, results]
context_pack: [research/findings.jsonl:29, research/findings.jsonl:48-49, research/findings.jsonl:66-67, research/manifest.json:1309-1315, research/manifest.json:1354-1360, research/tickets/141-draw-r8-toy-paired-paired-statistics-of-one-swee.md, src/toy/paired.py, tests/test_paired.py]
origin: research/SPEC.md#seams
proposed_by: planner
demo: analysis/refile/paired.json lists tests/test_paired.py and src/toy/paired.py at the sha256 they have now, beside the stale hashes the manifest holds for runs t76-a1 and t115-a1. It records five findings that replace t76-a1-f1, t115-a1-f1, t115-a1-f2, t116-a2-f1 and t116-a2-f2, each ending with res tags of this ticket's own run and naming the test classes that back it, which pass. Once the ticket is integrated, the manifest holds both files at their current hashes, so a drawing of R8 can pass its provenance check.
---

## Demo

analysis/refile/paired.json lists tests/test_paired.py and src/toy/paired.py at the sha256 they have now, beside the stale hashes the manifest holds for runs t76-a1 and t115-a1. It records five findings that replace t76-a1-f1, t115-a1-f1, t115-a1-f2, t116-a2-f1 and t116-a2-f2, each ending with res tags of this ticket's own run and naming the test classes that back it, which pass. Once the ticket is integrated, the manifest holds both files at their current hashes, so a drawing of R8 can pass its provenance check.

## Notes

Why this ticket exists: drawing R8 (#141) is running and reads tests/test_paired.py and src/toy/paired.py, which research/manifest.json holds at the hashes of runs t76-a1 and t115-a1. Ticket 116 later changed both files, and ticket 131 (commit b008f0a) added docstrings to paired.py. Neither re-registered its file, so R8's drawing meets the same provenance refusal that blocked #139, #142 and #143. No worker may write research/. A file is re-registered by a finding whose text carries a res tag of the worker's own run naming it: at integration the conductor hashes the file on main into the manifest under that run.

1. Read R8's five current findings (research/findings.jsonl lines 29, 48, 49, 66 and 67) against the two files as they are now, and run the test classes that back each: HandWorkedAnswers, Interface, Summarize, Refusals and PinnedSettings. If your Bash refuses the `PYTHONPATH=src` prefix, run unittest from a one-line script that puts src/ on sys.path itself.
2. Return five findings. Give each one:
   - `replaces` set to the finding it re-files.
   - The heading "toy.paired: paired statistics of one sweep point against the oracle ceiling".
   - negative false.
   - A provenance `<path>#<locator>`.
   - Text that keeps the replaced wording wherever it still holds.
   End every sentence with tags `{res:t<this ticket's id>-a<this attempt's number>/<path>#<locator>}`, using your own run id as your prompt gives it, never t76-a1, t115-a1 or t116-a2. Change them if you are resumed into a new attempt. Every number a sentence writes must stand on a line its locators name, as written. For t76-a1-f1's hand-worked answers (2/15, 0.975, 79, 75, 237, 0.5, 2.8/3, 10/17, -1/3 and 0.9), cite the line spans `L<a>-L<b>` of the test that hold them, and write counts such as the three replicates in words. t115-a1-f2's 0.005 is the line of GAP_DENOMINATOR_MIN in paired.py. Between them, the five findings cite both files.
3. Write analysis/refile/paired.json with two keys. `files` is a list of {path, sha256 (the file as it is now), manifest_run, manifest_sha256}. `findings` is a list of {replaces, heading, negative, provenance, text, tests}, where tests are unittest ids such as tests.test_paired.HandWorkedAnswers. Each text is exactly what you return.

Do not change either file. Return no passage.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 176, 177, 178, 179, 180, 181, 182, 183, 184, 185.

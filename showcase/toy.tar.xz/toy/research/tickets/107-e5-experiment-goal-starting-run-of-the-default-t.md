---
id: 107
title: "E5 experiment: goal starting run of the default train.py at seeds 1-3 for O2"
kind: experiment
difficulty: 2
status: accepted
blocked_by: [28]
touches: [experiments/E5/, results/E5/, results/smoke/E5/]
role: experimenter
skills: []
resources: {cpu: 2, gpu: 1, ram_gb: 8, wallclock_minutes: 30}
inputs: [src/toy/train.py, owner/measure.json]
outputs: [results/E5/start/seed1/summary.json, results/E5/start/seed2/summary.json, results/E5/start/seed3/summary.json]
acceptance:
  machine: ["python3 -c \"import json; t = open('experiments/E5/jobs.json').read(); json.loads(t); assert 'results/E5/start/seed1/summary.json' in t and 'configs/arms.json' not in t and '--val-fraction' not in t\"", "python3 -c \"import json; s = json.load(open('experiments/E5/jobs.json')); outs = [o for m in (s.get('members') or [s]) for o in (m.get('expected_outputs') or s.get('expected_outputs') or [])]; assert sorted(outs) == ['results/E5/start/seed%d/summary.json' % i for i in (1, 2, 3)]\"", "! grep -qE -- '--config|--val-fraction' experiments/E5/run.sh && bash experiments/E5/run.sh results/smoke/E5 --epochs 1 --device cpu && python3 -c \"import json; rows = [json.loads(l) for l in open('results/smoke/E5/changes.jsonl')][-3:]; assert [r['seed'] for r in rows] == [1, 2, 3] and all(r['candidate'] == 'start' and r['val_auroc'] is None and r['kept'] is None and 0 < r['auroc'] < 1 for r in rows)\" && test -f results/smoke/E5/start/seed3/summary.json"]
  quality: ["Do the jobs run train.py at its project-start defaults (no --config, no tuned flag) at the seeds decision #28 settled, and name only those summary.json files as outputs, so keep-if-better scores nothing else?"]
objectives: [O2]
sections: [methods]
goal: O2
context_pack: [owner/measure.json, owner/sample-summary.json, experiments/E2/point.sh, src/toy/train.py:156-245, research/SPEC.md#e5-claims-c7]
origin: research/SPEC.md#e5-claims-c7
proposed_by: planner
demo: The goal job trains the default train.py at seeds 1, 2 and 3; after it exits, the conductor's keep-if-better runs O2's command on each summary, prints the three auroc readings and journals the judgment for O2.
retry:
  host_oom: []
  gpu_oom: [--batch-size=64, --batch-size=16]
---

## Demo

The goal job trains the default train.py at seeds 1, 2 and 3; after it exits, the conductor's keep-if-better runs O2's command on each summary, prints the three auroc readings and journals the judgment for O2.

## Notes

Re-cut of #84, which never launched; nothing in its design failed. Decision #28 settled the seeds: the default train.py run at seeds 1, 2 and 3, with keep-if-better keeping on their mean. Seed 1 (B3's seed, D5) is the spec's goal run. Write experiments/E5/run.sh with the Write tool. Its interface is `run.sh <out-root> [extra train.py flags]`. Set python=${E5_PYTHON:-/home/bernaljp/.wayline/tools/venv/bin/python} as point.sh does. For s = 1, 2, 3, run `PYTHONPATH=src "$python" -B -m toy.train --seed "$s" --out "$root/start/seed$s/summary.json" "$@"`. A .json --out is a summary file, never a run directory. Pass no --config, no --val-fraction and no other flag of your own: this is the goal loop's starting value, not a candidate, and the only extra flags are the ones the caller passes (the retry ladder's --batch-size). After each seed, append one line to "$root/changes.jsonl": {"candidate": "start", "seed": s, "val_auroc": null, "auroc": <the summary's auroc>, "kept": null}, written by a python3 call that reads the summary. Write experiments/E5/jobs.json as one job: {"command": ["/bin/bash", "experiments/E5/run.sh", "results/E5"], "expected_outputs": [the three results/E5/start/seed<s>/summary.json]}. Because this ticket names goal O2, the conductor runs `PYTHONPATH=src python3 -m toy.eval --split held_out` on every path in outputs and in each job's expected_outputs. So list ONLY the three summary.json paths there, never changes.jsonl, which the eval command cannot read. The third criterion smoke-runs run.sh for one CPU epoch into results/smoke/E5/, so you need no smoke run of your own; bash and the venv's python are not on this role's allow list anyway. Candidates (E5 steps 2-4) are not this ticket: the E5 analysis proposes them if the start falls short. Then run these, one per Bash call: `wayline accept`; `git add experiments/E5/run.sh experiments/E5/jobs.json`; `git commit -m "E5: goal starting run"`; `wayline job add experiments/E5/jobs.json`. Return running with the job id, and commit nothing under results/. Bash: every part of a command must begin with python3, git add, git commit, git status, git diff, git log, ls, cat, wayline accept or wayline job add. mkdir, bash, heredocs, `>` redirects and `PYTHONPATH=` prefixes are refused, and those refusals blocked tickets 16, 76 and 83. Write files with the Write tool, and retry a refused command in an allowed form before you return blocked. Return one Methods passage. End every sentence with a provenance tag that resolves, and leave out any sentence you cannot tag. File no finding that states a number.

## Result

### Attempt 1

I wrote the goal job for E5 and registered it as t107-1; the real run has not started. experiments/E5/run.sh trains the default train.py three times, at seeds 1, 2 and 3. It passes no --config, no --val-fraction and no flags of its own, only what the caller adds (for example the retry ladder's --batch-size). Each summary goes to results/E5/start/seed<s>/summary.json, and each seed adds one line to results/E5/changes.jsonl with candidate start, the summary's auroc, and val_auroc and kept left null. experiments/E5/jobs.json is a single job that runs `/bin/bash experiments/E5/run.sh results/E5`. It lists only the three summary.json files as outputs, so the conductor's keep-if-better step reads only those with O2's eval command. All three acceptance checks passed under `wayline accept`, including the one-epoch CPU smoke run into results/smoke/E5. Both files are committed on ticket/107.

Wrote: `experiments/E5/run.sh`, `experiments/E5/jobs.json`

Ran: `wayline accept`, `git add experiments/E5/run.sh experiments/E5/jobs.json`, `git commit -m "E5: goal starting run"`, `wayline job add experiments/E5/jobs.json`

Jobs: `t107-1`

Passages:

- methods, Goal loop and held-out reads: The goal loop's starting value is toy.train run at seeds 1, 2 and 3 with its own defaults, given no pinned settings file and no validation split, and each seed's held-out AUROC is logged as a `start` line with a null val_auroc and a null kept {code:experiments/E5/run.sh#L14-L26}.

Every job exited 0 and its outputs parsed: t107-1.

**Verdict (quality): passed** by claude-opus-5-5, session `eb894d4c-d298-4c23-a9e1-d1e0bb394f45`.

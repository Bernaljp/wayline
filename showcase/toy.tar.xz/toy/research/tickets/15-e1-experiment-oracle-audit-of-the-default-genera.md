---
id: 15
title: "E1 experiment: oracle audit of the default generator on the 10^6-row draw D2"
kind: experiment
difficulty: 2
status: parked
blocked_by: [6]
touches: [experiments/E1/, results/E1/, results/smoke/E1/]
role: experimenter
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 8, wallclock_minutes: 60}
inputs: [src/toy/oracle.py, src/toy/generate.py]
outputs: [results/E1/oracle.json]
acceptance:
  machine: ["python3 -c \"import json; s = json.load(open('experiments/E1/job.json')); c = json.dumps(s['command']); assert 'results/E1/oracle.json' in s['expected_outputs'] and '10001' in c and '1000000' in c and 'toy.oracle' in c\""]
  quality: ["Does the job run toy.oracle once on D2 (seed 10001, 10^6 rows, default settings, CPU only) and write results/E1/oracle.json and nothing else?"]
objectives: [O3]
sections: [methods]
context_pack: [research/SPEC.md#e1-claims-c1-c2, research/SPEC.md#data, src/toy/oracle.py]
origin: research/SPEC.md#e1-claims-c1-c2
proposed_by: planner
demo: "`wayline status` shows the E1 job running `toy.oracle --seed 10001 --rows 1000000` on one core; when it exits, results/E1/oracle.json holds the Bayes AUROC, its half-width, the calibration error, the weight on x3*x4 with its line, and the additive gap."
---

## Demo

`wayline status` shows the E1 job running `toy.oracle --seed 10001 --rows 1000000` on one core; when it exits, results/E1/oracle.json holds the Bayes AUROC, its half-width, the calibration error, the weight on x3*x4 with its line, and the additive gap.

## Notes

Write experiments/E1/job.json, one job: command ["python3", "-B", "-m", "toy.oracle", "--seed", "10001", "--rows", "1000000", "--out", "results/E1/oracle.json"], env {"PYTHONPATH": "src"}, no GPU, expected_outputs ["results/E1/oracle.json"], wallclock 60. toy.oracle is stdlib only, so the system python3 runs it. Smoke-test the same command at --rows 2000 into results/smoke/E1/ and commit nothing under results/; then `wayline job add experiments/E1/job.json` and return running. Seed 10001 lies outside every replicate's seeds, so no model of E2-E5 sees D2; nothing is repeated, since the draw's size gives the precision.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49.

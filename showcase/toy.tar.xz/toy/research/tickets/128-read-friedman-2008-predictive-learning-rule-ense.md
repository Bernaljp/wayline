---
id: 128
title: "Read friedman-2008-predictive-learning-rule-ensembles in full: the level-2 read E6 needs (C8)"
kind: dossier
difficulty: 2
status: parked
blocked_by: []
touches: [analysis/E6/reads/friedman-2008-predictive-learning-rule-ensembles/]
role: reader
skills: []
inputs: [research/refs/friedman-2008-predictive-learning-rule-ensembles/dossier.json]
outputs: [research/refs/friedman-2008-predictive-learning-rule-ensembles/dossier.md, research/refs/friedman-2008-predictive-learning-rule-ensembles/entries.jsonl]
acceptance:
  machine: ["python3 -c \"import json; d = json.load(open('research/refs/friedman-2008-predictive-learning-rule-ensembles/dossier.json')); assert d['level'] == 2 and d['l2']['coverage']['pass'] is True\" && test -s research/refs/friedman-2008-predictive-learning-rule-ensembles/dossier.md && test -s research/refs/friedman-2008-predictive-learning-rule-ensembles/entries.jsonl"]
  quality: []
objectives: [O1]
context_pack: [research/refs/friedman-2008-predictive-learning-rule-ensembles/dossier.json]
origin: research/SPEC.md#e6-claims-c8
proposed_by: planner
demo: The conductor runs the level-2 read of friedman-2008-predictive-learning-rule-ensembles through absorb, with no worker session. It builds the inventory from the open-access Project Euclid PDF, and research/refs/friedman-2008-predictive-learning-rule-ensembles/ then holds dossier.md with the paper's sections and entries.jsonl with an entry per inventory item, while dossier.json records l2.coverage.pass true.
---

## Demo

The conductor runs the level-2 read of friedman-2008-predictive-learning-rule-ensembles through absorb, with no worker session. It builds the inventory from the open-access Project Euclid PDF, and research/refs/friedman-2008-predictive-learning-rule-ensembles/ then holds dossier.md with the paper's sections and entries.jsonl with an entry per inventory item, while dossier.json records l2.coverage.pass true.

## Notes

No worker session: the conductor runs this ticket as a promotion through absorb (absorb.run_dossier_ticket). The dossier is already at level 2. Ticket 112's consult promoted it at 2026-10-24T19:29:34Z (journal line 1704), but no full read ever ran. refs/friedman-2008-predictive-learning-rule-ensembles/ holds only dossier.json and qa_log.md: no inventory and no dossier.md. That is why E6 could not settle measures_paired_gain for it (ticket 112, findings t112-a1-f5 and t112-a2-f2). The run builds the inventory from the open-access PDF the scout recorded (open_access.pdf_url on projecteuclid.org, status bronze), reads it with absorb_level_2, and is done when the coverage audit passes. If Project Euclid refuses an automated download, the ticket goes to a person with the harness's own instruction: `wayline absorb --inventory friedman-2008-predictive-learning-rule-ensembles --pdf <path>`. An arXiv copy of the Annals of Applied Statistics version, believed to be arXiv:0811.1679, can serve once `wayline scout` confirms it. The touch set is a placeholder that the plan-time check requires: nothing is written there, because code writes the dossier under research/refs/. The machine criterion describes the state the read leaves; the conductor does not run it for a dossier ticket.

## Result

**Promotion:** refs/friedman-2008-predictive-learning-rule-ensembles has no inventory and none could be built: the open-access PDF of refs/friedman-2008-predictive-learning-rule-ensembles at https://projecteuclid.org/journals/annals-of-applied-statistics/volume-2/issue-3/Predictive-learning-via-rule-ensembles/10.1214/07-AOAS148.pdf answered 200 with something that is not a PDF; hand one over with wayline absorb --inventory friedman-2008-predictive-learning-rule-ensembles --pdf <path>.

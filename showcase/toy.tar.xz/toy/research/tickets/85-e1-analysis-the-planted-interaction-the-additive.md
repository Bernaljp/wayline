---
id: 85
title: "E1 analysis: the planted interaction, the additive gap and the Bayes ceiling (C1, C2 ceiling)"
kind: analysis
difficulty: 3
status: parked
blocked_by: [83]
touches: [analysis/E1/]
role: analyst
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 2, wallclock_minutes: 30}
inputs: [results/E1/oracle.json]
outputs: [analysis/E1/summary.json]
acceptance:
  machine: ["python3 -c \"import json; d = json.load(open('analysis/E1/summary.json')); assert {'interaction_weight', 'interaction_weight_locator', 'additive_gap', 'calibration_error', 'bayes_auroc', 'bayes_auroc_halfwidth', 'c1_supported', 'c2_ceiling_supported', 'ceiling_below_goal'} <= set(d) and d['c1_supported'] == (d['interaction_weight'] != 0 and d['additive_gap'] > 0.005 and d['calibration_error'] <= 0.01) and d['c2_ceiling_supported'] == (d['bayes_auroc_halfwidth'] <= 0.002 and d['calibration_error'] <= 0.01) and d['ceiling_below_goal'] == (d['bayes_auroc'] < 0.82)\""]
  quality: ["Does each verdict in analysis/E1/summary.json follow the spec's success rule for C1 and C2's ceiling part from the manifested oracle.json, and does the label rule stated in the findings match generate.py at the cited line?"]
objectives: [O3]
sections: [methods, results]
context_pack: [src/toy/generate.py:21-40, research/SPEC.md#e1-claims-c1-c2, research/SPEC.md#claims, research/SPEC.md#anti-claims]
origin: research/SPEC.md#e1-claims-c1-c2
proposed_by: planner
demo: analysis/E1/summary.json and the filed findings state the label rule with its line, the weight on x3*x4, the additive gap, the calibration error and the Bayes AUROC with its half-width, with C1's and C2's ceiling verdicts.
---

## Demo

analysis/E1/summary.json and the filed findings state the label rule with its line, the weight on x3*x4, the additive gap, the calibration error and the Bayes AUROC with its half-width, with C1's and C2's ceiling verdicts.

## Notes

Re-cut of ticket 64, which never launched. Read $WAYLINE_PROJECT/results/E1/oracle.json. Write analysis/E1/summarize.py and the analysis/E1/summary.json it writes, holding: the oracle's fields; the thresholds (0.005, 0.01, 0.002, 0.82), each under its own key; and three verdicts. c1_supported = interaction_weight != 0 and additive_gap > 0.005 and calibration_error <= 0.01 (A1 otherwise). c2_ceiling_supported = bayes_auroc_halfwidth <= 0.002 and calibration_error <= 0.01. ceiling_below_goal = bayes_auroc < 0.82 (A6). State how generate.py builds the label, with its line. Finding t6-a1-f1 gives the rule: signal*(0.6 x1 - 0.4 x2 + 1.1 m x3 x4), plus N(0, 1) noise, then a logistic coin flip. If the ceiling is below 0.82, file a decision request for the owner: O2 cannot be met on the default generator, and the generator, the split and the goal are the owner's (objective and data classes). A negative result is a finding too. Result rules the harness checks (tickets 41, 52, 58 and 65 failed on them): return one Methods passage and one Results passage; end every sentence of each with a provenance tag that resolves, and leave out any sentence you cannot tag. Every number in a finding sits literally at a key of analysis/E1/summary.json that the finding cites (analysis/E1/summary.json#bayes_auroc and the like), written as stored, with no percentage, rounding or derived count the cited keys do not hold; put any number you want to state into the JSON first. A finding that says what a current one says (t6-a1-f1 and t6-a1-f2 already state the label rule and the weight 4.4) names it in `replaces`. Leave a passage's evidence unset unless it replaces an inherited claim. results/ is git-ignored and not in the worktree: read it under $WAYLINE_PROJECT and commit only analysis/E1/. If a Bash command you need is refused, stop and return blocked naming it.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113.

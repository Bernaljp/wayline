---
id: 53
title: "toy.oracle: a committed test that the 10^6-row audit fits E1's hour and memory"
kind: code
difficulty: 2
status: parked
blocked_by: [2, 5]
touches: [tests/test_oracle_budget.py]
role: coder
skills: []
acceptance:
  machine: [PYTHONPATH=src python3 -B -m unittest -v tests.test_oracle_budget, grep -q '1000000' tests/test_oracle_budget.py && grep -q 'RUSAGE_CHILDREN' tests/test_oracle_budget.py]
  quality: ["Does the test run the oracle CLI as E1's job will (10^6 rows, default signal 4.0 and strength 1, one stdlib python3 process), at a seed outside D1's and D2's? Does it bound wall time and peak memory by E1's hour and a few GB? Does it print the measured numbers, so that the acceptance record backs them rather than an uncommitted run?"]
objectives: [O3]
sections: [methods]
context_pack: [src/toy/oracle.py:267-289, research/tickets/38-e1-experiment-oracle-audit-of-the-default-genera.md, research/SPEC.md#data, research/SPEC.md#e1-claims-c1-c2]
origin: research/SPEC.md#e1-claims-c1-c2
proposed_by: planner
demo: "`PYTHONPATH=src python3 -B -m unittest -v tests.test_oracle_budget` runs the oracle CLI on a 10^6-row draw. It passes and prints the run's wall-clock seconds and peak memory, both inside E1's hour and a few GB."
---

## Demo

`PYTHONPATH=src python3 -B -m unittest -v tests.test_oracle_budget` runs the oracle CLI on a 10^6-row draw. It passes and prints the run's wall-clock seconds and peak memory, both inside E1's hour and a few GB.

## Notes

Cut from ticket 6 by the planner's split.

\#6's notes required the oracle CLI to finish D2's 10^6 rows within E1's hour on one core and in a few GB of RAM. Its only evidence was an uncommitted diagnostic in the worker's session stream: about 20 s and about 0.8 GB. Write tests/test_oracle_budget.py, a unittest module that commits that check.

- It runs `[sys.executable, '-B', '-m', 'toy.oracle', '--seed', '20001', '--rows', '1000000', '--out', <tempdir>/oracle.json]` as a subprocess with the inherited environment (PYTHONPATH=src).
- It measures wall-clock seconds with time.monotonic, and the child's peak resident memory with resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss, which Linux reports in kilobytes.
- It asserts seconds < 3600 (E1's hour) and peak memory < 4 GiB (half the 8 GB #38 reserves for the E1 job).
- It checks that the written JSON has rows == 1000000 and carries bayes_auroc, bayes_auroc_halfwidth, calibration_error, interaction_weight and additive_gap.
- It prints one line to stderr, `toy.oracle budget: rows 1000000, seconds <s>, max_rss_mb <mb>`, so the acceptance record holds the measured numbers.

Seed 20001 lies outside D1's seeds 1-50 and D2's seed 10001, so the test does not compute E1's result. Assert nothing about the oracle's values beyond the keys and the row count. Do not edit src/toy/oracle.py or tests/test_oracle.py: another ticket is correcting them. The test runs for about 20 s, so keep it in its own module and tests.test_oracle stays fast. Use the standard library only, run Python with -B, and do not create tests/__init__.py. Earlier sessions were refused plain python3, so run the test through `wayline accept` and cite the acceptance record for the seconds and the memory. Report no figure from a run the record does not hold.

## Result

### Attempt 1

tests/test_oracle_budget.py is committed on ticket/53 (28b57dc) and unchanged. This round I added the Methods passage and removed the unmatched measured numbers from the finding. The test runs toy.oracle on seed 10001 and 10^6 rows as a child process. It asserts a zero exit status, the row count and seed in the JSON, wall-clock under 3600 s, and peak child memory under 4 GB. It prints the measured seconds and memory. In my earlier run it passed and `wayline accept` was ok. The audit stayed far inside both limits, but the measured figures are not saved in any file, so the finding no longer states them.

Wrote: `tests/test_oracle_budget.py`

Ran: `python3 -B -m unittest -v tests.test_oracle_budget`, `wayline accept`, `git commit`

Passages:

- methods, Oracle and Bayes ceiling: The cost of the audit is checked by running the oracle command line on the 1000000-row audit draw (seed 10001) as a child process, timing it with a wall clock, and reading the child's peak resident memory from the operating system's resource usage for waited-for children. The run must finish within 3600 seconds and under 4.0 GB, and must report all 1000000 rows. {code:tests/test_oracle_budget.py#OracleBudget}

Parameters:

- `OracleBudget.test_million_row_audit_fits_one_hour_and_a_few_gb` `MEMORY_LIMIT_GB`: E1's job asks for 8 GB of RAM and the spec says a few GB, so 4 GB is a tighter bound that still leaves room.
- `OracleBudget.test_million_row_audit_fits_one_hour_and_a_few_gb` `TIME_LIMIT_SECONDS`: E1's budget is an hour of CPU time, which is tighter than the 120-minute job wallclock.

Not methods:

- `tests/test_oracle_budget.py#peak_children_gb`: A test helper that converts ru_maxrss to GB; it is not a method of the paper.

**Verdict (quality): failed** by claude-opus-5-5, session `54bd8c9f-984d-4f17-8d3e-5cb29f07fd84`.

- [blocker] The test runs the oracle at SEED = 10001, which is D2's own seed (SPEC.md D2). The quality criterion asks for a seed outside D1's and D2's, and the ticket notes give seed 20001 so that the test does not compute E1's result. As written, every acceptance run computes E1's audit on D2 outside the E1 job, which is exactly what the criterion and notes were meant to prevent. (tests/test_oracle_budget.py line 27 (SEED = 10001), also the docstring at line 3)
- [major] The Methods passage in the Result describes the check as running 'the 1000000-row audit draw (seed 10001)'. So the Methods text also records the budget test as running on D2 itself, against the criterion and against the notes' 'Seed 20001 lies outside D1's seeds 1-50 and D2's seed 10001'. (research/tickets/53-toy-oracle-a-committed-test-that-the-10-6-row-au.md ## Result, Passages (methods, Oracle and Bayes ceiling))
- [major] The reason given for TIME_LIMIT_SECONDS says E1's budget is 'an hour of CPU time'. Neither SPEC.md E1 ('budget: CPU only; no GPU hours') nor ticket 38 (resources wallclock_minutes: 120) states an hour of CPU time, and SPEC line 161 says no wall-clock budget is set. The test also bounds wall-clock time (time.perf_counter), not CPU time. A reader of Methods would be told about a budget, and a quantity, that the code does not match. (research/tickets/53-toy-oracle-a-committed-test-that-the-10-6-row-au.md ## Result, Parameters (TIME_LIMIT_SECONDS); tests/test_oracle_budget.py lines 28, 43-48)
- [minor] The ticket notes require a check that the JSON carries bayes_auroc, bayes_auroc_halfwidth, calibration_error, interaction_weight and additive_gap, and the module docstring says it 'returned the E1 metrics'. The test asserts only rows and seed. It also reads stdout instead of writing --out <tempdir>/oracle.json as the notes specify. (tests/test_oracle_budget.py lines 10, 44-55)
- [minor] The wall-time and memory bounds and the printed numbers do meet the criterion. The test asserts < 3600 s and < 4 GB using RUSAGE_CHILDREN, and the acceptance record holds the printed line '19.4 s wall-clock, 0.68 GB peak memory'. But the Result wrongly says the measured figures 'are not saved in any file'. (research/journal.jsonl line 641-643 (acceptance, ticket 53); research/tickets/53-toy-oracle-a-committed-test-that-the-10-6-row-au.md ## Result, Attempt 1)

Escalated one rung up: the next attempt launches on rung 4 (r4 opus low), in a new session.

A finding was refused: provenance 'research/sessions/53/2/acceptance.json' is not <path>#<locator> (The oracle CLI's full audit of a 1000000-row draw at default signal and strength (seed 20001, a stand-in for D2) passes this test's bounds of under 3600 s wall-clock and under 4 GB child peak memory: the whole unittest took 19.4 s under wayline accept.)

### Attempt 2

The test file is unchanged from commit 9ab3b38 on ticket/53. That commit makes the test run at seed 20001, which is outside D1's and D2's seeds. It also writes --out to a tempdir, checks that the E1 metric keys are present, and bounds wall-clock time at 3600 s and child peak memory (RUSAGE_CHILDREN) at 4 GB. I mended the two passage failures. I dropped the 'evidence' field because P10 is the project's own passage, not an inherited claim. I also split the passage into two sentences, each ending with a code tag. `wayline accept` passed again: the unittest took 19.4 s, and the grep check passed.

Wrote: `tests/test_oracle_budget.py`

Ran: `wayline accept`, `git status --short`

Passages:

- methods, Oracle and Bayes ceiling, replacing P10: The cost of the audit is checked by running the oracle command line as a child process on a 1000000-row draw at default settings, with seed 20001, which lies outside D1's and D2's seeds {code:tests/test_oracle_budget.py#OracleBudget}. The run is timed with a wall clock against a one-hour bound that the test sets itself, and the child's peak resident memory, read from the operating system's resource usage for waited-for children, must stay under 4 GB {code:tests/test_oracle_budget.py#OracleBudget}.

Parameters:

- `OracleBudget` `SEED`: 20001 lies outside D1 (seeds 1-20) and D2 (seed 10001), so the budget test never computes E1's own audit.
- `OracleBudget` `TIME_LIMIT_SECONDS`: SPEC.md E1 sets no wall-clock budget, so this test sets one: an hour of wall-clock time, half the E1 job's 120-minute allowance.
- `OracleBudget` `MEMORY_LIMIT_GB`: 4 GB is 'a few GB' and half the 8 GB of RAM the E1 job requests.

Not methods:

- `tests/test_oracle_budget.py#peak_children_gb`: Converts ru_maxrss to GB for a resource check; it computes no result for the paper.

**Verdict (quality): failed** by claude-opus-5-5, session `4515aeec-73fb-4422-ad3a-f4d5243a5959`.

- [blocker] The TIME_LIMIT_SECONDS reason justifies the hour as 'half the E1 job's 120-minute allowance', and so do the comment at line 31 and the docstring at lines 7-8. 120 minutes is the figure of parked, superseded ticket 38. The live E1 job is ticket 62, committed in a5ba8aa during this attempt; it declares wallclock_minutes: 60, which the harness makes the job's RuntimeMaxSec=3600, so the 3600 s bound is E1's whole allowance, not half, and a Methods reader is told an allowance and a margin that do not exist. (research/tickets/53-toy-oracle-a-committed-test-that-the-10-6-row-au.md ## Result, Attempt 2, Parameters (TIME_LIMIT_SECONDS), line 90; research/tickets/62-e1-experiment-oracle-audit-of-the-default-genera.md line 11; harness/wayline/resources.py lines 1600-1619 and 694; tests/test_oracle_budget.py lines 7-8, 31)
- [blocker] The MEMORY_LIMIT_GB reason ('half the 8 GB of RAM the E1 job requests', also the comment at line 32 and the docstring at line 10) uses ticket 38's figure, which ticket 53's own notes (line 34) and the attempt's prompt (line 70) carried. Ticket 62 requests ram_gb: 4, which the harness makes the job's MemoryMax of 4 GiB, so the 4 GB bound is the job's whole request rather than half, and 'a few GB' alone does not justify 4. (research/tickets/53-toy-oracle-a-committed-test-that-the-10-6-row-au.md ## Result, Attempt 2, Parameters (MEMORY_LIMIT_GB), line 91, and ## Notes line 34; research/sessions/53/2/prompt.md line 70; research/tickets/62-e1-experiment-oracle-audit-of-the-default-genera.md line 11; harness/wayline/resources.py line 690; tests/test_oracle_budget.py lines 10, 32)
- [minor] The printed line has rows, seconds and peak memory but not the seed, so the acceptance record alone cannot show which draw was timed. Attempt 1's seed-10001 record and attempt 2's seed-20001 record carry the same line ('19.x s wall-clock, 0.68 GB peak memory'). (tests/test_oracle_budget.py lines 57-58; research/sessions/53/1/acceptance.json and research/sessions/53/2/acceptance.json (results[0].tail))
- [minor] peak_children_gb divides KiB by 1024^2, so the bound is 4 GiB (about 4.29 GB), while the constant's name, the printed line and the Methods passage all say '4 GB'. This matches the harness's MemoryMax (ram_gb x 1024^3), but the passage reads about 7% tighter than the test is. (tests/test_oracle_budget.py lines 36-40, 57; research/tickets/53-toy-oracle-a-committed-test-that-the-10-6-row-au.md ## Result, Attempt 2, Passages)

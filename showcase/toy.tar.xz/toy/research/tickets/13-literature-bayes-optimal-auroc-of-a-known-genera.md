---
id: 13
title: "Literature: Bayes-optimal AUROC of a known generator and the precision of an AUROC estimate"
kind: lit
difficulty: 2
status: parked
blocked_by: []
touches: []
role: surveyor
skills: []
acceptance:
  machine: []
  quality: []
objectives: [O3]
sections: [introduction]
context_pack: [research/sections/introduction.md, research/CONCERNS.md, research/SPEC.md#e1-claims-c1-c2, research/SPEC.md#methods, research/POSITION.md#what-the-references-lack]
origin: research/SPEC.md#e1-claims-c1-c2
proposed_by: planner
demo: The Introduction holds passages tagged at resolved dossiers on why ranking by the true P(y=1|x) gives the highest attainable ROC curve, how an AUROC's standard error is estimated, and why a gain is read as a share of the gap to that ceiling (K5).
---

## Demo

The Introduction holds passages tagged at resolved dossiers on why ranking by the true P(y=1|x) gives the highest attainable ROC curve, how an AUROC's standard error is estimated, and why a gain is read as a share of the gap to that ceiling (K5).

## Notes

Search for: the optimality of ranking by the true class probability or likelihood ratio for the ROC curve (Neyman-Pearson), so the Bayes classifier's AUROC is the ceiling no model beats in expectation; the variance of an AUROC estimate (Hanley & McNeil 1982; DeLong et al. 1988); the logistic-normal integral the generator's latent noise makes (for example the probit approximation); and simulation studies that report a learned model's AUROC against a known-generator ceiling. Check each cited work with `wayline scout`. Rest nothing on paper-a or paper-b.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49.

---
id: 180
title: Re-file R4's seven oracle-test findings against the current tests/test_oracle.py and narrow t6-a1-f4's 10^6-row sentence, re-pinning the file
kind: writing
difficulty: 3
status: open
blocked_by: []
touches: []
role: writer
skills: [interval-claims]
inputs: [tests/test_oracle.py, results/E1/oracle.json, analysis/E1/summary.json, research/findings.jsonl, research/manifest.json]
acceptance:
  machine: []
  quality: ["Do the seven findings that replace t6-a1-f2, t6-a1-f3, t6-a1-f4, t6-a1-f5, t52-a1-f1, t52-a1-f2 and t52-a4-f1 each cite tests/test_oracle.py as it is now, at own-run locators that hold every number they write? Does t6-a1-f4's replacement drop or support its 10^6-row sentence with keys of results/E1 or analysis/E1 cited at their existing runs, with no SE bound, multiple of SE or 'meaningful test' judgment that no cited key holds?"]
objectives: []
sections: [results]
context_pack: [research/findings.jsonl:12-15, research/findings.jsonl:18-19, research/findings.jsonl:28, research/sections/results.md:43-62, research/manifest.json:1120-1126, research/tickets/158-scope-down-a-report-claim-its-artifacts-do-not-s.md, tests/test_oracle.py, results/E1/oracle.json, analysis/E1/summary.json]
origin: research/REPORT.md#claim-5d06e38f7f896d69
proposed_by: planner
demo: The general report renders seven findings under R4's heading in place of t6-a1-f2 to t6-a1-f5, t52-a1-f1, t52-a1-f2 and t52-a4-f1. Each is tagged at this ticket's run on tests/test_oracle.py as it is now. The report header no longer lists t6-a1-f4's 10^6-row sentence as a failed claim, and research/manifest.json holds the current tests/test_oracle.py.
---

## Demo

The general report renders seven findings under R4's heading in place of t6-a1-f2 to t6-a1-f5, t52-a1-f1, t52-a1-f2 and t52-a4-f1. Each is tagged at this ticket's run on tests/test_oracle.py as it is now. The report header no longer lists t6-a1-f4's 10^6-row sentence as a failed claim, and research/manifest.json holds the current tests/test_oracle.py.

## Notes

Why: the sampled verdict failed t6-a1-f4's last sentence. Its numbers (10^6 rows, 50,000 per bin, SE <= 0.0023, about 4 SE, a meaningful test) appear at no cited locator. The verifier also found that the manifest holds tests/test_oracle.py only at run t6-a1 (10,710 bytes, commit 5885a7f). The file is now 14,557 bytes, after commits 3bc54ac, a52b13e, dd89183 and 3fee2a7. So seven current findings cite t6-a1/tests/test_oracle.py, and three of them (t52-a1-f1, t52-a1-f2, t52-a4-f1) cite tests the pinned bytes do not contain. This ticket replaces #158 and the kill argument's point 2 for t6-a1-f4.

How a re-pin works: a sentence ending with `{res:t<this ticket>-a<this attempt>/tests/test_oracle.py#<locator>}` makes the conductor hash the file on main into research/manifest.json under this run at integration, replacing the t6-a1 entry. Every t6-a1 tag on the file then stops resolving, which is why all seven findings are replaced here. t6-a1-f1 cites t2-a3/src/toy/generate.py, not this file: leave it alone.

Put own-run tags only on tests/test_oracle.py. Cite results/E1/oracle.json at t102-a1, analysis/E1/summary.json at t103-a1, and src/toy/oracle.py at t131-a1, with those run ids and never your own. An own-run tag on them would re-pin them and break O3's answer and every E1 finding. Use your run id as your prompt gives it.

What to return: seven findings, each with `replaces`, the replaced finding's `heading` as research/findings.jsonl records it ("toy.oracle: the generator's true P(y=1|x), Bayes ceiling, calibration and additive gap"), `negative` as recorded (t6-a1-f4 is true), a `provenance` at tests/test_oracle.py, and text that keeps the replaced wording wherever it still holds. Use locators such as `Calibration.test_largest_gap_at_20000_rows_is_sampling_noise`, `Calibration.test_calibration_error_on_200000_rows_and_a_miscalibrated_control`, `Transcription.test_true_prob_matches_generate_row_by_monte_carlo`, `Cli.test_interaction_weight_is_the_unrounded_product`, `Quadrature.test_logistic_normal_integral_is_converged`, or a line span `L<a>-L<b>` of the current file. Each must hold every number its sentence writes, as written. The SE ~0.016 and seed-7 0.034 text now sits in test_largest_gap_at_20000_rows_is_sampling_noise.

For t6-a1-f4's last sentence, either drop it, or keep only what cited keys hold. For example, D2's rows and calibration_error are in results/E1/oracle.json at t102-a1, and the limit is analysis/E1/summary.json#limits.calibration_error at t103-a1. No artifact holds the 0.0023 bound, the 'about 4 SE', or evidence that 0.01 is a meaningful test at 10^6 rows: leave them out.

Say what a test asserts, not that it passed. Edit no file. Return no passage.

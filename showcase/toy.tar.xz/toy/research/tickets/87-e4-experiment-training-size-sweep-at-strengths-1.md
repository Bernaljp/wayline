---
id: 87
title: "E4 experiment: training-size sweep at strengths 1 and 0"
kind: experiment
difficulty: 3
status: parked
blocked_by: [65]
touches: [experiments/E4/, results/runs/E4/, results/smoke/E4/]
role: experimenter
skills: []
resources: {cpu: 2, gpu: 1, ram_gb: 16, wallclock_minutes: 60}
inputs: [configs/arms.json, src/toy/train.py, src/toy/generate.py, experiments/E2/point.sh]
outputs: [results/runs/E4/m1_n1000/without/seed20/heldout_scores.csv, results/runs/E4/m1_n2000/without/seed20/heldout_scores.csv, results/runs/E4/m1_n4000/without/seed20/heldout_scores.csv, results/runs/E4/m1_n8000/without/seed20/heldout_scores.csv, results/runs/E4/m1_n32000/without/seed20/heldout_scores.csv, results/runs/E4/m1_n64000/without/seed20/heldout_scores.csv, results/runs/E4/m0_n1000/without/seed20/heldout_scores.csv, results/runs/E4/m0_n2000/without/seed20/heldout_scores.csv, results/runs/E4/m0_n4000/without/seed20/heldout_scores.csv, results/runs/E4/m0_n8000/without/seed20/heldout_scores.csv, results/runs/E4/m0_n32000/without/seed20/heldout_scores.csv, results/runs/E4/m0_n64000/without/seed20/heldout_scores.csv]
acceptance:
  machine: ["python3 -c \"import json; t = open('experiments/E4/jobs.json').read(); json.loads(t); assert all(('results/runs/E4/m%d_n%d/%s/seed%d/heldout_scores.csv' % (m, n, a, i)) in t for m in (0, 1) for n in (1000, 2000, 4000, 8000, 32000, 64000) for a in ('with', 'without') for i in range(1, 21)) and '_n16000/' not in t and '_n0/' not in t\"", grep -rq -- '--train-rows' experiments/E4/ && grep -rq -- '--rows' experiments/E4/ && grep -rq -- '--strength' experiments/E4/]
  quality: ["Do the jobs run exactly the twelve points (strength 1 and 0, sizes 1000 to 64000 without 16000), capping the default draw's training rows for the small sizes and drawing n/0.8 rows for the large ones, seeds 1-20, both arms, configs/arms.json, nothing tuned?"]
objectives: [O4]
sections: [methods]
context_pack: [configs/arms.json, experiments/E2/point.sh, experiments/E2/jobs.json:1-10, research/SPEC.md#e4-claims-c6, research/SPEC.md#methods]
origin: research/SPEC.md#e4-claims-c6
proposed_by: planner
demo: "`wayline status` shows twelve E4 jobs, one per strength 1 or 0 and training size 1000 to 64000, each running 40 paired runs into results/runs/E4/m<m>_n<n>/."
retry:
  host_oom: []
  gpu_oom: [--batch-size=64, --batch-size=16]
---

## Demo

`wayline status` shows twelve E4 jobs, one per strength 1 or 0 and training size 1000 to 64000, each running 40 paired runs into results/runs/E4/m<m>_n<n>/.

## Notes

Re-cut of ticket 67, which never launched. It waits on the E2 gate #65. n0 is 16000 training rows: configs/arms.json's 20000 rows less the held-out fifth. The sizes are therefore 1000, 2000, 4000 and 8000 (n0/16 to n0/2), and 32000 and 64000 (2*n0 and 4*n0); none is under 200. experiments/E2/point.sh takes <out-root> <first-seed> <last-seed> [extra train.py flags] and runs both arms with --config configs/arms.json and --save-scores. Call it, or write experiments/E4/point.sh. Give jobs.json one member per point, for m in {1, 0} and n in {1000, 2000, 4000, 8000, 32000, 64000}: seeds 1-20, both arms, `--strength m`. For n up to 8000, add `--train-rows n`; this caps the default draw and leaves the held-out fifth unchanged. For n = 32000 and n = 64000, add `--rows 40000` and `--rows 80000` (n/0.8 rows, with the last fifth held out; a flag on the command line wins over the config's rows). The out-root is results/runs/E4/m<m>_n<n>. The n0 points at m = 1 and m = 0 are E2's m1_n0 and E3's m0_n0: do not re-run them. Each member's expected_outputs lists every run's three files literally. The retry ladder's --batch-size passes through to train.py. Nothing is tuned and no seed is dropped. Smoke-test one seed at m0_n1000 on the CPU into results/smoke/E4/, and commit nothing under results/. Return one Methods passage, every sentence ending with a provenance tag that resolves, and leave out any sentence you cannot tag. File no finding that states a number. If a Bash command you need (python3, wayline, git) is refused, stop at once and return blocked naming it.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113.

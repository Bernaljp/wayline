---
id: 24
title: "E4 analysis: gain across training sizes and the zero-strength cost per size (C6)"
kind: analysis
difficulty: 3
status: parked
blocked_by: [9, 19, 20]
touches: [analysis/E4/]
role: analyst
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 8, wallclock_minutes: 30}
inputs: [results/runs/E4/, results/runs/E2/m1_n0/, results/runs/E3/m0_n0/]
outputs: [analysis/E4/sweep_m1.json, analysis/E4/sweep_m0.json, analysis/E4/verdict.json]
acceptance:
  machine: ["python3 -c \"import json; a = json.load(open('analysis/E4/sweep_m1.json')); b = json.load(open('analysis/E4/sweep_m0.json')); assert {'gain_shrink', 'gain_shrink_lo'} <= set(a) and len(a['points']) == 7 and len(b['points']) == 7\"", "python3 -c \"import json; d = json.load(open('analysis/E4/verdict.json')); assert {'c6_supported', 'a5', 'unresolved'} <= set(d)\""]
  quality: ["Does C6's verdict follow gain_shrink <= 0.005 (A5 when gain_shrink_lo > 0.005, unresolved between), and is the zero-strength difference per size reported as the overfitting cost rather than claimed?"]
objectives: [O4]
sections: [methods, results]
context_pack: [research/SPEC.md#e4-claims-c6, research/SPEC.md#claims, research/SPEC.md#anti-claims]
origin: research/SPEC.md#e4-claims-c6
proposed_by: planner
demo: analysis/E4/sweep_m1.json and sweep_m0.json and the findings show the paired gain with its CI at each training size from 1000 to 64000 rows at strength 1 and 0, gain_shrink with its CI, and C6's verdict.
---

## Demo

analysis/E4/sweep_m1.json and sweep_m0.json and the findings show the paired gain with its CI at each training size from 1000 to 64000 rows at strength 1 and 0, gain_shrink with its CI, and C6's verdict.

## Notes

Run toy.sweep twice: `PYTHONPATH=src python3 -B -m toy.sweep "$WAYLINE_PROJECT/results/runs/E4" --axis rows --strength 1 --point "$WAYLINE_PROJECT/results/runs/E2/m1_n0" --out analysis/E4/sweep_m1.json` and the same with `--strength 0 --point "$WAYLINE_PROJECT/results/runs/E3/m0_n0" --out analysis/E4/sweep_m0.json` (seven sizes each). Write analysis/E4/verdict.py and verdict.json: c6_supported = gain_shrink <= 0.005 at m = 1; a5 = gain_shrink_lo > 0.005 (then C3's gain is partly a small-sample effect); unresolved when neither holds. At m = 0 report the paired difference at each size as the overfitting cost K4 asks about, not as a claim. A8: the claims reach only across these grids. Propose seeds 21-50 where Q15's rule says (SD above 0.02, or an interval too wide at m = 0 or the smallest size).

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49.

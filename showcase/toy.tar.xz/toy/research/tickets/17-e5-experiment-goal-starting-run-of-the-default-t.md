---
id: 17
title: "E5 experiment: goal starting run of the default train.py for O2"
kind: experiment
difficulty: 2
status: parked
blocked_by: [28]
touches: [experiments/E5/, results/E5/, results/smoke/E5/]
role: experimenter
skills: []
resources: {cpu: 2, gpu: 1, ram_gb: 8, wallclock_minutes: 30}
inputs: [src/toy/train.py, owner/measure.json]
outputs: [results/E5/start/seed1/summary.json, results/E5/start/seed2/summary.json, results/E5/start/seed3/summary.json]
acceptance:
  machine: ["python3 -c \"import json; t = open('experiments/E5/jobs.json').read(); json.loads(t); assert 'results/E5/start/seed1/summary.json' in t and 'configs/arms.json' not in t and '--val-fraction' not in t\"", "python3 -c \"import json; s = json.load(open('experiments/E5/jobs.json')); outs = [o for m in (s.get('members') or [s]) for o in (m.get('expected_outputs') or s.get('expected_outputs') or [])]; assert outs and all(o.endswith('summary.json') for o in outs)\""]
  quality: ["Do the jobs run train.py at its project-start defaults (no --config, no tuned flag) at the seeds decision D1 settled, and name only those summary.json files as outputs, so keep-if-better scores nothing else?"]
objectives: [O2]
sections: [methods]
goal: O2
context_pack: [owner/measure.json, owner/sample-summary.json, research/SPEC.md#e5-claims-c7, src/toy/train.py]
origin: research/SPEC.md#e5-claims-c7
proposed_by: planner
demo: The goal job trains the default train.py at seeds 1, 2 and 3; after it exits, the conductor's keep-if-better runs O2's command on each summary, prints the three auroc readings and journals the judgment for O2.
retry:
  host_oom: []
  gpu_oom: [--batch-size=64, --batch-size=16]
---

## Demo

The goal job trains the default train.py at seeds 1, 2 and 3; after it exits, the conductor's keep-if-better runs O2's command on each summary, prints the three auroc readings and journals the judgment for O2.

## Notes

Paused by decision D1; this cut follows its recommended answer (three seeds). Run train.py as it stands, with no flag beyond --seed and --out: `PYTHONPATH=src /home/bernaljp/.wayline/tools/venv/bin/python -B -m toy.train --seed <s> --out results/E5/start/seed<s>/summary.json` for s = 1, 2, 3. Seed 1 is B3's seed, the spec's goal run (D5: train.py has no default seed). No --config, no --val-fraction, no other flag: this is the goal loop's starting value, not a candidate. Write experiments/E5/run.sh and experiments/E5/jobs.json (one job running the three seeds in turn, passing --batch-size through for the retry ladder). After each seed, the script appends one line to results/E5/changes.jsonl: {"candidate": "start", "seed": s, "val_auroc": null, "auroc": <the summary's auroc>, "kept": null}; toy.goallog counts the start as one held-out read. Because the ticket names goal O2, the conductor runs `PYTHONPATH=src python3 -m toy.eval --split held_out` on every path in outputs and in each job's expected_outputs: list ONLY the three summary.json paths there, never changes.jsonl, which the eval command cannot read and which would fail the ticket. Candidates (E5 steps 2-4) are not this ticket. If D1 is answered otherwise, this ticket is re-cut. Smoke-test on the CPU into results/smoke/E5/ and commit nothing under results/.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49.

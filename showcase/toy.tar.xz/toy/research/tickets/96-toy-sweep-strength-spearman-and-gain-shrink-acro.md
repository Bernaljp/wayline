---
id: 96
title: "toy.sweep: strength_spearman and gain_shrink across sweep points"
kind: code
difficulty: 3
status: accepted
blocked_by: [115, 116]
touches: [src/toy/sweep.py, tests/test_sweep.py, tests/fixtures/sweep/]
role: coder
skills: []
inputs: [src/toy/paired.py, src/toy/stats.py]
outputs: [src/toy/sweep.py, tests/test_sweep.py, tests/fixtures/sweep/]
acceptance:
  machine: [PYTHONPATH=src python3 -B -m unittest tests.test_sweep, "PYTHONPATH=src python3 -B -m toy.sweep tests/fixtures/sweep/E3 --axis strength | python3 -c \"import json, sys; d = json.load(sys.stdin); assert 'strength_spearman' in d and len(d['points']) >= 3 and all('strength' in p and 'paired_gain_lo' in p for p in d['points'])\"", "PYTHONPATH=src python3 -B -m toy.sweep tests/fixtures/sweep/rows --axis rows --strength 1 | python3 -c \"import json, sys; d = json.load(sys.stdin); assert {'gain_shrink', 'gain_shrink_lo', 'gain_shrink_hi'} <= set(d) and len(d['points']) >= 2\"", "PYTHONPATH=src python3 -B -c \"import inspect; from toy.sweep import sweep; assert {'exp_dir', 'axis', 'strength', 'points'} <= set(inspect.signature(sweep).parameters)\""]
  quality: ["Do strength_spearman and gain_shrink use exactly the points and the common seeds the spec names, read each point's strength and size from its runs' config.json, and take reused points from the directories given rather than re-running them?"]
objectives: [O4]
sections: [methods]
context_pack: [src/toy/stats.py:227-240, src/toy/paired.py, research/SPEC.md#e3-claims-c4-c5, research/SPEC.md#e4-claims-c6, research/SPEC.md#seams]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`PYTHONPATH=src python3 -m toy.sweep tests/fixtures/sweep/E3 --axis strength` prints a per-point table and strength_spearman; `--axis rows --strength 1` on tests/fixtures/sweep/rows prints gain_shrink with its interval."
---

## Demo

`PYTHONPATH=src python3 -m toy.sweep tests/fixtures/sweep/E3 --axis strength` prints a per-point table and strength_spearman; `--axis rows --strength 1` on tests/fixtures/sweep/rows prints gain_shrink with its interval.

## Notes

Re-cut of #77, which never launched; nothing in its design failed. Write only src/toy/sweep.py, tests/test_sweep.py and tests/fixtures/sweep/. The CLI is `toy.sweep <exp-dir> --axis strength|rows [--strength m] [--point DIR ...] [--out PATH]`. Also expose sweep(exp_dir, axis, strength=None, points=()), which returns the dict the CLI prints; the E3 and E4 analyses call it from their scripts. A point is a directory holding with/ and without/. Every such directory directly under <exp-dir> is a point, and each --point (or entry of points) adds one from another experiment: E3 reuses E2's results/runs/E2/m1_n0, and E4 reuses E2's m1_n0 at m = 1 and E3's m0_n0 at m = 0. Read each point's strength and train_rows from its runs' config.json, never from its name (m1_n0 carries no number). Each point's statistics come from toy.paired's one-point function: point_stats, as #76's notes name it, or paired if it landed under that name. Each entry of the output's points list is a flat dict: dir, strength, train_rows, and every key that function returns. With --axis strength, the points must share one training size; it is an error if they differ. Sort them by strength and add strength_spearman, the Spearman correlation between strength and paired_gain, with average ranks (toy.stats.spearman). With --axis rows --strength m, take only the points at strength m and sort them by train_rows. Then add gain_shrink: over the seeds the smallest and largest points share, the mean of (d_i at the smallest size - d_i at the largest size). Give its paired 95% t-interval as gain_shrink_lo and gain_shrink_hi. It is an error when those two points share no seed. Fixtures: tests/fixtures/sweep/E3/ (at least three strength points) and tests/fixtures/sweep/rows/ (at least two sizes at strength 1), with the answers worked out by hand. Stdlib only. Bash: this role runs a command only when every part of it begins with a program on its allow list: python3, git add, git commit, git status, git diff, git log, ls, cat and wayline accept. These are refused: a `PYTHONPATH=src` prefix, mkdir, bash, a heredoc or a `>` redirect into a file, and the venv's python called by its path. Those refusals blocked tickets 16, 76 and 83. So write every file with the Write tool, and run one plain command per Bash call. Let `wayline accept` run the tests and the criteria. For a check of your own, run `python3 -B -c "import sys; sys.path.insert(0, 'src'); ..."`. Retry a refused command in an allowed form, and return blocked only when that form is refused too. The harness checks the Result against these rules (tickets 41, 52, 53, 58 and 65 failed on them). Return one Methods passage. End every sentence of it with a provenance tag that resolves, such as {code:src/toy/sweep.py#sweep}, and leave out any sentence you cannot tag. A finding that states a number cites a locator holding that literal number. A passage that says what a current one says names it in `replaces`. Leave a passage's evidence unset.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Result

### Attempt 1

Added `toy.sweep` (src/toy/sweep.py) with the interface ticket 96's notes ask for: the function `sweep(exp_dir, axis, strength=None, points=())` and the CLI `toy.sweep <exp-dir> --axis strength|rows [--strength m] [--point DIR ...] [--out PATH]`.

How points are found and read:
- A point is any directory directly under exp_dir that holds both with/ and without/. Each `--point` (or entry of `points`) adds a reused point from another experiment, which is read from its own directory and never re-run.
- Each point's statistics come from `toy.paired.point_stats`. Its strength and train_rows come from its runs' config.json, never from the directory name.
- Each entry of the output's `points` list is a flat dict: `dir`, then every key `point_stats` returns.

The two axes:
- `--axis strength`: the points must share one train_rows. They are sorted by strength, and `strength_spearman` is Spearman's rho with average ranks (`toy.stats.spearman`) between strength and paired_gain.
- `--axis rows --strength m`: keeps only the points at strength m and sorts them by train_rows. `gain_shrink` is the mean of (d_i at the smallest size − d_i at the largest size) over the seeds those two points share. Its 95% t-interval is given as `gain_shrink_lo` and `gain_shrink_hi`, alongside `gain_shrink_seeds`, `gain_shrink_n`, `smallest_train_rows` and `largest_train_rows`.

Refusals (ValueError, exit 2 on the CLI):
- points that disagree on the signal or on toy.paired's TRAINING_KEYS (the pinned settings);
- two points at one strength (strength axis) or one train_rows (rows axis);
- the same directory given twice;
- a strength given with the strength axis, or none given with the rows axis;
- fewer than two points to sweep;
- fewer than two shared seeds for gain_shrink. The notes asked for an error only when the two points share no seed; with one shared seed a t-interval cannot be formed, so that is refused too;
- any refusal by toy.paired at any point.

Fixtures (tests/fixtures/sweep/):
- E3/ has m0_n0, m0.5_n0 and m4_n0. E2/m1_n0 is a reused point.
- rows/ has m1_n20, m1_n40, m1_n80 and m0_n20.
- Every run is a real `toy.generate` draw at signal 4, scored so that it loses an exact number k of positive–negative pairs.
- tests/fixtures/sweep/build.py wrote them. tests/test_sweep.py does not rely on it: it checks every run's k on disk against its own table.

Hand-worked answers in tests/test_sweep.py:
- strength_spearman is 1 over E3 alone and 0.8 with E2's m1_n0 added.
- m4's paired_gain_lo is (11 − t(0.975,1))/42.
- gain_shrink at m = 1 is 197/2200 ± t(0.975,1)·43/2200, over seeds 2–3 only.
- gain_shrink at m = 0, with E3's m0_n0 added as E4 adds it, is exactly 0.

Checks run:
- The 25 tests in tests.test_sweep pass, as do test_paired and test_stats (91 tests together).
- `wayline accept` passes all four acceptance commands.
- Committed on ticket/96 as 73dc8ba.

One thing for later analyses: called with runs/E2 as exp_dir, the module would also count runs/E2/converge as a point, because that directory holds with/ and without/. The E3 and E4 analyses pass E2's m1_n0 by `points`, so they are not affected.

Wrote: `src/toy/sweep.py`, `tests/test_sweep.py`, `tests/fixtures/sweep/build.py`, `tests/fixtures/sweep/E3/`, `tests/fixtures/sweep/E2/m1_n0/`, `tests/fixtures/sweep/rows/`

Ran: `python3 -B tests/fixtures/sweep/build.py`, `python3 -B -c "import sys, unittest; sys.path.insert(0, 'src'); unittest.main(module=None, argv=['t', 'tests.test_sweep'])"`, `python3 -B -c "import sys, unittest; sys.path.insert(0, 'src'); unittest.main(module=None, argv=['t', 'tests.test_paired', 'tests.test_stats', 'tests.test_sweep'])"`, `wayline accept`, `git add src/toy/sweep.py tests/test_sweep.py tests/fixtures/sweep`, `git commit`

Passages:

- methods, Statistics: toy.sweep takes each sweep point's paired statistics from toy.paired, reads the point's interaction strength and training size from its runs' config.json rather than from the directory name, and refuses a sweep whose points disagree on the signal or on the pinned training settings {code:src/toy/sweep.py#read_points}. Points reused from another experiment, such as E2's $m = 1$ point in E3 and E3's $m = 0$ point in E4, join the sweep from their own directories and are not rerun {code:src/toy/sweep.py#point_dirs}. Along the strength axis, with every point at one training size, strength_spearman is Spearman's correlation, with average ranks, between the strength $m$ and the mean paired gain over the points {code:src/toy/sweep.py#strength_axis}. Along the training-size axis at one strength $m$, gain_shrink is the mean, over the seeds that both the smallest and the largest point ran, of $e_i = d_i^{\text{smallest}} - d_i^{\text{largest}}$, with its paired 95% t-interval on $n - 1$ degrees of freedom; a seed run at only one of those two points does not enter {code:src/toy/sweep.py#rows_axis}.

Parameters:

- `rows_axis` `confidence`: gain_shrink's paired interval uses toy.paired's CONFIDENCE (0.95), since SPEC E4 asks for a paired 95% CI and this matches the level of paired_gain's t-interval.
- `sweep` `strength`: Defaults to None because only the rows axis picks a strength, and that axis refuses to run without one rather than guessing it.
- `sweep` `points`: Defaults to no extra points, so a sweep covers only its own experiment directory unless reused points are named explicitly.

Not methods:

- `src/toy/sweep.py#main`: Command-line wrapper: parses arguments, prints or writes sweep()'s JSON and turns refusals into exit 2.
- `src/toy/sweep.py#_is_point`: Directory test for with/ and without/, the run-directory layout SPEC.md#seams already fixes.
- `src/toy/sweep.py#_one_per`: Input check that refuses two points at the same axis value; it computes no statistic.
- `tests/fixtures/sweep/build.py#scores_losing`: Builds test fixture scores with a known number of discordant pairs; it is not used on any result.
- `tests/fixtures/sweep/build.py#write_run`: Writes fixture run directories for the tests only.
- `tests/fixtures/sweep/build.py#main`: Rebuilds the test fixtures; it is not part of any analysis.

**Verdict (result): passed** by claude-opus-5-5, session `4df9f8de-3e04-42d6-b052-457d4b481386`.

- [minor] `sweep()` is a public function this change adds. It is not cited by a {code:...} tag in the Methods passage, and it is not listed in `not_methods`, yet the Result gives reasons for its parameters. The coder rule asks for one or the other. The harness's code-to-Methods check only reads `code/` and this project's code is in `src/`, so it could not catch this; every inventory row reads 'not seen by the parsers'. Nothing in the Result is false because of it. (src/toy/sweep.py:124 (def sweep); research/tickets/96-toy-sweep-strength-spearman-and-gain-shrink-acro.md ## Result, Passages / Not methods)
- [minor] 'The E3 and E4 analyses pass E2's m1_n0 by `points`, so they are not affected' describes analyses that do not exist yet. Tickets 109 and 110 are still open; their notes do call sweep with points=[.../E2/m1_n0] (and E3's m0_n0 for E4's m = 0 run), never with results/runs/E2 as exp_dir. So the remark is an instruction in those tickets, not something ticket 96's artifacts show. The converge directory it warns about is results/runs/E2/converge, and it does hold with/ and without/. (research/tickets/96-toy-sweep-strength-spearman-and-gain-shrink-acro.md:77 (## Result, 'One thing for later analyses'))
- [minor] Outside the question: SPEC's script for strength_spearman is `toy.sweep runs/E3 --axis strength`, with no --point. Because points defaults to empty, that command run as written covers E3's five directories, not the 'six points' the metric names. E2's m = 1 point joins only through --point. Ticket 109 passes the point and its acceptance checks all six strengths, but anyone reproducing from the SPEC line gets a different number. (research/SPEC.md:139 (## Metrics, strength_spearman))
- [minor] I could not run the tests or the acceptance commands myself, because python3 was refused in this session. That the 25 tests and the four acceptance commands pass rests on the harness's own `wayline accept` record (exit 0 on all four, 'Ran 25 tests ... OK'), dated 11 s before commit 73dc8ba. That commit is identical on the ticket paths to main's 6fa5730 and to the working tree. Separately, I re-derived every hand-worked answer (-1/42, 57/400, 3/50, 11/42, rho 1 and 0.8, (11 - t)/42, 197/2200 +/- t*43/2200, and 0 at m = 0) from the fixture tables, and I checked several heldout_scores.csv files against their k. (research/sessions/96/1/acceptance.json)

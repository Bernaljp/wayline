---
id: 33
title: "toy.goallog: held-out reads of the goal loop from results/E5/changes.jsonl"
kind: code
difficulty: 1
status: parked
blocked_by: [50]
touches: [code/src/toy/goallog.py, code/tests/test_goallog.py, code/tests/fixtures/goallog/]
role: coder
skills: []
acceptance:
  machine: [PYTHONPATH=code/src python3 -B -m unittest discover -s code/tests -p 'test_goallog.py', "PYTHONPATH=code/src python3 -B -m toy.goallog code/tests/fixtures/goallog/changes.jsonl | python3 -c \"import json, sys; d = json.load(sys.stdin); assert {'heldout_reads', 'heldout_scorings', 'candidates'} <= set(d)\""]
  quality: []
objectives: [O2]
sections: [methods]
context_pack: [research/SPEC.md#e5-claims-c7, research/SPEC.md#seams]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`PYTHONPATH=code/src python3 -m toy.goallog code/tests/fixtures/goallog/changes.jsonl` prints heldout_reads and the per-candidate table."
---

## Demo

`PYTHONPATH=code/src python3 -m toy.goallog code/tests/fixtures/goallog/changes.jsonl` prints heldout_reads and the per-candidate table.

## Notes

Paused by the layout decision; cut for its recommended answer (package at code/src/toy/, tests at code/tests/). Write only under code/. `toy.goallog <changes.jsonl>` reads E5's log. Each line is one held-out scoring of one seed of one candidate, with these fields: candidate (a name; 'start' for the unchanged default run), seed, val_auroc (null for the start), auroc, kept (true, false, or null until keep-if-better judges it), and an optional note. It prints JSON with these keys: heldout_reads, the number of distinct candidates scored on the held-out fifth (the start plus each candidate; the spec allows at most six); heldout_scorings, the number of lines (decision #28 scores each candidate at seeds 1, 2 and 3); candidates, one row per candidate giving its seeds, their aurocs, their mean, val_auroc and kept; and the kept and discarded counts. A malformed line is refused with its line number and exit 1. Fixture: code/tests/fixtures/goallog/changes.jsonl, with a start at three seeds and two candidates. Stdlib only; run Python with -B. Return one Methods passage whose claim sentences each end with a provenance tag.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73.

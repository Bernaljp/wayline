---
id: 31
title: "toy.paired: paired statistics of one sweep point against the oracle ceiling"
kind: code
difficulty: 4
status: parked
blocked_by: [5, 50, 52, 53]
touches: [code/src/toy/paired.py, code/tests/test_paired.py, code/tests/fixtures/paired/]
role: coder
skills: []
acceptance:
  machine: [PYTHONPATH=code/src python3 -B -m unittest discover -s code/tests -p 'test_paired.py', "PYTHONPATH=code/src python3 -B -m toy.paired code/tests/fixtures/paired/point | python3 -c \"import json, sys; d = json.load(sys.stdin); assert d['n_pairs'] >= 3 and {'paired_gain', 'paired_gain_lo', 'paired_gain_hi', 'sd_d', 'signed_rank_p', 'delong_rejections', 'gap_closed', 'mean_auroc_with', 'mean_auroc_without', 'mean_bayes_auroc', 'per_seed'} <= set(d)\""]
  quality: ["Does toy.paired pair the arms only on identical seeds, draws and held-out rows, refuse an incomplete or mismatched pair rather than drop it, and compute every statistic the spec's Methods (Statistics) names exactly as defined there?"]
objectives: [O1, O3, O4]
sections: [methods]
context_pack: [code/src/toy/generate.py:43-56, code/src/toy/train.py:224-243, code/src/toy/stats.py, code/src/toy/oracle.py, research/SPEC.md#seams, research/SPEC.md#methods, research/SPEC.md#e2-claims-c2-c3]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`PYTHONPATH=code/src python3 -m toy.paired code/tests/fixtures/paired/point` prints the paired gain with its 95% t-interval, the signed-rank p, the DeLong rejection count, gap_closed and each arm's and the oracle's mean AUROC, matching the hand-worked answers in the test."
---

## Demo

`PYTHONPATH=code/src python3 -m toy.paired code/tests/fixtures/paired/point` prints the paired gain with its 95% t-interval, the signed-rank p, the DeLong rejection count, gap_closed and each arm's and the oracle's mean AUROC, matching the hand-worked answers in the test.

## Notes

Paused by the layout decision; cut for its recommended answer (package at code/src/toy/, tests at code/tests/). Write only under code/. `toy.paired <point-dir> [--out PATH]` reads <point-dir>/<with|without>/seed<i>/{summary.json, heldout_scores.csv, config.json}, the run-directory layout train.py writes (train.py lines 224-243). The real runs live under results/runs/<E>/<point>/, for example results/runs/E2/m1_n0/. Print one flat JSON object, and write it to --out when given, with these keys: paired_gain, paired_gain_lo, paired_gain_hi, sd_d, signed_rank_p, delong_rejections, gap_closed, gap_closed_lo, gap_closed_hi (all three null, with gap_closed_reason, when the denominator is <= 0.005), mean_auroc_with, mean_auroc_without, mean_bayes_auroc, n_pairs, strength, train_rows, and per_seed (seed, auroc_with, auroc_without, d, bayes, delong_p). Expose point_stats(point_dir), returning that dict, for toy.sweep. Pair only seeds present in both arms whose config.json agree on seed, signal, rows, train_rows and strength, and whose held-out labels are identical. An incomplete or mismatched pair is an error that lists the seeds, never a silent drop (every run is reported). run_auroc is the summary's auroc, checked against the AUROC recomputed from heldout_scores.csv. d_i = auroc_with - auroc_without. Use toy.stats for: the 95% t-interval on n-1 df; the exact two-sided signed-rank p; the per-replicate DeLong test of the two correlated AUROCs (count the replicates with p < 0.05); and the 10,000-resample paired bootstrap of gap_closed (fixed seed). For bayes_i: regenerate the draw with toy.generate.generate(seed, signal, rows, strength) using config.json's values, take the held-out rows the CSV indexes (checking that their labels match), score them with toy.oracle.true_prob at that strength, and take the AUROC. true_prob is the seam's call; latent_mean gives the same ranking if speed matters. gap_closed = mean(d) / mean(bayes - auroc_without). The module must work for 20 to 50 seeds and for held-out sets of up to 16,000 rows. The fixture goes under code/tests/fixtures/paired/point/: at least three seeds with tiny held-out sets drawn by toy.generate, its statistics worked out by hand in the test's comments. Stdlib only; run Python with -B. Return one Methods passage whose every claim sentence ends with a provenance tag ({code:code/src/toy/paired.py#point_stats} and the like).

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Result

### Attempt 1

I wrote no code because this ticket can't pass in the repository as it stands. It was cut for decision 50's recommended answer: move the package to code/src/toy/ and the tests to code/tests/. The owner chose the third option instead. Commit dd64a6a, "owner: no code repository for now (decision 50)", removed code_repository from harness.json, and that option says the project keeps src/ and tests/ and the planner re-cuts T1-T5 with touch sets under src/toy/ and tests/. The worktree has no code/ directory. The package toy.paired needs (toy.stats, toy.generate, toy.oracle, toy.__init__) is at src/toy/, and its tests are in tests/. Both acceptance commands set PYTHONPATH=code/src, and my touch set allows only code/src/toy/paired.py, code/tests/test_paired.py and code/tests/fixtures/paired/. So `import toy` can't find the package's other modules, and unittest discovery can't start in code/tests. Making it pass from here would take one of two hacks: put the project's modules on sys.path from inside paired.py, or copy them under code/, which is outside the touch set and goes against the owner's choice. I ran `wayline accept` to confirm. Both commands fail: 'Start directory is not importable: code/tests' and 'No module named toy'. The working tree is unchanged, so I have nothing to commit. Note also that ticket 50 is still open in the ledger with no answer journaled (journal.jsonl holds only its ticket_created and decision_opened events, lines 387-388), but harness.json on this branch already shows option 3.

Ran: `git log --oneline | head -5; ls -R code; git status`, `git show --stat HEAD HEAD~1 HEAD~2`, `git show HEAD~2  (decision 50 commit: removes code_repository from harness.json)`, `cat research/tickets/31-*.md research/tickets/50-*.md`, `grep decision 50 events in research/journal.jsonl`, `wayline accept  (both acceptance commands FAIL: code/tests not importable; No module named toy)`

Proposed Re-cut tickets 30-34 under the kept layout: touch sets src/toy/<module>.py, tests/test_<module>.py, tests/fixtures/<module>/; acceptance with PYTHONPATH=src and discover -s tests (harness) (admission decides what joins the graph).

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73.

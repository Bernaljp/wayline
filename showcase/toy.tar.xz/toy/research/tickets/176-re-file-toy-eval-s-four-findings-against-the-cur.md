---
id: 176
title: Re-file toy.eval's four findings against the current eval.py and test_eval.py, re-pinning both files in the manifest (R9, R12)
kind: writing
difficulty: 2
status: open
blocked_by: []
touches: []
role: writer
skills: [interval-claims]
inputs: [src/toy/eval.py, tests/test_eval.py, research/findings.jsonl, research/manifest.json]
acceptance:
  machine: []
  quality: ["Do the four findings that replace t95-a1-f1, t95-a1-f2, t117-a1-f1 and t118-a1-f1 state only what src/toy/eval.py and tests/test_eval.py hold now, keep the replaced wording wherever it still holds, and end every sentence with tags of this ticket's own run on those two files whose locators hold every number the sentence writes?"]
objectives: []
sections: [results]
context_pack: [research/findings.jsonl:31-32, research/findings.jsonl:50-51, research/sections/results.md:126-133, research/sections/results.md:209-210, research/manifest.json:1327-1369, research/tickets/153-re-file-toy-eval-s-four-findings-r9-r12-against.md, src/toy/eval.py, tests/test_eval.py]
origin: research/SPEC.md#seams
proposed_by: planner
demo: The general report renders four findings in place of t95-a1-f1, t95-a1-f2, t117-a1-f1 and t118-a1-f1, still under the R9 and R12 headings, each sentence tagged at this ticket's run. Once the ticket is integrated, research/manifest.json holds tests/test_eval.py and src/toy/eval.py at their current sha256 under this run, so the next drawings of R9 and R12 pass `wayline drawing check`'s provenance test.
---

## Demo

The general report renders four findings in place of t95-a1-f1, t95-a1-f2, t117-a1-f1 and t118-a1-f1, still under the R9 and R12 headings, each sentence tagged at this ticket's run. Once the ticket is integrated, research/manifest.json holds tests/test_eval.py and src/toy/eval.py at their current sha256 under this run, so the next drawings of R9 and R12 pass `wayline drawing check`'s provenance test.

## Notes

Why: the manifest still holds tests/test_eval.py at run t95-a1 (3854 bytes) and src/toy/eval.py at run t117-a1. Ticket 118 (commit bd8727c) later added two tests, and ticket 131 (commit b008f0a) added docstrings. So drawing R9 (#142) was blocked on the stale hashes, and R12 cannot be drawn either. This ticket replaces #153. It is a writing ticket, not an analysis ticket, because it returns findings and no Methods passage.

How a re-pin works: suppose a finding's sentence ends with `{res:t<this ticket>-a<this attempt>/<path>#<locator>}` and that names a file on main. When the ticket is integrated, the conductor hashes the file into research/manifest.json under this run, replacing the path's old entry. The manifest keeps one entry per path, and a tag resolves only at the (run, path) it names. So every finding that cites the path at its old run stops resolving. The current findings that cite these two files are exactly the four this ticket replaces: t95-a1-f1, t95-a1-f2 and t118-a1-f1 cite t95-a1/tests/test_eval.py, and t117-a1-f1 cites t117-a1/src/toy/eval.py. Use your own run id, as your prompt gives it, on these two files and on no other manifested path. If you are resumed into a new attempt, change every own-run tag to that attempt's id.

What to return: four findings, each with the following fields.
- `replaces`: the finding it re-files.
- `heading`: as research/findings.jsonl records it. That is "eval.py: --summary PATH and --split val, O2's goal command unchanged" for the three t95/t117 findings, and "Evaluation command" for t118-a1-f1.
- `negative`: false.
- `provenance`: `<path>#<locator>` at the file the finding is about.
- Text that keeps the replaced wording wherever it still holds and corrects whatever no longer holds.

Tags: end every sentence, right after its full stop, with one or more own-run tags. Use a test locator such as `Eval.test_o2_command_reads_wayline_artifact_unchanged`, `Eval.test_val_split_never_falls_back_to_held_out`, `Eval.test_wayline_artifact_run_directory_reads_its_summary_json` or `Eval.test_positional_run_directory_reads_its_summary_json`, a symbol such as `read_metric` or `summary_path`, a constant's name, or a line span `L<a>-L<b>`. The lines a locator names must hold every number its sentence writes, as written: 0.8502984862625299 sits on a line of tests/test_eval.py. Between them, the four findings cite both files.

Say what a test asserts, not that it passed, unless a cited artifact records the run. Edit no file: the manifest takes each file as it is on main. Return no passage. If a finding no longer holds for the current files, re-file it corrected and say in your result what changed.

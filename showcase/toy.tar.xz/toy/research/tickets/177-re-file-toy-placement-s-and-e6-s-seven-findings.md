---
id: 177
title: Re-file toy.placement's and E6's seven findings against the current placement.py and placement_summary.json, re-pinning both and saying K7's bar is not met (R10, R13)
kind: writing
difficulty: 3
status: open
blocked_by: []
touches: []
role: writer
skills: [interval-claims]
inputs: [src/toy/placement.py, analysis/E6/placement_summary.json, analysis/E6/placement.json, tests/test_placement.py, research/findings.jsonl, research/manifest.json]
acceptance:
  machine: []
  quality: ["Do the seven findings that replace t98-a1-f1, t98-a1-f2, t112-a1-f2, t112-a1-f3, t112-a1-f5, t112-a2-f1 and t112-a2-f2 state only what src/toy/placement.py and analysis/E6/placement_summary.json hold now? Do they end every sentence with own-run tags on those files whose leaf keys or lines hold every number written? And do they say plainly that C8 stays unresolved, so C3-C6 are not placed against as many resolved works as K7's success criterion asks?"]
objectives: []
sections: [results]
context_pack: [research/findings.jsonl:33-34, research/findings.jsonl:58-67, research/sections/results.md:137-158, research/manifest.json:1336-1342, research/manifest.json:4621-4627, research/tickets/154-re-file-toy-placement-s-and-e6-s-seven-findings.md, research/tickets/162-scope-down-the-general-report-s-claims-the-kill.md, analysis/E6/placement_summary.json, src/toy/placement.py, research/SPEC.md#e6-claims-c8]
origin: research/SPEC.md#e6-claims-c8
proposed_by: planner
demo: The general report renders seven findings in place of t98-a1-f1, t98-a1-f2, t112-a1-f2, t112-a1-f3, t112-a1-f5, t112-a2-f1 and t112-a2-f2, under the R10 and R13 headings. Each sentence is tagged at this ticket's run, and the C8 finding says C8 is unresolved with resolved_refs 2, so K7's bar is not met. Once integrated, research/manifest.json holds src/toy/placement.py and analysis/E6/placement_summary.json at their current sha256, so the next drawings of R10 and R13 pass their provenance check.
---

## Demo

The general report renders seven findings in place of t98-a1-f1, t98-a1-f2, t112-a1-f2, t112-a1-f3, t112-a1-f5, t112-a2-f1 and t112-a2-f2, under the R10 and R13 headings. Each sentence is tagged at this ticket's run, and the C8 finding says C8 is unresolved with resolved_refs 2, so K7's bar is not met. Once integrated, research/manifest.json holds src/toy/placement.py and analysis/E6/placement_summary.json at their current sha256, so the next drawings of R10 and R13 pass their provenance check.

## Notes

Why: the manifest holds src/toy/placement.py at run t98-a1 and analysis/E6/placement_summary.json at run t112-a1 (329 bytes). Both changed later (commits b008f0a and 742eeaf), and the summary file on main is now about 2.3 KB. So drawing R10 (#143) was blocked and R13 cannot be drawn. The kill argument's point 4 also stands: K7 was closed as answered though C8 is unresolved (resolved_refs 2). This ticket replaces #154 and covers that point for the findings. A concern's status is code's: say what the artifacts show and do not assert K7 met.

How a re-pin works: a sentence ending with `{res:t<this ticket>-a<this attempt>/<path>#<locator>}` that names a file on main makes the conductor hash that file into research/manifest.json under this run at integration, replacing the path's old entry. A tag resolves only at the (run, path) it names, so every older-run tag on the path stops resolving. The current findings that cite these two files are exactly the seven replaced here:
- t98-a1-f1 and t98-a1-f2 cite t98-a1/src/toy/placement.py#place and #check_entry.
- The five t112 findings cite t112-a1/analysis/E6/placement_summary.json.
Put own-run tags on src/toy/placement.py and analysis/E6/placement_summary.json. You may also put them on tests/test_placement.py and analysis/E6/placement.json, which the manifest does not hold. Put them on no other manifested path, and cite a dossier with a `ref:` tag. Use your run id as your prompt gives it, and change every own-run tag if you are resumed into a new attempt.

What to return: seven findings, each with `replaces`, the replaced finding's `heading` as research/findings.jsonl records it, and `negative` as recorded (t112-a1-f3 and t112-a1-f5 are true, the rest false). Give each a `provenance` at the file it is about, and text that keeps the replaced wording wherever it still holds.

Tags: end every sentence, right after its full stop, with tags whose locators hold every number it writes, as written. A JSON locator is a dotted path to a leaf key, such as `resolved_refs`, `prior_measures_gain`, `c8_verdict`, `mismatches` or `unsettled`. For a list entry, use its index, as in `entries.0.reason`. Do not cite a whole object. The level-2-but-abstract-only facts for Friedman 2008 and Bien 2013, and Lou 2013's level 0, are in each entry's `reason`.

In the C8 finding (replacing t112-a1-f5), say that C8 is unresolved under SPEC E6's rule with resolved_refs 2. Say also that C3-C6 are therefore not placed against the number of resolved works K7's success criterion asks for. Write the spec's threshold as a number only if a cited key holds it, or else name the rule in words.

Edit no file. Return no passage.

---
id: 154
title: Re-file toy.placement's and E6's seven findings (R10, R13) against the current placement.py and placement_summary.json, so the manifest takes their current hashes
kind: analysis
difficulty: 2
status: parked
blocked_by: []
touches: [analysis/refile/placement.json]
role: analyst
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 2, wallclock_minutes: 15}
inputs: [src/toy/placement.py, analysis/E6/placement_summary.json, analysis/E6/placement.json, research/findings.jsonl, research/refs/]
outputs: [analysis/refile/placement.json]
acceptance:
  machine: ["python3 -c \"import hashlib, json, re; d = json.load(open('analysis/refile/placement.json')); fs = {f['path']: f['sha256'] for f in d['files']}; need = {'src/toy/placement.py', 'analysis/E6/placement_summary.json'}; assert need <= set(fs) and all(hashlib.sha256(open(p, 'rb').read()).hexdigest() == h for p, h in fs.items()); fd = d['findings']; assert sorted(f['replaces'] for f in fd) == ['t112-a1-f2', 't112-a1-f3', 't112-a1-f5', 't112-a2-f1', 't112-a2-f2', 't98-a1-f1', 't98-a1-f2']; tags = [re.findall(r'\\{res:(t[0-9]+-a[0-9]+)/([^#{}]+)#[^{}]+\\}', f['text']) for f in fd]; runs = {r for t in tags for r, p in t}; cited = {p for t in tags for r, p in t}; assert all(tags) and len(runs) == 1 and not runs & {'t98-a1', 't112-a1', 't112-a2'} and need <= cited <= set(fs); assert all(f['provenance'].partition('#')[0] in fs for f in fd); n = {f['replaces']: f['negative'] for f in fd}; assert n['t112-a1-f3'] is True and n['t112-a1-f5'] is True and n['t98-a1-f1'] is False and n['t112-a2-f1'] is False\"", "ids=$(python3 -c \"import json; d = json.load(open('analysis/refile/placement.json')); t = {f['replaces']: set(f.get('tests') or []) for f in d['findings']}; assert 'tests.test_placement.Unsettled.test_null_on_verified_work_counts_toward_neither_number' in t['t98-a1-f1'] and 'tests.test_placement.MissingDossier' in t['t98-a1-f2']; print(' '.join(sorted(set().union(*t.values()))))\") && test -n \"$ids\" && PYTHONPATH=src python3 -B -m unittest $ids && PYTHONPATH=src python3 -B -c \"import json, os; from toy.placement import place; s = json.load(open('analysis/E6/placement_summary.json')); r = place('analysis/E6/placement.json', os.path.join(os.environ.get('WAYLINE_PROJECT') or '.', 'research', 'refs')); assert all(r[k] == s[k] for k in ('resolved_refs', 'prior_measures_gain', 'mismatches', 'unsettled'))\""]
  quality: ["Does each re-filed finding state only what src/toy/placement.py, analysis/E6/placement_summary.json and the five D6 dossiers show as they are now? C8 should stay unresolved with resolved_refs as stored, t112-a1-f3 and t112-a1-f5 should stay negative, and each number should sit at a locator one of its sentence's own-run res tags names."]
objectives: []
sections: [methods, results]
context_pack: [research/findings.jsonl:33-34, research/findings.jsonl:59-65, research/manifest.json:1336-1342, research/manifest.json:4621-4627, research/tickets/143-draw-r10-toy-placement-resolved-refs-and-prior-m.md#result, research/tickets/146-draw-r13-e6-literature-placement-of-c3-c6-c8.md, analysis/E6/placement_summary.json, analysis/E6/place.py, src/toy/placement.py, tests/test_placement.py]
origin: research/SPEC.md#e6-claims-c8
proposed_by: planner
demo: analysis/refile/placement.json lists src/toy/placement.py and analysis/E6/placement_summary.json at the sha256 they have now, beside the stale hashes the manifest holds for runs t98-a1 and t112-a1. It records seven findings that replace t98-a1-f1, t98-a1-f2, t112-a1-f2, t112-a1-f3, t112-a1-f5, t112-a2-f1 and t112-a2-f2, each ending with res tags of this ticket's own run. toy.placement, recomputed read-only, gives the stored resolved_refs, prior_measures_gain, mismatches and unsettled. Once the ticket is integrated, the manifest holds both files at their current hashes, so drawings of R10 and R13 can pass their provenance check.
---

## Demo

analysis/refile/placement.json lists src/toy/placement.py and analysis/E6/placement_summary.json at the sha256 they have now, beside the stale hashes the manifest holds for runs t98-a1 and t112-a1. It records seven findings that replace t98-a1-f1, t98-a1-f2, t112-a1-f2, t112-a1-f3, t112-a1-f5, t112-a2-f1 and t112-a2-f2, each ending with res tags of this ticket's own run. toy.placement, recomputed read-only, gives the stored resolved_refs, prior_measures_gain, mismatches and unsettled. Once the ticket is integrated, the manifest holds both files at their current hashes, so drawings of R10 and R13 can pass their provenance check.

## Notes

Why this ticket exists: drawing R10 (#143) was blocked because research/manifest.json holds src/toy/placement.py at run t98-a1's hash and analysis/E6/placement_summary.json at run t112-a1's 329-byte version. Ticket 131 (commit b008f0a) later added docstrings to placement.py, and ticket 112's second attempt (commit 742eeaf) rewrote the summary with per-entry rows. Neither re-registered its file, because a finding whose provenance names a path the manifest already holds is filed without re-hashing it. Drawing R13 (#146) reads the same summary. No worker may write research/. A file is re-registered by a finding whose text carries a res tag of the worker's own run naming it: at integration the conductor hashes the file on main into the manifest under that run.

1. Read R10's two current findings (research/findings.jsonl lines 33-34) against src/toy/placement.py as it is now, and run the tests that back them.
2. Read R13's five current findings (lines 59, 60, 62, 64 and 65) against analysis/E6/placement_summary.json and the five dossiers under research/refs/. State each dossier's level as its dossier.json gives it now. Do not run analysis/E6/place.py: it rewrites analysis/E6/placement_summary.json, which is outside your touch set, and records the worktree's refs path. Recompute read-only with toy.placement.place('analysis/E6/placement.json', <project root>/research/refs), the project root being $WAYLINE_PROJECT. If resolved_refs, prior_measures_gain, mismatches or unsettled differ from the stored file, return blocked naming the keys, since the summary itself would then be stale.
3. Return seven findings. Give each one:
   - `replaces` set to the finding it re-files.
   - That finding's heading: "toy.placement: resolved_refs and prior_measures_gain, tolerating unscouted works and unsettled entries" for t98-a1-f1 and f2, and "E6: literature placement of C3-C6 (C8)" for the five t112 findings.
   - That finding's negative flag: t112-a1-f3 and t112-a1-f5 are negative, the rest are not.
   - A provenance `<path>#<locator>`.
   - Text that keeps the replaced wording wherever it still holds.
   End every sentence with tags `{res:t<this ticket's id>-a<this attempt's number>/<path>#<locator>}`, using your own run id as your prompt gives it, never t98-a1, t112-a1 or t112-a2. Change them if you are resumed into a new attempt. Use JSON keys of placement_summary.json (resolved_refs, prior_measures_gain, mismatches, unsettled, c8_verdict), symbols of placement.py (place, check_entry), or line spans, so that every number a sentence writes sits at a locator it names. The 4 that C8 needs and the years in the works' names are spec parameters. Between them, the seven findings cite both files.
4. Write analysis/refile/placement.json with two keys. `files` is a list of {path, sha256 (the file as it is now), manifest_run, manifest_sha256}. `findings` is a list of {replaces, heading, negative, provenance, text, tests}. tests are the unittest ids that back a t98 finding, e.g. tests.test_placement.Unsettled.test_null_on_verified_work_counts_toward_neither_number and tests.test_placement.MissingDossier, and are empty for the t112 findings, which the recomputation backs. Any further file you cite with an own-run tag joins `files`. Each text is exactly what you return.

Return no passage.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 176, 177, 178, 179, 180, 181, 182, 183, 184, 185.

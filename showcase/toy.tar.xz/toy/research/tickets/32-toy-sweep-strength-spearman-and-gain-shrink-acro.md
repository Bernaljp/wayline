---
id: 32
title: "toy.sweep: strength_spearman and gain_shrink across sweep points"
kind: code
difficulty: 3
status: parked
blocked_by: [31, 50]
touches: [code/src/toy/sweep.py, code/tests/test_sweep.py, code/tests/fixtures/sweep/]
role: coder
skills: []
acceptance:
  machine: [PYTHONPATH=code/src python3 -B -m unittest discover -s code/tests -p 'test_sweep.py', "PYTHONPATH=code/src python3 -B -m toy.sweep code/tests/fixtures/sweep/E3 --axis strength | python3 -c \"import json, sys; d = json.load(sys.stdin); assert 'strength_spearman' in d and d['points'] and all('strength' in p and 'paired_gain_lo' in p for p in d['points'])\"", "PYTHONPATH=code/src python3 -B -m toy.sweep code/tests/fixtures/sweep/rows --axis rows --strength 1 | python3 -c \"import json, sys; d = json.load(sys.stdin); assert {'gain_shrink', 'gain_shrink_lo', 'gain_shrink_hi'} <= set(d) and len(d['points']) >= 2\""]
  quality: ["Do strength_spearman and gain_shrink use exactly the points and the common seeds the spec names, read each point's strength and size from its runs' config.json, and take reused points from the directories given rather than re-running them?"]
objectives: [O4]
sections: [methods]
context_pack: [code/src/toy/paired.py, research/SPEC.md#e3-claims-c4-c5, research/SPEC.md#e4-claims-c6, research/SPEC.md#seams]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`PYTHONPATH=code/src python3 -m toy.sweep code/tests/fixtures/sweep/E3 --axis strength` prints a per-point table and strength_spearman; `--axis rows --strength 1` on code/tests/fixtures/sweep/rows prints gain_shrink with its interval."
---

## Demo

`PYTHONPATH=code/src python3 -m toy.sweep code/tests/fixtures/sweep/E3 --axis strength` prints a per-point table and strength_spearman; `--axis rows --strength 1` on code/tests/fixtures/sweep/rows prints gain_shrink with its interval.

## Notes

Paused by the layout decision; cut for its recommended answer (package at code/src/toy/, tests at code/tests/). Write only under code/. `toy.sweep <exp-dir> --axis strength|rows [--strength m] [--point DIR ...] [--out PATH]`. A point is a directory holding with/ and without/. Every such directory directly under <exp-dir> is a point. Each --point adds a point from another experiment: E3 reuses E2's results/runs/E2/m1_n0, and E4 reuses E2's m1_n0 at m = 1 and E3's m0_n0 at m = 0. Read each point's strength and train_rows from its runs' config.json, never from its name (names like m1_n0 carry no number). Each entry of the output's points list is a flat dict: dir, strength, train_rows, and every key of toy.paired.point_stats. --axis strength: the points must share one training size (an error if they differ); sort them by strength and add strength_spearman, the Spearman correlation (average ranks, toy.stats) between strength and paired_gain. --axis rows --strength m: take only the points at strength m and sort them by train_rows. Add gain_shrink = the mean, over the seeds the smallest and largest points share, of (d_i at the smallest size - d_i at the largest size), with its paired 95% t-interval as gain_shrink_lo and gain_shrink_hi. It is an error when those two points share no seed. Fixtures: code/tests/fixtures/sweep/E3/ (an E3-like directory of at least three strength points) and code/tests/fixtures/sweep/rows/ (at least two sizes at strength 1), with the answers worked out by hand. Stdlib only; run Python with -B. Return one Methods passage whose claim sentences each end with a provenance tag.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73.

---
id: 79
title: "toy.placement: resolved_refs and prior_measures_gain, tolerating unscouted works and unsettled entries"
kind: code
difficulty: 2
status: parked
blocked_by: []
touches: [src/toy/placement.py, tests/test_placement.py, tests/fixtures/placement/]
role: coder
skills: []
acceptance:
  machine: [PYTHONPATH=src python3 -B -m unittest tests.test_placement, "PYTHONPATH=src python3 -B -m toy.placement tests/fixtures/placement/placement.json --refs tests/fixtures/placement/refs | python3 -c \"import json, sys; d = json.load(sys.stdin); assert {'resolved_refs', 'prior_measures_gain', 'entries', 'mismatches', 'unsettled'} <= set(d) and d['mismatches'] == []\"", "d=$(mktemp -d) && mkdir -p \"$d/refs\" && printf '[{\"slug\": \"unscouted\", \"doi\": \"10.1/x\", \"existence\": \"missing\", \"measures_paired_gain\": null, \"locator\": null}]\\n' > \"$d/p.json\" && PYTHONPATH=src python3 -B -m toy.placement \"$d/p.json\" --refs \"$d/refs\" > \"$d/out.json\" && python3 -c \"import json, sys; d = json.load(open(sys.argv[1])); assert d['resolved_refs'] == 0 and d['prior_measures_gain'] == 0 and d['mismatches'] == [] and d['unsettled'] == ['unscouted']\" \"$d/out.json\""]
  quality: []
objectives: [O1]
sections: [methods]
context_pack: [research/refs/paper-a/dossier.json, research/refs/delong-1988-comparing-areas-under-two-more/dossier.json, research/SPEC.md#e6-claims-c8, research/SPEC.md#seams]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`PYTHONPATH=src python3 -m toy.placement tests/fixtures/placement/placement.json --refs tests/fixtures/placement/refs` prints resolved_refs, prior_measures_gain and unsettled. An entry for an unscouted work with existence 'missing' and measures_paired_gain null exits 0 and counts as unresolved, and the tests show that an entry whose existence disagrees with its dossier exits 1."
---

## Demo

`PYTHONPATH=src python3 -m toy.placement tests/fixtures/placement/placement.json --refs tests/fixtures/placement/refs` prints resolved_refs, prior_measures_gain and unsettled. An entry for an unscouted work with existence 'missing' and measures_paired_gain null exits 0 and counts as unresolved, and the tests show that an entry whose existence disagrees with its dossier exits 1.

## Notes

Re-cut of ticket 58. Its code passed both of its criteria (9 tests OK) and is committed on branch ticket/58. It failed only on its returned passages: the first time it returned no Methods passage, and the second time it carried the untagged sentence 'It uses the Python standard library alone.'. Start from it: `git checkout ticket/58 -- src/toy/placement.py tests/test_placement.py tests/fixtures/placement`. Then fix the two places where it departs from what E6 needs. (a) load_entries refuses measures_paired_gain null. Accept true, false or null, where null means the dossier cannot settle it. A null entry counts toward neither number, and its slug is listed under a new key, unsettled: the slugs of every entry whose measures_paired_gain is null, in input order. (b) check_entry reports every entry without a dossier as a mismatch. One unscouted D6 work would then make E6's analysis command exit 1, when the spec says it should report C8 unresolved (SPEC E6: resolved_refs < 4). An entry whose existence is 'missing' and whose dossier is absent agrees, and counts as unresolved. An entry naming 'verified' or 'unresolved' with no dossier, or 'missing' when a dossier exists, is a mismatch and exits 1. Change test_missing_dossier_exits_1 to match, and add tests for both rules. Keep the rest: resolved means the dossier's existence is 'verified' (the scout's only other value is 'unresolved'), plus the DOI cross-check and exit 2 on malformed input. The fixture placement.json must stay free of mismatches, because the acceptance runs it. `toy.placement <placement.json> [--refs research/refs]`; stdlib only; run Python as python3 -B. Result rules the harness checks (tickets 41, 52, 53, 58 and 65 failed on them): return one Methods passage; end every sentence of it with a provenance tag that resolves, such as {code:src/toy/placement.py#place}, and leave out any sentence you cannot tag; a finding that states a number cites a locator holding that literal number (ticket 58's first finding cited paper-a's dossier for counts and years it did not hold), and a code locator is matched as a literal substring; a passage or finding that says what a current one says names it in `replaces`; leave a passage's evidence unset unless it replaces an inherited claim. If a Bash command you need (python3, wayline accept, git) is refused, stop at once and return blocked naming it.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113.

---
id: 142
title: "Draw R9: eval.py: --summary PATH and --split val, O2's goal command unchanged"
kind: drawing
difficulty: 2
status: parked
blocked_by: []
touches: [drawings/R9-1/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O1, O2]
context_pack: []
origin: drawing R9-1 at run_end
proposed_by: conductor
demo: R9 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R9-1

Code opened this drawing of R9 ("eval.py: --summary PATH and --split val, O2's goal command unchanged") at a rest point (run_end), over its findings t95-a1-f1, t95-a1-f2, t117-a1-f1. Its brief, rendered by code at each launch, is in the prompt.

## Result

### Attempt 1

I fixed two of the three failures, but one is outside my touch set. Fixed: (1) draw.py no longer reads owner/sample-summary.json or owner/measure.json, which the clean room does not hold. The owner sample's AUROC now comes from the test file's SAMPLE_AUROC constant, and the 0.82 target is no longer quoted. (2) The finding now quotes only the count at the key it cites, and every sentence of the methods passage ends with a provenance tag. Not fixed: the drawing check's provenance test fails because research/manifest.json holds stale hashes for both inputs. tests/test_eval.py was recorded under run t95-a1 (manifest sha ac8a0df8...), and commit bd8727c later added two run-directory tests to it (current sha e1cc54a3...). src/toy/eval.py was recorded under t117-a1 (manifest sha 57abee1c...), and ticket 131's commit b008f0a later added docstrings (current sha 813c5025...). Only the manifest can be changed to fix this, and it is in research/, which I may not edit. The drawing reads the current files, and the 14 tests it tabulates include the ones that back finding t117-a1-f1. The rerun was done by `wayline tools run`, not in the clean room; `wayline accept` passes but runs no machine acceptance on this ticket.

Wrote: `drawings/R9-1/draw.py`, `drawings/R9-1/contract.csv`, `drawings/R9-1/numbers.json`, `drawings/R9-1/drawing.json`

Ran: `wayline tools run matplotlib -- drawings/R9-1/draw.py`, `wayline accept`, `git add drawings/R9-1 && git commit`

Passages:

- methods, Checking the evaluation command: To tabulate the contract of toy.eval, the drawing script parses the text of tests/test_eval.py with Python's ast module, without importing or running it [res:drawings/R9-1/numbers.json]. For each test method it reads the split and the summary source from the arguments and environment of the run(...) call, the summary's keys from the self.write(...) calls, and the expected output or error from the assertEqual and assertIn calls [res:drawings/R9-1/numbers.json]. It counts as reading the owner sample every test whose expected output is the test file's SAMPLE_AUROC constant, and reports how many tests print a metric, how many expect a refusal, and how many pass a run directory [res:drawings/R9-1/numbers.json].

Proposed Re-record tests/test_eval.py and src/toy/eval.py in the manifest at their current hashes (harness) (admission decides what joins the graph).

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 153, 154, 155, 156.

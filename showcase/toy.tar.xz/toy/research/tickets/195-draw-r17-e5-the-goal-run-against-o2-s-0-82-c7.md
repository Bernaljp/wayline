---
id: 195
title: "Draw R17: E5: the goal run against O2's 0.82 (C7)"
kind: drawing
difficulty: 2
status: open
blocked_by: []
touches: [drawings/R17-3/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O2]
context_pack: []
origin: drawing R17-3 at order
proposed_by: conductor
demo: R17 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R17-3

Code opened this drawing of R17 ("E5: the goal run against O2's 0.82 (C7)") at a rest point (order), over its findings t111-a1-f1, t111-a1-f2, t111-a1-f3, t111-a1-f4, t111-a1-f5, t111-a1-f6, t111-a1-f7, t111-a1-f9. Its brief, rendered by code at each launch, is in the prompt.

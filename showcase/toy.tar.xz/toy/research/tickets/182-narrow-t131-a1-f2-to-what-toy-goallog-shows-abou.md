---
id: 182
title: Narrow t131-a1-f2 to what toy.goallog shows about the kept field, every sentence tagged (R18)
kind: writing
difficulty: 2
status: open
blocked_by: []
touches: []
role: writer
skills: [interval-claims]
inputs: [src/toy/goallog.py, tests/test_goallog.py, research/findings.jsonl]
acceptance:
  machine: []
  quality: ["Does the finding that replaces t131-a1-f2 claim only what src/toy/goallog.py and tests/test_goallog.py show (no claim about the rest of src/toy), with the kept values tagged at parse_line or the module docstring and every sentence, the first included, ending with a tag?"]
objectives: []
sections: [results]
context_pack: [research/findings.jsonl:175, research/sections/results.md:433-437, research/manifest.json:19840-19846, research/tickets/161-scope-down-a-report-claim-its-artifacts-do-not-s.md, src/toy/goallog.py, tests/test_goallog.py]
origin: research/REPORT.md#claim-8adb99d6b84363c9
proposed_by: planner
demo: The general report renders one finding in place of t131-a1-f2 that says what toy.goallog does with each candidate's kept field, with every sentence tagged. The report header no longer lists t131-a1-f2 as a failed claim, and R18's headline carries a tag.
---

## Demo

The general report renders one finding in place of t131-a1-f2 that says what toy.goallog does with each candidate's kept field, with every sentence tagged. The report header no longer lists t131-a1-f2 as a failed claim, and R18's headline carries a tag.

## Notes

Why: the sampled verdict failed t131-a1-f2. Its first sentence, "No module in src/toy implements a keep rule", covers all 13 modules, but its only tag points at goallog.summarise. The parenthetical "(true, false, or null)" is enforced in parse_line (lines 69-70) and stated in the module docstring (lines 10-11), not in summarise. The first sentence also carries no tag, which is why R18's headline renders untagged (the kill argument's point 9). This ticket replaces #161.

Narrow the finding to toy.goallog:
- parse_line takes kept as true, false or null and refuses anything else.
- summarise takes kept from a candidate's first line, refuses a line whose kept differs, and counts kept (true) and discarded (false) candidates.
So toy.goallog records keep decisions and makes none. Drop the package-wide sentence and "Whatever decides keep-if-better lives outside the package", unless a cited artifact covers the whole package. No current one does.

Tag every sentence, right after its full stop. src/toy/goallog.py is manifested at t131-a1 with its current hash. t131-a1-f2 is the only current finding citing it there, so own-run tags `{res:t<this ticket>-a<this attempt>/src/toy/goallog.py#<locator>}` are safe. tests/test_goallog.py is not manifested and may take own-run tags too. Tag no other manifested path with your run id.

Return one finding with `replaces` t131-a1-f2, its `heading` as research/findings.jsonl records it, and a `provenance` such as src/toy/goallog.py#summarise. Set `negative` by this rule: a finding is negative when it reports that something the work tested did not hold or was not found (a claim unsupported, an anti-claim confirmed, a change discarded, a defect found, a question left unresolved). A finding that describes what code does is not. Edit no file. Return no passage.

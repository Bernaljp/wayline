---
id: 167
title: "Draw R6: Oracle audit cost on the 10^6-row draw D2"
kind: drawing
difficulty: 2
status: parked
blocked_by: []
touches: [drawings/R6-2/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O3]
context_pack: []
origin: drawing R6-2 at order
proposed_by: conductor
demo: R6 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R6-2

Code opened this drawing of R6 ("Oracle audit cost on the 10^6-row draw D2") at a rest point (order), over its findings t53-a1-f1. Its brief, rendered by code at each launch, is in the prompt.

## Result

### Attempt 1

I drew nothing for R6: its only input can't pass the provenance check. R6's one finding (t53-a1-f1) cites tests/test_oracle_budget.py. The file on disk now hashes to sha256 a6204639…, but the manifest holds dea33416… for run t53-a1. The first drawing attempt, R6-1 (ticket 139), failed on exactly this ('tests/test_oracle_budget.py no longer has the hash the manifest holds for run t53-a1'). The file also holds only limits (3600 s, 4.0 GB) and no measured values, so even a passing draw would show two constants and no data view worth plotting. The measured run (19.5 s, 0.68 GB in research/sessions/53/1/acceptance.json) is not a manifest artifact, and the brief says missing data is not to be worked around. Ticket 160 is already narrowing the finding: the current test runs seed 20001, not D2's seed 10001. Open decision 152 and ticket 156 already cover the hash mismatch. I wrote nothing to drawings/R6-2/, so there was nothing to commit; wayline accept passed because the ticket has no machine acceptance.

Ran: `git status --short`, `sha256sum tests/test_oracle_budget.py`, `wayline accept`

Proposed Register the oracle audit's measured cost (seconds, peak memory, rows, seed) as an artifact (code) (admission decides what joins the graph).

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 176, 177, 178, 179, 180, 181, 182, 183, 184, 185.

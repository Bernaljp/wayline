---
id: 38
title: "E1 experiment: oracle audit of the default generator on the 10^6-row draw D2"
kind: experiment
difficulty: 2
status: parked
blocked_by: [52, 53]
touches: [experiments/E1/, results/E1/, results/smoke/E1/]
role: experimenter
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 8, wallclock_minutes: 120}
inputs: [src/toy/oracle.py, src/toy/generate.py]
outputs: [results/E1/oracle.json]
acceptance:
  machine: ["python3 -c \"import json; t = open('experiments/E1/jobs.json').read(); json.loads(t); assert 'toy.oracle' in t and '10001' in t and '1000000' in t and 'results/E1/oracle.json' in t\""]
  quality: ["Does the job run toy.oracle once on D2 (seed 10001, 10^6 rows, default signal and strength, CPU only) and write results/E1/oracle.json and nothing else?"]
objectives: [O3]
sections: [methods]
context_pack: [research/SPEC.md#e1-claims-c1-c2, research/SPEC.md#data, src/toy/oracle.py, experiments/E2/jobs.json]
origin: research/SPEC.md#e1-claims-c1-c2
proposed_by: planner
demo: "`wayline status` shows the E1 job running `toy.oracle --seed 10001 --rows 1000000` on one core; when it exits, results/E1/oracle.json holds the Bayes AUROC, its half-width, the calibration error, the weight on x3*x4 with its line, and the additive gap."
---

## Demo

`wayline status` shows the E1 job running `toy.oracle --seed 10001 --rows 1000000` on one core; when it exits, results/E1/oracle.json holds the Bayes AUROC, its half-width, the calibration error, the weight on x3*x4 with its line, and the additive gap.

## Notes

Write experiments/E1/jobs.json in the same job-file form as experiments/E2/jobs.json: one job whose command runs `PYTHONPATH=src python3 -B -m toy.oracle --seed 10001 --rows 1000000 --out results/E1/oracle.json`, with no GPU and expected_outputs ["results/E1/oracle.json"]. If the job form needs the environment set in a script, run it through a small experiments/E1/run.sh. If src/ no longer exists because the layout decision moved the package without symlinks, use PYTHONPATH=code/src. toy.oracle is stdlib only, so the system python3 runs it. Smoke-test the same command at --rows 2000 into results/smoke/E1/ and commit nothing under results/. Then run `wayline job add experiments/E1/jobs.json` and return running. Seed 10001 lies outside every replicate's seeds, so no model of E2-E5 sees D2. Nothing is repeated, since the draw's size gives the precision. Return one Methods passage describing the audit, each claim sentence ending with a provenance tag ({code:src/toy/oracle.py#audit} and the like); ticket 16 failed acceptance for returning none.

## Result

### Attempt 1

I wrote experiments/E1/jobs.json but could not finish the ticket. Bash permission was denied for the smoke test (`python3 -m toy.oracle --rows 2000`), and I did not try to work around the denial. After my first two `ls` calls, every Bash command that ran anything was refused ("don't ask mode"). So I have not run the smoke test, `wayline accept`, `git add`/`git commit` or `wayline job add`, and no job exists. The spec is not committed, so the conductor would lose it. It is a single job that runs `/usr/bin/env PYTHONPATH=src /usr/bin/python3 -B -m toy.oracle --seed 10001 --rows 1000000 --out results/E1/oracle.json`, with expected_outputs ["results/E1/oracle.json"]. To finish, Bash needs to be allowed for python3, wayline and git. Then run the smoke test at --rows 2000 into results/smoke/E1/, run `wayline accept`, commit experiments/E1/jobs.json on ticket/38, and run `wayline job add experiments/E1/jobs.json`.

Wrote: `experiments/E1/jobs.json`

Ran: `ls src/toy; ls experiments/E2`

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73.

---
id: 10
title: "toy.goallog: held-out reads of the goal loop from results/E5/changes.jsonl"
kind: code
difficulty: 1
status: parked
blocked_by: []
touches: [src/toy/goallog.py, tests/test_goallog.py, tests/fixtures/goallog/]
role: coder
skills: []
acceptance:
  machine: [PYTHONPATH=src python3 -B -m unittest tests.test_goallog, "PYTHONPATH=src python3 -B -m toy.goallog tests/fixtures/goallog/changes.jsonl | python3 -c \"import json, sys; assert 'heldout_reads' in json.load(sys.stdin)\""]
  quality: []
objectives: [O2]
sections: [methods]
context_pack: [research/SPEC.md#e5-claims-c7, research/SPEC.md#seams]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`python3 -m toy.goallog tests/fixtures/goallog/changes.jsonl` prints heldout_reads and the per-candidate table."
---

## Demo

`python3 -m toy.goallog tests/fixtures/goallog/changes.jsonl` prints heldout_reads and the per-candidate table.

## Notes

`toy.goallog <changes.jsonl>` reads E5's log, one JSON line per held-out scoring of one seed of one candidate: candidate (a name; 'start' for the unchanged default run), seed, val_auroc (null for the start), auroc, kept (true, false, or null until keep-if-better judges it) and an optional note. Print JSON with heldout_reads (the number of distinct candidates scored on the held-out fifth: the start plus each candidate; the spec allows at most six), per-candidate rows, and kept and discarded counts. Refuse a malformed line with its line number. Fixture tests/fixtures/goallog/changes.jsonl. Stdlib only; run Python with -B.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49.

---
id: 124
title: Admit the parked proposal c3a0b19879a6?
kind: decision
difficulty: 1
status: open
blocked_by: []
blocking: null
human_only: true
touches: []
role: decider
skills: []
acceptance: {}
context_pack: []
origin: proposal c3a0b19879a6
proposed_by: decider
demo: "The owner answers: Is the parked proposal c3a0b19879a6, \"E5: set the goal run's auroc beside E2's 20-seed mean inside E5's result (A7)\", admitted to the run?"
---

## Decision

Is the parked proposal c3a0b19879a6, "E5: set the goal run's auroc beside E2's 20-seed mean inside E5's result (A7)", admitted to the run?

- options:
  - admit
  - keep parked
- recommended: keep parked
- evidence:
  - parked because: cap
  - kind: analysis
  - proposed_by: verifier
  - origin: ticket 111's quality verdict: proposal 1
  - touches: ["analysis/E5/"]
  - the proposal as parked: research/proposals/c3a0b19879a6.json
  - the decider was refused it: its answer falls in a class on the irreversible list (goal): keep parked
- blocking: null, so no ticket waits on it
- human-only: yes, only the owner answers it
- asked by: proposal c3a0b19879a6

<!-- wayline:decision {"ticket":124,"question":"Is the parked proposal c3a0b19879a6, \"E5: set the goal run's auroc beside E2's 20-seed mean inside E5's result (A7)\", admitted to the run?","options":["admit","keep parked"],"recommended":"keep parked","evidence":["parked because: cap","kind: analysis","proposed_by: verifier","origin: ticket 111's quality verdict: proposal 1","touches: [\"analysis/E5/\"]","the proposal as parked: research/proposals/c3a0b19879a6.json","the decider was refused it: its answer falls in a class on the irreversible list (goal): keep parked"],"human_only":true,"reversible":true,"answer":null,"rationale":null,"confidence":null,"decided_by":null,"timestamp":null,"blocking":null} -->

## How to answer

`wayline answer 124 "<answer>"`, from the command line or from a session; the answer form in the dashboard's decisions view; or the answer written under an `## Answer` heading at the end of this file. Each is journaled as the owner's decision, and the conductor closes this ticket at its next wave.

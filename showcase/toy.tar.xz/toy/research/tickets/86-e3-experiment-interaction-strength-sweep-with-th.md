---
id: 86
title: "E3 experiment: interaction-strength sweep with the zero-strength null control"
kind: experiment
difficulty: 2
status: parked
blocked_by: [65]
touches: [experiments/E3/, results/runs/E3/, results/smoke/E3/]
role: experimenter
skills: []
resources: {cpu: 2, gpu: 1, ram_gb: 8, wallclock_minutes: 30}
inputs: [configs/arms.json, src/toy/train.py, src/toy/generate.py, experiments/E2/point.sh]
outputs: [results/runs/E3/m0_n0/without/seed20/heldout_scores.csv, results/runs/E3/m0.25_n0/without/seed20/heldout_scores.csv, results/runs/E3/m0.5_n0/without/seed20/heldout_scores.csv, results/runs/E3/m2_n0/without/seed20/heldout_scores.csv, results/runs/E3/m4_n0/without/seed20/heldout_scores.csv]
acceptance:
  machine: ["python3 -c \"import json; t = open('experiments/E3/jobs.json').read(); json.loads(t); assert all(('results/runs/E3/m%s_n0/%s/seed%d/heldout_scores.csv' % (m, a, i)) in t for m in ('0', '0.25', '0.5', '2', '4') for a in ('with', 'without') for i in range(1, 21)) and 'results/runs/E3/m1_n0/' not in t\"", "grep -rq -- '--strength' experiments/E3/ && { grep -rq 'configs/arms.json' experiments/E3/ || grep -q 'experiments/E2/point.sh' experiments/E3/jobs.json; }"]
  quality: ["Do the jobs run exactly the strengths 0, 0.25, 0.5, 2 and 4 at the default size, seeds 1-20, both arms, with configs/arms.json and nothing tuned, leaving m = 1 to E2's runs and the default draw unchanged?"]
objectives: [O4]
sections: [methods]
context_pack: [configs/arms.json, experiments/E2/point.sh, experiments/E2/jobs.json:1-10, research/SPEC.md#e3-claims-c4-c5, research/SPEC.md#methods]
origin: research/SPEC.md#e3-claims-c4-c5
proposed_by: planner
demo: "`wayline status` shows five E3 jobs, one per strength 0, 0.25, 0.5, 2 and 4, each running 40 paired runs into results/runs/E3/m<m>_n0/."
retry:
  host_oom: []
  gpu_oom: [--batch-size=64, --batch-size=16]
---

## Demo

`wayline status` shows five E3 jobs, one per strength 0, 0.25, 0.5, 2 and 4, each running 40 paired runs into results/runs/E3/m<m>_n0/.

## Notes

Re-cut of ticket 66, which never launched. It waits on the E2 gate #65 (reproduction and convergence). If the gate fails, a decision revisits Q14 before this runs. experiments/E2/point.sh already takes <out-root> <first-seed> <last-seed> [extra train.py flags] and runs both arms with --config configs/arms.json and --save-scores. Call it from experiments/E3/jobs.json, or write experiments/E3/point.sh if you need something it lacks. Give jobs.json one member per strength m in {0, 0.25, 0.5, 2, 4}. Each member runs seeds 1-20 in both arms with the extra flags `--strength m` and the out-root results/runs/E3/m<m>_n0 (m0_n0, m0.25_n0, m0.5_n0, m2_n0, m4_n0). m = 1 is E2's results/runs/E2/m1_n0 and is not re-run. Each member's expected_outputs lists every run's summary.json, heldout_scores.csv and config.json literally, as E2's does. The retry ladder's --batch-size passes through to train.py. The multiplier scales generate.py's nonzero weight of 1.1 on x3*x4 (INTERACTION_WEIGHT; finding t6-a1-f2 gives 4.4 at signal 4), so A1's absolute-weight switch does not apply and this ticket does not wait on E1. Finding t2-a3-f2: the features and the random stream do not depend on strength, so sweep points share common random numbers. Nothing is tuned and no seed is dropped. Smoke-test one seed at m = 0 on the CPU into results/smoke/E3/, and commit nothing under results/. Return one Methods passage, every sentence ending with a provenance tag that resolves, and leave out any sentence you cannot tag. File no finding that states a number. If a Bash command you need (python3, wayline, git) is refused, stop at once and return blocked naming it.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113.

---
id: 153
title: Re-file toy.eval's four findings (R9, R12) against the current eval.py and test_eval.py, so the manifest takes their current hashes
kind: analysis
difficulty: 2
status: parked
blocked_by: []
touches: [analysis/refile/eval.json]
role: analyst
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 2, wallclock_minutes: 15}
inputs: [tests/test_eval.py, src/toy/eval.py, research/findings.jsonl, research/manifest.json]
outputs: [analysis/refile/eval.json]
acceptance:
  machine: ["python3 -c \"import hashlib, json, re; d = json.load(open('analysis/refile/eval.json')); fs = {f['path']: f['sha256'] for f in d['files']}; need = {'tests/test_eval.py', 'src/toy/eval.py'}; assert need <= set(fs) and all(hashlib.sha256(open(p, 'rb').read()).hexdigest() == h for p, h in fs.items()); fd = d['findings']; assert sorted(f['replaces'] for f in fd) == ['t117-a1-f1', 't118-a1-f1', 't95-a1-f1', 't95-a1-f2']; tags = [re.findall(r'\\{res:(t[0-9]+-a[0-9]+)/([^#{}]+)#[^{}]+\\}', f['text']) for f in fd]; runs = {r for t in tags for r, p in t}; cited = {p for t in tags for r, p in t}; assert all(tags) and len(runs) == 1 and not runs & {'t95-a1', 't117-a1', 't118-a1'} and need <= cited <= set(fs); assert all(f['provenance'].partition('#')[0] in fs for f in fd) and all(f['negative'] is False for f in fd)\"", "ids=$(python3 -c \"import json; d = json.load(open('analysis/refile/eval.json')); t = {f['replaces']: set(f.get('tests') or []) for f in d['findings']}; p = 'tests.test_eval.Eval.'; assert p + 'test_o2_command_reads_wayline_artifact_unchanged' in t['t95-a1-f1'] and p + 'test_val_split_never_falls_back_to_held_out' in t['t95-a1-f2'] and {p + 'test_wayline_artifact_run_directory_reads_its_summary_json', p + 'test_positional_run_directory_reads_its_summary_json'} <= t['t118-a1-f1'] and t['t117-a1-f1']; print(' '.join(sorted(set().union(*t.values()))))\") && test -n \"$ids\" && PYTHONPATH=src python3 -B -m unittest $ids"]
  quality: ["Does each re-filed finding state only what tests/test_eval.py and src/toy/eval.py show as they are now? It should keep the replaced finding's wording wherever that still holds, correct what no longer holds, and hold each number on a line that one of its sentence's own-run res tags names. Is its text the one analysis/refile/eval.json records?"]
objectives: []
sections: [methods, results]
context_pack: [research/findings.jsonl:31-32, research/findings.jsonl:50-51, research/manifest.json:1327-1369, research/tickets/142-draw-r9-eval-py-summary-path-and-split-val-o2-s.md#result, research/tickets/145-draw-r12-evaluation-command.md, tests/test_eval.py, src/toy/eval.py]
origin: research/SPEC.md#seams
proposed_by: planner
demo: analysis/refile/eval.json lists tests/test_eval.py and src/toy/eval.py at the sha256 they have now, beside the stale hashes the manifest holds for runs t95-a1 and t117-a1. It records four findings that replace t95-a1-f1, t95-a1-f2, t117-a1-f1 and t118-a1-f1. Each ends with res tags of this ticket's own run and names the tests that back it, and those tests pass. Once the ticket is integrated, research/manifest.json holds both files at their current hashes, so drawings of R9 and R12 can pass `wayline drawing check`'s provenance test.
---

## Demo

analysis/refile/eval.json lists tests/test_eval.py and src/toy/eval.py at the sha256 they have now, beside the stale hashes the manifest holds for runs t95-a1 and t117-a1. It records four findings that replace t95-a1-f1, t95-a1-f2, t117-a1-f1 and t118-a1-f1. Each ends with res tags of this ticket's own run and names the tests that back it, and those tests pass. Once the ticket is integrated, research/manifest.json holds both files at their current hashes, so drawings of R9 and R12 can pass `wayline drawing check`'s provenance test.

## Notes

Why this ticket exists: drawing R9 (#142) was blocked, and drawing R12 (#145, running) will be too, because both read tests/test_eval.py and src/toy/eval.py. research/manifest.json still holds those files at the hashes of runs t95-a1 and t117-a1. Ticket 118 (commit bd8727c) later added two tests to tests/test_eval.py, and ticket 131 (commit b008f0a) added docstrings to src/toy/eval.py. Neither re-registered its file, so the drawing check refuses any drawing that reads them. No worker may write research/. A file is re-registered by a finding whose text carries a res tag of the worker's own run naming that file: when the ticket is integrated, the conductor hashes the file as it is on main into the manifest under that run, replacing the stale entry.

1. Read the four current findings (research/findings.jsonl lines 31, 32, 50 and 51) against the two files as they are now, and run the tests that back each. If your Bash refuses the `PYTHONPATH=src` prefix, run unittest from a one-line script that puts src/ on sys.path itself.
2. Return four findings. Give each one:
   - `replaces` set to the finding it re-files.
   - That finding's heading: "eval.py: --summary PATH and --split val, O2's goal command unchanged" for t95-a1-f1, t95-a1-f2 and t117-a1-f1, and "Evaluation command" for t118-a1-f1.
   - negative false.
   - A provenance `<path>#<locator>` at the file the finding is about.
   - Text that keeps the replaced wording wherever it still holds.
   End every sentence with one or more tags `{res:t<this ticket's id>-a<this attempt's number>/<path>#<locator>}`, using your own run id as your prompt gives it, never t95-a1 or t117-a1. If you are resumed into a new attempt, change every tag to that attempt's run id. A locator is a symbol (`read_metric`, `Eval.test_o2_command_reads_wayline_artifact_unchanged`), a constant's name (`SAMPLE_AUROC`, whose line holds 0.8502984862625299), or a line span `L<a>-L<b>`. The lines it names must hold every number its sentence writes, as written. Between them, the four findings cite both files.
3. Write analysis/refile/eval.json with two keys. `files` is a list of {path, sha256 (the file as it is now), manifest_run, manifest_sha256 (what research/manifest.json holds for it now)}. `findings` is a list of {replaces, heading, negative, provenance, text, tests}, where tests are the unittest ids that back the finding, e.g. tests.test_eval.Eval.test_o2_command_reads_wayline_artifact_unchanged. Each text is exactly what you return.

Do not change tests/test_eval.py or src/toy/eval.py: the manifest takes the hash on main. Return no passage. No section passage cites these files at an old run except the Results passages these findings render. If a finding no longer holds for the current file, re-file it corrected and say what changed in your result.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 176, 177, 178, 179, 180, 181, 182, 183, 184, 185.

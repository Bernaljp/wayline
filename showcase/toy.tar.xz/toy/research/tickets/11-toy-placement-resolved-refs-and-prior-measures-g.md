---
id: 11
title: "toy.placement: resolved_refs and prior_measures_gain from a placement record and the dossiers"
kind: code
difficulty: 2
status: parked
blocked_by: []
touches: [src/toy/placement.py, tests/test_placement.py, tests/fixtures/placement/]
role: coder
skills: []
acceptance:
  machine: [PYTHONPATH=src python3 -B -m unittest tests.test_placement, "PYTHONPATH=src python3 -B -m toy.placement tests/fixtures/placement/placement.json --refs tests/fixtures/placement/refs | python3 -c \"import json, sys; d = json.load(sys.stdin); assert {'resolved_refs', 'prior_measures_gain'} <= set(d)\""]
  quality: []
objectives: [O1]
sections: [methods]
context_pack: [research/refs/paper-a/dossier.json, research/SPEC.md#e6-claims-c8, research/SPEC.md#seams]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`python3 -m toy.placement tests/fixtures/placement/placement.json --refs tests/fixtures/placement/refs` prints resolved_refs and prior_measures_gain, and exits 1 on an entry whose existence disagrees with its dossier."
---

## Demo

`python3 -m toy.placement tests/fixtures/placement/placement.json --refs tests/fixtures/placement/refs` prints resolved_refs and prior_measures_gain, and exits 1 on an entry whose existence disagrees with its dossier.

## Notes

`toy.placement <placement.json> [--refs research/refs]` reads a list of entries {slug, doi, existence, measures_paired_gain (true, false, or null when the dossier cannot settle it), locator} and each <refs>/<slug>/dossier.json (shaped like research/refs/paper-a/dossier.json: 'existence' at the top level, 'unresolved' until the scout resolves it). An entry whose existence differs from its dossier's, or whose dossier is missing, is listed under mismatches and makes the command exit 1. Print JSON with resolved_refs (entries whose dossier existence is not 'unresolved'), prior_measures_gain (resolved entries with measures_paired_gain true), entries and mismatches. Fixtures under tests/fixtures/placement/ (a placement.json and a refs/ tree). Stdlib only; run Python with -B.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49.

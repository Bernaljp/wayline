---
id: 123
title: "E3 findings: the strength sweep, C5 and A3 re-filed, every number at a leaf key its sentence cites"
kind: analysis
difficulty: 3
status: accepted
blocked_by: [16, 96, 105, 122]
touches: [analysis/E3/findings_c5.json]
role: analyst
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 4, wallclock_minutes: 30}
inputs: [analysis/E3/verdict.json, analysis/E3/sweep.json, research/manifest.json]
outputs: [analysis/E3/findings_c5.json]
acceptance:
  machine: ["python3 -B analysis/E3/sweep_analysis.py --check && python3 -B analysis/E3/cite_check.py analysis/E3/findings_c5.json && python3 -c \"import json; t = json.load(open('analysis/E3/findings_c5.json')); assert sorted(f['replaces'] for f in t['findings']) == sorted('t109-a1-f%d' % i for i in range(8, 20)); assert [x['replaces'] for x in t['passages'] if x['section'] == 'discussion'] == ['P41'] and [x['replaces'] for x in t['passages'] if x['section'] == 'methods'] == [None]\"", "python3 -c \"import json; t = json.load(open('analysis/E3/findings_c5.json')); es = t['findings'] + t['passages']; c = lambda r: {k.split('#', 1)[1] for e in es if e.get('replaces') == r for s in e['sentences'] for k in s['cites']}; x = lambda r: ' '.join(s['text'] for e in es if e.get('replaces') == r for s in e['sentences']); assert {'c5_supported', 'strength_spearman', 'spearman_min', 'by_strength.m4.m', 'by_strength.m4.paired_gain_lo'} <= c('t109-a1-f16'); assert {'sd_rule', 'sd_rule_exceeded_at', 'revisit_seed_first', 'revisit_seed_last'} <= c('t109-a1-f18'); assert {'strength_spearman', 'n_points'} <= c('t109-a1-f14') and {'max_sd_d', 'n_points'} <= c('t109-a1-f19'); assert {'by_strength.m0p25.m', 'by_strength.m0p25.paired_gain', 'by_strength.m0p25.gap_closed', 'by_strength.m0p25.delong_rejections'} <= c('t109-a1-f8'); assert {'a3', 'by_strength.m0.m'} <= c('t109-a1-f17') and 'only restates what generate.py plants' in x('t109-a1-f17'); assert {'a3', 'strength_spearman', 'by_strength.m0.paired_gain', 'by_strength.m4.paired_gain'} <= c('P41') and 'only restates what generate.py plants' in x('P41') and 'tabular' not in x('P41')\""]
  quality: ["Does each of the twelve findings state only what the t109-a1 finding it replaces stated, with every number held at a leaf key its sentence cites and written as stored? Does C5's finding follow strength_spearman >= spearman_min and an m = 4 lower bound above zero? Do the A3 finding and the passage replacing P41 say in A3's words that the gain only restates what generate.py plants, without reaching to A8's tabular-data scope?"]
objectives: [O4]
sections: [methods, results]
context_pack: [research/sections/discussion.md:9-12, research/findings.jsonl:90-101, analysis/E3/verdict.json, analysis/E3/sweep_analysis.py, analysis/E2/cite_check.py, research/tickets/109-e3-analysis-gain-across-interaction-strengths-an.md#result, research/SPEC.md#e3-claims-c4-c5, research/SPEC.md#anti-claims]
origin: research/SPEC.md#e3-claims-c4-c5
proposed_by: planner
demo: "`python3 -B analysis/E3/cite_check.py analysis/E3/findings_c5.json` exits 0. Twelve findings replace t109-a1-f8 to f19. They give, from m = 0.25 to m = 4, the paired gain with its t-interval at confidence 0.95 and gap_closed with its CI, then strength_spearman against spearman_min, C5's verdict, A3 and Q15's SD rule, with every number at a leaf key its sentence cites. The Discussion passage that replaces P41 says in A3's words that the gain only restates what generate.py plants."
---

## Demo

`python3 -B analysis/E3/cite_check.py analysis/E3/findings_c5.json` exits 0. Twelve findings replace t109-a1-f8 to f19. They give, from m = 0.25 to m = 4, the paired gain with its t-interval at confidence 0.95 and gap_closed with its CI, then strength_spearman against spearman_min, C5's verdict, A3 and Q15's SD rule, with every number at a leaf key its sentence cites. The Discussion passage that replaces P41 says in A3's words that the gain only restates what generate.py plants.

## Notes

Cut from ticket 109 by the planner's split.

Second half of the split of #109. It waits on the first half, which did two things:
- It added keys to analysis/E3/verdict.json: spearman_min, harmless_band, harmless_lo, harmless_hi, delong_alpha, gap_denominator_min, confidence, bootstrap_resamples, seed_first, seed_last, revisit_seed_first, revisit_seed_last, n_points and strength_grid, and, in each by_strength entry, m and gap_closed_reason.
- It wrote analysis/E3/cite_check.py, whose docstring gives the table format and rules: dotted leaf cites, signed numbers, and no number from a cited object. analysis/E3/findings_c4.json is a passing example.
\#109's numbers stand. Do not change sweep_analysis.py, sweep.json, verdict.json or cite_check.py, which are outside this touch set. If a number you want to state is at no key, leave it out, or return blocked and name it.

Write analysis/E3/findings_c5.json, and run `python3 -B analysis/E3/cite_check.py analysis/E3/findings_c5.json` until it exits 0. It holds twelve findings under the heading 'E3: paired gain across interaction strengths (C4, C5)'. Each replaces one t109-a1 finding and holds what that finding held, corrected:
- t109-a1-f8, at m = 0.25 (by_strength.m0p25): paired_gain with its t-interval at confidence; gap_closed with gap_closed_lo and gap_closed_hi; delong_rejections of n_pairs.
- t109-a1-f9, at m = 0.5: paired_gain with its interval, and gap_closed with its CI.
- t109-a1-f10, at m = 1, reusing E2's runs (by_strength.m1.dir): paired_gain with its interval, and gap_closed.
- t109-a1-f11, at m = 2: paired_gain with its interval, and gap_closed.
- t109-a1-f12, at m = 4: paired_gain with its interval, which lies wholly above zero.
- t109-a1-f13, at m = 4: mean_auroc_with, mean_bayes_auroc, mean_auroc_without and gap_closed.
- t109-a1-f14: strength_spearman over the n_points points.
- t109-a1-f15: gain_monotone_in_strength, meaning the mean paired gain rises at every step of strength_grid.
- t109-a1-f16: c5_supported, because strength_spearman is at least spearman_min and by_strength.m4.paired_gain_lo is above zero.
- t109-a1-f17: a3 is confirmed, said in A3's words: the gain is about zero at strength 0 (c4_supported) and rises with the planted strength (c5_supported), so it only restates what generate.py plants. Keep A3's 'only', which #109 dropped.
- t109-a1-f18, negative as before: sd_rule_exceeded_at is empty. No point's sd_d exceeds sd_rule, so seeds revisit_seed_first to revisit_seed_last are not added.
- t109-a1-f19: max_sd_d over the n_points points.

The table also holds two passages:
- One Discussion passage replacing P41, under 'What the gain does and does not show'. It reads the strength sweep against K1 and K4. It says A3 is confirmed and, in A3's words, that the gain only restates what generate.py plants. It gives the m = 0 gain, the m = 4 gain and strength_spearman as stored. It gives the zero-strength cost: n_negative_d of n_pairs, signed_rank_p, and band_over_cost against harmless_band. And it says the readings are taken at train_rows only. Drop P41's sentence on tabular data in general: that scope belongs to A8, which E4 tests, not to A3.
- One new Methods passage on how sweep_analysis.py reads A3 (c4_supported and c5_supported), gain_monotone_in_strength, and Q15's SD rule (sd_rule_exceeded_at and the revisit seeds). Each sentence cites analysis/E3/sweep_analysis.py#compute.

Cite the leaf key of every number, point labels included: 'm = 4' cites verdict.json#by_strength.m4.m, and 'strength 0' cites by_strength.m0.m. Write the level as 'confidence 0.95', never as a percentage. Write values as stored, with negative ones signed in ASCII, and write counts in digits ('6 points', not 'six'). Use no 'about' or 'only' before a number; A3's phrase 'about zero' is words, not a number. Write 'sha256', not 'SHA-256'. Do not merge two old findings into one replacement.

Return exactly the table's sentences. End each with one tag per cite: {res:<run>/<path>#<key>} for a .json cite (the dotted key as cited), and {code:<path>#<name>} for a .py cite. <run> is the run id in research/manifest.json's last entry for that path. That is the first half's run, since it rewrote both JSON files. Leave evidence unset.

Bash: this role runs a command only when every part of it begins with a program on its allow list: python3, git add, git commit, git status, git diff, git log, ls, cat and wayline accept. A `PYTHONPATH=` prefix, mkdir, bash, heredocs and `>` redirects are refused, and those refusals blocked tickets 16, 76 and 83. Write files with the Write or Edit tool, run one plain command per Bash call, and retry a refused command in an allowed form before you return blocked. results/ is git-ignored and not in the worktree, so sweep_analysis.py --check reads it under the project root. Commit only analysis/E3/findings_c5.json.

## Result

### Attempt 1

Wrote analysis/E3/findings_c5.json, and analysis/E3/cite_check.py passes it on all 14 entries. Twelve findings replace t109-a1-f8 to f19, each with only the content of the finding it replaces. Every number is written as stored and sits at a leaf key of analysis/E3/verdict.json that its sentence cites, point labels included. The tags use the manifest's last run id for that file, t122-a2. Every cite is to verdict.json, which holds strength_spearman too, so nothing cites sweep.json. The table covers each point from m = 0.25 to m = 4: the paired gain with its t-interval at confidence 0.95, gap_closed (with its CI where the old finding gave one), and the m = 0.25 DeLong count. It then gives the m = 4 AUROCs and strength_spearman over the 6 points. Last come monotonicity, and C5's verdict against spearman_min and the m = 4 lower bound. A3 is in A3's words, 'only' kept. The negative SD-rule finding cites sd_rule, sd_rule_exceeded_at and the revisit seeds, and the last finding gives max_sd_d. The Discussion passage replaces P41 and drops the tabular-data sentence, which is A8's scope. A new Methods passage under 'Sweeps' says how sweep_analysis.py#compute reads A3, monotonicity and Q15's SD rule. sweep_analysis.py --check, cite_check and both acceptance commands pass, and wayline accept passed. Committed as 8ad8701 on ticket/123.

Wrote: `analysis/E3/findings_c5.json`

Ran: `python3 -B analysis/E3/cite_check.py analysis/E3/findings_c5.json`, `python3 -B analysis/E3/sweep_analysis.py --check /home/bernaljp/wayline-m8/toy`, `python3 -c <ticket acceptance assertions>`, `wayline accept`, `git add analysis/E3/findings_c5.json`, `git commit (8ad8701 on ticket/123)`

Passages:

- discussion, What the gain does and does not show, replacing P41: The strength sweep is the test A3 set in advance for the planted-effect objection (K1), and A3 is confirmed {res:t122-a2/analysis/E3/verdict.json#a3}. With no planted interaction, at $m = 0$, the column's mean paired gain is -0.0003186665215305473 AUROC {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.m} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.paired_gain}. As the planted weight on $x_3x_4$ grows, the gain rises at every step of the strength grid, and at $m = 4$ it is 0.31434161002887523 {res:t122-a2/analysis/E3/verdict.json#gain_monotone_in_strength} {res:t122-a2/analysis/E3/verdict.json#strength_grid} {res:t122-a2/analysis/E3/verdict.json#by_strength.m4.m} {res:t122-a2/analysis/E3/verdict.json#by_strength.m4.paired_gain}. Its Spearman correlation with strength, strength_spearman, is 1.0 {res:t122-a2/analysis/E3/verdict.json#strength_spearman}. The gain is therefore about zero at strength 0 and rises with the planted strength, so it only restates what generate.py plants and is not a finding about interaction terms apart from the generator {res:t122-a2/analysis/E3/verdict.json#a3} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.m}. As a null control (K4), the zero-strength point shows that the unneeded column has a measurable cost: 16 of 20 seeds score lower with it, and the exact signed-rank p is 0.00485992431640625 {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.n_negative_d} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.n_pairs} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.signed_rank_p}. That cost is 31.38076743038538 times smaller in size than C4's harmlessness tolerance of 0.01 {res:t122-a2/analysis/E3/verdict.json#zero_cost.band_over_cost} {res:t122-a2/analysis/E3/verdict.json#zero_cost.harmless_band}. These readings are taken at a single training size, 16000 rows {res:t122-a2/analysis/E3/verdict.json#train_rows}.
- methods, Sweeps: The E3 analysis reads A3 as confirmed when C4 and C5 are both supported, that is, when the gain is about zero at $m = 0$ and rises with $m$ {code:analysis/E3/sweep_analysis.py#compute} {res:t122-a2/analysis/E3/verdict.json#by_strength.m0.m}. It reads the gain as monotone in strength when the mean paired gain rises strictly at every step of the strength grid {code:analysis/E3/sweep_analysis.py#compute} {res:t122-a2/analysis/E3/verdict.json#strength_grid}. It applies Q15's SD rule at each point: it lists in sd_rule_exceeded_at every strength whose SD of the per-seed differences $d_i$ exceeds sd_rule, 0.02, and such a point would add seeds 21 to 50 {code:analysis/E3/sweep_analysis.py#compute} {res:t122-a2/analysis/E3/verdict.json#sd_rule} {res:t122-a2/analysis/E3/verdict.json#revisit_seed_first} {res:t122-a2/analysis/E3/verdict.json#revisit_seed_last}.

**Verdict (result): passed** by claude-opus-5-5, session `f94369d3-b6f1-44cc-ba3e-6313069335df`.

- [minor] The Result says 'Every cite is to verdict.json'. That is not literally true: all three sentences of the new Methods passage also cite analysis/E3/sweep_analysis.py#compute. What the sentence means to say does hold: every .json cite is to analysis/E3/verdict.json and none is to sweep.json. (research/tickets/123-e3-findings-the-strength-sweep-c5-and-a3-re-file.md line 66 (## Result, Attempt 1); cf. analysis/E3/findings_c5.json lines 176, 180, 184)
- [minor] The ticket's Demo says the table gives 'gap_closed with its CI' at every point from m = 0.25 to m = 4. The table gives a gap_closed CI only at m = 0.25 and m = 0.5 (findings_c5.json lines 12, 22) and bare gap_closed at m = 1, 2 and 4 (lines 32, 42, 62). That follows the ticket's Notes (lines 39-44) and the old findings (research/findings.jsonl lines 92, 93, 95), and the Result says so. The fault is in the Demo's wording, not in the work. (research/tickets/123-e3-findings-the-strength-sweep-c5-and-a3-re-file.md line 27 (## Demo) against lines 39-44 (## Notes))
- [minor] This session could not run python3, so I did not run cite_check.py, sweep_analysis.py --check or the acceptance one-liners myself. Instead I applied R1-R5 and every assertion by hand to each sentence against analysis/E3/verdict.json, and all hold. That file's sha256 89ce1823...92c6 matches the manifest's t122-a2 entry, the one the tags name. For the --check recompute I relied on two things: the harness's acceptance events (research/journal.jsonl lines 4037-4039: exit 0, 'cite_check.py: 14 entries pass R1-R5', 'match the recomputed results'), and commit 8ad8701 touching only findings_c5.json. (research/tickets/123-e3-findings-the-strength-sweep-c5-and-a3-re-file.md line 15 (acceptance.machine); analysis/E3/sweep_analysis.py (main, --check))

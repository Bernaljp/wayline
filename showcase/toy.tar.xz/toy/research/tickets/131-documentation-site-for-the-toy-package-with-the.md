---
id: 131
title: Documentation site for the toy package, with the docstrings its build checks for
kind: docs
difficulty: 3
status: accepted
blocked_by: [2, 3, 5, 8, 96, 97, 98, 115, 116, 117, 118]
touches: [docs/, .readthedocs.yaml, harness.json, src/toy/converge.py, src/toy/eval.py, src/toy/generate.py, src/toy/goallog.py, src/toy/oracle.py, src/toy/paired.py, src/toy/placement.py, src/toy/stats.py, src/toy/sweep.py, src/toy/train.py]
role: documentarian
skills: []
acceptance:
  machine: [test -f .readthedocs.yaml && grep -rqs 'toy.paired' docs/reference/ && grep -rqs 'toy.oracle' docs/reference/ && grep -rqs 'toy.sweep' docs/reference/ && grep -rqs 'toy.placement' docs/reference/ && grep -rqs 'toy.goallog' docs/reference/ && grep -rqs 'toy.converge' docs/reference/, grep -rqs -- '--no-interaction' docs/how-to/ && grep -rqs -- '--summary' docs/how-to/, "python3 -B -c \"import ast; want = {'converge': ['convergence', 'main'], 'eval': ['main', 'read_metric'], 'generate': ['main', 'read_split', 'write_split'], 'goallog': ['main'], 'oracle': ['main'], 'paired': ['main'], 'placement': ['load_entries', 'main', 'place'], 'stats': ['mean'], 'sweep': ['main'], 'train': ['build_parser', 'is_under_owner', 'main']}; defs = {m: {n.name: n for n in ast.parse(open('src/toy/%s.py' % m, encoding='utf-8').read()).body if isinstance(n, ast.FunctionDef)} for m in want}; missing = ['%s.%s' % (m, f) for m in want for f in want[m] if not ast.get_docstring(defs[m][f])]; assert not missing, missing\" && PYTHONPATH=src python3 -B -m unittest tests.test_generate tests.test_eval tests.test_stats tests.test_converge tests.test_goallog tests.test_placement tests.test_paired tests.test_sweep && PYTHONPATH=src /home/bernaljp/.wayline/tools/venv/bin/python -B -m unittest tests.test_train"]
  quality: ["Does every page and every added docstring describe only what the code on main does (train.py's arms and flags, the oracle ceiling, the paired statistics and the held-out discipline) with no behaviour the code lacks, and does the diff to src/toy/ change docstrings only?"]
objectives: []
context_pack: [research/tickets/113-documentation-site-for-the-toy-package-and-its-n.md, research/SPEC.md#seams, research/INTAKE.md, src/toy/]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`wayline docs build` passes all seven of its checks, the docstrings check included. The 18 public functions it found undocumented now have docstrings that say what they do, with no behaviour changed: 15 in converge, eval, generate, goallog, oracle, paired, placement, stats and sweep, plus train.py's build_parser, is_under_owner and main. The site is rebuilt from #113's attempt on branch ticket/113 (eb1db82) wherever that attempt still holds against main. It has a reference page per public module, toy.paired, toy.oracle and toy.sweep included, and a how-to that runs one paired comparison with --no-interaction and reads it with toy.paired."
---

## Demo

`wayline docs build` passes all seven of its checks, the docstrings check included. The 18 public functions it found undocumented now have docstrings that say what they do, with no behaviour changed: 15 in converge, eval, generate, goallog, oracle, paired, placement, stats and sweep, plus train.py's build_parser, is_under_owner and main. The site is rebuilt from #113's attempt on branch ticket/113 (eb1db82) wherever that attempt still holds against main. It has a reference page per public module, toy.paired, toy.oracle and toy.sweep included, and a how-to that runs one paired comparison with --no-interaction and reads it with toy.paired.

## Notes

Re-cut of #113, which was blocked for one reason. `wayline docs build` passed 6 of its 7 checks, but its docstrings check failed on 15 public functions in modules outside #113's touch set: toy.converge.convergence and main, toy.eval.main and read_metric, toy.generate.main, read_split and write_split, toy.goallog.main, toy.oracle.main, toy.paired.main, toy.placement.load_entries, main and place, toy.stats.mean, and toy.sweep.main. On main, train.py's build_parser, is_under_owner and main also lack docstrings; #113 added those only on its own branch. This touch set takes in those modules for their docstrings only. A docs ticket may write the package's docstrings, and adding a docstring adds no public API, so no separate code ticket is cut. In oracle.py touch only main's docstring, since #52 (needs_human) holds oracle.py's other changes. Attempt 1's whole site (Sphinx with furo, a tutorial, two how-tos, a reference page per module, an explanation and four example scripts) is on branch ticket/113 at eb1db82. `git diff main ticket/113 -- docs/ .readthedocs.yaml harness.json src/toy/train.py` shows it. Rebuild from it what still holds, checking each claim against the code on main. Everything else in #113's Notes stands: `wayline docs init --theme furo`, which may add only the docs theme to harness.json (no code_repository, and no change to the budgets, the autonomy or the human-only classes); autodoc_mock_imports = ['torch']; and making train.py's module docstring and ready_interactions docstring say what the code does. Bash: this role runs a command only when every part of it begins with a program on its allow list (wayline docs, wayline accept, python3, git add, git commit, git status, git diff, git log, ls and cat). Write files with the Write tool, and run one plain command per Bash call.

## Result

### Attempt 1

The docs site is rebuilt on main and `wayline docs build` now passes all seven of its checks, the docstrings check included (63 public symbols). `wayline accept` passes too, with all four criteria, including the unit tests and tests.test_train in the tools venv.

**The site.** It is ticket 113's attempt (eb1db82), rebuilt file by file. Between 113's base and main, the only source files that differ are the ones 113 changed itself, so its pages still match the code. Bash refused `git checkout ticket/113 --`, so I read each file with `git show` and wrote it back with the Write tool. The site has:
- a tutorial;
- a how-to that trains both arms with --no-interaction and --save-scores, reads one run with toy.eval --summary, and reads the point with toy.paired;
- a how-to for toy.sweep, converge, goallog and placement;
- 11 reference pages, one per public module;
- an explanation page;
- a gallery figure drawn by the build from toy.oracle.audit;
- four example scripts, all run by the build.

**Docstrings.** I added them to the 18 functions the ticket lists, and changed no code. While doing that I found that train.py's module docstring and `ready_interactions` docstring described a down-weighting of duplicate rows that the code does not do. Ticket 113 had been asked to fix this and left it. Both now say what the code does: `--batch-size` only sizes a tensor of zeros that is allocated and freed unread.

**Explanation page.** It now also covers what --batch-size really does, and makes clear that toy.goallog records and counts the `kept` field but does not apply a keep rule itself.

Committed on ticket/131 as 2871afd.

Wrote: `.readthedocs.yaml`, `harness.json`, `docs/conf.py`, `docs/requirements.txt`, `docs/index.rst`, `docs/tutorials/index.rst`, `docs/tutorials/first-paired-comparison.rst`, `docs/how-to/index.rst`, `docs/how-to/run-a-paired-comparison.rst`, `docs/how-to/sweep-strength-or-rows.rst`, `docs/explanation/index.rst`, `docs/explanation/design.rst`, `docs/gallery/index.rst`, `docs/examples/index.rst`, `docs/examples/oracle_ceiling.py`, `docs/examples/paired_comparison.py`, `docs/examples/read_fixtures.py`, `docs/examples/plot_additive_gap.py`, `docs/reference/index.rst`, `docs/reference/toy.converge.rst`, `docs/reference/toy.eval.rst`, `docs/reference/toy.generate.rst`, `docs/reference/toy.goallog.rst`, `docs/reference/toy.metrics.rst`, `docs/reference/toy.oracle.rst`, `docs/reference/toy.paired.rst`, `docs/reference/toy.placement.rst`, `docs/reference/toy.stats.rst`, `docs/reference/toy.sweep.rst`, `docs/reference/toy.train.rst`, `src/toy/converge.py`, `src/toy/eval.py`, `src/toy/generate.py`, `src/toy/goallog.py`, `src/toy/oracle.py`, `src/toy/paired.py`, `src/toy/placement.py`, `src/toy/stats.py`, `src/toy/sweep.py`, `src/toy/train.py`

Ran: `git show ticket/113:<each docs file> (read 113's site; git checkout was refused)`, `wayline docs init --theme furo (wrote harness.json docs block, identical to 113's)`, `wayline docs build (pass: structure, docstrings, examples, build, reference, site, links)`, `wayline accept (pass, 4/4 criteria)`, `git add .readthedocs.yaml docs harness.json src/toy`, `git commit (2871afd on ticket/131)`

Not methods:

- `code/src/toy/converge.py#convergence`: Only a docstring was added; behaviour unchanged.
- `code/src/toy/converge.py#main`: Only a docstring was added to the CLI entry point.
- `code/src/toy/eval.py#read_metric`: Only a docstring was added; it reads a key from a summary JSON.
- `code/src/toy/eval.py#main`: Only a docstring was added to the CLI entry point.
- `code/src/toy/generate.py#write_split`: Only a docstring was added; JSON-lines file I/O.
- `code/src/toy/generate.py#read_split`: Only a docstring was added; JSON-lines file I/O.
- `code/src/toy/generate.py#main`: Only a docstring was added to the CLI entry point.
- `code/src/toy/goallog.py#main`: Only a docstring was added to the CLI entry point.
- `code/src/toy/oracle.py#main`: Only a docstring was added to the CLI entry point.
- `code/src/toy/paired.py#main`: Only a docstring was added to the CLI entry point.
- `code/src/toy/placement.py#load_entries`: Only a docstring was added; it validates a record file.
- `code/src/toy/placement.py#place`: Only a docstring was added; behaviour unchanged.
- `code/src/toy/placement.py#main`: Only a docstring was added to the CLI entry point.
- `code/src/toy/stats.py#mean`: Only a docstring was added; arithmetic mean.
- `code/src/toy/sweep.py#main`: Only a docstring was added to the CLI entry point.
- `code/src/toy/train.py#is_under_owner`: Only a docstring was added; a path guard.
- `code/src/toy/train.py#build_parser`: Only a docstring was added; argparse setup.
- `code/src/toy/train.py#main`: Only a docstring was added to the CLI entry point.
- `code/src/toy/train.py#ready_interactions`: Only its docstring was corrected to match the code; behaviour unchanged.

**Verdict (quality): failed** by claude-opus-5-5, session `1f4b8fe5-8254-4a4c-8c89-29e7b9cc6579`.

- [blocker] The example says the oracle's AUROC "on the held-out rows is the most any model can reach there", and the tutorial at first-paired-comparison.rst:24-25 says "its AUROC is the best any model can reach". The code computes the Bayes scorer's AUROC on a finite sample, which is a ceiling only in expectation (SPEC.md:107, B2). The code's own output refutes the per-sample claim: analysis/E2/paired.json:860-862 (seed 16, default generator) has auroc_with 0.848202 above bayes_auroc 0.848112 on the same 4,000 held-out rows, and analysis/E3/sweep.json:697-699 (m = 0, seed 13) has both arms above it. (docs/examples/oracle_ceiling.py:3-4 (module docstring, literalincluded at docs/tutorials/first-paired-comparison.rst:27 and docs/examples/index.rst:14))
- [major] "so the best AUROC any model could reach is known exactly" overstates the oracle ceiling. toy.oracle reports the ceiling with a DeLong 95% half-width (src/toy/oracle.py:164-168, bayes_auroc_halfwidth at :266), SPEC.md:16 (C2) calls it known to within ±0.002, and trained arms exceed it on particular held-out sets (analysis/E2/paired.json:860-862). (docs/index.rst:13-14)
- [major] additive_gap is called "the most a model with the x3 * x4 column could gain over one without it", but the code computes no such bound: it is the oracle's AUROC minus an x1..x4 regression's on a half split (src/toy/oracle.py:222-237). Measured gains exceed it: at E2 seed 16, d = 0.083146 is larger than that seed's whole gap to the ceiling, gap_without = 0.083056 (analysis/E2/paired.json:863,868), and 9 of E2's 20 d_i exceed E1's population additive_gap of 0.0882 (results/E1/oracle.json:11). The same claim is at docs/examples/plot_additive_gap.py:7-8. (docs/gallery/index.rst:15-16)
- [major] "--config configs/arms.json applies the pinned settings (model, optimiser, epochs, learning rate)" credits --config with behaviour train.py lacks. Only signal, rows, epochs and lr are applied from the file (CONFIG_FLAGS, src/toy/train.py:48, :198-201). optimizer, weight_decay, minibatch and held_out_fraction are only checked against the code's fixed values and refused if they differ (CONFIG_FIXED, :50-51, :146-148), and the file's model key is never read. (docs/tutorials/first-paired-comparison.rst:45-46)
- [minor] "the difference d_i is far less noisy than either one alone" is contradicted by E2's own result. sd_d is 0.00603 (analysis/E2/paired.json:1177), while the with arm's 20 per-seed AUROCs in the same file have an SD of about 0.0053 and the without arm's about 0.0072, so at the default point d_i is noisier than the with arm alone. (docs/explanation/design.rst:54-55 (Why paired statistics))
- [minor] "Every analysis module reads only the layout <point>/<with|without>/seed<i>/..." is false for two of the modules docs/index.rst:15-18 lists under the analysis. toy.goallog reads a changes.jsonl log (src/toy/goallog.py:108-116), and toy.placement reads placement.json and research/refs dossiers (src/toy/placement.py:43-49, :77-86). (docs/explanation/design.rst:65-66 (Everything the analysis modules need is in the run directory))
- [minor] The toy.converge, toy.goallog and toy.placement commands drop the PYTHONPATH=src prefix that the page's other commands carry. The project has no pyproject.toml or setup.py, so run as written from the project root they fail to import toy instead of printing what the page says. (docs/how-to/sweep-strength-or-rows.rst:42-49 (The other records))
- [minor] Outside the question: --batch-size's argparse help still says "the interaction gram matrix's side", which the corrected module and ready_interactions docstrings (:4-7, :55-58) now contradict. A docstrings-only diff could not change it, so it is proposed as a code ticket. (src/toy/train.py:165-166)

### Attempt 1

I fixed the seven docs findings from the quality verdict, and `wayline accept` passes again with all four criteria. `wayline docs build` passes all 7 checks, and the unit tests pass. The fixes are committed on ticket/131 as 986b685, on top of 2871afd.

What changed:
- **The oracle ceiling** (index.rst, tutorial, oracle_ceiling.py, design.rst): the Bayes AUROC is now described as a ceiling in expectation, reported with a DeLong 95% half-width (`bayes_auroc_halfwidth`). The pages say a trained arm can come out slightly above it on one finite held-out set.
- **additive_gap** (tutorial, gallery caption, plot_additive_gap.py): it is now described as what the code computes. That is the oracle's AUROC minus an x1..x4 regression's, fitted on the first half of the rows and scored on the second. The pages now call it an estimate from that one split, not a bound on the paired gain.
- **--config** (tutorial): the page now says that only signal, rows, epochs and lr become the flags' defaults. optimizer, weight_decay, minibatch and held_out_fraction are only checked against the code's fixed values (Adam, 0.0, 256, 0.2), and the run is refused if they differ. Other keys in the file are not read.
- **Pairing** (design.rst): the claim that d_i is "far less noisy" is gone. The page now says pairing does not guarantee a smaller variance than either arm's AUROC alone.
- **Run-directory layout** (design.rst): the page now says only toy.paired, toy.sweep and toy.converge read that layout. toy.goallog reads changes.jsonl, and toy.placement reads the placement record and the dossiers under research/refs.
- **Commands** (sweep-strength-or-rows.rst): the converge, goallog and placement commands now carry `PYTHONPATH=src` like the page's other commands.

One finding is not fixed: the `--batch-size` help text in train.py still says it is "the interaction gram matrix's side". Changing it would change what `--help` prints, so it does not fit this docstrings-only ticket. I propose it below as a small code ticket.

Wrote: `docs/index.rst`, `docs/tutorials/first-paired-comparison.rst`, `docs/how-to/sweep-strength-or-rows.rst`, `docs/explanation/design.rst`, `docs/gallery/index.rst`, `docs/examples/index.rst`, `docs/examples/oracle_ceiling.py`, `docs/examples/plot_additive_gap.py`

Ran: `wayline accept (pass, 4/4 criteria, docs build 7/7)`, `git add docs`, `git commit (986b685 on ticket/131)`

Proposed Correct toy.train's --batch-size help text, which still calls it the interaction gram matrix's side (code) (admission decides what joins the graph).

**Verdict (docs_read): passed** by claude-opus-5-5, session `c78394fb-ef9c-43e2-91b4-f602afe37236`.

- [minor] Step 1 shows oracle_ceiling.py but never says to run it or what it prints, and the script prints two different Bayes AUROCs. The first is computed on the 800 held-out rows (oracle_ceiling.py:22-23). The second is audit's bayes_auroc, with the bayes_auroc_halfwidth computed over all 4,000 rows, train and held-out pooled (oracle_ceiling.py:25; oracle.py:259-262). 'bayes_auroc_halfwidth is its DeLong 95% half-width' (line 27) leaves a learner to attach that half-width to the held-out number printed just above it. Separately, line 74's 'The whole lesson as one script' points to paired_comparison.py, which skips Step 1. No page shows what any command or example prints apart from 'auroc: <value>'. (docs/tutorials/first-paired-comparison.rst:25-31 (Step 1: look at the data and its ceiling))
- [minor] The page says that on one finite held-out set the oracle's AUROC is 'reported with a DeLong 95% half-width, bayes_auroc_halfwidth', but no command reports a half-width for an arm's held-out set. toy.paired's per-seed bayes_auroc carries none (src/toy/paired.py:169-177). toy.oracle's command computes bayes_auroc_halfwidth on its own draw with the train and held-out rows pooled (src/toy/oracle.py:295-298). (docs/explanation/design.rst:17-20 (The data has a known answer))
- [minor] 'Other keys in the file are not read' is not what the code does. train.py reads the whole --config file and records it in every run's config.json as `pinned` (src/toy/train.py:145, :242), and toy.paired refuses a pair whose `pinned` contents differ (src/toy/paired.py:75, :157-159). The other keys do not change training, but arms run with files that differ only in, say, `seeds` or `_about` cannot be paired. 'Not applied' would be accurate. (docs/tutorials/first-paired-comparison.rst:53 (Step 2: train both arms))
- [minor] The page says 'experiments/E2/point.sh <out-root> <first-seed> <last-seed> runs the same loop', but the script runs a hard-coded interpreter, /home/bernaljp/.wayline/tools/venv/bin/python, unless E2_PYTHON is set (experiments/E2/point.sh:13). Run as written on any other machine, it fails. The page does not mention E2_PYTHON. (docs/how-to/run-a-paired-comparison.rst:19)
- [minor] 'Train each point with its own --strength m or --train-rows n' does not cover the larger sizes. --train-rows only caps the draw's training rows and refuses any n above them (src/toy/train.py:80-82), so training sizes above the default 16,000, such as E4's 2·n0 and 4·n0 (research/SPEC.md:79), need --rows N. That also moves the held-out fifth onto new rows, and the page says neither. (docs/how-to/sweep-strength-or-rows.rst:8-9)
- [minor] 'Asking for more rows extends the draw instead of reshuffling it, so a larger run never changes what an earlier held-out split measured' can be read as saying the held-out split stays fixed as rows grow. With a larger --rows, the held-out split is the last fifth of the longer draw, all new rows, and the earlier held-out rows become training rows (src/toy/generate.py:53-56). Only --train-rows leaves the held-out fifth unchanged (src/toy/train.py:78-89). What the prefix property actually guarantees is that earlier training rows never become held-out rows. (docs/explanation/design.rst:22-24 (The data has a known answer))
- [minor] The caption ends 'no model is trained', but lines 14-15 say the orange curve is a logistic regression 'fitted to the first half of the rows', and audit does fit one by Newton-Raphson (src/toy/oracle.py:191-237). It means that no toy.train run is made. The section title 'How much the interaction column can buy' (line 6) also still frames additive_gap as what the column buys, which the caption itself qualifies. (docs/gallery/index.rst:21 (How much the interaction column can buy))
- [minor] The how-to guides are only run-a-paired-comparison.rst and sweep-strength-or-rows.rst. There is no recipe for E1's oracle audit command (`toy.oracle --seed 10001 --rows 1000000`, research/SPEC.md:134-138), and none for E5's practice of choosing settings on a validation split with --val-fraction and `toy.eval --split val` (research/SPEC.md:44, :124). Both can be pieced together from the reference, the tutorial's use of audit and the explanation, but not followed as a task. (docs/how-to/index.rst:6-10 (toctree))
- [minor] The scope names README.md as one of the three statements of the package's purpose, but there is no README.md (or any README) at the project root. The purpose was judged from research/INTAKE.md and research/SPEC.md alone, which state it fully. Whatever README.md would have said could not be checked. (README.md)

---
id: 184
title: Correct the negative flag on the procedural findings that put R11 and R14-R17 under 'Cannot be inferred'
kind: writing
difficulty: 3
status: open
blocked_by: []
touches: []
role: writer
skills: [interval-claims]
inputs: [research/findings.jsonl, research/REPORT.md, research/SPEC.md]
acceptance:
  machine: []
  quality: ["Of the ten negative-flagged findings of R11 and R14-R17, does the ticket re-file exactly those that report no failed claim, confirmed anti-claim, discarded change or unresolved question (for example t121-a1-f10, which says only that Q15's SD rule did not add seeds) with negative false and their text and tags unchanged? Does it leave the true negatives as they are, naming each and why in its result?"]
objectives: []
sections: [results]
context_pack: [research/REPORT.md#7-what-can-and-cannot-be-inferred, research/tickets/162-scope-down-the-general-report-s-claims-the-kill.md, research/findings.jsonl:41, research/findings.jsonl:47, research/findings.jsonl:116, research/findings.jsonl:126, research/findings.jsonl:141, research/findings.jsonl:157-158, research/findings.jsonl:161, research/findings.jsonl:164, research/findings.jsonl:168]
origin: research/REPORT.md#kill-argument
proposed_by: planner
demo: The general report renders the findings that only record a revisit rule not firing, or an anti-claim the data rule out, as non-negative, with their text and tags unchanged. R14 and any other result whose only negatives were such findings leaves 'Cannot be inferred' in section 7, while R11's and the others' true negatives stay where they are.
---

## Demo

The general report renders the findings that only record a revisit rule not firing, or an anti-claim the data rule out, as non-negative, with their text and tags unchanged. R14 and any other result whose only negatives were such findings leaves 'Cannot be inferred' in section 7, while R11's and the others' true negatives stay where they are.

## Notes

Why: the kill argument's point 3 stands. Section 7 of research/REPORT.md lists R11 and R14-R17 under 'Cannot be inferred' because each holds a finding flagged negative, while section 4 answers O1-O4 from the same results. R14 is there only because t121-a1-f10 is flagged negative, and that finding says only that the SD rule did not trigger more seeds. This ticket is part of the re-cut of #162. Section 7's wording is code's; what a finding can correct is its own flag.

The rule: a finding is negative when it reports that something the work tested did not hold or was not found. That covers a claim unsupported, an anti-claim confirmed, a change discarded, a defect found, or a question left unresolved. A finding is not negative when it records that a revisit rule did not fire, that an anti-claim was ruled out (which supports its claim), or that a step was not needed.

The findings flagged negative in these results are:
- R11: t103-a1-f7 and t103-a1-f13.
- R14: t121-a1-f10.
- R15: t122-a2-f3 and t123-a1-f11.
- R16: t110-a1-f15, t110-a1-f16, t110-a1-f19 and t110-a1-f22.
- R17: t111-a1-f4.
Judge each by the rule.

For each one that is wrongly flagged, return a finding with `replaces` set to it, its `heading` and `provenance` as research/findings.jsonl records them, `negative` false, and its text exactly as recorded, tags included. Do not add, drop or rewrite a tag, and use no tag of your own run. The tags cite analysis/E1-E5 artifacts that O1-O4's answers cite, and an own-run tag would re-pin them and break those answers.

Leave every true negative alone, and list in your result each finding you kept negative and why. Do not touch R4, R13 or R18: other tickets of this plan re-file their findings. Edit no file. Return no passage.

---
id: 16
title: "E2 experiment: 20 paired seeds with and without the x3*x4 column, plus convergence reruns"
kind: experiment
difficulty: 3
status: accepted
blocked_by: [3]
touches: [experiments/E2/, results/runs/E2/, results/smoke/E2/]
role: experimenter
skills: []
resources: {cpu: 2, gpu: 1, ram_gb: 8, wallclock_minutes: 60}
inputs: [configs/arms.json, src/toy/train.py]
outputs: [results/runs/E2/m1_n0/with/seed1/summary.json, results/runs/E2/m1_n0/without/seed1/summary.json, results/runs/E2/m1_n0/with/seed20/heldout_scores.csv, results/runs/E2/m1_n0/without/seed20/heldout_scores.csv, results/runs/E2/converge/with/seed3/summary.json, results/runs/E2/converge/without/seed3/summary.json]
acceptance:
  machine: ["python3 -c \"import json; json.load(open('experiments/E2/jobs.json'))\"", grep -q 'results/runs/E2/m1_n0/without/seed20/' experiments/E2/jobs.json && grep -q 'results/runs/E2/converge/' experiments/E2/jobs.json && grep -rq -- '--no-interaction' experiments/E2/ && grep -rq 'configs/arms.json' experiments/E2/ && grep -rq -- '--save-scores' experiments/E2/]
  quality: ["Do the jobs run exactly seeds 1-20 in both arms with configs/arms.json and nothing tuned, plus replicates 1-3 in both arms at 60 epochs, each run into its own directory under results/runs/E2/, never over another summary or into owner/?"]
objectives: [O1, O3]
sections: [methods]
context_pack: [owner/sample-summary.json, configs/arms.json, research/SPEC.md#e2-claims-c2-c3, research/SPEC.md#seams, src/toy/train.py]
origin: research/SPEC.md#e2-claims-c2-c3
proposed_by: planner
demo: "`wayline status` shows E2's two jobs: 40 paired runs at seeds 1-20 and six convergence runs at doubled epochs, each run writing summary.json, heldout_scores.csv and config.json to its own directory under results/runs/E2/."
retry:
  host_oom: []
  gpu_oom: [--batch-size=64, --batch-size=16]
---

## Demo

`wayline status` shows E2's two jobs: 40 paired runs at seeds 1-20 and six convergence runs at doubled epochs, each run writing summary.json, heldout_scores.csv and config.json to its own directory under results/runs/E2/.

## Notes

Write experiments/E2/point.sh: given an output root, a seed list and extra flags, for each seed run the with arm then the without arm: `PYTHONPATH=src /home/bernaljp/.wayline/tools/venv/bin/python -B -m toy.train --config configs/arms.json --seed $i [--no-interaction] --save-scores --out <root>/<with|without>/seed$i/ <extra flags>`, passing every extra flag (the retry ladder's --batch-size, the convergence member's --epochs 60) through to train.py; stop on the first failure. That python is the tools venv's, which has torch with CUDA. Write experiments/E2/jobs.json as one spec with two members, which keeps the GPU job count small: m1_n0 (seeds 1-20, out results/runs/E2/m1_n0) and converge (seeds 1-3 at --epochs 60, twice configs/arms.json's 30, out results/runs/E2/converge). Each member's expected_outputs lists, literally, the summary.json, heldout_scores.csv and config.json of every run it makes. Smoke-test point.sh on the CPU (--rows 500 --epochs 1 --device cpu into results/smoke/E2/), commit nothing under results/, then `wayline job add experiments/E2/jobs.json` and return running. Seed i drives both the generator and torch, as Q15 allows. Nothing is tuned and no seed is dropped; replicate 1's with run is checked against owner/sample-summary.json afterwards.

## Result

### Attempt 1

Added the Methods passage the ticket declares. Code and jobs are unchanged from commit 39287df on ticket/16, and `wayline accept` passes again. The point.sh runner and the two jobs are already registered. t16-1 runs seeds 1-20 in both arms (40 runs) under configs/arms.json into results/runs/E2/m1_n0. t16-2 runs seeds 1-3 in both arms at --epochs 60 (6 runs) into results/runs/E2/converge. Every run writes summary.json, heldout_scores.csv and config.json to its own directory. Caveat: point.sh was not smoke-tested here. Running the tools-venv python and bash on the script was denied in this session, so the first job is its first real test.

Wrote: `experiments/E2/point.sh`, `experiments/E2/jobs.json`

Ran: `wayline accept`, `wayline job add experiments/E2/jobs.json`

Jobs: `t16-1`, `t16-2`

Passages:

- methods, Arms and pinned settings: For E2, each replicate $i = 1..20$ uses seed $i$ for both the generator and torch, and is trained twice on the same draw with the pinned settings in configs/arms.json: once with the $x_3x_4$ column (the `with` arm) and once with --no-interaction (the `without` arm). Each run saves its held-out scores to its own directory, <root>/<arm>/seed<i>/ {code:experiments/E2/point.sh#L14-L22}. The `without` arm keeps the five-column design but fills the $x_3x_4$ column with 0.0. Both arms therefore start from the same initial weights and see the same minibatch order {code:src/toy/train.py#featurize}. To check convergence, replicates 1-3 are rerun in both arms at 60 epochs, twice the pinned 30. Any extra flag given to the runner is passed through to every run {code:experiments/E2/point.sh#L19-L20}.

Parameters:

- `experiments/E2/point.sh` `--epochs` = 60: The convergence check reruns replicates 1-3 at twice configs/arms.json's 30 pinned epochs, as SPEC E2 requires.
- `experiments/E2/point.sh` `--config` = configs/arms.json: E2-E4 use the pinned settings in configs/arms.json, so nothing is tuned.

Every job exited 0 and its outputs parsed: t16-1, t16-2.

**Verdict (diff): passed** by claude-opus-5-5, session `f9dabf23-c5ef-463a-9677-7447b443d828`.

- [minor] Line 13 lets an `E2_PYTHON` environment variable replace the tools-venv interpreter the ticket pins (`/home/bernaljp/.wayline/tools/venv/bin/python`). The ticket did not ask for this override, and neither summary.json nor config.json records which interpreter ran. Both job records (research/jobs/t16-1.json, t16-2.json) carry env {}, so these runs used the pinned default; the override is only a gap in provenance for any rerun. (experiments/E2/point.sh line 13 (as added in a1f4ac6): python="${E2_PYTHON:-/home/bernaljp/.wayline/tools/venv/bin/python}")
- [minor] The ticket asks for point.sh to be smoke-tested on the CPU (--rows 500 --epochs 1 --device cpu into results/smoke/E2/) before `wayline job add`. The Result says this was not done, and results/smoke/ holds no E2 output. This is a process step outside the diff, and it did no harm: t16-1 and t16-2 each finished in one attempt with exit 0 (research/jobs/t16-1.json and t16-2.json, attempts). (research/tickets/16-e2-experiment-20-paired-seeds-with-and-without-t.md line 34 (## Notes) against line 40 (## Result / ### Attempt 1, 'Caveat: point.sh was not smoke-tested here'))
- [minor] The Result's Parameters list places `--epochs` = 60 in experiments/E2/point.sh. The value is set in experiments/E2/jobs.json line 130, the converge member's command. point.sh only passes it through and names it in its header comment (line 6), so a Methods writer following that locator lands on the wrong file. This is outside the diff. (research/tickets/16-e2-experiment-20-paired-seeds-with-and-without-t.md line 54 (## Result, Parameters))

---
id: 49
title: Documentation site for the toy package and its new modules and flags
kind: docs
difficulty: 3
status: parked
blocked_by: [2, 3, 5, 8, 30, 31, 32, 33, 34, 52, 53]
touches: [docs/, .readthedocs.yaml, harness.json, code/src/toy/]
role: documentarian
skills: []
acceptance:
  machine: [test -f .readthedocs.yaml, grep -rqs 'toy.paired' docs/reference/ && grep -rqs 'toy.oracle' docs/reference/ && grep -rqs 'toy.sweep' docs/reference/ && grep -rqs 'toy.placement' docs/reference/ && grep -rqs 'toy.goallog' docs/reference/, grep -rqs -- '--no-interaction' docs/how-to/ && grep -rqs -- '--summary' docs/how-to/]
  quality: ["Does every page describe only what the code does, including train.py's arms and flags, the oracle ceiling and the held-out discipline, with no behaviour the code lacks?"]
objectives: []
context_pack: [research/INTAKE.md, research/SPEC.md#seams, code/src/toy/]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`wayline docs build` passes; the site's reference has a page for each public module including toy.paired, toy.oracle and toy.sweep, and a how-to runs one paired comparison with --no-interaction and reads it with toy.paired."
---

## Demo

`wayline docs build` passes; the site's reference has a page for each public module including toy.paired, toy.oracle and toy.sweep, and a how-to runs one paired comparison with --no-interaction and reads it with toy.paired.

## Notes

This is the project's first docs ticket. It runs after the layout decision is carried out, so the package is at code/src/toy/. Build the site with `wayline docs init --theme furo`, which records the theme in harness.json, and `wayline docs build`, in the project's environment. Reference: one page per public module (toy.generate, toy.train, toy.eval, toy.metrics, toy.stats, toy.oracle, toy.paired, toy.sweep, toy.converge, toy.goallog, toy.placement), with autodoc_mock_imports = ['torch']. How-to: run one paired comparison at a seed (train.py with and without --no-interaction, into two run directories), read it with toy.paired, and score a run with toy.eval --summary. Explanation: the two arms (Q14), the oracle ceiling, the held-out discipline, and the goal's keep rule. Touch code/src/toy/ only for docstrings, never behaviour. Three docstrings need fixing: train.py's module docstring and its ready_interactions docstring describe a down-weighting of duplicate rows that the code does not do, so make them say what the code does; eval.py's docstring calls the measure O1's when it is O2's. Run Python as python3 -B so no __pycache__ is left. Describe only what you read in the code or saw an example do.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73.

---
id: 83
title: "E1 experiment: oracle audit of the default generator on the 10^6-row draw D2"
kind: experiment
difficulty: 2
status: parked
blocked_by: []
touches: [experiments/E1/, results/E1/, results/smoke/E1/]
role: experimenter
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 8, wallclock_minutes: 120}
inputs: [src/toy/oracle.py, src/toy/generate.py]
outputs: [results/E1/oracle.json]
acceptance:
  machine: ["python3 -c \"import json; t = open('experiments/E1/jobs.json').read(); json.loads(t); assert 'toy.oracle' in t and '10001' in t and '1000000' in t and 'results/E1/oracle.json' in t\""]
  quality: ["Does the job run toy.oracle once on D2 (seed 10001, 10^6 rows, signal 4.0 and strength 1, CPU only) and write results/E1/oracle.json and nothing else?"]
objectives: [O3]
sections: [methods]
context_pack: [experiments/E2/jobs.json:1-10, tests/test_oracle_budget.py:1-14, src/toy/oracle.py:247-300, research/SPEC.md#e1-claims-c1-c2, research/SPEC.md#data]
origin: research/SPEC.md#e1-claims-c1-c2
proposed_by: planner
demo: "`wayline status` shows the E1 job running `toy.oracle --seed 10001 --rows 1000000` on one core; when it exits, results/E1/oracle.json holds the Bayes AUROC, its half-width, the calibration error, the weight on x3*x4 with its line, and the additive gap."
---

## Demo

`wayline status` shows the E1 job running `toy.oracle --seed 10001 --rows 1000000` on one core; when it exits, results/E1/oracle.json holds the Bayes AUROC, its half-width, the calibration error, the weight on x3*x4 with its line, and the additive gap.

## Notes

Re-cut of ticket 62, which never launched. Two changes. First, it no longer waits on #52. #52 rewrites oracle.py's comments and tests and drops the rounding of interaction_weight, which at D2's signal 4.0 prints 4.4 either way (4.0*1.1 is bit-identical to 4.4; ticket 6's verdict). #52's verdict also found that nothing in the probabilities, ceiling, calibration or additive gap changed, so the audit's numbers do not depend on it. Second, the job asks for 8 GB and 120 minutes. tests/test_oracle_budget.py (integrated by #53) states its 4 GB and one-hour bounds as half of that allowance; the audit it times took about 20 s and 0.7 GB. Write experiments/E1/jobs.json in the form of experiments/E2/jobs.json: one job, no GPU, and expected_outputs ["results/E1/oracle.json"]. Its command runs `PYTHONPATH=src python3 -B -m toy.oracle --seed 10001 --rows 1000000 --out results/E1/oracle.json` through a small experiments/E1/run.sh that sets PYTHONPATH. The CLI's default --signal 4.0 and --strength 1 are D2's default settings. toy.oracle is stdlib only, so the system python3 runs it. Smoke-test the same command at --rows 2000 into results/smoke/E1/oracle.json, and commit nothing under results/. Then run `wayline job add experiments/E1/jobs.json` and return running. Seed 10001 lies outside every replicate's seeds, so no model of E2-E5 sees D2. Nothing is repeated, since the draw's size gives the precision. Return one Methods passage, every sentence ending with a provenance tag that resolves ({code:src/toy/oracle.py#audit} and the like), and leave out any sentence you cannot tag. File no finding that states a number, because the job has not run. A passage that says what a current one says (the Methods section already has 'Oracle and Bayes ceiling' passages) names it in `replaces`. If a Bash command you need (python3, wayline, git) is refused, stop at once and return blocked naming it.

## Result

### Attempt 1

I wrote no jobs.json, run.sh, smoke output, commit or job. The Bash call was denied ("don't ask mode") after my first read-only Bash call had worked. The denied call was one compound command. It created experiments/E1, wrote run.sh and jobs.json with heredocs, ran the 2000-row smoke test, ran wayline accept, committed, and ran wayline job add. The ticket says to stop and return blocked if a needed Bash command is refused. I did not try to work around the denial.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113.

---
id: 174
title: "Draw R17: E5: the goal run against O2's 0.82 (C7)"
kind: drawing
difficulty: 2
status: parked
blocked_by: []
touches: [drawings/R17-2/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O2]
context_pack: []
origin: drawing R17-2 at order
proposed_by: conductor
demo: R17 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R17-2

Code opened this drawing of R17 ("E5: the goal run against O2's 0.82 (C7)") at a rest point (order), over its findings t111-a1-f1, t111-a1-f2, t111-a1-f3, t111-a1-f4, t111-a1-f5, t111-a1-f6, t111-a1-f7, t111-a1-f9. Its brief, rendered by code at each launch, is in the prompt.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 176, 177, 178, 179, 180, 181, 182, 183, 184, 185.

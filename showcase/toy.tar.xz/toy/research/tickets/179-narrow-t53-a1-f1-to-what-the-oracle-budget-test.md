---
id: 179
title: Narrow t53-a1-f1 to what the oracle budget test holds, re-pinning tests/test_oracle_budget.py if decision 152 says so (R6)
kind: writing
difficulty: 3
status: open
blocked_by: [152]
touches: []
role: writer
skills: [interval-claims]
inputs: [tests/test_oracle_budget.py, research/findings.jsonl, research/manifest.json]
acceptance:
  machine: []
  quality: ["Does the finding that replaces t53-a1-f1 follow decision 152's answer? Does it say only what the version of tests/test_oracle_budget.py it cites holds: its seed, rows and limits, each on a line its tags name, with no claim that the audit passed and no claim about D2 that the cited bytes contradict?"]
objectives: []
sections: [results]
context_pack: [research/findings.jsonl:21, research/sections/results.md:248-249, research/manifest.json:1300-1307, research/tickets/152-tests-test-oracle-budget-py-changed-after-run-t5.md, research/tickets/160-scope-down-a-report-claim-its-artifacts-do-not-s.md, research/tickets/156-re-file-the-oracle-budget-finding-r6-to-describe.md, tests/test_oracle_budget.py]
origin: research/REPORT.md#claim-562cff7c301dc8d1
proposed_by: planner
demo: "The general report renders one finding in place of t53-a1-f1 under \"Oracle audit cost on the 10^6-row draw D2\". If decision 152 re-registers the file, that finding says the committed test holds a 1000000-row stand-in audit at seed 20001 to 3600 seconds and 4.0 GiB, tagged at this ticket's run, and research/manifest.json then holds the current file so R6 can be drawn. Otherwise it says the same of run t53-a1's version, tagged at t53-a1. Neither claims the audit passed."
---

## Demo

The general report renders one finding in place of t53-a1-f1 under "Oracle audit cost on the 10^6-row draw D2". If decision 152 re-registers the file, that finding says the committed test holds a 1000000-row stand-in audit at seed 20001 to 3600 seconds and 4.0 GiB, tagged at this ticket's run, and research/manifest.json then holds the current file so R6 can be drawn. Otherwise it says the same of run t53-a1's version, tagged at t53-a1. Neither claims the audit passed.

## Notes

Why: t53-a1-f1 says the committed test audits D2 at seed 10001 and that the audit passed. The verifier (#160) found three problems:
- The file on main (commit 607722b) runs SEED = 20001, outside D1 and D2.
- No cited artifact records a run.
- The locator TIME_LIMIT_SECONDS reaches only the 3600 line.
The manifest still holds run t53-a1's bytes (2421 bytes, sha dea33416, git 017f053), so drawing R6 was blocked twice (#139, #167). Decision 152 asks whether to register the current file again. This ticket replaces #156 and #160 and waits on that answer.

By decision 152's answer:
- "Register the current file again ..." (its recommended answer): describe the current file. It runs `toy.oracle` on a 1000000-row stand-in draw at seed 20001, outside D1 (seeds 1-20) and D2 (seed 10001), so it never computes E1's own result. It asserts a wall-clock limit of TIME_LIMIT_SECONDS = 3600.0 and a peak child memory limit of MEMORY_LIMIT_GB = 4.0. That bound is in GiB, because peak_children_gb divides ru_maxrss (KiB on Linux) by 1024^2. End each sentence with `{res:t<this ticket>-a<this attempt>/tests/test_oracle_budget.py#L<a>-L<b>}` tags whose spans hold its numbers: ROWS, SEED and the two limits are at L29-L32, and peak_children_gb is at L36-L40 as the file stands. That re-pins the file at integration, and t53-a1-f1 is the only current finding that cites it.
- "Keep the t53-a1 registration and restore or archive the old bytes", or "Close the drawing without a table": write no own-run tag. Narrow t53-a1-f1 to what t53-a1's bytes hold (read them with `git log -p 017f053 -- tests/test_oracle_budget.py` or `git diff 017f053^ 017f053`). Write it in the past tense, as what the test held at run t53-a1, with `{res:t53-a1/tests/test_oracle_budget.py#L<a>-L<b>}` tags at spans valid in that version (ROWS, SEED and the limits at L26-L29 there). Archiving the old bytes needs a code ticket; say so in your result.

Either way, drop "the audit passed both when the test was run". No manifested or project artifact records the run: the acceptance record under research/sessions/ is not one. Say what the test asserts.

Return one finding with `replaces` t53-a1-f1, `heading` "Oracle audit cost on the 10^6-row draw D2", `negative` false, and `provenance` tests/test_oracle_budget.py#SEED. Edit no file. Return no passage.

---
id: 9
title: "toy.sweep: strength_spearman and gain_shrink across sweep points"
kind: code
difficulty: 3
status: parked
blocked_by: [7]
touches: [src/toy/sweep.py, tests/test_sweep.py, tests/fixtures/sweep/]
role: coder
skills: []
acceptance:
  machine: [PYTHONPATH=src python3 -B -m unittest tests.test_sweep, "PYTHONPATH=src python3 -B -m toy.sweep tests/fixtures/sweep/E3 --axis strength | python3 -c \"import json, sys; d = json.load(sys.stdin); assert 'strength_spearman' in d and d['points']\""]
  quality: ["Do strength_spearman and gain_shrink use exactly the points and the common seeds the spec names, read each point's strength and size from its runs' config.json, and take reused points from the directories given rather than re-running them?"]
objectives: [O4]
sections: [methods]
context_pack: [research/SPEC.md#e3-claims-c4-c5, research/SPEC.md#e4-claims-c6, research/SPEC.md#seams]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`python3 -m toy.sweep tests/fixtures/sweep/E3 --axis strength` prints a per-point table and strength_spearman; --axis rows --strength 1 on its fixture prints gain_shrink with its interval."
---

## Demo

`python3 -m toy.sweep tests/fixtures/sweep/E3 --axis strength` prints a per-point table and strength_spearman; --axis rows --strength 1 on its fixture prints gain_shrink with its interval.

## Notes

`toy.sweep <exp-dir> --axis strength|rows [--strength m] [--point DIR ...] [--out PATH]`. A point is a directory holding with/ and without/; read each point's strength and train_rows from its runs' config.json, never from its name. --point adds a point from another experiment (E3 reuses E2's m1_n0, E4 reuses E2's m1_n0 and E3's m0_n0). --axis strength: the points at a common training size; output points (per point: strength, train_rows and toy.paired.point_stats) and strength_spearman, the Spearman correlation (average ranks) between strength and paired_gain. --axis rows --strength m: the points at strength m ordered by train_rows; output points and gain_shrink = the mean over the seeds the two points share of (d_i at the smallest size - d_i at the largest size), with its paired 95% t-interval as gain_shrink_lo and gain_shrink_hi; an error when those two points share no seeds. Output JSON keys: points (a list) plus strength_spearman, or gain_shrink, gain_shrink_lo, gain_shrink_hi. Fixtures under tests/fixtures/sweep/ (an E3-like directory and a rows fixture) with answers worked by hand. Stdlib only; run Python with -B.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49.

---
id: 113
title: Documentation site for the toy package and its new modules and flags
kind: docs
difficulty: 3
status: parked
blocked_by: [2, 3, 5, 8, 96, 97, 98, 115, 116, 117, 118]
touches: [docs/, .readthedocs.yaml, harness.json, src/toy/train.py]
role: documentarian
skills: []
acceptance:
  machine: [test -f .readthedocs.yaml, grep -rqs 'toy.paired' docs/reference/ && grep -rqs 'toy.oracle' docs/reference/ && grep -rqs 'toy.sweep' docs/reference/ && grep -rqs 'toy.placement' docs/reference/ && grep -rqs 'toy.goallog' docs/reference/ && grep -rqs 'toy.converge' docs/reference/, grep -rqs -- '--no-interaction' docs/how-to/ && grep -rqs -- '--summary' docs/how-to/]
  quality: ["Does every page describe only what the code does, including train.py's arms and flags, the oracle ceiling and the held-out discipline, with no behaviour the code lacks?"]
objectives: []
context_pack: [research/INTAKE.md, research/SPEC.md#seams, src/toy/]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`wayline docs build` passes; the site's reference has a page for each public module including toy.paired, toy.oracle and toy.sweep, and a how-to runs one paired comparison with --no-interaction and reads it with toy.paired."
---

## Demo

`wayline docs build` passes; the site's reference has a page for each public module including toy.paired, toy.oracle and toy.sweep, and a how-to runs one paired comparison with --no-interaction and reads it with toy.paired.

## Notes

Re-cut of #93, which never launched. It no longer waits on #52, which holds src/toy/oracle.py and has failed four attempts. It does not touch oracle.py, and autodoc picks up oracle.py's docstrings as they stand when the site builds. #52's own item 6, on the docstrings that say what signal to pass, stays #52's. This is the project's first docs ticket; the package is at src/toy/ (decision #50 kept the old layout). Build the site with `wayline docs init --theme furo`, which records the theme in harness.json, and `wayline docs build`. harness.json carries the owner's edit dd64a6a (no code_repository), and the init may add only the docs theme. Do not put code_repository back, and do not touch the budgets, the autonomy or the human-only classes. Reference: one page per public module (toy.generate, toy.train, toy.eval, toy.metrics, toy.stats, toy.oracle, toy.paired, toy.sweep, toy.converge, toy.goallog, toy.placement), with autodoc_mock_imports = ['torch']. How-to: run one paired comparison at a seed (train.py with and without --no-interaction, into two run directories with --save-scores), read it with toy.paired, and score a run with toy.eval --summary. Explanation: the two arms (Q14), the oracle ceiling, the held-out discipline, and the goal's keep rule. In src/toy/ touch only train.py, and only its docstrings, never its behaviour. Its module docstring and its ready_interactions docstring describe a down-weighting of duplicate rows that the code does not do: make them say what the code does. Describe only what you read in the code or saw an example do. Bash: this role runs a command only when every part of it begins with a program on its allow list: wayline docs, wayline accept, python3, git add, git commit, git status, git diff, git log, ls and cat. A `PYTHONPATH=` prefix, mkdir, bash, heredocs and `>` redirects are refused, and those refusals blocked tickets 16, 76 and 83. Write files with the Write tool (it creates directories), run one plain command per Bash call, and retry a refused command in an allowed form before you return blocked, naming it.

## Result

### Attempt 1

I wrote the full Sphinx site for toy, with the furo theme. It has a tutorial for a first paired comparison and two how-to guides. The first how-to trains both arms with --no-interaction, reads one run with toy.eval --summary and reads the point with toy.paired. The second covers toy.sweep, converge, goallog and placement. There is also a reference page per public module, an explanation of the design and its limits, a gallery figure drawn by the build from toy.oracle.audit, and four example scripts. The build runs all four examples and they pass, including one that really trains torch on the CPU. `wayline docs build` passes 6 of its 7 checks: structure, examples, build (no warnings), reference, site and links. The docstrings check fails because 15 public functions have no docstring, and all of them are in modules outside this ticket's touch set. I added the three that were missing in src/toy/train.py, the only source file I could edit. Because that one check fails, `wayline accept` fails on the `wayline docs build` criterion. The criteria that were checked passed: .readthedocs.yaml exists, the reference greps for every module pass, and the how-to greps for --no-interaction and --summary pass. Everything is committed on ticket/113 as eb1db82.

Wrote: `.readthedocs.yaml`, `harness.json`, `src/toy/train.py`, `docs/conf.py`, `docs/requirements.txt`, `docs/index.rst`, `docs/tutorials/index.rst`, `docs/tutorials/first-paired-comparison.rst`, `docs/how-to/index.rst`, `docs/how-to/run-a-paired-comparison.rst`, `docs/how-to/sweep-strength-or-rows.rst`, `docs/explanation/index.rst`, `docs/explanation/design.rst`, `docs/gallery/index.rst`, `docs/examples/index.rst`, `docs/examples/oracle_ceiling.py`, `docs/examples/paired_comparison.py`, `docs/examples/read_fixtures.py`, `docs/examples/plot_additive_gap.py`, `docs/reference/index.rst`, `docs/reference/toy.converge.rst`, `docs/reference/toy.eval.rst`, `docs/reference/toy.generate.rst`, `docs/reference/toy.goallog.rst`, `docs/reference/toy.metrics.rst`, `docs/reference/toy.oracle.rst`, `docs/reference/toy.paired.rst`, `docs/reference/toy.placement.rst`, `docs/reference/toy.stats.rst`, `docs/reference/toy.sweep.rst`, `docs/reference/toy.train.rst`

Ran: `wayline docs init --theme furo`, `wayline docs env (three times: skeleton requirements, then with matplotlib, then with CPU torch)`, `wayline docs build (repeatedly; final: 6/7 checks pass, docstrings fails on 15 symbols outside the touch set)`, `wayline accept (fail: only the `wayline docs build` criterion)`, `git commit on ticket/113 (eb1db82)`

Not methods:

- `code/src/toy/train.py#is_under_owner`: Only a docstring was added; it is a path guard that refuses writes under owner/, not a method.
- `code/src/toy/train.py#build_parser`: Only a docstring was added; it builds the command-line parser.
- `code/src/toy/train.py#main`: Only a docstring was added; it is the CLI entry point, and its behavior is unchanged.

Proposed Docstrings for the 15 public functions the docs build reports as undocumented (code) (admission decides what joins the graph).

## Superseded

Re-cut by the planner with the owner's change; its replacements are tickets 128, 129, 130, 131.

---
id: 116
title: "toy.paired: pair the arms on every pinned training setting, differing only in the x3*x4 column"
kind: code
difficulty: 3
status: accepted
blocked_by: [5, 115]
touches: [src/toy/paired.py, tests/test_paired.py, tests/fixtures/paired/]
role: coder
skills: []
inputs: [src/toy/paired.py, tests/test_paired.py, tests/fixtures/paired/point/, src/toy/train.py, configs/arms.json]
outputs: [src/toy/paired.py, tests/test_paired.py, tests/fixtures/paired/point/]
acceptance:
  machine: [PYTHONPATH=src python3 -B -m unittest tests.test_paired && PYTHONPATH=src python3 -B -m unittest tests.test_paired.PinnedSettings, "e='import json, sys; p, k, v = sys.argv[1:4]; c = json.load(open(p)); c[k] = json.loads(v); open(p, \"w\").write(json.dumps(c))'; d=$(mktemp -d) && cp -r tests/fixtures/paired/point \"$d/a\" && cp -r tests/fixtures/paired/point \"$d/b\" && python3 -c \"$e\" \"$d/a/without/seed2/config.json\" batch_size 64 && python3 -c \"$e\" \"$d/b/without/seed2/config.json\" epochs 60 && PYTHONPATH=src python3 -B -m toy.paired \"$d/a\" > \"$d/a.json\" && python3 -c \"import json, sys; a = json.load(open(sys.argv[1])); assert a['n_pairs'] == 3 and abs(a['paired_gain'] - 2 / 15) < 1e-12\" \"$d/a.json\" && { PYTHONPATH=src python3 -B -m toy.paired \"$d/b\" > /dev/null 2> \"$d/b.err\"; test $? -eq 2; } && grep -qw epochs \"$d/b.err\"", "e='import json, sys; p, k, v = sys.argv[1:4]; c = json.load(open(p)); c[k] = json.loads(v); open(p, \"w\").write(json.dumps(c))'; d=$(mktemp -d) && for x in f p r; do cp -r tests/fixtures/paired/point \"$d/$x\" || exit 1; done && python3 -c \"$e\" \"$d/f/with/seed1/config.json\" features '[\"x1\", \"x2\", \"x3\", \"x4\"]' && python3 -c \"$e\" \"$d/p/without/seed3/config.json\" pinned '{\"weight_decay\": 0.01}' && python3 -c \"$e\" \"$d/r/with/seed3/config.json\" lr 0.05 && python3 -c \"$e\" \"$d/r/without/seed3/config.json\" lr 0.05 && for x in f:features p:pinned r:lr; do { PYTHONPATH=src python3 -B -m toy.paired \"$d/${x%%:*}\" > /dev/null 2> \"$d/err\"; test $? -eq 2; } && grep -qw \"${x#*:}\" \"$d/err\" || exit 1; done", "python3 -c \"import glob, json; fs = sorted(glob.glob('tests/fixtures/paired/point/*/seed*/config.json')); assert len(fs) == 6 and all({'features', 'val_fraction', 'epochs', 'lr', 'minibatch', 'pinned'} <= set(json.load(open(f))) for f in fs)\" && PYTHONPATH=src python3 -B -m toy.paired tests/fixtures/paired/point | python3 -c \"import json, sys; d = json.load(sys.stdin); assert d['n_pairs'] == 3 and (d['epochs'], d['lr'], d['minibatch']) == (30, 0.1, 256) and abs(d['paired_gain'] - 2 / 15) < 1e-12\""]
  quality: ["Does toy.paired refuse, rather than drop or summarise, a replicate whose arms differ in anything but the x3*x4 column and the settings that cannot change the fit (batch_size, dataloader_workers, device, the config path), and a point whose replicates differ in a pinned setting, as SPEC.md#methods' Arms (Q14) requires?"]
objectives: [O1, O3, O4]
sections: [methods]
context_pack: [src/toy/train.py:47-61, src/toy/train.py:224-233, configs/arms.json, tests/fixtures/paired/point/with/seed1/config.json, research/sections/methods.md:19-26, src/toy/paired.py, tests/test_paired.py, research/tickets/76-toy-paired-paired-statistics-of-one-sweep-point.md, research/SPEC.md#methods]
origin: research/SPEC.md#methods
proposed_by: planner
demo: "On copies of the fixture, toy.paired exits 2 naming the setting in three cases: the without arm at seed 2 trained 60 epochs, the with arm at seed 1 lists no interaction column, or the arms' pinned settings differ. A copy whose arms differ only in batch_size prints the fixture's paired_gain of 2/15. The fixture's own output now carries epochs 30, lr 0.1 and minibatch 256."
---

## Demo

On copies of the fixture, toy.paired exits 2 naming the setting in three cases: the without arm at seed 2 trained 60 epochs, the with arm at seed 1 lists no interaction column, or the arms' pinned settings differ. A copy whose arms differ only in batch_size prints the fixture's paired_gain of 2/15. The fixture's own output now carries epochs 30, lr 0.1 and minibatch 256.

## Notes

Cut from ticket 76 by the planner's split.

Split from #76; runs after T1, on the same files. SPEC.md#methods, Arms (Q14): the two arms share the model, optimiser, epochs, learning rate, any regularisation, both seeds and the held-out fifth, and differ only in the x3*x4 column. Today toy.paired pairs them on five keys only (PAIRED_KEYS: seed, strength, signal, rows, train_rows), so a pair trained at different epochs is summarised without complaint (#76's verdict). train.py's config.json holds seed, arm, features, strength, signal, rows, train_rows, val_fraction, epochs, lr, minibatch, batch_size, dataloader_workers, device, config and pinned, where pinned is the content of configs/arms.json (src/toy/train.py:227-232).

1. replicate refuses, with a ValueError (so exit 2) that names the key, when:
- the two arms of a seed disagree on any of seed, strength, signal, rows, train_rows, val_fraction, epochs, lr, minibatch or pinned; or
- the with arm's features are not the without arm's features followed by 'interaction'.
A run whose config.json lacks one of these keys, or lacks features, is refused as not written by train.py.
2. These are not compared, and the module docstring says why:
- batch_size: it sizes a scratch matrix that train() allocates and frees before the fit and that never reaches it (src/toy/train.py:54-61, 110-111), and the GPU-OOM retry ladder shrinks it;
- dataloader_workers and device: the scheduler may vary them;
- config: it is only the path, and pinned carries its content.
3. summarize refuses a point whose replicates disagree on strength, signal, rows, train_rows, val_fraction, epochs, lr, minibatch or pinned, and names the key. Its dict carries epochs, lr and minibatch beside strength, signal, rows and train_rows.
4. Each of the six config.json under tests/fixtures/paired/point lacks some keys train.py writes. Add them: val_fraction 0.0, minibatch 256, batch_size 256, dataloader_workers 0, device "cpu", config "configs/arms.json", and a pinned dict, the same in all six: optimizer Adam, lr 0.1, epochs 30, minibatch 256, weight_decay 0.0, signal 4.0, rows 50, held_out_fraction 0.2, seeds [1, 2, 3]. Leave the scores, summaries and labels alone: every hand-worked answer stays.
5. Add a test class `PinnedSettings` that shows each refusal of points 1 and 3. It also shows that a pair differing only in batch_size, dataloader_workers or device is summarised with the fixture's statistics. Update the Summarize tests' record helper for the new keys. T1's Interface tests and every existing test must keep passing.

Result rules. The harness checks the Result against these; #76 failed on them.
- Return one Methods passage that replaces P15 (research/sections/methods.md:25-26, from #76), and name P15 in `replaces`. It states the whole pairing rule: what both arms share, the one column they differ in, what is not compared and why, the refusal of arms that ran different seeds, and the rule that a point's replicates share their settings.
- End every sentence with a provenance tag that resolves, such as {code:src/toy/paired.py#replicate}, {code:src/toy/paired.py#seeds} or {code:src/toy/paired.py#summarize}. Leave out any sentence you cannot tag.
- File one finding that replaces t76-a1-f2 (#76's list of refusals), name it in `replaces`, and cite tests/test_paired.py#PinnedSettings or tests/test_paired.py#Refusals.
- Under Not methods, never list seeds, replicate, summarize, point_stats or any other function a passage cites. #76's verdict failed on exactly that.
- A finding that states a number cites a locator holding that literal number.
- Leave a passage's evidence unset.

Bash. This role runs a command only when every part of it begins with a program on its allow list: python3, git add, git commit, git status, git diff, git log, ls, cat and wayline accept. These are refused: a `PYTHONPATH=src` prefix, mkdir, bash, heredocs, `>` redirects into a file, and the venv's python called by its path. Those refusals blocked tickets 16, 76 and 83. So:
- write every file with the Write tool;
- run one plain command per Bash call;
- let `wayline accept` run the tests and the criteria;
- for a check of your own, run `python3 -B -c "import sys; sys.path.insert(0, 'src'); ..."`.
Retry a refused command in an allowed form, and return blocked only when that form is refused too.

## Result

### Attempt 1

toy.paired now pairs the two arms on every training setting train.py records, not only the draw. read_run requires each config.json to record seed, strength, signal, rows, train_rows, val_fraction, epochs, lr, minibatch, pinned and features, and refuses a run whose features are not its arm's: x1..x4 plus interaction for with, x1..x4 for without. replicate refuses a seed whose two runs disagree on any of PAIRED_KEYS + TRAINING_KEYS (val_fraction, epochs, lr, minibatch, the pinned --config contents). summarize refuses replicates of one point that disagree on any of them, comparing values by their sorted-key JSON so the pinned dict compares by content. batch_size, dataloader_workers and device are deliberately not compared: they do not touch the fit, and the retry ladder may change them. The printed record and each per_seed entry now carry val_fraction, epochs, lr, minibatch and pinned. The six fixture config.json files were rewritten in train.py's run-directory form (adding batch_size, config, dataloader_workers, device, minibatch, pinned, val_fraction); the scores and summaries are unchanged. tests/test_paired.py: _record carries the new keys, HandWorkedAnswers checks the fixture's training settings, and a new PinnedSettings class covers each refusal and the batch_size-only case. Nothing outside tests/test_paired.py calls toy.paired. Running python3 directly is refused in this session, so the tests and the acceptance commands ran only through `wayline accept`, which passed all four. Committed as 1617509 on ticket/116; the tree is clean.

Wrote: `src/toy/paired.py`, `tests/test_paired.py`, `tests/fixtures/paired/point/with/seed1/config.json`, `tests/fixtures/paired/point/with/seed2/config.json`, `tests/fixtures/paired/point/with/seed3/config.json`, `tests/fixtures/paired/point/without/seed1/config.json`, `tests/fixtures/paired/point/without/seed2/config.json`, `tests/fixtures/paired/point/without/seed3/config.json`

Ran: `wayline accept (all four acceptance commands ok)`, `git commit on ticket/116 (1617509)`

Passages:

- methods, Statistics, replacing P15: toy.paired refuses to summarise a replicate whose two runs disagree on seed, strength, signal, rows or training rows, whose arms scored different labels, whose labels are not the held-out rows the generator draws from the recorded settings, or whose summary AUROC is not the AUROC of its own saved scores {code:src/toy/paired.py#replicate}. It also refuses a replicate whose two runs disagree on any training setting train.py records: the validation fraction, epochs, learning rate, minibatch size and the pinned settings file's contents {code:src/toy/paired.py#TRAINING_KEYS}. It refuses a run whose feature columns are not its arm's, $x_1..x_4$ and $x_3x_4$ for the with arm and $x_1..x_4$ for the without arm, so the arms differ only in that one column {code:src/toy/paired.py#read_run}. It refuses a point whose replicates disagree on any of these settings {code:src/toy/paired.py#summarize}, and a point whose two arms ran different sets of seeds {code:src/toy/paired.py#seeds}.

Parameters:

- `toy.paired.replicate` `TRAINING_KEYS`: These are the training settings train.py writes to a run's config.json that SPEC.md#methods (Arms, Pinned settings, Q14) requires both arms to share; batch_size, dataloader_workers and device are left out because they size a diagnostic allocation or choose the hardware and do not change the fit.
- `toy.paired.read_run` `ARM_FEATURES`: The with arm's columns are toy.generate.FEATURES plus interaction and the without arm's are FEATURES alone, as train.py records them, so the arms differ only in the x3*x4 column.

**Verdict (result): failed** by claude-opus-5-5, session `9bc33bec-4457-4a73-944b-2a07bd8d27af`.

- [blocker] The ticket's Result rule (line 47) requires the passage replacing P15 to state what is not compared and why, but P30 never mentions batch_size, dataloader_workers, device or the config path, though such a sentence was taggable (#TRAINING_KEYS resolves). Its 'any training setting train.py records' therefore reads as covering batch_size and device, which train.py writes to config.json (train.py:230-232) and toy.paired does not compare (paired.py:31-33, 143), so the paper's Methods describes a stricter pairing than the code enforces. (research/tickets/116-toy-paired-pair-the-arms-on-every-pinned-trainin.md:73 (## Result, Passages, replacing P15), against :47 (Result rules); research/sections/methods.md:26 (P30))
- [major] The ticket requires one finding that replaces t76-a1-f2 and names it in `replaces`, and the result schema allows that field (research/sessions/116/1/schema.json:74-80), but t116-a1-f1 has replaces null. Its text also lists only the new arm-level refusals, leaving out #76's refusals and the point-level refusal that PinnedSettings tests, so the ledger keeps two partial refusal lists (both true) instead of one complete one. (research/findings.jsonl:63 (t116-a1-f1, "replaces":null); research/sessions/116/1/result.json:130-136; research/tickets/116-toy-paired-pair-the-arms-on-every-pinned-trainin.md:49 (Result rules))
- [minor] Note 4 asks for config "configs/arms.json" and a pinned dict that includes seeds [1, 2, 3], but all six files have "config": "arms.json" and a pinned dict with no seeds, the seed list SPEC.md:39 says configs/arms.json records. The Result calls these files train.py's run-directory form without disclosing the departure; no test outcome depends on it. (tests/fixtures/paired/point/with/seed1/config.json:4 and :11 (the same in the other five files); research/tickets/116-toy-paired-pair-the-arms-on-every-pinned-trainin.md:43 (Notes, item 4))
- [minor] Note 2 asks the module docstring to say why config is not compared (it is only the path; pinned carries its content), but the docstring explains only batch_size, dataloader_workers and device. The code is right: config is in neither key tuple. (src/toy/paired.py:31-33 (module docstring); research/tickets/116-toy-paired-pair-the-arms-on-every-pinned-trainin.md:41 (Notes, item 2))
- [minor] The reason and the summary say device does 'not change the fit', but train.py picks the device by availability (train.py:204) and runs the fit on it (train.py:113-126), and CPU and CUDA arithmetic need not agree bitwise. The sounder reason is that SPEC.md:38 does not list the device among what the arms share, and the docstring's 'the retry ladder may change' device is not borne out either, since the job specs' ladder steps only --batch-size (research/jobs/t106-6.json:150-156). (research/tickets/116-toy-paired-pair-the-arms-on-every-pinned-trainin.md:77 (## Result, Parameters: TRAINING_KEYS) and :65 (Result summary); src/toy/paired.py:32-33)
- [minor] PinnedSettings shows a missing epochs key refused (:434-439) but not a missing features key, which Note 1 names (ticket line 37). It shows the point-level refusal for lr and pinned only (:441-444, :452-458); the code covers all these cases (paired.py:105-107, 166, 173-176), so the gap is in what the class shows, not in behaviour. (tests/test_paired.py:376-458 (class PinnedSettings))
- [minor] python3 was refused in this session, so I could not run the tests or the acceptance commands myself. I traced the 11 PinnedSettings tests and the three acceptance shell commands by hand against paired.py and the fixtures, and the pass otherwise rests on acceptance.json (44 and 11 tests OK, 4/4 commands, run 19:30:58Z, nine seconds before commit 1617509, whose eight files are identical to main's f2e541d). (research/sessions/116/1/acceptance.json:1-31)

### Attempt 1

Attempt 2 fixes the verifier's points on attempt 1. Code (commit 0e5b254 on ticket/116, tree clean):

- src/toy/paired.py adds NOT_COMPARED = (batch_size, dataloader_workers, device, config). The module docstring now gives the reason for each:
  - batch_size sizes a scratch matrix train() allocates and frees before the fit (train.py ready_interactions), and the GPU-OOM ladder shrinks it.
  - dataloader_workers is the number of loader processes, not which rows load or in what order (the shuffle is seeded), and the host-OOM ladder shrinks it, per train.py's --dataloader-workers help.
  - device is whichever of cuda and cpu the job's machine had. CPU and CUDA arithmetic need not agree bit for bit, so such a pair is paired at that precision. The earlier claim that device does not change the fit is withdrawn.
  - config is only the path; pinned carries its content, which is compared.
  - The docstring also says SPEC.md#methods' Arms (Q14) lists none of the four among what the arms share. The compared keys and the refusals are unchanged from attempt 1.
- The six fixture config.json files now record config "configs/arms.json" and a pinned dict with seeds [1, 2, 3], as Note 4 asks. Scores, summaries and labels are untouched.
- tests/test_paired.py PinnedSettings now also shows:
  - every compared key, including features, refused when missing;
  - every training setting (val_fraction, epochs, lr, minibatch, pinned) refused across the replicates of a point;
  - each not-compared key, changed alone, leaving the fixture's statistics unchanged;
  - the fixture's keys are exactly PAIRED_KEYS + TRAINING_KEYS + NOT_COMPARED + arm + features, with no overlap between compared and not compared.

Result:

- The Methods passage states the whole pairing rule, including what is not compared and why. It replaces P30, the passage attempt 1 put in P15's place; the worktree's research/sections/methods.md no longer holds P15.
- The one finding replaces t76-a1-f2 and lists every refusal. It also subsumes attempt 1's t116-a1-f1, which the harness may withdraw.

Checks: python3 is refused in this session, so the tests and acceptance commands ran only through `wayline accept`, which passed 4/4.

Wrote: `src/toy/paired.py`, `tests/test_paired.py`, `tests/fixtures/paired/point/with/seed1/config.json`, `tests/fixtures/paired/point/with/seed2/config.json`, `tests/fixtures/paired/point/with/seed3/config.json`, `tests/fixtures/paired/point/without/seed1/config.json`, `tests/fixtures/paired/point/without/seed2/config.json`, `tests/fixtures/paired/point/without/seed3/config.json`

Ran: `wayline accept (4/4 ok)`, `git add src/toy/paired.py tests/test_paired.py tests/fixtures/paired`, `git commit on ticket/116 (0e5b254)`, `git status --short (clean)`

Passages:

- methods, Statistics, replacing P30: toy.paired pairs the two arms of a seed only when both runs record the same draw (seed, strength, signal, rows and training rows) and the same training settings (validation fraction, epochs, learning rate, minibatch size and the content of the pinned settings file), and refuses the replicate otherwise {code:src/toy/paired.py#replicate}. The one column the arms differ in is $x_3x_4$: a with run must record the features $x_1..x_4$ and the interaction, a without run $x_1..x_4$ alone, and a run that records other features, or lacks a compared key, is refused {code:src/toy/paired.py#read_run}. It also refuses a replicate whose arms scored different labels, whose labels are not the held-out rows the generator draws from the recorded settings, or whose summary AUROC is not the AUROC of its own saved scores {code:src/toy/paired.py#replicate}. Four keys the runs record are not compared, and the spec's list of what the arms share names none of them {code:src/toy/paired.py#NOT_COMPARED}. The batch size only sizes a scratch matrix that training allocates and frees before the fit {code:src/toy/train.py#ready_interactions}. The number of data-loading workers sets how many processes load the seeded minibatches, not which rows they hold {code:src/toy/paired.py#NOT_COMPARED}. The device is whichever of CUDA and CPU the job's machine had, so a pair run on different devices is paired only at the precision the two agree to {code:src/toy/paired.py#NOT_COMPARED}. The pinned settings file's path is not compared because its content is {code:src/toy/paired.py#TRAINING_KEYS}. A point is refused when its two arms ran different sets of seeds {code:src/toy/paired.py#seeds}, and when its replicates disagree on any compared draw or training setting {code:src/toy/paired.py#summarize}.

Parameters:

- `toy.paired.replicate` `TRAINING_KEYS`: These are the training settings train.py writes to a run's config.json that SPEC.md#methods' Arms and Pinned settings (Q14) require both arms, and so every replicate of a point, to share: validation fraction, epochs, learning rate, minibatch size and the pinned settings content.
- `toy.paired.replicate` `NOT_COMPARED`: SPEC.md#methods' Arms (Q14) lists none of these among what the arms share: batch_size sizes a scratch matrix freed before the fit, dataloader_workers sets how many processes load the seeded minibatches, device is the job machine's (pairing at the precision CPU and CUDA agree to), and config is only the path whose content pinned carries.
- `toy.paired.read_run` `ARM_FEATURES`: The with arm's columns are toy.generate.FEATURES plus interaction and the without arm's are FEATURES alone, as train.py records them, so the arms differ only in the x3*x4 column.

### Attempt 2

The failed check was the result's findings, not the code. My single finding repeated attempt 1's t116-a1-f1 without naming it in `replaces`. I split it into two findings:
- Finding 1 replaces t76-a1-f2, as the ticket's rules require. It covers the draw-level and point-level refusals and cites tests/test_paired.py#Refusals.
- Finding 2 replaces t116-a1-f1 and says the same thing more fully. It covers the arm-level training-setting and feature refusals, the missing-key refusal, and the keys left uncompared. It cites tests/test_paired.py#PinnedSettings.

The code is unchanged and needed no new commit: branch ticket/116 holds f2e541d (already on main) and 0e5b254, and the tree is clean. `wayline accept` passes again, 4/4.

What the code does:
- read_run requires every compared key and features to be present, and refuses features that are not the arm's.
- replicate refuses a seed whose arms disagree on PAIRED_KEYS + TRAINING_KEYS, and names the key.
- summarize refuses a point whose replicates disagree on any of those keys, and prints epochs, lr and minibatch.
- NOT_COMPARED (batch_size, dataloader_workers, device, config) is listed, and the docstring says why each is left out.
- The fixture's config.json files record config "configs/arms.json" and a pinned dict that includes seeds [1, 2, 3]. Every hand-worked answer stands: paired_gain 2/15, and the output carries epochs 30, lr 0.1, minibatch 256.

The Methods passage replaces P30.

Wrote: `src/toy/paired.py`, `tests/test_paired.py`, `tests/fixtures/paired/point/with/seed1/config.json`, `tests/fixtures/paired/point/with/seed2/config.json`, `tests/fixtures/paired/point/with/seed3/config.json`, `tests/fixtures/paired/point/without/seed1/config.json`, `tests/fixtures/paired/point/without/seed2/config.json`, `tests/fixtures/paired/point/without/seed3/config.json`

Ran: `wayline accept (4/4 ok; research/sessions/116/2/acceptance.json)`, `git status --short (clean; code committed as 0e5b254 on ticket/116)`

Passages:

- methods, Statistics, replacing P30: toy.paired pairs the two arms of a seed only when both runs record the same draw (seed, strength, signal, rows and training rows) and the same training settings (validation fraction, epochs, learning rate, minibatch size and the content of the pinned settings file), and refuses the replicate otherwise {code:src/toy/paired.py#replicate}. The one column the arms differ in is $x_3x_4$: a with run must record the features $x_1..x_4$ and the interaction, a without run $x_1..x_4$ alone, and a run that records other features, or lacks a compared key, is refused {code:src/toy/paired.py#read_run}. It also refuses a replicate whose arms scored different labels, whose labels are not the held-out rows the generator draws from the recorded settings, or whose summary AUROC is not the AUROC of its own saved scores {code:src/toy/paired.py#replicate}. Four keys the runs record are not compared, and the spec's list of what the arms share names none of them {code:src/toy/paired.py#NOT_COMPARED}. The batch size only sizes a scratch matrix that training allocates and frees before the fit {code:src/toy/train.py#ready_interactions}. The number of data-loading workers sets how many processes load the seeded minibatches, not which rows they hold {code:src/toy/paired.py#NOT_COMPARED}. The device is whichever of CUDA and CPU the job's machine had, so a pair run on different devices is paired only at the precision the two agree to {code:src/toy/paired.py#NOT_COMPARED}. The pinned settings file's path is not compared because its content is {code:src/toy/paired.py#TRAINING_KEYS}. A point is refused when its two arms ran different sets of seeds {code:src/toy/paired.py#seeds}, and when its replicates disagree on any compared draw or training setting {code:src/toy/paired.py#summarize}.

Parameters:

- `toy.paired.replicate` `TRAINING_KEYS`: These are the training settings train.py writes to a run's config.json that SPEC.md#methods' Arms and Pinned settings (Q14) require both arms, and so every replicate of a point, to share: validation fraction, epochs, learning rate, minibatch size and the pinned settings content.
- `toy.paired.replicate` `NOT_COMPARED`: SPEC.md#methods' Arms (Q14) lists none of these among what the arms share: batch_size sizes a scratch matrix freed before the fit, dataloader_workers sets how many processes load the seeded minibatches, device is the job machine's (pairing at the precision CPU and CUDA agree to), and config is only the path whose content pinned carries.
- `toy.paired.read_run` `ARM_FEATURES`: The with arm's columns are toy.generate.FEATURES plus interaction and the without arm's are FEATURES alone, as train.py records them, so the arms differ only in the x3*x4 column.

**Verdict (result): passed** by claude-opus-5-5, session `5fea6386-1635-43cc-ad07-86759b96dcbf`.

- [minor] Finding t116-a2-f1, which replaces t76-a1-f2, cites tests/test_paired.py#Refusals, but no test in that class shows its last clause, 'a point whose replicates disagree on any compared setting' (that is in Summarize, :204-207, and PinnedSettings, :456-468). For a seed's arms disagreeing on the draw, Refusals shows only strength (:322-325), not seed, signal, rows or train_rows; every clause is true of the code (paired.py:157-159, 187-190). (research/findings.jsonl:66 (t116-a2-f1, provenance tests/test_paired.py#Refusals); tests/test_paired.py:304-373 (class Refusals))
- [minor] Note 5 asks PinnedSettings to show each refusal of Notes 1 and 3, but no test in the file shows arms that disagree on seed, signal, rows or train_rows, or replicates that disagree on signal, rows or train_rows. The code refuses all of these in the same loops the tests exercise (paired.py:157-159, 187-190), so the gap is in what the tests show, not in behaviour. (tests/test_paired.py:376-490 (class PinnedSettings) and :204-207 (Summarize); research/tickets/116-toy-paired-pair-the-arms-on-every-pinned-trainin.md:44 (Notes, item 5))
- [minor] The module docstring says the host-OOM retry ladder shrinks dataloader_workers, but all 38 job specs under research/jobs have "host_oom": [] and the harness steps only that ladder after doubling memory (harness wayline/resources.py:2044-2059), so the claim rests on train.py:163's help text alone. The reason not to compare the key stands without it, and neither P35 nor the NOT_COMPARED reason repeats the claim. (src/toy/paired.py:40-41 (module docstring); research/jobs/t106-6.json:150; src/toy/train.py:163)
- [minor] Outside the subject: the rendered Parameters table still shows attempt 1's TRAINING_KEYS reason ('...do not change the fit', withdrawn in attempt 2) and has no NOT_COMPARED row. methods.md was rendered at 21:03:41.660Z, 74 ms before research/sessions/116/2/methods.json was written, because _close files passages before write_code_rule (harness wayline/conductor.py:5150-5162); the next render should pick up attempt 2's reasons. (research/sections/methods.md:140 (Parameters table, TRAINING_KEYS row); research/sessions/116/2/methods.json; /home/bernaljp/wayline-m8/harness/wayline/conductor.py:5150-5162)
- [minor] python3 was refused in this session, so I could not run the tests or the acceptance commands; I traced PinnedSettings and the three acceptance shell commands by hand against paired.py and the fixtures. The pass otherwise rests on the harness's acceptance events (46 and 13 tests OK, 4/4 commands, in the worktree, rebased and on main), and git diff shows the eight files on main (849de99) and in the worktree identical to 0e5b254. (research/journal.jsonl:2270-2272 (acceptance events: worktree, rebased, main); research/sessions/116/2/acceptance.json:1-31)

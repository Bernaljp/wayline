---
id: 137
title: "Draw R4: toy.oracle: the generator's true P(y=1|x), Bayes ceiling, calibration and additive gap"
kind: drawing
difficulty: 2
status: failed
blocked_by: []
touches: [drawings/R4-1/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O1, O3]
context_pack: []
origin: drawing R4-1 at run_end
proposed_by: conductor
demo: R4 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R4-1

Code opened this drawing of R4 ("toy.oracle: the generator's true P(y=1|x), Bayes ceiling, calibration and additive gap") at a rest point (run_end), over its findings t6-a1-f1, t6-a1-f2, t6-a1-f3, t6-a1-f4, t6-a1-f5, t52-a1-f1, t52-a1-f2, t52-a4-f1. Its brief, rendered by code at each launch, is in the prompt.

## Result

### Attempt 1

Fixed the failed checks. draw.py no longer reads src/toy/generate.py, whose hash no longer matches the manifest; it takes the latent weights (linear_weights, interaction_weight) and noise_sd from results/E1/oracle.json, which is now the drawing's only input. The house colours are now the axes' default colours, so seaborn's #4C72B0 no longer appears in any SVG. The calibration plot's x-axis label is now 34 characters. numbers.json now holds the 0.999 quantile level. Every finding sentence now ends with its own res tags for each number it quotes, and finding 3 now states the sign on each side of the curve correctly. The plot numbers are unchanged: Bayes ceiling 0.8555, additive model 0.7681, gap 0.0882, worst calibration bin 0.003901, sum of squared z 18.013 on 20 df. I could not run `wayline drawing check` or `wayline numbers check` myself in this session (permission denied). I checked the plots and SVG colours by hand, `wayline accept` passes, and the work is committed.

Wrote: `drawings/R4-1/draw.py`, `drawings/R4-1/drawing.json`, `drawings/R4-1/numbers.json`, `drawings/R4-1/reliability.png`, `drawings/R4-1/reliability.svg`, `drawings/R4-1/calibration_gap.png`, `drawings/R4-1/calibration_gap.svg`, `drawings/R4-1/auroc_ladder.png`, `drawings/R4-1/auroc_ladder.svg`, `drawings/R4-1/additive_coefficients.png`, `drawings/R4-1/additive_coefficients.svg`, `drawings/R4-1/logistic_normal_link.png`, `drawings/R4-1/logistic_normal_link.svg`, `drawings/R4-1/calibration_bins.csv`, `drawings/R4-1/auroc_summary.csv`

Ran: `wayline tools run matplotlib -- drawings/R4-1/draw.py`, `wayline accept`, `git add drawings/R4-1 && git commit`

Passages:

- methods, Oracle calibration and link (drawing R4-1): Drawing R4-1 reads the 20 equal-count calibration bins of the E1 oracle run. For each bin it takes the signed gap between the mean label and the mean oracle probability $\bar p$, and divides by the binomial standard error $\sqrt{\bar p(1-\bar p)/n}$ to get $z$. It reports $\sum z^2$ against a $\chi^2$ on as many df as bins, whose upper tail it computes in closed form for even df [res:drawings/R4-1/numbers.json#chi2_bins]. From the weights and the noise sd recorded in the E1 run, it computes the generator's link $P(y=1\mid\mu)=E[\sigma(\mu+e)]$ with $e\sim N(0,\sigma_e^2)$ by Gauss–Hermite quadrature over the latent mean's full range. It compares this link to $\sigma(\mu)$ [res:drawings/R4-1/numbers.json#max_sigmoid_minus_true]. It also compares the additive model's coefficients to the latent weights by their ratio [res:drawings/R4-1/numbers.json#attenuation_x1].

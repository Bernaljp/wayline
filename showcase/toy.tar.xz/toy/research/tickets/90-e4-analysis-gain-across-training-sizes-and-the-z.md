---
id: 90
title: "E4 analysis: gain across training sizes and the zero-strength cost per size (C6)"
kind: analysis
difficulty: 3
status: parked
blocked_by: [16, 77, 86, 87]
touches: [analysis/E4/]
role: analyst
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 4, wallclock_minutes: 60}
inputs: [results/runs/E4/, results/runs/E2/m1_n0/, results/runs/E3/m0_n0/]
outputs: [analysis/E4/sweep_m1.json, analysis/E4/sweep_m0.json, analysis/E4/verdict.json]
acceptance:
  machine: ["python3 -c \"import json; a = json.load(open('analysis/E4/sweep_m1.json')); b = json.load(open('analysis/E4/sweep_m0.json')); v = json.load(open('analysis/E4/verdict.json')); want = [1000, 2000, 4000, 8000, 16000, 32000, 64000]; assert sorted(int(p['train_rows']) for p in a['points']) == want and sorted(int(p['train_rows']) for p in b['points']) == want and v['c6_supported'] == (a['gain_shrink'] <= 0.005) and v['a5'] == (a['gain_shrink_lo'] > 0.005) and 'unresolved' in v\""]
  quality: ["Does C6's verdict follow gain_shrink and gain_shrink_lo as the spec defines them, is the m = 0 difference at each size reported as K4's cost rather than claimed, and does every finding's number sit at the field it cites?"]
objectives: [O4]
sections: [methods, results]
context_pack: [research/SPEC.md#e4-claims-c6, research/SPEC.md#claims, research/SPEC.md#anti-claims]
origin: research/SPEC.md#e4-claims-c6
proposed_by: planner
demo: analysis/E4/sweep_m1.json and sweep_m0.json and the findings show the paired gain with its CI at each training size from 1000 to 64000 rows at strength 1 and 0, gain_shrink with its CI, and C6's verdict.
---

## Demo

analysis/E4/sweep_m1.json and sweep_m0.json and the findings show the paired gain with its CI at each training size from 1000 to 64000 rows at strength 1 and 0, gain_shrink with its CI, and C6's verdict.

## Notes

Re-cut of ticket 70, which never launched. Run toy.sweep twice, seven sizes each. First: `PYTHONPATH=src python3 -B -m toy.sweep "$WAYLINE_PROJECT/results/runs/E4" --axis rows --strength 1 --point "$WAYLINE_PROJECT/results/runs/E2/m1_n0" --out analysis/E4/sweep_m1.json`. Second: the same with `--strength 0 --point "$WAYLINE_PROJECT/results/runs/E3/m0_n0" --out analysis/E4/sweep_m0.json`. Then write analysis/E4/verdict.py and the analysis/E4/verdict.json it writes, with these keys. c6_supported = gain_shrink <= 0.005 at m = 1. a5 = gain_shrink_lo > 0.005; when it holds, C3's gain is partly a small-sample effect. unresolved = neither holds. And the thresholds, each under its own key. At m = 0, report the paired difference at each size as the overfitting cost K4 asks about, not as a claim. A8: the claims reach only across these grids. Propose seeds 21-50 where Q15's rule calls for them (an SD above 0.02, or an interval too wide at m = 0 or at the smallest size). Result rules the harness checks (tickets 41, 52, 58 and 65 failed on them): return one Methods passage and one Results passage; end every sentence of each with a provenance tag that resolves, and leave out any sentence you cannot tag. Every number in a finding sits literally at a key of the analysis/E4/ JSON it cites, written as stored, with no percentage, rounding or derived count; put any number you want to state into verdict.json first. A finding that says what a current one says names it in `replaces`. Leave a passage's evidence unset unless it replaces an inherited claim. results/ is git-ignored: read it under $WAYLINE_PROJECT and commit only analysis/E4/. If a Bash command you need is refused, stop and return blocked naming it.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113.

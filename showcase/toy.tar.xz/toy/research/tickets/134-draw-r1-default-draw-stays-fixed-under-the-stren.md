---
id: 134
title: "Draw R1: Default draw stays fixed under the strength parameter"
kind: drawing
difficulty: 2
status: done
blocked_by: []
touches: [drawings/R1-1/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O3, O4]
context_pack: []
origin: drawing R1-1 at run_end
proposed_by: conductor
demo: R1 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R1-1

Code opened this drawing of R1 ("Default draw stays fixed under the strength parameter") at a rest point (run_end), over its findings t2-a3-f1, t2-a3-f2. Its brief, rendered by code at each launch, is in the prompt.

## Result

### Attempt 1

R1 has nothing to plot, so drawing R1-1 has no plots and no tables. Its two findings cite a hash constant (tests/test_generate.py#DEFAULT_DRAW_SHA256) and the generator's row function (src/toy/generate.py#row). Neither holds data that can be plotted, and making a strength sweep would mean running the project's code, which a drawing may not do. draw.py reads both artifacts as text and writes numbers.json: the digest, seed 1, signal 4.0, 20000 rows, and that the Gaussian draw does not depend on strength. drawing.json explains why each view was left out and lists the missing sweep data as an open question. wayline accept passed and the work is committed on ticket/134.

Wrote: `drawings/R1-1/draw.py`, `drawings/R1-1/numbers.json`, `drawings/R1-1/drawing.json`

Ran: `wayline tools run matplotlib -- drawings/R1-1/draw.py`, `wayline accept`, `git commit`

Proposed Record label flip rate and corr(y, x3*x4) across the strength sweep as an artifact (analysis) (admission decides what joins the graph).

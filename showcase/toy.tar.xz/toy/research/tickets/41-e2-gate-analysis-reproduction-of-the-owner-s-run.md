---
id: 41
title: "E2 gate analysis: reproduction of the owner's run and convergence at doubled epochs"
kind: analysis
difficulty: 2
status: parked
blocked_by: [8, 16]
touches: [analysis/E2/checks.py, analysis/E2/checks.json]
role: analyst
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 4, wallclock_minutes: 30}
inputs: [results/runs/E2/m1_n0/, results/runs/E2/converge/, owner/sample-summary.json]
outputs: [analysis/E2/checks.json]
acceptance:
  machine: [test -f analysis/E2/checks.py, "python3 -c \"import json; d = json.load(open('analysis/E2/checks.json')); assert d['reproduction_gap'] <= 0.002 and d['convergence_drop'] <= 0.01 and d['gate_passed'] is True\""]
  quality: ["Are reproduction_gap and convergence_drop computed by the committed script from the manifested E2 runs, and does each finding state its number with its threshold?"]
objectives: [O1]
sections: [methods, results]
context_pack: [owner/sample-summary.json, src/toy/eval.py, src/toy/converge.py, research/SPEC.md#e2-claims-c2-c3]
origin: research/SPEC.md#e2-claims-c2-c3
proposed_by: planner
demo: analysis/E2/checks.json shows replicate 1's with-term AUROC within 0.002 of the owner's 0.8503 and the largest relative loss drop at doubled epochs at or below 1%, and the two findings say so.
---

## Demo

analysis/E2/checks.json shows replicate 1's with-term AUROC within 0.002 of the owner's 0.8503 and the largest relative loss drop at doubled epochs at or below 1%, and the two findings say so.

## Notes

The runs are at $WAYLINE_PROJECT/results/runs/E2/ (results/ is not in the worktree). Write analysis/E2/checks.py, which writes analysis/E2/checks.json with these fields. run_auroc_with_seed1: from `PYTHONPATH=src python3 -B -m toy.eval --split held_out "$WAYLINE_PROJECT/results/runs/E2/m1_n0/with/seed1/summary.json"`. That is eval.py's positional path, the same reader the spec's --summary spelling names; --summary arrives with T1, which this gate does not wait for. b3_auroc: owner/sample-summary.json's auroc, 0.8502984862625299. reproduction_gap: their absolute difference. convergence_drop and per_run: from `PYTHONPATH=src python3 -B -m toy.converge "$WAYLINE_PROJECT/results/runs/E2/converge"`, whose pinned runs default to the sibling m1_n0. gate_passed = reproduction_gap <= 0.002 and convergence_drop <= 0.01. Use PYTHONPATH=code/src if src/ no longer exists. Commit both files and file one finding per check, citing analysis/E2/checks.json. The machine criterion is the spec's gate and fails by design when a check fails: do not loosen it. If a check fails, return blocked with a decision request. A failed convergence check revisits Q14 before E3 and E4 run. A reproduction gap above 0.002 stops E2 until its cause is found and recorded. E3, E4 and C3's analysis wait on this gate. Return Methods and Results passages whose claim sentences each end with a provenance tag.

## Result

### Attempt 1

Both E2 pre-checks pass and gate_passed is true in the committed analysis/E2/checks.json. Replicate 1's with-term AUROC equals the owner's. The largest relative training-loss drop at doubled epochs is under the 1% limit. This resubmission adds the missing Methods passage and restates the findings so each number sits in the file it cites. Nothing in the code or checks.json changed.

Wrote: `analysis/E2/checks.py`, `analysis/E2/checks.json`

Ran: `python3 analysis/E2/checks.py`, `wayline accept`

Passages:

- methods, Convergence check: The E2 gate script reads replicate 1's with-term AUROC and compares it with the owner's sample AUROC, then reuses toy.converge to take the largest relative drop in final training loss from the pinned epochs to twice them over replicates 1-3 in both arms. It writes reproduction_gap, convergence_drop and a gate_passed flag that is true only when both checks are within their limits. {code:analysis/E2/checks.py#main}

Escalated one rung up: the next attempt launches on rung 4 (r4 opus low), in a new session.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73.

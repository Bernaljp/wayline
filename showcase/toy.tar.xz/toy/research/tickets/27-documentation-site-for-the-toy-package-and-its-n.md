---
id: 27
title: Documentation site for the toy package and its new modules and flags
kind: docs
difficulty: 3
status: parked
blocked_by: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
touches: [docs/, .readthedocs.yaml, harness.json, src/toy/]
role: documentarian
skills: []
acceptance:
  machine: [test -f .readthedocs.yaml, grep -rqs 'toy.paired' docs/reference/ && grep -rqs 'toy.oracle' docs/reference/ && grep -rqs 'toy.sweep' docs/reference/, grep -rqs -- '--no-interaction' docs/how-to/]
  quality: ["Does every page describe only what the code does, including train.py's arms and flags, the oracle ceiling and the held-out discipline, with no behaviour the code lacks?"]
objectives: []
context_pack: [research/INTAKE.md, research/SPEC.md#seams, src/toy/]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`wayline docs build` passes; the site's reference has a page for each public module including toy.paired, toy.oracle and toy.sweep, and a how-to runs one paired comparison with --no-interaction and reads it with toy.paired."
---

## Demo

`wayline docs build` passes; the site's reference has a page for each public module including toy.paired, toy.oracle and toy.sweep, and a how-to runs one paired comparison with --no-interaction and reads it with toy.paired.

## Notes

Build the site with `wayline docs init --theme furo` and `wayline docs build` in the project's environment. Reference: one page per public module (toy.generate, toy.train, toy.eval, toy.metrics, toy.stats, toy.oracle, toy.paired, toy.sweep, toy.converge, toy.goallog, toy.placement), with autodoc_mock_imports = ['torch']. How-to: run one paired comparison at a seed (train.py with and without --no-interaction into two run directories) and read it with toy.paired; score a run with toy.eval --summary. Explanation: the two arms (Q14), the oracle ceiling, the held-out discipline and the goal's keep rule. Touch src/toy/ only for docstrings, never behaviour; train.py's ready_interactions docstring describes a down-weighting the code does not do, so make it say what the code does. Run Python as python3 -B so no __pycache__ is left. Describe only what you read in the code or saw an example do.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49.

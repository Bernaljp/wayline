---
id: 73
title: Documentation site for the toy package and its new modules and flags
kind: docs
difficulty: 3
status: parked
blocked_by: [2, 3, 5, 8, 52, 54, 55, 56, 57, 58]
touches: [docs/, .readthedocs.yaml, harness.json, src/toy/]
role: documentarian
skills: []
acceptance:
  machine: [test -f .readthedocs.yaml, grep -rqs 'toy.paired' docs/reference/ && grep -rqs 'toy.oracle' docs/reference/ && grep -rqs 'toy.sweep' docs/reference/ && grep -rqs 'toy.placement' docs/reference/ && grep -rqs 'toy.goallog' docs/reference/ && grep -rqs 'toy.converge' docs/reference/, grep -rqs -- '--no-interaction' docs/how-to/ && grep -rqs -- '--summary' docs/how-to/]
  quality: ["Does every page describe only what the code does, including train.py's arms and flags, the oracle ceiling and the held-out discipline, with no behaviour the code lacks?"]
objectives: []
context_pack: [research/INTAKE.md, research/SPEC.md#seams, src/toy/]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`wayline docs build` passes; the site's reference has a page for each public module including toy.paired, toy.oracle and toy.sweep, and a how-to runs one paired comparison with --no-interaction and reads it with toy.paired."
---

## Demo

`wayline docs build` passes; the site's reference has a page for each public module including toy.paired, toy.oracle and toy.sweep, and a how-to runs one paired comparison with --no-interaction and reads it with toy.paired.

## Notes

This is the project's first docs ticket; the package is at src/toy/ (decision #50 kept the old layout). Build the site with `wayline docs init --theme furo`, which records the theme in harness.json, and `wayline docs build`, in the project's environment. Reference: one page per public module (toy.generate, toy.train, toy.eval, toy.metrics, toy.stats, toy.oracle, toy.paired, toy.sweep, toy.converge, toy.goallog, toy.placement), with autodoc_mock_imports = ['torch']. How-to: run one paired comparison at a seed (train.py with and without --no-interaction, into two run directories with --save-scores), read it with toy.paired, and score a run with toy.eval --summary. Explanation: the two arms (Q14), the oracle ceiling, the held-out discipline, and the goal's keep rule. Touch src/toy/ only for docstrings, never behaviour. train.py's module docstring and its ready_interactions docstring describe a down-weighting of duplicate rows that the code does not do: make them say what the code does. If toy.oracle's latent_mean and true_prob docstrings still do not say the caller must pass the signal and strength the rows were drawn at (generate() defaults to signal 1.0, the oracle to 4.0), say so. Run Python as python3 -B so no __pycache__ is left. Describe only what you read in the code or saw an example do.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93.

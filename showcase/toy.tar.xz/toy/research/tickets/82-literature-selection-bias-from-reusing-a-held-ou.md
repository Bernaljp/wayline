---
id: 82
title: "Literature: selection bias from reusing a held-out set, and tuning on a validation split (O2)"
kind: lit
difficulty: 2
status: parked
blocked_by: []
touches: []
role: surveyor
skills: []
acceptance:
  machine: []
  quality: []
objectives: [O2]
sections: [introduction]
context_pack: [research/sections/introduction.md, research/CONCERNS.md, research/SPEC.md#e5-claims-c7, research/SPEC.md#methods, research/POSITION.md#what-the-references-lack]
origin: research/SPEC.md#e5-claims-c7
proposed_by: planner
demo: "The Introduction holds passages tagged at resolved dossiers on two points: why a held-out score chosen over several reads is biased upward, and why tuning belongs on a validation split cut from the training rows (K3). That is the discipline the goal loop for 0.82 follows."
---

## Demo

The Introduction holds passages tagged at resolved dossiers on two points: why a held-out score chosen over several reads is biased upward, and why tuning belongs on a validation split cut from the training rows (K3). That is the discipline the goal loop for 0.82 follows.

## Notes

Re-cut of ticket 61, which never launched. Search for: over-fitting in model selection (Cawley & Talbot 2010, JMLR); adaptive reuse of a holdout and the bias it causes (Dwork et al. 2015, 'The reusable holdout'; Recht et al. 2019; Roelofs et al. 2019 on Kaggle holdouts); and nested or split-sample validation for tuning (Varma & Simon 2006). Check each cited work with `wayline scout`. Every sentence of a passage ends with a {ref:<slug>#...} tag at a dossier the scout verified; leave out a sentence you cannot tag. A passage that says what a current one says names it in `replaces`. Rest nothing on paper-a or paper-b.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113.

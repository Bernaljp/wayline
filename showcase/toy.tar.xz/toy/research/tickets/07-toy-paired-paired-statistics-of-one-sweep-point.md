---
id: 7
title: "toy.paired: paired statistics of one sweep point against the oracle ceiling"
kind: code
difficulty: 4
status: parked
blocked_by: [5, 6]
touches: [src/toy/paired.py, tests/test_paired.py, tests/fixtures/paired/]
role: coder
skills: []
acceptance:
  machine: [PYTHONPATH=src python3 -B -m unittest tests.test_paired, "PYTHONPATH=src python3 -B -m toy.paired tests/fixtures/paired/point | python3 -c \"import json, sys; d = json.load(sys.stdin); assert d['n_pairs'] >= 3 and {'paired_gain', 'paired_gain_lo', 'paired_gain_hi', 'signed_rank_p', 'delong_rejections', 'gap_closed', 'mean_auroc_with', 'mean_auroc_without', 'mean_bayes_auroc'} <= set(d)\""]
  quality: ["Does toy.paired pair the arms only on identical seeds, draws and held-out rows, refuse an incomplete pair rather than drop it, and compute every statistic the spec's Methods (Statistics) names exactly as defined there?"]
objectives: [O1, O4]
sections: [methods]
context_pack: [src/toy/generate.py:34-44, research/SPEC.md#seams, research/SPEC.md#methods, research/SPEC.md#e2-claims-c2-c3]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`python3 -m toy.paired tests/fixtures/paired/point` prints the paired gain with its 95% t-interval, the signed-rank p, the DeLong rejection count, gap_closed and each arm's and the oracle's mean AUROC, matching the hand-worked answers in the test."
---

## Demo

`python3 -m toy.paired tests/fixtures/paired/point` prints the paired gain with its 95% t-interval, the signed-rank p, the DeLong rejection count, gap_closed and each arm's and the oracle's mean AUROC, matching the hand-worked answers in the test.

## Notes

`toy.paired <point-dir> [--out PATH]` reads <point-dir>/<with|without>/seed<i>/{summary.json, heldout_scores.csv, config.json} (the spec's run-directory layout; the real runs live under results/runs/<E>/<point>/) and prints JSON: paired_gain, paired_gain_lo, paired_gain_hi, sd_d, signed_rank_p, delong_rejections, gap_closed, gap_closed_lo, gap_closed_hi, mean_auroc_with, mean_auroc_without, mean_bayes_auroc, n_pairs and per_seed (seed, auroc_with, auroc_without, d, bayes, delong_p). Expose point_stats(point_dir) for toy.sweep. Pair only seeds present in both arms with identical seed, signal, rows, train_rows and strength in config.json and identical held-out labels; an incomplete or mismatched pair is an error that lists the seeds, never a silent drop (every run is reported). run_auroc is the summary's auroc, checked against the AUROC recomputed from heldout_scores.csv. d_i = auroc_with - auroc_without; 95% t-interval on n-1 df; exact two-sided signed-rank p; DeLong test of the two correlated AUROCs per replicate, counting p < 0.05 (all from toy.stats). bayes_i: regenerate the draw with toy.generate.generate(seed, signal, rows, strength) from config.json, take the held-out rows the CSV indexes (check their labels match), score them with toy.oracle.true_prob, take the AUROC. gap_closed = mean(d) / mean(bayes - auroc_without) with toy.stats' 10,000-resample paired bootstrap CI (fixed seed); null with a reason when the denominator is <= 0.005. Fixture under tests/fixtures/paired/point/ with at least three seeds and tiny held-out sets drawn by toy.generate, whose statistics are worked by hand in the test's comments. Stdlib only; run Python with -B.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49.

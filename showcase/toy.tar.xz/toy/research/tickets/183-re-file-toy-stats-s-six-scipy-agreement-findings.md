---
id: 183
title: Re-file toy.stats's six scipy-agreement findings so they also cite src/toy/stats.py, which the manifest does not hold
kind: writing
difficulty: 2
status: open
blocked_by: []
touches: []
role: writer
skills: [interval-claims]
inputs: [tests/test_stats_scipy.py, src/toy/stats.py, research/findings.jsonl, research/manifest.json]
acceptance:
  machine: []
  quality: ["Do the six findings that replace t5-a3-f1 to t5-a3-f6 each tie the tolerance they state to the line of tests/test_stats_scipy.py that asserts it and name the function of src/toy/stats.py under test, with own-run tags on both files whose locators hold every number written?"]
objectives: []
sections: [results]
context_pack: [research/findings.jsonl:5-10, research/sections/results.md:12-30, research/manifest.json:31-37, research/tickets/162-scope-down-the-general-report-s-claims-the-kill.md, tests/test_stats_scipy.py, src/toy/stats.py]
origin: research/REPORT.md#kill-argument
proposed_by: planner
demo: The general report renders six findings under R3's heading in place of t5-a3-f1 to t5-a3-f6. Each ends with tags of this ticket's run on tests/test_stats_scipy.py and on the function of src/toy/stats.py it checks. Once integrated, research/manifest.json holds an entry for src/toy/stats.py, which the kill argument's point 8 found missing.
---

## Demo

The general report renders six findings under R3's heading in place of t5-a3-f1 to t5-a3-f6. Each ends with tags of this ticket's run on tests/test_stats_scipy.py and on the function of src/toy/stats.py it checks. Once integrated, research/manifest.json holds an entry for src/toy/stats.py, which the kill argument's point 8 found missing.

## Notes

Why: the kill argument's point 8 stands. research/manifest.json has no entry for src/toy/stats.py, the module every paired statistic in E2-E4 comes from. The six findings on toy.stats cite only t5-a3/tests/test_stats_scipy.py. This ticket covers point 8 and is part of the re-cut of #162. The other half of point 8 (train.py and oracle.py pinned only from the docs run t131-a1) needs no finding: the per-run outputs are pinned.

How a re-pin works: a sentence ending with `{res:t<this ticket>-a<this attempt>/<path>#<locator>}` makes the conductor hash that file on main into research/manifest.json under this run at integration, replacing any old entry for the path. src/toy/stats.py has none. tests/test_stats_scipy.py has t5-a3's, and the six findings replaced here are the only current ones citing it. Put own-run tags on these two files and on no other manifested path. Use your run id as your prompt gives it.

What to return: six findings, each with `replaces`, the replaced finding's `heading` as research/findings.jsonl records it, `negative` false, a `provenance` at tests/test_stats_scipy.py, and text that keeps the replaced wording wherever it still holds. Each sentence ends with a tag at the test line or method that asserts its tolerance and one at the function of src/toy/stats.py under test (read the file for the names). The locators must hold every number written, as written (12 decimal places, 10, 1e-12, 0.05, 10000, 95%). If the test file writes the interval's level as 0.95, write that rather than a percentage. Say what a test asserts, not that it passed. Edit no file. Return no passage.

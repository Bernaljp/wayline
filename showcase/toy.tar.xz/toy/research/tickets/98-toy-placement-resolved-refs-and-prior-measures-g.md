---
id: 98
title: "toy.placement: resolved_refs and prior_measures_gain, tolerating unscouted works and unsettled entries"
kind: code
difficulty: 2
status: accepted
blocked_by: []
touches: [src/toy/placement.py, tests/test_placement.py, tests/fixtures/placement/]
role: coder
skills: []
outputs: [src/toy/placement.py, tests/test_placement.py, tests/fixtures/placement/]
acceptance:
  machine: [PYTHONPATH=src python3 -B -m unittest tests.test_placement, "PYTHONPATH=src python3 -B -m toy.placement tests/fixtures/placement/placement.json --refs tests/fixtures/placement/refs | python3 -c \"import json, sys; d = json.load(sys.stdin); assert {'resolved_refs', 'prior_measures_gain', 'entries', 'mismatches', 'unsettled'} <= set(d) and d['mismatches'] == []\"", "d=$(mktemp -d) && mkdir -p \"$d/refs\" && printf '[{\"slug\": \"unscouted\", \"doi\": \"10.1/x\", \"existence\": \"missing\", \"measures_paired_gain\": null, \"locator\": null}]\\n' > \"$d/p.json\" && PYTHONPATH=src python3 -B -m toy.placement \"$d/p.json\" --refs \"$d/refs\" > \"$d/out.json\" && python3 -c \"import json, sys; d = json.load(open(sys.argv[1])); assert d['resolved_refs'] == 0 and d['prior_measures_gain'] == 0 and d['mismatches'] == [] and d['unsettled'] == ['unscouted']\" \"$d/out.json\""]
  quality: []
objectives: [O1]
sections: [methods]
context_pack: [.worktrees/58/src/toy/placement.py, .worktrees/58/tests/test_placement.py, research/refs/delong-1988-comparing-areas-under-two-more/dossier.json, research/SPEC.md#e6-claims-c8, research/SPEC.md#seams]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`PYTHONPATH=src python3 -m toy.placement tests/fixtures/placement/placement.json --refs tests/fixtures/placement/refs` prints resolved_refs, prior_measures_gain and unsettled. An entry for an unscouted work with existence 'missing' and measures_paired_gain null exits 0 and counts as unresolved, and the tests show that an entry whose existence disagrees with its dossier exits 1."
---

## Demo

`PYTHONPATH=src python3 -m toy.placement tests/fixtures/placement/placement.json --refs tests/fixtures/placement/refs` prints resolved_refs, prior_measures_gain and unsettled. An entry for an unscouted work with existence 'missing' and measures_paired_gain null exits 0 and counts as unresolved, and the tests show that an entry whose existence disagrees with its dossier exits 1.

## Notes

Re-cut of #79, which never launched; it was itself a re-cut of #58. #58's code passed both of its criteria (9 tests OK) and sits on branch ticket/58, in the worktree .worktrees/58/. It failed only on its returned passages: the first time it returned no Methods passage, and the second time its passage carried the untagged sentence 'It uses the Python standard library alone.'. Start from that code. git checkout is not on this role's allow list, so Read .worktrees/58/src/toy/placement.py, .worktrees/58/tests/test_placement.py and the files under .worktrees/58/tests/fixtures/placement/, and write them into your worktree with the Write tool. If that worktree is gone, `git log -p ticket/58` shows the same files. Then fix the two places where it departs from what E6 needs. (a) load_entries refuses measures_paired_gain null. Accept true, false or null, where null means the dossier cannot settle it. A null entry counts toward neither number, and its slug goes under a new key, unsettled: the slugs of every entry whose measures_paired_gain is null, in input order. (b) check_entry reports every entry without a dossier as a mismatch, so one unscouted D6 work would make E6's analysis exit 1, where the spec reports C8 unresolved (SPEC E6: resolved_refs < 4). Make it agree when an entry's existence is 'missing' and its dossier is absent; such an entry counts as unresolved. An entry naming 'verified' or 'unresolved' with no dossier, or 'missing' when a dossier exists, is a mismatch and exits 1. Change test_missing_dossier_exits_1 to match, and add a test for each rule. Keep the rest as it is: a work counts as resolved when its dossier's existence is 'verified' (the scout's only other value is 'unresolved'), the DOI cross-check stays, and malformed input exits 2. The fixture placement.json must stay free of mismatches, because the acceptance runs it. The CLI is `toy.placement <placement.json> [--refs research/refs]`; stdlib only. Bash: this role runs a command only when every part of it begins with a program on its allow list: python3, git add, git commit, git status, git diff, git log, ls, cat and wayline accept. These are refused: a `PYTHONPATH=src` prefix, mkdir, bash, a heredoc or a `>` redirect into a file, and the venv's python called by its path. Those refusals blocked tickets 16, 76 and 83. So write every file with the Write tool, and run one plain command per Bash call. Let `wayline accept` run the tests and the criteria. For a check of your own, run `python3 -B -c "import sys; sys.path.insert(0, 'src'); ..."`. Retry a refused command in an allowed form, and return blocked only when that form is refused too. The harness checks the Result against these rules (tickets 41, 52, 53, 58 and 65 failed on them). Return one Methods passage. End every sentence of it with a provenance tag that resolves, such as {code:src/toy/placement.py#place}, and leave out any sentence you cannot tag. A finding that states a number cites a locator holding that literal number: #58's first finding cited paper-a's dossier for counts and years it did not hold. A passage that says what a current one says names it in `replaces`. Leave a passage's evidence unset.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Result

### Attempt 1

I copied #58's toy.placement code, tests and fixtures from .worktrees/58 into this worktree using Write, then made the two fixes the ticket asked for. (a) load_entries now accepts measures_paired_gain as true, false or null and still refuses any other value with exit 2. An entry with null counts toward neither resolved_refs nor prior_measures_gain, even when its dossier is verified, and its slug goes under a new output key, `unsettled`, in input order. (b) check_entry treats a missing dossier as agreeing only when the entry's existence is 'missing', and that entry counts as unresolved. An entry saying 'verified' or 'unresolved' with no dossier is a mismatch and exits 1, and so is one saying 'missing' when a dossier exists. The DOI cross-check, the rule that a work is resolved when its dossier says 'verified', and exit 2 on malformed input are unchanged. The fixture placement.json gains work-f, a 'missing' entry with no dossier and a null gain, and work-d's gain is now null. The fixture's answers are resolved_refs 4, prior_measures_gain 1, unsettled [work-d, work-f] and no mismatches. test_missing_dossier_exits_1 became test_verified_without_dossier_exits_1. New tests cover 'unresolved' with no dossier (exit 1), 'missing' with a dossier (exit 1), 'missing' with no dossier (exit 0, unresolved, unsettled), a null gain on a verified work counting toward neither number, an empty `unsettled`, and a non-boolean gain (exit 2). That makes 15 tests. `wayline accept` passed all three acceptance commands. The work is committed on ticket/98 as c3be098.

Wrote: `src/toy/placement.py`, `tests/test_placement.py`, `tests/fixtures/placement/placement.json`, `tests/fixtures/placement/refs/work-a/dossier.json`, `tests/fixtures/placement/refs/work-b/dossier.json`, `tests/fixtures/placement/refs/work-c/dossier.json`, `tests/fixtures/placement/refs/work-d/dossier.json`, `tests/fixtures/placement/refs/work-e/dossier.json`

Ran: `wayline accept`, `python3 -B -m unittest -v tests.test_placement (without PYTHONPATH; failed to import toy, as expected)`, `git add src/toy/placement.py tests/test_placement.py tests/fixtures/placement`, `git commit`, `git status --short`

Passages:

- methods, Literature placement: The literature placement reads one entry per D6 work and cross-checks each entry's existence and DOI against the dossier at research/refs/<slug>/dossier.json; an entry for a work with no dossier must state existence 'missing', and any disagreement is listed as a mismatch {code:src/toy/placement.py#check_entry}. resolved_refs counts the entries whose dossier states existence 'verified' and whose measures_paired_gain is settled, prior_measures_gain counts those with measures_paired_gain true, and the entries whose measures_paired_gain is null are listed as unsettled and count toward neither number {code:src/toy/placement.py#place}.

Parameters:

- `toy.placement.main` `--refs`: It defaults to research/refs because that is where the scout files dossiers, so E6 reads the project's own dossiers unless a fixture directory is passed.

Not methods:

- `src/toy/placement.py#load_entries`: Input validation of the placement record (required fields, unique slugs, a gain of true/false/null); it computes nothing the paper reports.
- `src/toy/placement.py#_read_json`: File reading with error messages; plumbing.
- `src/toy/placement.py#_norm_doi`: Lower-cases and strips a DOI string before comparing; plumbing for the cross-check described under check_entry.
- `src/toy/placement.py#main`: Command-line wrapper that prints place()'s JSON and maps mismatches to exit codes.

Proposed docs: toy.placement CLI and placement.json schema (unsettled, existence 'missing') (docs) (admission decides what joins the graph).

**Verdict (result): passed** by claude-opus-5-5, session `c6004135-42db-446d-8e3c-4b31f15edb94`.

- [minor] Finding t98-a1-f2 says a mismatch 'makes the command exit 1' but cites src/toy/placement.py#check_entry. check_entry only records the problems. The exit code is set in main (line 115: `return 1 if result["mismatches"] else 0`). The claim is true, but the cited locator does not hold it. (research/findings.jsonl line 34 (t98-a1-f2); src/toy/placement.py line 115)
- [minor] Not every malformed input exits 2. A non-string slug (line 72 `Path(refs_dir) / entry["slug"]`, or an unhashable one at line 57) and a dossier, or its identifiers, that is valid JSON but not an object (lines 81 and 86, `.get`) raise an uncaught TypeError or AttributeError. Python then exits 1, the code E6 reads as a mismatch, while the docstring (lines 20-21) promises 2. This comes unchanged from #58, which the ticket said to keep. (src/toy/placement.py lines 57, 72, 81, 86; docstring lines 20-21)
- [minor] An entry with existence 'missing' and no dossier but a settled gain (true or false) agrees and raises no mismatch. It counts toward neither number and is not listed under unsettled, so a self-contradictory record (a work never read but marked as measuring the gain, or not) goes unflagged. The module's own docstring (lines 18-19) says such a work 'cannot be said to measure the gain, or not to'. The counts stay correct, and the ticket does not specify this case. (src/toy/placement.py lines 75-78 and 96-101)
- [minor] SPEC's metric definition of resolved_refs is 'D6's five works whose dossier existence is no longer unresolved'. As the ticket instructed, place() (line 96) now also requires a settled measures_paired_gain. So the SPEC metric and the Methods passage P19 disagree on a verified work with a null gain. This is a gap between the ticket and SPEC, not a defect of this work, but the report's metric definition needs reconciling. (research/SPEC.md line 144 (Metrics: resolved_refs); src/toy/placement.py line 96)
- [minor] This session could not run the tests or the three acceptance commands (python3 was refused). That the 15 tests pass and the criteria hold rests on two things: a hand trace of all 15 tests and the fixture against placement.py (resolved_refs 4, prior_measures_gain 1, unsettled [work-d, work-f], no mismatches), and the harness's record ('Ran 15 tests ... OK', all three commands exit 0). The worker's stream shows no Write after `wayline accept`, and `git diff --stat c3be098 b855624` and `git diff --stat HEAD` show no change to the subject files. (research/sessions/98/1/acceptance.json)

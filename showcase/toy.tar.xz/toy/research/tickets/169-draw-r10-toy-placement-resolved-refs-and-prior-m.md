---
id: 169
title: "Draw R10: toy.placement: resolved_refs and prior_measures_gain, tolerating unscouted works and unsettled entries"
kind: drawing
difficulty: 2
status: blocked
blocked_by: []
touches: [drawings/R10-2/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O1]
context_pack: []
origin: drawing R10-2 at order
proposed_by: conductor
demo: R10 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R10-2

Code opened this drawing of R10 ("toy.placement: resolved_refs and prior_measures_gain, tolerating unscouted works and unsettled entries") at a rest point (order), over its findings t98-a1-f1, t98-a1-f2. Its brief, rendered by code at each launch, is in the prompt.

## Result

### Attempt 1

I fixed the passage tag and added the missing citation for 27 in findings 2 and 3, but `wayline drawing check` cannot pass from inside this ticket. The manifest records analysis/E6/placement_summary.json at sha256 7e165a10…, the 329-byte counts-only version from run t112-a1 (commit b45f3dc). The file on disk is a later version, regenerated with per-entry rows by place.py (commits 677d0e2 and 742eeaf), and its hash dd8a0f1f… was never added to the manifest. R10's only data artifact is this file, so every plot and table from it fails provenance. I'm not allowed to edit research/ or analysis/. The drawing itself (one headline tile grid, two tables, numbers.json) is committed on ticket/169 and is correct against the file on disk. Once the conductor records the current file's hash, the drawing should pass `drawing check` without changes.

Wrote: `drawings/R10-2/draw.py`, `drawings/R10-2/drawing.json`, `drawings/R10-2/numbers.json`, `drawings/R10-2/entry_tests.png`, `drawings/R10-2/entry_tests.svg`, `drawings/R10-2/entries.csv`, `drawings/R10-2/rule_cases.csv`

Ran: `wayline tools run matplotlib -- draw.py`, `wayline accept`, `sha256sum analysis/E6/placement_summary.json`, `git show b45f3dc:analysis/E6/placement_summary.json`

Passages:

- methods, Drawing R10-2: The drawing script reads analysis/E6/placement_summary.json, the output of toy.placement on E6's works, without importing or running the project's code. For each entry it recomputes agreement (an entry with no dossier agrees only when its existence is 'missing'; one with a dossier agrees when its existence is not 'missing' and equals the dossier's), whether it counts toward resolved_refs (dossier existence 'verified' and measures_paired_gain not null), toward prior_measures_gain (resolved and gain true), and whether it is unsettled (gain null), and compares these recounts with the stored counts [res:drawings/R10-2/numbers.json#recount_matches_stored]. It then enumerates every combination of entry existence (verified, unresolved, missing), dossier state (none, verified, unresolved) and gain (true, false, null), applies the same rule to each, and counts the combinations [res:drawings/R10-2/numbers.json#n_rule_cases], those that some E6 entry falls in [res:drawings/R10-2/numbers.json#n_rule_cases_exercised], and those that mismatch yet count toward resolved_refs [res:drawings/R10-2/numbers.json#n_cases_mismatch_but_counted_resolved]. The enumeration leaves out the DOI cross-check that toy.placement also makes [code:drawings/R10-2/draw.py#outcome].

Proposed Record the regenerated analysis/E6/placement_summary.json (t112-a2) in the manifest (harness), Exercise toy.placement's no-dossier and mismatch branches on a recorded fixture (code) (admission decides what joins the graph).

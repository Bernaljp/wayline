---
id: 149
title: "Draw R16: E4: paired gain across training sizes (C6)"
kind: drawing
difficulty: 2
status: parked
blocked_by: []
touches: [drawings/R16-1/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O4]
context_pack: []
origin: drawing R16-1 at run_end
proposed_by: conductor
demo: R16 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R16-1

Code opened this drawing of R16 ("E4: paired gain across training sizes (C6)") at a rest point (run_end), over its findings t110-a1-f1, t110-a1-f2, t110-a1-f3, t110-a1-f4, t110-a1-f5, t110-a1-f6, t110-a1-f7, t110-a1-f8, t110-a1-f9, t110-a1-f10, t110-a1-f11, t110-a1-f12, t110-a1-f13, t110-a1-f14, t110-a1-f15, t110-a1-f16, t110-a1-f17, t110-a1-f18, t110-a1-f19, t110-a1-f20, t110-a1-f21, t110-a1-f22. Its brief, rendered by code at each launch, is in the prompt.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 153, 154, 155, 156.

---
id: 192
title: "Draw R14: E2: paired AUROC gain of the x3*x4 column over 20 seeds"
kind: drawing
difficulty: 2
status: open
blocked_by: []
touches: [drawings/R14-3/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O1, O2, O3]
context_pack: []
origin: drawing R14-3 at order
proposed_by: conductor
demo: R14 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R14-3

Code opened this drawing of R14 ("E2: paired AUROC gain of the x3*x4 column over 20 seeds") at a rest point (order), over its findings t120-a1-f1, t120-a1-f2, t120-a1-f3, t120-a1-f4, t121-a1-f1, t121-a1-f2, t121-a1-f3, t121-a1-f4, t121-a1-f5, t121-a1-f6, t121-a1-f7, t121-a1-f8, t121-a1-f9, t121-a1-f10, t111-a1-f8. Its brief, rendered by code at each launch, is in the prompt.

---
id: 106
title: "E4 experiment: training-size sweep at strengths 1 and 0"
kind: experiment
difficulty: 3
status: accepted
blocked_by: [3, 16]
touches: [experiments/E4/, results/runs/E4/, results/smoke/E4/]
role: experimenter
skills: []
resources: {cpu: 2, gpu: 1, ram_gb: 8, wallclock_minutes: 60}
inputs: [configs/arms.json, src/toy/train.py, src/toy/generate.py, experiments/E2/point.sh]
outputs: [results/runs/E4/m1_n1000/without/seed20/heldout_scores.csv, results/runs/E4/m1_n2000/without/seed20/heldout_scores.csv, results/runs/E4/m1_n4000/without/seed20/heldout_scores.csv, results/runs/E4/m1_n8000/without/seed20/heldout_scores.csv, results/runs/E4/m1_n32000/without/seed20/heldout_scores.csv, results/runs/E4/m1_n64000/without/seed20/heldout_scores.csv, results/runs/E4/m0_n1000/without/seed20/heldout_scores.csv, results/runs/E4/m0_n2000/without/seed20/heldout_scores.csv, results/runs/E4/m0_n4000/without/seed20/heldout_scores.csv, results/runs/E4/m0_n8000/without/seed20/heldout_scores.csv, results/runs/E4/m0_n32000/without/seed20/heldout_scores.csv, results/runs/E4/m0_n64000/without/seed20/heldout_scores.csv]
acceptance:
  machine: ["python3 -c \"import json; t = open('experiments/E4/jobs.json').read(); json.loads(t); assert all(('results/runs/E4/m%d_n%d/%s/seed%d/heldout_scores.csv' % (m, n, a, i)) in t for m in (0, 1) for n in (1000, 2000, 4000, 8000, 32000, 64000) for a in ('with', 'without') for i in range(1, 21)) and '_n16000/' not in t and '_n0/' not in t\"", "python3 -c \"import json, subprocess, sys; ms = json.load(open('experiments/E4/jobs.json'))['members']; f = lambda c, k: c[c.index(k) + 1] if k in c else None; g = lambda c: (f(c, '--strength'), f(c, '--train-rows') or str(int(f(c, '--rows')) * 4 // 5)); assert len(ms) == 12 and {g(m['command']) for m in ms} == {(s, str(n)) for s in ('0', '1') for n in (1000, 2000, 4000, 8000, 32000, 64000)} and all(m['command'][:2] == ['/bin/bash', 'experiments/E2/point.sh'] and m['command'][2] == 'results/runs/E4/m%s_n%s' % g(m['command']) and m['command'][3:5] == ['1', '20'] and not ('--train-rows' in m['command'] and '--rows' in m['command']) for m in ms); c = [a.replace('results/runs/E4/', 'results/smoke/E4/') for a in ms[0]['command']]; c[4] = '1'; sys.exit(subprocess.run(c + ['--epochs', '1', '--device', 'cpu']).returncode)\" && python3 -c \"import glob; assert glob.glob('results/smoke/E4/m*_n*/without/seed1/heldout_scores.csv')\""]
  quality: ["Do the jobs run exactly the twelve (strength, size) points the spec names, seeds 1-20 and both arms with configs/arms.json, capping the default draw's training rows for sizes up to 8000 and drawing n/0.8 rows for 32000 and 64000, with the held-out fifth unchanged and nothing tuned?"]
objectives: [O4]
sections: [methods]
context_pack: [configs/arms.json, experiments/E2/point.sh, experiments/E2/jobs.json:1-10, src/toy/train.py:156-183, research/SPEC.md#e4-claims-c6, research/SPEC.md#methods]
origin: research/SPEC.md#e4-claims-c6
proposed_by: planner
demo: "`wayline status` shows the twelve E4 job members, one per strength 1 or 0 and training size 1000 to 64000, each running 40 paired runs into results/runs/E4/m<m>_n<n>/."
retry:
  host_oom: []
  gpu_oom: [--batch-size=64, --batch-size=16]
---

## Demo

`wayline status` shows the twelve E4 job members, one per strength 1 or 0 and training size 1000 to 64000, each running 40 paired runs into results/runs/E4/m<m>_n<n>/.

## Notes

Re-cut of #87, which never launched. It no longer waits on the E2 gate, which passed (analysis/E2/checks.json on main: gate_passed true); the gate's re-cut only re-files its findings. configs/arms.json records the model as torch.nn.Linear, a logistic regression linear in its inputs, so C6's prediction stands as written and is not revised before this runs (SPEC risks). n0 is 16000 training rows: configs/arms.json's 20000 rows less the held-out fifth. The sizes are therefore 1000, 2000, 4000 and 8000 (n0/16 to n0/2) and 32000 and 64000 (2*n0 and 4*n0); none is under 200. Reuse experiments/E2/point.sh. Write experiments/E4/jobs.json with the Write tool, in the form of experiments/E2/jobs.json, with one member per point, for m in {1, 0} and n in {1000, 2000, 4000, 8000, 32000, 64000}. Each member's command is ["/bin/bash", "experiments/E2/point.sh", "results/runs/E4/m<m>_n<n>", "1", "20", "--strength", "<m>", ...], with m written 1 or 0, then the size flag. For n up to 8000 the size flag is `--train-rows <n>`, which caps the default draw and leaves the held-out fifth unchanged. For n = 32000 and n = 64000 it is `--rows 40000` and `--rows 80000` respectively: n/0.8 rows with the last fifth held out, where a flag on the command line wins over the config's rows. Never give a member both flags. The second criterion reads that shape and smoke-runs the first member at seed 1 for one CPU epoch into results/smoke/E4/, so you need no smoke run of your own. The n0 points at m = 1 and m = 0 are E2's m1_n0 and E3's m0_n0: do not re-run them. Each member's expected_outputs lists every run's three files literally. The retry ladder's --batch-size passes through to train.py. Nothing is tuned and no seed is dropped. Then run these, one per Bash call: `wayline accept`; `git add experiments/E4/jobs.json`; `git commit -m "E4: size sweep jobs"`; `wayline job add experiments/E4/jobs.json`. Return running with the job ids, and commit nothing under results/. Bash: every part of a command must begin with python3, git add, git commit, git status, git diff, git log, ls, cat, wayline accept or wayline job add. mkdir, bash, heredocs, `>` redirects and `PYTHONPATH=` prefixes are refused, and those refusals blocked tickets 16, 76 and 83. Write files with the Write tool, and retry a refused command in an allowed form before you return blocked. Return one Methods passage. End every sentence with a provenance tag that resolves, and leave out any sentence you cannot tag. File no finding that states a number.

## Result

### Attempt 1

This adds the missing Methods passage, under a new heading "Training-size sweep (E4)". It says how the E4 sweep is laid out and cites experiments/E4/make_jobs.py and experiments/E2/point.sh. The code and job spec are unchanged: they were already committed on ticket/106, and the twelve jobs t106-1 to t106-12 were added once and are still the ones running. wayline accept passes again. Jobs t106-1 to t106-6 run strength 1 and t106-7 to t106-12 run strength 0, each at training sizes 1000, 2000, 4000, 8000, 32000 and 64000 in that order. Each job runs seeds 1–20 for both arms with the pinned settings. Sizes below n0 = 16000 pass --train-rows n. The two larger sizes pass --rows 40000 and --rows 80000, which is n/0.8 rows with the last fifth held out. The n0 points are left out because E4 reuses the E2 and E3 runs there.

Wrote: `experiments/E4/make_jobs.py`, `experiments/E4/jobs.json`

Ran: `python3 experiments/E4/make_jobs.py`, `wayline accept`, `git commit`, `wayline job add experiments/E4/jobs.json`

Jobs: `t106-1`, `t106-2`, `t106-3`, `t106-4`, `t106-5`, `t106-6`, `t106-7`, `t106-8`, `t106-9`, `t106-10`, `t106-11`, `t106-12`

Passages:

- methods, Training-size sweep (E4): E4 sweeps the training size $n \in \{1000, 2000, 4000, 8000, 32000, 64000\}$ at interaction strengths $m = 1$ and $m = 0$, with twenty paired replicates (seeds 1–20, both arms, pinned settings) per point. The $n_0 = 16000$ points reuse E2's and E3's runs {code:experiments/E4/make_jobs.py#L8-L19}. Sizes below $n_0$ keep only the first $n$ training rows of the default 20000-row draw (--train-rows), so the held-out fifth is unchanged. The sizes $2n_0$ and $4n_0$ draw $n/0.8$ rows (--rows 40000 and 80000) and hold out the last fifth {code:experiments/E4/make_jobs.py#L14-L15}. Every run goes through the E2 runner, which trains the `with` arm and then the `without` arm on each seed with configs/arms.json {code:experiments/E2/point.sh#L1-L25}.

Parameters:

- `toy.train` `--train-rows`: SPEC E4: sizes below n0 = 16000 cap the D1 draw's training rows at the first n, leaving the held-out fifth unchanged.
- `toy.train` `--rows`: SPEC E4: sizes 2·n0 and 4·n0 draw n/0.8 rows (40000, 80000) and hold out the last fifth.
- `toy.train` `--strength`: SPEC E4 sweeps size at m = 1 (planted interaction) and m = 0 (null control, K4).

Not methods:

- `experiments/E4/make_jobs.py`: It only writes the job spec listing the sweep points; it computes nothing.

Escalated one rung up: the next attempt launches on rung 6 (r6 opus high), in a new session.

### Attempt 2

Re-registered the E4 training-size sweep as 12 jobs (t106-13..t106-24); the earlier t106-1..12 were cancelled when attempt 1 failed. experiments/E4/jobs.json (generated by experiments/E4/make_jobs.py, both committed on ticket/106 at 12ab0c9) has one member per (m, n) for m in {1, 0} and n in {1000, 2000, 4000, 8000, 32000, 64000}, in that order: m1_n1000 … m1_n64000 then m0_n1000 … m0_n64000. Each member runs `/bin/bash experiments/E2/point.sh results/runs/E4/m<m>_n<n> 1 20 --strength <m>` plus one size flag: `--train-rows n` for n ≤ 8000, or `--rows 40000` / `--rows 80000` for 32000 / 64000. That is 40 paired runs per point (seeds 1-20, with and without arms, configs/arms.json), and each member lists all 120 expected files (summary.json, heldout_scores.csv, config.json per run). The n0 points reuse E2's m1_n0 and E3's m0_n0 and are not re-run. The earlier attempt's machine acceptance failed on its returned Methods passage: first it had none, then a code tag cited lines 1-25 of the 22-line point.sh. This attempt returns a passage whose tags cite existing lines and symbols. The ticket's acceptance commands and `wayline accept` pass, including the one-epoch CPU smoke run into results/smoke/E4/.

Wrote: `experiments/E4/jobs.json`, `experiments/E4/make_jobs.py`, `results/smoke/E4/m1_n1000/`

Ran: `python3 -c <acceptance 1>`, `python3 -c <acceptance 2: shape check + 1-epoch CPU smoke of member 0 seed 1>`, `python3 -c <acceptance 3: smoke output glob>`, `wayline accept`, `wayline job add experiments/E4/jobs.json`

Jobs: `t106-13`, `t106-14`, `t106-15`, `t106-16`, `t106-17`, `t106-18`, `t106-19`, `t106-20`, `t106-21`, `t106-22`, `t106-23`, `t106-24`

Passages:

- methods, Sweeps: E4 runs twelve sweep points, one per interaction strength $m \in \{1, 0\}$ and training size $n \in \{1000, 2000, 4000, 8000, 32000, 64000\}$, each under results/runs/E4/m<m>_n<n> {code:experiments/E4/make_jobs.py#L8-L15}. For sizes below the default 16000 training rows, the run passes --train-rows $n$ and keeps only the first $n$ rows of the default draw's training rows {code:src/toy/train.py#split_training}. For 32000 and 64000 it passes --rows $n/0.8$, so the generator draws 40000 or 80000 rows and holds out the last fifth {code:experiments/E4/make_jobs.py#L14}. At each point, seeds 1 to 20 each train the `with` arm and then the `without` arm (--no-interaction) with the pinned settings in configs/arms.json, saving each run's held-out scores {code:experiments/E2/point.sh#L14-L22}.

Not methods:

- `experiments/E4/make_jobs.py`: It only writes the job spec listing the sweep's commands and expected files; the method is the train.py runs it lists.

Every job exited 0 and its outputs parsed: t106-13, t106-14, t106-15, t106-16, t106-17, t106-18, t106-19, t106-20, t106-21, t106-22, t106-23, t106-24.

**Verdict (diff): passed** by claude-opus-5-5, session `e1249fa7-6248-44a0-83c7-8baa3dd4ecf1`.

- [minor] I could not parse the committed jobs.json with json.loads or run the ticket's machine acceptance in this session, because Python execution was refused. I judged it valid from the diff text instead: all 13 command blocks, the first and last lines, and a length of 1635 lines that matches json.dump(indent=1) for 12 members of 9 command items and 120 outputs each (13 + 12×135 + 2). Grep counts agree: 120 entries under each of the 12 roots, 480 each of summary.json, heldout_scores.csv and config.json, 720 per arm, 72 at seed1 and at seed20, and 26 flag tokens, which is --strength plus one size flag in each of the 13 commands. The harness's job record research/jobs/t106-13.json also carries member 1's command and outputs, so the file was parsed when registered. (experiments/E4/jobs.json (git show 863cd3158014, new file, lines 1-1635))

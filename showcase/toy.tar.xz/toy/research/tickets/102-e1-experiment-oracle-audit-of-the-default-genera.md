---
id: 102
title: "E1 experiment: oracle audit of the default generator on the 10^6-row draw D2"
kind: experiment
difficulty: 2
status: accepted
blocked_by: []
touches: [experiments/E1/, results/E1/, results/smoke/E1/]
role: experimenter
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 8, wallclock_minutes: 120}
inputs: [src/toy/oracle.py, src/toy/generate.py]
outputs: [results/E1/oracle.json]
acceptance:
  machine: ["python3 -c \"import json; t = open('experiments/E1/jobs.json').read(); json.loads(t); assert 'toy.oracle' in t and '10001' in t and '1000000' in t and 'results/E1/oracle.json' in t\"", "python3 -c \"import json, subprocess, sys; s = json.load(open('experiments/E1/jobs.json')); m = (s.get('members') or [s])[0]; assert m['expected_outputs'] == ['results/E1/oracle.json']; sub = {'10001': '20001', '1000000': '2000', 'results/E1/oracle.json': 'results/smoke/E1/oracle.json'}; sys.exit(subprocess.run([sub.get(a, a) for a in m['command']]).returncode)\" && python3 -c \"import json; d = json.load(open('results/smoke/E1/oracle.json')); assert d['seed'] == 20001 and d['rows'] == 2000 and d['signal'] == 4.0 and d['strength'] == 1.0 and {'bayes_auroc', 'bayes_auroc_halfwidth', 'calibration_error', 'interaction_weight', 'interaction_weight_locator', 'additive_gap'} <= set(d)\""]
  quality: ["Does the job run toy.oracle once on D2 (seed 10001, 10^6 rows, signal 4.0 and strength 1, CPU only) and write results/E1/oracle.json and nothing else?"]
objectives: [O3]
sections: [methods]
context_pack: [experiments/E2/jobs.json:1-10, tests/test_oracle_budget.py:1-14, src/toy/oracle.py:272-295, research/SPEC.md#e1-claims-c1-c2, research/SPEC.md#data]
origin: research/SPEC.md#e1-claims-c1-c2
proposed_by: planner
demo: "`wayline status` shows the E1 job running `toy.oracle --seed 10001 --rows 1000000` on one core; when it exits, results/E1/oracle.json holds the Bayes AUROC, its half-width, the calibration error, the weight on x3*x4 with its line, and the additive gap."
---

## Demo

`wayline status` shows the E1 job running `toy.oracle --seed 10001 --rows 1000000` on one core; when it exits, results/E1/oracle.json holds the Bayes AUROC, its half-width, the calibration error, the weight on x3*x4 with its line, and the additive gap.

## Notes

Re-cut of #83, which was blocked when the role refused its one compound Bash command. That command ran mkdir, wrote two files by heredoc, ran a smoke test, then wayline accept, git and wayline job add. This role runs a command only when every part of it begins with a program on its allow list: python3, git add, git commit, git status, git diff, git log, ls, cat, wayline accept and wayline job add. mkdir, bash, heredocs, `>` redirects and `PYTHONPATH=` prefixes are refused. No script is needed this time. With the Write tool (which creates the directory), write experiments/E1/jobs.json as one job: {"command": ["/usr/bin/env", "PYTHONPATH=src", "python3", "-B", "-m", "toy.oracle", "--seed", "10001", "--rows", "1000000", "--out", "results/E1/oracle.json"], "expected_outputs": ["results/E1/oracle.json"]}. Keep every argument its own string. The second criterion smoke-runs that very command with three values swapped (seed 20001, 2000 rows, out path results/smoke/E1/oracle.json), so you need no smoke run of your own. The CLI's defaults, --signal 4.0 and --strength 1, are D2's default settings, and toy.oracle is stdlib only, so the system python3 runs it. The ticket asks for one core, 8 GB and 120 minutes. tests/test_oracle_budget.py (#53) states its 4 GB and one-hour bounds as half of that allowance, and the audit it timed took about 20 s and 0.7 GB. Then run these commands, one per Bash call: `wayline accept`; `git add experiments/E1/jobs.json`; `git commit -m "E1: oracle audit job on D2"`; `wayline job add experiments/E1/jobs.json`. Return running with the job id. Commit nothing under results/. Seed 10001 lies outside every replicate's seeds, so no model of E2-E5 sees D2. Nothing is repeated, because the draw's size gives the precision. This ticket does not wait on #52. #52 changes oracle.py's comments, its tests and the rounding of interaction_weight, but none of the numbers the audit reports at D2's settings: 4.0*1.1 is the double 4.4. Return one Methods passage. End every sentence with a provenance tag that resolves, such as {code:src/toy/oracle.py#audit}, and leave out any sentence you cannot tag. A Methods passage on 'Oracle and Bayes ceiling' already exists: a passage that says what it says names it in `replaces`. File no finding that states a number, because the job has not run. Retry a refused command in an allowed form, and return blocked only when that form is refused too, naming it.

## Result

### Attempt 1

Wrote experiments/E1/jobs.json, which is one job: `/usr/bin/env PYTHONPATH=src python3 -B -m toy.oracle --seed 10001 --rows 1000000 --out results/E1/oracle.json`. This is the D2 draw at the default settings (signal 4.0, strength 1), CPU only, with expected output results/E1/oracle.json. Both acceptance checks passed under `wayline accept`, including the seed-20001, 2000-row smoke run of the same command into results/smoke/E1/. The spec is committed on ticket/102 as eb4a9a6, and the job was added as t102-1. The audit has not run yet, so there are no findings.

Wrote: `experiments/E1/jobs.json`

Ran: `wayline accept`, `git add experiments/E1/jobs.json`, `git commit -m "E1: oracle audit job on D2"`, `wayline job add experiments/E1/jobs.json`

Jobs: `t102-1`

Passages:

- methods, Oracle and Bayes ceiling: The audit runs on all rows of the draw, training and held-out together, and reports the seed, row count, signal and strength next to the audit metrics {code:src/toy/oracle.py#main}. The metrics are the Bayes AUROC with its half-width, the calibration error, the weight on $x_3x_4$ with its source locator, and the additive gap {code:src/toy/oracle.py#audit}. The weight on $x_3x_4$ is reported as $\text{signal}\cdot 1.1\,m$ {code:src/toy/oracle.py#audit}. The additive reference is an unpenalised logistic regression on $x_1..x_4$ {code:src/toy/oracle.py#additive_gap}.

Every job exited 0 and its outputs parsed: t102-1.

**Verdict (quality): passed** by claude-opus-5-5, session `43b560ad-1316-4e90-93fe-f22925a32c60`.

- [minor] I could not reproduce the audit myself: the stdout-only re-run (`PYTHONPATH=src python3 -B -m toy.oracle --seed 10001 --rows 1000000`) was refused in this session. Three things show the file is this job's output. Its sha256 (569514bd…) matches the manifest entry the harness journaled when t102-1 finished. It is byte-identical to the job's captured stdout in results/logs/t102-1.log. It echoes seed 10001, rows 1000000, signal 4.0 and strength 1.0, and its counts add up to 10^6: 20 bins of 50000 rows, and 500000 rows each for the additive fit and its scoring. Whether the numbers themselves are right is outside this criterion. (results/E1/oracle.json (whole file), cross-checked against research/journal.jsonl:1099 (manifest event, sha256 569514bdaed8505ef39457518655b2d4715c2d6d2bf966f517b2f9367b88e92a, size 3836))
- [minor] The job's recorded duration overstates the run. The attempt runs from started_at 17:04:31.287Z to ended_at 17:16:03.351Z, which was journaled as "seconds": 692. But results/E1/oracle.json and results/logs/t102-1.log were both last modified at 17:04:50.71Z, about 19 s after launch, and oracle.py:295-300 exits right after it writes and prints. So 692 s is when the conductor recorded the exit (conductor.py _job_seconds reads ended_at), not how long the audit ran, and reproduce.py would report it as the job's time. This is a harness accounting issue, not ticket 102's work, and it is not a second run: there is one attempt, one job_launched event, and one copy of the output in the log. (research/jobs/t102-1.json:42-43 (attempts[0].started_at / ended_at); research/journal.jsonl:1098 (job_finished, seconds 692))

---
id: 181
title: Re-file toy.converge's two findings against the current converge.py and its test, citing the fixture's 0.05 where it is worked out (R5)
kind: writing
difficulty: 2
status: open
blocked_by: []
touches: []
role: writer
skills: [interval-claims]
inputs: [src/toy/converge.py, tests/test_converge.py, tests/fixtures/converge/, research/findings.jsonl, research/manifest.json]
acceptance:
  machine: []
  quality: ["Do the two findings that replace t8-a2-f1 and t8-a2-f2 cite the current src/toy/converge.py and tests/test_converge.py at own-run locators? Is the fixture's 0.05 from the without arm at seed 2 tagged at the lines of tests/test_converge.py that work it out or assert it, with no claim that the test passed?"]
objectives: []
sections: [results]
context_pack: [research/findings.jsonl:16-17, research/sections/results.md:64-70, research/manifest.json:1129-1136, research/tickets/159-scope-down-a-report-claim-its-artifacts-do-not-s.md, src/toy/converge.py, tests/test_converge.py]
origin: research/REPORT.md#claim-2dfdd14e568392b5
proposed_by: planner
demo: The general report renders two findings under R5's heading in place of t8-a2-f1 and t8-a2-f2. The fixture sentence's 0.05 is tagged at tests/test_converge.py, and every sentence is tagged at this ticket's run. The report header no longer lists that sentence as a failed claim, and research/manifest.json holds the current src/toy/converge.py and tests/test_converge.py.
---

## Demo

The general report renders two findings under R5's heading in place of t8-a2-f1 and t8-a2-f2. The fixture sentence's 0.05 is tagged at tests/test_converge.py, and every sentence is tagged at this ticket's run. The report header no longer lists that sentence as a failed claim, and research/manifest.json holds the current src/toy/converge.py and tests/test_converge.py.

## Notes

Why: the sampled verdict failed t8-a2-f1's sentence "On the fixture the maximum is 0.05, from the without arm at seed 2". Its only tag cites t8-a2/src/toy/converge.py#convergence, which holds no fixture, no 0.05, no arm and no seed. The numbers are worked out in tests/test_converge.py's docstring (lines 3-12: 0.03/0.60 = 0.05 for the without arm at seed 2) and asserted in test_convergence_drop_is_the_largest_drop and test_per_run_carries_both_losses_and_epochs. Also, the manifest holds src/toy/converge.py only at t8-a2 (4383 bytes, sha 8552c8), before ticket 131 added docstrings (commit b008f0a). This ticket replaces #159 and covers the kill argument's point 2 for t8-a2-f1.

How a re-pin works: a sentence ending with `{res:t<this ticket>-a<this attempt>/<path>#<locator>}` makes the conductor hash the file on main into research/manifest.json under this run at integration, replacing the path's old entry. t8-a2-f1 and t8-a2-f2 are the only current findings citing src/toy/converge.py (at t8-a2), so both are replaced here. Put own-run tags on src/toy/converge.py and tests/test_converge.py. You may also tag files under tests/fixtures/converge/, which the manifest does not hold. Tag no other manifested path. Use your run id as your prompt gives it.

What to return: two findings, each with `replaces`, `heading` "toy.converge: largest relative training-loss drop at doubled epochs", `negative` false, a `provenance` at the file it is about, and text that keeps the replaced wording wherever it still holds. The locators are `convergence`, `_epochs`, a test method, or a line span `L<a>-L<b>`. Each must hold every number its sentence writes (0.01, 1%, 0.05, seed 2, exit 2). t8-a2-f2's second sentence speaks for tickets 3 and 16: narrow it to what converge.py shows, the keys it reads and that it exits 2 when one is missing. Say what a test asserts, not that it passed. Edit no file. Return no passage.

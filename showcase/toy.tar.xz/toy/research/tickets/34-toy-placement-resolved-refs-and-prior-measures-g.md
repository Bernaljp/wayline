---
id: 34
title: "toy.placement: resolved_refs and prior_measures_gain from a placement record and the dossiers"
kind: code
difficulty: 2
status: parked
blocked_by: [50]
touches: [code/src/toy/placement.py, code/tests/test_placement.py, code/tests/fixtures/placement/]
role: coder
skills: []
acceptance:
  machine: [PYTHONPATH=code/src python3 -B -m unittest discover -s code/tests -p 'test_placement.py', "PYTHONPATH=code/src python3 -B -m toy.placement code/tests/fixtures/placement/placement.json --refs code/tests/fixtures/placement/refs | python3 -c \"import json, sys; d = json.load(sys.stdin); assert {'resolved_refs', 'prior_measures_gain', 'entries', 'mismatches'} <= set(d)\""]
  quality: []
objectives: [O1]
sections: [methods]
context_pack: [research/refs/paper-a/dossier.json, research/refs/delong-1988-comparing-areas-under-two-more/dossier.json, research/SPEC.md#e6-claims-c8, research/SPEC.md#seams]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`PYTHONPATH=code/src python3 -m toy.placement code/tests/fixtures/placement/placement.json --refs code/tests/fixtures/placement/refs` prints resolved_refs and prior_measures_gain, and exits 1 on an entry whose existence disagrees with its dossier."
---

## Demo

`PYTHONPATH=code/src python3 -m toy.placement code/tests/fixtures/placement/placement.json --refs code/tests/fixtures/placement/refs` prints resolved_refs and prior_measures_gain, and exits 1 on an entry whose existence disagrees with its dossier.

## Notes

Paused by the layout decision; cut for its recommended answer (package at code/src/toy/, tests at code/tests/). Write only under code/. `toy.placement <placement.json> [--refs research/refs]`. placement.json is a JSON list of entries with these fields: slug; doi (bare, lower case, no 'doi:' prefix); existence; measures_paired_gain (true, false, or null when the dossier cannot settle it); and locator. For each entry, read <refs>/<slug>/dossier.json. Its top-level 'existence' is 'unresolved' until the scout resolves it, and 'verified' or another value after (see the two dossiers in the context pack). An entry with no dossier must say existence 'missing', and it counts as unresolved. A missing dossier is not an error, so an unscouted work makes C8 unresolved rather than failing the command. An entry whose existence differs from its dossier's, or that says 'missing' when a dossier exists, is listed under mismatches and makes the command exit 1. Print JSON with these keys: resolved_refs (entries whose dossier exists and is not 'unresolved'), prior_measures_gain (resolved entries with measures_paired_gain true), entries, and mismatches. Fixtures go under code/tests/fixtures/placement/: a placement.json and a refs/ tree with one resolved, one unresolved and one missing dossier. Add a test of the mismatch exit. Stdlib only; run Python with -B. Return one Methods passage whose claim sentences each end with a provenance tag.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Result

### Attempt 1

I wrote toy.placement, its test and its fixtures, but I could not run any of it. Bash was denied (don't-ask mode) after my first few read-only commands, so the unit tests, the acceptance pipeline, `wayline accept` and `git commit` were all refused. The files are in the worktree and uncommitted. The module and tests have never been executed, so the work is unverified. The ticket stays blocked until a session can run Bash.

What I wrote (all under the touch set):
- `code/src/toy/placement.py`: `toy.placement <placement.json> [--refs research/refs]` reads a JSON list of entries (slug, doi, existence, measures_paired_gain, locator). For each entry it reads `<refs>/<slug>/dossier.json`. It prints JSON with resolved_refs, prior_measures_gain, entries and mismatches. An entry with no dossier has dossier existence 'missing', which counts as unresolved and is not an error. An entry whose existence differs from its dossier's is listed under mismatches, and the command exits 1. Unreadable or malformed input exits 2. It uses the standard library only.
- `code/tests/test_placement.py`: six tests. They cover the counts (resolved_refs 2, prior_measures_gain 1), an unresolved work that cannot count toward prior_measures_gain, three mismatch cases that each exit 1 (existence disagrees with the dossier, 'missing' while a dossier exists, no dossier but not 'missing'), and exit 2 on a missing file or a missing field.
- `code/tests/fixtures/placement/`: `placement.json` with four entries, and `refs/` with three dossiers (verified with gain true, verified with gain false, unresolved). The fourth entry has no dossier and says 'missing'.

Layout: the worktree has `src/toy` and `tests` at the root and no `code/` directory. Following the ticket's cut layout decision, I created `code/src/toy/placement.py` with no `__init__.py`, so `toy` resolves as a namespace package under `PYTHONPATH=code/src`. If `toy/__init__.py` moves under `code/src` later, nothing here changes.

To finish:
1. Run the two acceptance commands, then `wayline accept`.
2. Fix anything that fails.
3. `git add code/ && git commit` on `ticket/34`.

Wrote: `code/src/toy/placement.py`, `code/tests/test_placement.py`, `code/tests/fixtures/placement/placement.json`, `code/tests/fixtures/placement/refs/gain-2020-explicit-product/dossier.json`, `code/tests/fixtures/placement/refs/nogain-2019-interaction/dossier.json`, `code/tests/fixtures/placement/refs/unresolved-note/dossier.json`

Ran: `ls/cat/git inspection of the worktree (read-only)`

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73.

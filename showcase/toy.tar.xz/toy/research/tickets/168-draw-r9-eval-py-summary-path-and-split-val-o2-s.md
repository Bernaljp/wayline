---
id: 168
title: "Draw R9: eval.py: --summary PATH and --split val, O2's goal command unchanged"
kind: drawing
difficulty: 2
status: blocked
blocked_by: []
touches: [drawings/R9-2/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O1, O2]
context_pack: []
origin: drawing R9-2 at order
proposed_by: conductor
demo: R9 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R9-2

Code opened this drawing of R9 ("eval.py: --summary PATH and --split val, O2's goal command unchanged") at a rest point (order), over its findings t95-a1-f1, t95-a1-f2, t117-a1-f1. Its brief, rendered by code at each launch, is in the prompt.

## Result

### Attempt 1

Drawing R9-2 is one table, contract.csv, and no plots. draw.py builds the table by reading tests/test_eval.py as text. That table fails `wayline drawing check` because the file has changed since the manifest recorded it. The manifest holds sha256 ac8a0df8… for tests/test_eval.py, recorded under run t95-a1, and that hash matches commit 27d10e3. Commit bd8727c from ticket 117 then changed the file, and its current hash is e1cc54a3…. No manifest entry records that version. src/toy/eval.py has drifted the same way: the manifest holds 57abee1c…, the file is now 813c5025…. Both drawing directory and project root have the new versions. I cannot repair the manifest because research/ is off-limits to me. Reading the old version from git would make the input something other than a manifest path, and dropping the table would remove the drawing's only useful view. The numbers-check failures are fixed in the findings below: each sentence now cites the numbers.json key that holds every number it quotes. The drawing files are already committed on ticket/168.

Wrote: `drawings/R9-2/draw.py`, `drawings/R9-2/contract.csv`, `drawings/R9-2/numbers.json`, `drawings/R9-2/drawing.json`

Ran: `wayline tools run matplotlib -- drawings/R9-2/draw.py`, `wayline accept`, `sha256sum tests/test_eval.py src/toy/eval.py`, `git log --oneline -5 -- tests/test_eval.py`, `git show 27d10e3:tests/test_eval.py | sha256sum`

Passages:

- methods, Evaluation command contract: The contract of the evaluation command was tabulated from the text of its test file: each test method was parsed with Python's ast module, without importing or running it. For each test, the script records the argument list passed to the command, the environment it sets, and the asserted outcome: the printed line, or an exit with its required message or exit code. The counts are the number of test methods expecting a printed metric or an exit, and the number whose asserted output is the sample summary's AUROC [res:drawings/R9-2/numbers.json#n_refused].

Proposed Record the current tests/test_eval.py and src/toy/eval.py in the manifest (harness) (admission decides what joins the graph).

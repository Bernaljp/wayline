---
id: 144
title: "Draw R11: E1: planted interaction, additive gap and Bayes ceiling on D2"
kind: drawing
difficulty: 2
status: done
blocked_by: []
touches: [drawings/R11-1/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O3]
context_pack: []
origin: drawing R11-1 at run_end
proposed_by: conductor
demo: R11 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R11-1

Code opened this drawing of R11 ("E1: planted interaction, additive gap and Bayes ceiling on D2") at a rest point (run_end), over its findings t103-a1-f1, t103-a1-f2, t103-a1-f3, t103-a1-f4, t103-a1-f5, t103-a1-f6, t103-a1-f7, t103-a1-f8, t103-a1-f9, t103-a1-f10, t103-a1-f11, t103-a1-f12, t103-a1-f13. Its brief, rendered by code at each launch, is in the prompt.

## Result

### Attempt 1

Fixed and committed R11-1, the drawing of E1 on D2. It has three plots: an AUROC ladder with the additive model, the oracle, the Bayes ceiling with its DeLong interval and the 0.82 goal; a lollipop of the additive coefficients; and a reliability diagram with signed residuals per bin. It also has one criteria table. The two headline plots are the AUROC ladder and the coefficient plot. The rerun failed because draw.py read figures/style.json, which the clean room does not hold; the house palette is now written into the script. The coefficient plot's y label ran past the canvas, so it is now shorter and the figure is taller. The findings are split so each sentence cites the numbers.json key that holds its number. wayline accept passes. I could not run `wayline drawing check` or `wayline numbers check` myself because the permission mode denied them, so the conductor's rerun will be their first check.

Wrote: `drawings/R11-1/draw.py`, `drawings/R11-1/drawing.json`, `drawings/R11-1/numbers.json`, `drawings/R11-1/auroc_ladder.png`, `drawings/R11-1/auroc_ladder.svg`, `drawings/R11-1/additive_coefficients.png`, `drawings/R11-1/additive_coefficients.svg`, `drawings/R11-1/calibration.png`, `drawings/R11-1/calibration.svg`, `drawings/R11-1/criteria.csv`

Ran: `wayline tools run matplotlib -- drawings/R11-1/draw.py`, `wayline accept`, `git add drawings/R11-1 && git commit`

Passages:

- methods, Drawing R11-1: The drawing script reads results/E1/oracle.json and computes four derived quantities. The share of the gap the goal requires is $(0.82 - \mathrm{AUROC}_{add})/(\mathrm{AUROC}_{Bayes} - \mathrm{AUROC}_{add})$ (res:drawings/R11-1/numbers.json#share_of_ceiling_gap_closed_by_goal). The goal's margin over the additive model is $0.82 - \mathrm{AUROC}_{add}$ (res:drawings/R11-1/numbers.json#goal_minus_additive). The fitted x1:x2 ratio is the ratio of the additive model's x1 and x2 coefficients (res:drawings/R11-1/numbers.json#coef_ratio_x1_x2). The oracle-minus-Bayes difference is oracle_auroc_second_half minus bayes_auroc (res:drawings/R11-1/numbers.json#oracle_minus_bayes).

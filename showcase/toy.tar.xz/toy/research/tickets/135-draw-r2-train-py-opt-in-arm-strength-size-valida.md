---
id: 135
title: "Draw R2: train.py: opt-in arm, strength, size, validation, config and run-directory flags, plus configs/arms.json"
kind: drawing
difficulty: 2
status: done
blocked_by: []
touches: [drawings/R2-1/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O1, O2, O4]
context_pack: []
origin: drawing R2-1 at run_end
proposed_by: conductor
demo: R2 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R2-1

Code opened this drawing of R2 ("train.py: opt-in arm, strength, size, validation, config and run-directory flags, plus configs/arms.json") at a rest point (run_end), over its findings t3-a1-f1, t3-a1-f2. Its brief, rendered by code at each launch, is in the prompt.

## Result

### Attempt 1

R2's only artifact is tests/test_train.py. It holds one recorded number (BASE_AUROC, the held-out AUROC of a seed-1, 2000-row, 2-epoch cpu smoke run) and two equality assertions on weights, and no series or distribution. So the drawing has no plots. It has one table, regression_anchor.csv: draw.py reads the constants from the test file as text (it parses them and never imports the code) and writes the table and numbers.json. Two plots were left out, with reasons: a single-value mark would be a flat summary, and the weights are never recorded in any artifact. wayline accept passed; the drawing directory is committed on ticket/135.

Wrote: `drawings/R2-1/draw.py`, `drawings/R2-1/numbers.json`, `drawings/R2-1/regression_anchor.csv`, `drawings/R2-1/drawing.json`

Ran: `wayline tools run matplotlib -- drawings/R2-1/draw.py`, `wayline accept`, `git add drawings/R2-1 && git commit`

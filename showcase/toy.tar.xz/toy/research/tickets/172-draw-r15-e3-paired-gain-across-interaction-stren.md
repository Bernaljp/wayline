---
id: 172
title: "Draw R15: E3: paired gain across interaction strengths (C4, C5)"
kind: drawing
difficulty: 2
status: parked
blocked_by: []
touches: [drawings/R15-2/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O4]
context_pack: []
origin: drawing R15-2 at order
proposed_by: conductor
demo: R15 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R15-2

Code opened this drawing of R15 ("E3: paired gain across interaction strengths (C4, C5)") at a rest point (order), over its findings t122-a2-f1, t122-a2-f2, t122-a2-f3, t122-a2-f4, t122-a2-f5, t122-a2-f6, t122-a2-f7, t123-a1-f1, t123-a1-f2, t123-a1-f3, t123-a1-f4, t123-a1-f5, t123-a1-f6, t123-a1-f7, t123-a1-f8, t123-a1-f9, t123-a1-f10, t123-a1-f11, t123-a1-f12. Its brief, rendered by code at each launch, is in the prompt.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 176, 177, 178, 179, 180, 181, 182, 183, 184, 185.

---
id: 78
title: "toy.goallog: held-out reads of the goal loop from results/E5/changes.jsonl"
kind: code
difficulty: 2
status: parked
blocked_by: []
touches: [src/toy/goallog.py, tests/test_goallog.py, tests/fixtures/goallog/]
role: coder
skills: []
acceptance:
  machine: [PYTHONPATH=src python3 -B -m unittest tests.test_goallog, "PYTHONPATH=src python3 -B -m toy.goallog tests/fixtures/goallog/changes.jsonl | python3 -c \"import json, sys; d = json.load(sys.stdin); assert {'heldout_reads', 'heldout_scorings', 'candidates', 'kept', 'discarded'} <= set(d) and d['heldout_reads'] == 3 and d['heldout_scorings'] == 9\""]
  quality: []
objectives: [O2]
sections: [methods]
context_pack: [research/SPEC.md#e5-claims-c7, research/SPEC.md#seams]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`PYTHONPATH=src python3 -m toy.goallog tests/fixtures/goallog/changes.jsonl` prints heldout_reads and the per-candidate table."
---

## Demo

`PYTHONPATH=src python3 -m toy.goallog tests/fixtures/goallog/changes.jsonl` prints heldout_reads and the per-candidate table.

## Notes

Re-cut of ticket 57, which never launched. Write only src/toy/goallog.py, tests/test_goallog.py and tests/fixtures/goallog/. `toy.goallog <changes.jsonl>` reads E5's log. Each line is one held-out scoring of one seed of one candidate: candidate (a name; 'start' for the unchanged default run), seed, val_auroc (null for the start), auroc, kept (true, false, or null until keep-if-better judges it), and an optional note. Print JSON with these keys. heldout_reads: the number of distinct candidates scored on the held-out fifth, the start plus each candidate (the spec allows at most six). heldout_scorings: the number of lines (decision #28 scores each candidate at seeds 1, 2 and 3). candidates: one row per candidate with its seeds, their aurocs, their mean, val_auroc and kept. kept and discarded: the counts. A malformed line is refused with its line number and exit 1. Fixture: tests/fixtures/goallog/changes.jsonl with the start and two candidates, each at seeds 1, 2 and 3 (nine lines, so heldout_reads 3 and heldout_scorings 9). Stdlib only; run Python as python3 -B. Result rules the harness checks (tickets 41, 52, 53, 58 and 65 failed on them): return one Methods passage; end every sentence of it with a provenance tag that resolves, such as {code:src/toy/goallog.py#main}, and leave out any sentence you cannot tag; a finding that states a number cites a locator holding that literal number, and a code locator is matched as a literal substring; a passage or finding that says what a current one says names it in `replaces`; leave a passage's evidence unset unless it replaces an inherited claim. If a Bash command you need is refused, stop and return blocked naming it.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113.

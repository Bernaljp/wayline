---
id: 8
title: "toy.converge: largest relative training-loss drop at doubled epochs"
kind: code
difficulty: 2
status: accepted
blocked_by: []
touches: [src/toy/converge.py, tests/test_converge.py, tests/fixtures/converge/]
role: coder
skills: []
acceptance:
  machine: [PYTHONPATH=src python3 -B -m unittest tests.test_converge, "PYTHONPATH=src python3 -B -m toy.converge tests/fixtures/converge/E2/converge | python3 -c \"import json, sys; d = json.load(sys.stdin); assert 'convergence_drop' in d and d['per_run']\""]
  quality: []
objectives: [O1]
sections: [methods]
context_pack: [research/SPEC.md#e2-claims-c2-c3, research/SPEC.md#seams]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`python3 -m toy.converge tests/fixtures/converge/E2/converge` prints convergence_drop and the per-run loss drops the test works out by hand."
---

## Demo

`python3 -m toy.converge tests/fixtures/converge/E2/converge` prints convergence_drop and the per-run loss drops the test works out by hand.

## Notes

`toy.converge <converge-dir> [--pinned <point-dir>]`, default --pinned the sibling m1_n0 of <converge-dir>. For each <arm>/seed<i> under <converge-dir> (E2 reruns replicates 1-3 in both arms at twice the pinned epochs), read final_train_loss from its summary.json and from the same arm and seed under the pinned point; drop = (loss_pinned - loss_double) / loss_pinned. Check that config.json's epochs are doubled. Print JSON with convergence_drop (the largest drop) and per_run (arm, seed, loss_pinned, loss_double, drop). It reads training loss only, never held-out AUROC. Fixture under tests/fixtures/converge/E2/{converge,m1_n0}/ with hand-worked answers. Stdlib only; run Python with -B; do not create tests/__init__.py.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Result

### Attempt 2

Added src/toy/converge.py (`toy.converge <converge-dir> [--pinned <point-dir>]`, stdlib only). For each arm/seed under the converge dir it reads final_train_loss from that run's summary.json and from the same run under the pinned point (default: sibling m1_n0). It requires config.json epochs to be exactly twice the pinned epochs. It prints JSON with convergence_drop (the largest of (pinned-double)/pinned), n_runs and per_run (arm, seed, epochs, losses, drop). Refusals exit 2: missing run, missing final_train_loss or epochs, epochs not doubled, empty dir. Fixture under tests/fixtures/converge/E2/{m1_n0,converge} has hand-worked drops (0.02, 0.01, 0, 0.01, 0.05, -0.02, so convergence_drop is 0.05), plus an ignored pinned seed 4. tests/test_converge.py has 12 tests. `wayline accept` passed both commands; committed as 0befd68 on ticket/8. Two assumptions follow from the spec leaving them open: config.json carries an `epochs` key, and summary.json carries `final_train_loss`.

Wrote: `src/toy/converge.py`, `tests/test_converge.py`, `tests/fixtures/converge/E2/`

Ran: `wayline accept`

Passages:

- methods, Convergence check: The convergence check takes, for each arm and seed rerun at twice the pinned epochs, the relative drop $(L_{\text{pinned}} - L_{2\times})/L_{\text{pinned}}$ in final training loss against the same arm and seed at the pinned epochs, and reports the largest as convergence_drop. It refuses a rerun whose configured epochs are not exactly twice the pinned ones, and it never reads held-out AUROC. {code:src/toy/converge.py#convergence}

Not methods:

- `run_dirs`: directory listing of the run layout; plumbing
- `main`: argparse CLI wrapper that prints the JSON
- `_read_json`: file-reading helper
- `_final_loss`: reads one key from summary.json
- `_epochs`: reads one key from config.json
- `_seed_number`: parses the seed number from a directory name
- `relative_drop`: one-line arithmetic, described in the convergence Methods passage via convergence

**Verdict (diff): passed** by claude-opus-5-5, session `548a1136-e9d9-4c5e-a670-50e0bda2c68b`.

- [minor] relative_drop also refuses a non-positive pinned loss (raises ValueError when loss_pinned <= 0). The Methods passage lists the doubled-epochs refusal but not this one. That doesn't overturn the not_method claim, because the formula itself is in the passage and the guard only keeps the ratio defined, but a reader of Methods won't learn that such runs are refused. (src/toy/converge.py (commit 3b2931d18b75), def relative_drop, lines 63-67)
- [minor] The ticket's Result says the work was committed as 0befd68 on ticket/8, but the diff being judged is commit 3b2931d18b75. I could only read 3b2931d, which contains converge.py, the test and the fixtures. I could not run git or the tests to tie the two hashes together, because Bash was denied in this session. (research/tickets/08-toy-converge-largest-relative-training-loss-drop.md, ## Result / ### Attempt 2)

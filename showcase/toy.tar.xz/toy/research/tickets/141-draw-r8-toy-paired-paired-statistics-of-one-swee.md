---
id: 141
title: "Draw R8: toy.paired: paired statistics of one sweep point against the oracle ceiling"
kind: drawing
difficulty: 2
status: accepted
blocked_by: []
touches: [drawings/R8-1/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O1, O3, O4]
context_pack: []
origin: drawing R8-1 at run_end
proposed_by: conductor
demo: R8 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R8-1

Code opened this drawing of R8 ("toy.paired: paired statistics of one sweep point against the oracle ceiling") at a rest point (run_end), over its findings t76-a1-f1, t115-a1-f1, t115-a1-f2, t116-a2-f1, t116-a2-f2. Its brief, rendered by code at each launch, is in the prompt.

## Result

### Attempt 1

Redrew R8 from analysis/E2/paired.json, the manifested output of toy.paired at the strength-1.0 sweep point with 20 paired seeds; its hash matches the manifest. The earlier input, tests/test_paired.py, no longer has the hash the manifest records, so its fixture views could not pass the provenance check. Those views, and the refusal table, are left out and raised as an open question. The palette is now inlined, so the script reruns in the clean room. There are five plots, three of them headlines: arms against the Bayes ceiling per seed, paired differences with the t-interval, and gain against the gap. The other two are the redrawn bootstrap of gap_closed and the per-seed DeLong z. There is also a per-seed table. Recomputing from the per-seed records reproduces the reported gain (0.087), sd, gap_closed (0.99) and mean AUROCs. A seeded bootstrap lands within 0.00004 of the reported CI. The with arm falls short of the ceiling by 0.0009 on average. `wayline accept` passed, but `wayline drawing check` was blocked in this session, so the drawing checks were not rerun here.

Wrote: `drawings/R8-1/draw.py`, `drawings/R8-1/drawing.json`, `drawings/R8-1/numbers.json`, `drawings/R8-1/arms_per_seed.png`, `drawings/R8-1/arms_per_seed.svg`, `drawings/R8-1/paired_differences.png`, `drawings/R8-1/paired_differences.svg`, `drawings/R8-1/gain_vs_gap.png`, `drawings/R8-1/gain_vs_gap.svg`, `drawings/R8-1/bootstrap_gap_closed.png`, `drawings/R8-1/bootstrap_gap_closed.svg`, `drawings/R8-1/delong_z.png`, `drawings/R8-1/delong_z.svg`, `drawings/R8-1/per_seed.csv`

Ran: `sha256sum tests/test_paired.py`, `sha256sum analysis/E2/paired.json`, `wayline tools run matplotlib -- drawings/R8-1/draw.py`, `git add -A drawings/R8-1`, `git commit`, `wayline accept`

Passages:

- methods, Drawing the paired statistics of one sweep point: The drawing reads toy.paired's per-seed records for one sweep point and recomputes the mean paired difference, its sample standard deviation, the mean AUROC of each arm and of the oracle, and gap_closed, the mean gain divided by the mean gap that the without arm leaves to the Bayes AUROC {code:drawings/R8-1/draw.py#gap_closed_of}. It redraws the interval for gap_closed with a paired bootstrap that resamples seeds with replacement, keeps each seed's gain and gap together, and takes the percentile bounds of the resampled ratios under a fixed random seed {code:drawings/R8-1/draw.py#bootstrap_ratio}.

Parameters:

- `bootstrap_ratio` `draws`: Uses as many resamples as toy.paired's own bootstrap, so the two intervals can be compared.
- `bootstrap_ratio` `seed`: Fixes the resampling so the clean room reproduces numbers.json exactly.

Not methods:

- `drawings/R8-1/draw.py#save`: It only writes each figure as PNG and SVG.

Proposed Re-manifest tests/test_paired.py and its fixture run directories (harness) (admission decides what joins the graph).

**Verdict (diff): passed** by claude-opus-5-5, session `8d49de3f-25bd-45dd-9cd8-536d2d84fbb7`.

- [minor] The `seed` reason goes into the paper's Methods table word for word, and it is written in harness terms a paper reader does not know: "the clean room" and "numbers.json". It also does not say that the value 20261025 is arbitrary, or that NumPy's generator is not toy.paired's random.Random(0), which makes the redrawn interval an independent check rather than a replay. A clearer wording would be: "An arbitrary fixed seed for NumPy's generator, so a rerun reproduces the redrawn interval exactly." The substance holds (see code_rule), so this is wording only. (research/sections/methods.md:214 (## Parameters table, `bootstrap_ratio` `seed` row); reason as filed at research/sessions/141/1/methods.json:11)

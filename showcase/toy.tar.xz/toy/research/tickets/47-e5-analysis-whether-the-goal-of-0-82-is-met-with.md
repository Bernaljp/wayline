---
id: 47
title: "E5 analysis: whether the goal of 0.82 is met without tuning on held-out data (C7)"
kind: analysis
difficulty: 2
status: parked
blocked_by: [33, 39, 40, 44]
touches: [analysis/E5/]
role: analyst
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 2, wallclock_minutes: 30}
inputs: [results/E5/, analysis/E1/summary.json, analysis/E2/paired.json]
outputs: [analysis/E5/goal.json]
acceptance:
  machine: ["python3 -c \"import json; d = json.load(open('analysis/E5/goal.json')); assert {'heldout_reads', 'goal_run_auroc', 'goal_met', 'seed_aurocs', 'harness_judgment', 'mean_auroc_with_e2', 'ceiling_below_goal', 'a7', 'c7_supported'} <= set(d) and d['heldout_reads'] <= 6 and d['goal_met'] == (d['goal_run_auroc'] >= 0.82)\""]
  quality: ["Is the goal run's auroc set beside 0.82, the three seeds, E1's ceiling and E2's 20-seed mean, with C7's verdict following the spec's rule and O2 never redefined as a mean over seeds?"]
objectives: [O2]
sections: [methods, results]
context_pack: [owner/measure.json, research/SPEC.md#e5-claims-c7, research/SPEC.md#anti-claims, research/SPEC.md#methods]
origin: research/SPEC.md#e5-claims-c7
proposed_by: planner
demo: analysis/E5/goal.json and the findings give the goal run's auroc beside 0.82, heldout_reads, E1's ceiling and E2's 20-seed mean with-term AUROC, with C7's verdict.
---

## Demo

analysis/E5/goal.json and the findings give the goal run's auroc beside 0.82, heldout_reads, E1's ceiling and E2's 20-seed mean with-term AUROC, with C7's verdict.

## Notes

Run `PYTHONPATH=code/src python3 -B -m toy.goallog "$WAYLINE_PROJECT/results/E5/changes.jsonl"`. Read the keep-if-better judgment the conductor journaled for the E5 ticket (progress events with goal O2 in research/journal.jsonl). If changes.jsonl is missing, rebuild its start lines from the three manifested summaries and say so. Write analysis/E5/goal.py and the analysis/E5/goal.json it writes, with these fields: heldout_reads; seed_aurocs (seeds 1-3); goal_run_auroc (seed 1, B3's seed, D5); goal_met = goal_run_auroc >= 0.82; harness_judgment (the judgment on the mean of three that decision #28 set); bayes_auroc and ceiling_below_goal from analysis/E1/summary.json (A6); mean_auroc_with_e2 from analysis/E2/paired.json; a7 = mean_auroc_with_e2 < 0.82 <= goal_run_auroc (when it holds, say the goal is met by its measure while the mean falls short); and c7_supported = goal_met and heldout_reads <= 6 and every kept change was chosen by val_auroc (none so far). If the start falls short of 0.82 and the ceiling is at least 0.82, propose E5's candidate changes, at most five, each its own goal ticket under the keep rule. Candidates are epochs and learning rate, an L2 penalty, and input columns drawn from x1..x4 and their six pairwise products, each chosen by val_auroc on --val-fraction 0.2 runs. A discarded change returns only with new evidence. Never redefine O2 as a mean over seeds (Q15). Keep every number in a finding equal to the field it cites. Return Methods and Results passages whose claim sentences each end with a provenance tag.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73.

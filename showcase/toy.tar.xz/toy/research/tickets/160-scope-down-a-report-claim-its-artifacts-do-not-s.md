---
id: 160
title: Scope down a report claim its artifacts do not support
kind: writing
difficulty: 3
status: parked
blocked_by: []
touches: []
role: writer
skills: []
inputs: [research/REPORT.md, research/findings.jsonl#t53-a1-f1, tests/test_oracle_budget.py#TIME_LIMIT_SECONDS]
outputs: []
acceptance:
  machine: []
  quality: [Does every claim sentence the verifier could not support now say only what its cited artifacts do?]
context_pack: [research/REPORT.md, research/findings.jsonl#t53-a1-f1, tests/test_oracle_budget.py#TIME_LIMIT_SECONDS]
origin: research/REPORT.md#claim-562cff7c301dc8d1
proposed_by: verifier
demo: The general report renders the narrowed finding in place of `t53-a1-f1`, and the next run end samples it.
sections: [results]
---

## Demo

The general report renders the narrowed finding in place of `t53-a1-f1`, and the next run end samples it.

## The claim the verifier could not support

> `t53-a1-f1` The committed test holds the audit of the default draw D2 (seed 10001, 1000000 rows) to a wall-clock limit of 3600 seconds and a peak child memory limit of 4.0 GB, and the audit passed both when the test was run.{res:t53-a1/tests/test_oracle_budget.py#TIME_LIMIT_SECONDS}

Verifier session `f19dbc8e-7635-4a86-99e8-cdb87e036c76` (claude-opus-5-5) opened the cited artifacts and found:

- [blocker] The sentence says the committed test audits the default draw D2 at seed 10001. The committed file at this path (HEAD, commit 607722b) runs SEED = 20001, commented 'outside D1 (seeds 1-20) and D2 (seed 10001)', and its docstring says it uses that seed 'so the test never computes E1's own result'. On which draw is audited, the artifact says the opposite of the sentence. (tests/test_oracle_budget.py line 30 (SEED = 20001) and docstring lines 3-5; tag res:t53-a1/tests/test_oracle_budget.py#TIME_LIMIT_SECONDS)
- [blocker] The clause 'the audit passed both when the test was run' claims a run outcome, but the only cited artifact is test source: at TIME_LIMIT_SECONDS it sets the 3600 s limit and asserts against it, and records no run, no measured value and no pass. The run record (research/sessions/53/1/acceptance.json: exit 0, '19.5 s wall-clock, 0.68 GB peak memory') is not cited, and its printed line does not name the seed, so the clause says more than the cited artifact does. (tests/test_oracle_budget.py#TIME_LIMIT_SECONDS (lines 31, 53, 58, 65); research/findings.jsonl line 21 (provenance is only this tag))
- [major] The tag names run t53-a1's registration of the file (2421 bytes, sha256 dea33416…), but the file at the path is now 3058 bytes, sha256 a6204639… (commit 607722b), and no manifest entry holds it. The t53-a1 bytes exist only in git (017f053, SEED = 10001 at line 27); read there they support the seed, rows and limits but still not 'passed', and the present-tense 'the committed test' no longer describes main. Open decision 152 and ticket 156 already cover this mismatch. (research/manifest.json lines 1300-1307)
- [major] The locator TIME_LIMIT_SECONDS names only the lines that mention that constant, and of the sentence's numbers those lines hold only 3600. The 4.0 GB limit, seed 10001 and 1000000 rows sit on the MEMORY_LIMIT_GB, SEED and ROWS lines (29-32 now, 26-29 at 017f053), which the locator does not reach; the harness's line-based reading (harness/wayline/numbers.py lines 162-163) does not reach them either. (tests/test_oracle_budget.py#TIME_LIMIT_SECONDS (lines 31, 53, 58, 65 now; lines 28, 46, 51, 56 at 017f053))
- [minor] peak_children_gb divides ru_maxrss (reported in KiB on Linux) by 1024^2, so the asserted bound is 4.0 GiB, about 4.29 GB. The sentence repeats the constant's '4.0 GB'. The direction (under the limit) is right; the unit is loose. (tests/test_oracle_budget.py lines 32, 36-40, 66)

The sentence is a finding as its ticket recorded it (`t53-a1-f1`), and the report renders findings as recorded. Return in the result the finding narrowed to what the artifacts support, with its provenance, naming the finding it narrows in its `replaces` (`t53-a1-f1`); the ledger records it in that finding's place and the next render reads it.

A finding's provenance is the artifact's path in the project and a locator, the form the manifest resolves (`analysis/ablation/signal-4.json#paired_gain`), never a report tag such as `{res:<run>/<path>}`: the ledger refuses a provenance it cannot find in `manifest.json` or on disk.

## The artifacts the verifier opened

- `tests/test_oracle_budget.py#TIME_LIMIT_SECONDS`

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 176, 177, 178, 179, 180, 181, 182, 183, 184, 185.

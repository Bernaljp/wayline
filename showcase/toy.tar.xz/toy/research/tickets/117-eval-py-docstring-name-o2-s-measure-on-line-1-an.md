---
id: 117
title: "eval.py docstring: name O2's measure on line 1 and say that the positional path and WAYLINE_ARTIFACT take a run directory"
kind: code
difficulty: 1
status: accepted
blocked_by: []
touches: [src/toy/eval.py]
role: coder
skills: []
inputs: [src/toy/eval.py]
outputs: [src/toy/eval.py]
acceptance:
  machine: ["PYTHONPATH=src python3 -B -m unittest tests.test_eval && head -n 1 src/toy/eval.py | grep -q \"O2's measure\"", "! grep -q \"O1's\" src/toy/eval.py && WAYLINE_ARTIFACT=owner/sample-summary.json PYTHONPATH=src python3 -B -m toy.eval --split held_out | grep -qx 'auroc: 0.8502984862625299'", "python3 -B -c \"import ast; d = ast.get_docstring(ast.parse(open('src/toy/eval.py', encoding='utf-8').read())); assert 'WAYLINE_ARTIFACT' in d and 'positional' in d and d.count('run directory') >= 2\""]
  quality: ["Does line 1 of src/toy/eval.py name O2's measure, with no remaining mention of O1? Does the module docstring say that the positional path and WAYLINE_ARTIFACT take a run directory, as --summary does? Is the behaviour unchanged? Does the returned Methods passage replace P17 with every sentence ending in a code tag that resolves?"]
objectives: [O1, O2]
sections: [methods]
context_pack: [src/toy/eval.py, research/sections/methods.md:59-62, research/tickets/95-eval-py-summary-path-and-split-val-o2-s-goal-com.md#result, research/SPEC.md#seams]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`head -n 1 src/toy/eval.py` names O2's measure instead of O1's. The module docstring says that the positional path and WAYLINE_ARTIFACT accept a run directory, as --summary does. `WAYLINE_ARTIFACT=owner/sample-summary.json PYTHONPATH=src python3 -m toy.eval --split held_out` still prints auroc: 0.8502984862625299."
---

## Demo

`head -n 1 src/toy/eval.py` names O2's measure instead of O1's. The module docstring says that the positional path and WAYLINE_ARTIFACT accept a run directory, as --summary does. `WAYLINE_ARTIFACT=owner/sample-summary.json PYTHONPATH=src python3 -m toy.eval --split held_out` still prints auroc: 0.8502984862625299.

## Notes

Cut from ticket 95 by the planner's split.

This ticket is half of a split of #95. #95's code is already on main: commit 27d10e3 added --summary, --split val and the 12 tests in tests/test_eval.py. Do not rewrite that code. #95 failed on two things, and this ticket fixes the first.

(1) The verifier's blocker. Line 1 of the module docstring still reads "O1's measure's `eval_command`". O1 has no measure (research/OBJECTIVES.md); the goal command is O2's measure. Change it to "O2's measure's". #95's second attempt made this fix in commit 1c49fd4 on ticket/95, but that commit is not on main. Make the one-word edit here; do not rely on that branch.

(2) A minor point the verifier raised. read_metric (line 38) passes every artifact through summary_path, so the positional path and WAYLINE_ARTIFACT accept a run directory too, not only --summary. Nothing documents this. Add one sentence to the module docstring saying so, using the words "positional" and "run directory". Change no behaviour. tests/test_eval.py is not in your touch set; the other half of the split (T2) adds tests that pin this behaviour.

Return one Methods passage under the heading "Evaluation command", with `replaces` set to P17. End every sentence with a tag that resolves, and leave the passage's evidence unset. Suggested text: "eval.py reads one toy.train summary and prints one metric from it {code:src/toy/eval.py#main}. The summary is named by --summary, which takes a summary file or a run directory holding summary.json, or else by the positional path or WAYLINE_ARTIFACT {code:src/toy/eval.py#main}. `--split held_out` prints the held-out `auroc` and `--split val` prints the `val_auroc` of a --val-fraction run {code:src/toy/eval.py#SPLIT_METRICS}. A summary without the requested split's metric is an error and is never answered from the other split {code:src/toy/eval.py#read_metric}." Leave out the run-directory case of the positional path and WAYLINE_ARTIFACT: T2's passage states it, and two passages saying the same thing fail the repeat check. Write code locators as src/toy/..., never code/src/toy/....

File no finding. Findings t95-a1-f1 and t95-a1-f2 stand, and #95's resume failed only because it re-filed f2 without naming it in `replaces`.

Bash: this role runs a command only when every part of it begins with a program on its allow list: python3, git add, git commit, git status, git diff, git log, ls, cat and wayline accept. A `PYTHONPATH=src` prefix, mkdir, bash, a heredoc and a `>` redirect are refused. Edit with the Edit or Write tool, and run one plain command per Bash call. `wayline accept` runs the criteria and sets PYTHONPATH itself. For a check of your own, use `python3 -B -c "import sys; sys.path.insert(0, 'src'); ..."`. If a command is refused, retry it in an allowed form, and return blocked only if that form is refused too, naming it.

## Result

### Attempt 1

Line 1 of the module docstring in src/toy/eval.py now reads "O2's measure's `eval_command`". Before, it said O1's, but O1 has no measure. I added a paragraph to the docstring saying that `--summary`, the positional path and WAYLINE_ARTIFACT all accept a run directory and read its summary.json, because read_metric applies summary_path to every source. The positional argument's --help text now says the same. Only docstring and help text changed, so the behaviour is unchanged. `wayline accept` passed all three acceptance commands: tests.test_eval passes, and `WAYLINE_ARTIFACT=owner/sample-summary.json ... --split held_out` still prints auroc: 0.8502984862625299. The work is committed as cd869ee on ticket/117.

Wrote: `src/toy/eval.py`

Ran: `wayline accept`, `git add src/toy/eval.py`, `git commit`

Passages:

- methods, Evaluation command: Whichever source names the summary (--summary, the positional path, or WAYLINE_ARTIFACT), eval.py reads the named file, or the summary.json inside it when the path is a run directory {code:src/toy/eval.py#read_metric}.

**Verdict (quality): failed** by claude-opus-5-5, session `10500f2f-5058-45a1-acad-11afdfe917ea`.

- [blocker] The returned Methods passage does not replace P17. Its `replaces` is null, so it was journaled as a new passage, P24, beside P17. P17 stands unchanged at research/sections/methods.md:61-62: it still names only --summary and WAYLINE_ARTIFACT as sources and tags only the last of its four sentences. The returned passage is also not the replacement the Notes asked for (ticket line 38), which is the four-sentence account of the evaluation command with each sentence ending in a code tag and `replaces: P17`. Parts 1-3 of the criterion hold (src/toy/eval.py:1 reads "O2's measure's", no "O1" anywhere in the file, lines 20-21 cover the positional path and WAYLINE_ARTIFACT), so this part alone fails the ticket. (research/sessions/117/1/result.json:112-118 (passages[0].replaces = null); research/passages.jsonl:24 (P24, replaces null); research/sections/methods.md:59-65 (## Evaluation command: P17 and P24 side by side))
- [major] P24 states the one case the Notes said to leave out: the run-directory case of the positional path and WAYLINE_ARTIFACT, tagged {code:src/toy/eval.py#read_metric}. Ticket 118 is told to return that same sentence, with the same tag, as its own passage under the same heading. When 118 lands, "Evaluation command" will carry two passages saying the same thing, which is the repeat the Notes warned of. (research/tickets/117-eval-py-docstring-name-o2-s-measure-on-line-1-an.md:38 (## Notes); research/sections/methods.md:64-65 (P24); research/tickets/118-tests-test-eval-py-pin-that-the-positional-path.md ## Notes)
- [minor] This is outside the criterion. The Notes say "File no finding", but the result filed t117-a1-f1 under R9's heading with replaces null. That is the same pattern the Notes say failed #95's resume. (research/findings.jsonl:50 (t117-a1-f1); research/tickets/117-eval-py-docstring-name-o2-s-measure-on-line-1-an.md:40 (## Notes))
- [minor] The likely cause, outside the criterion: the worker's prompt restates only the ticket's title, kind, demo, touch set, machine acceptance and budget (_ticket_section). So the Notes, which hold `replaces: P17`, the suggested text, the run-directory exclusion and "file no finding", never reached the worker, and its session never opened the ticket file. The pack's methods.md:59-62 excerpt also showed P18, not P17 (prompt.md:85-91). This is the known gap at harness/docs/verification/m5.md:825, and a retry built the same way is likely to fail the same way. (research/sessions/117/1/prompt.md:1-10 and 85-91; /home/bernaljp/wayline-m8/harness/wayline/worker.py:744-757 (_ticket_section))
- [minor] I could not rerun tests.test_eval or the goal command myself, because this session's Bash refused python3. My judgment that behaviour is unchanged rests on two things. First, the diff of 12aed98, which is identical to cd869ee: it changes only the module docstring (lines 1, 13-14, 20-21) and the positional argument's help= text (line 54, which changes --help output only). Second, the harness's acceptance records in the worktree, after the rebase, and on main: 12 tests OK, and the command prints auroc: 0.8502984862625299. (research/journal.jsonl:1335-1337 (acceptance worktree/rebased/main); research/sessions/117/1/acceptance.json; src/toy/eval.py:54)

### Attempt 1

This retry fixes the Methods passage; the code needed no change. The verifier found the code correct: line 1 of src/toy/eval.py names O2's measure, no "O1" remains in the file, the docstring says that --summary, the positional path and WAYLINE_ARTIFACT take a run directory, and behaviour is unchanged. That is commit cd869ee on ticket/117, and the working tree is clean. `wayline accept` passes all three acceptance commands again. What failed was the passage. This result returns the four-sentence account of the evaluation command that the ticket's Notes ask for, with `replaces: P17` and a code tag ending every sentence. As the Notes ask, it leaves out the run-directory case of the positional path and WAYLINE_ARTIFACT, which ticket 118 states, and it files no finding. One leftover remains that I cannot remove: attempt 1 journaled P24 (methods.md:64-65) and finding t117-a1-f1. A worker cannot withdraw either. When ticket 118 returns its run-directory sentence, it should name P24 in `replaces` so the heading does not carry the sentence twice. I could not read the ticket file in attempt 1 because the prompt did not include its Notes; I read them this time.

Ran: `wayline accept`, `git status --short`

Passages:

- methods, Evaluation command, replacing P17: eval.py reads one toy.train summary and prints one metric from it {code:src/toy/eval.py#main}. The summary is named by --summary, which takes a summary file or a run directory holding summary.json, or else by the positional path or WAYLINE_ARTIFACT {code:src/toy/eval.py#main}. `--split held_out` prints the held-out `auroc` and `--split val` prints the `val_auroc` of a --val-fraction run {code:src/toy/eval.py#SPLIT_METRICS}. A summary without the requested split's metric is an error and is never answered from the other split {code:src/toy/eval.py#read_metric}.

Proposed Ticket 118's run-directory passage should replace P24 (writing) (admission decides what joins the graph).

**Verdict (quality): passed** by claude-opus-5-5, session `3bb57e4a-7395-4a0b-bdb4-53d551a39c2a`.

- [minor] This session's Bash refused python3, so I did not rerun tests.test_eval, the goal command or the harness's tag resolver myself. My judgment that behaviour is unchanged rests on two things. First, the diff of 12aed98, which matches cd869ee for eval.py: it changes only the module docstring (lines 1, 13-14 reflowed, 20-21) and the positional argument's help= text at line 54, which alters --help output only. Second, the harness's acceptance records: 12 tests OK and `auroc: 0.8502984862625299`, in the worktree, after the rebase and on main. My judgment that the tags resolve rests on reading code_tag_problem and _python_names (harness/wayline/provenance.py:314-371) against `git show main:src/toy/eval.py`. That file defines SPLIT_METRICS (line 31, a module-level assignment), read_metric (line 40) and main (line 48). (src/toy/eval.py:54; research/journal.jsonl:1665-1667 (acceptance worktree/rebased/main))
- [minor] This is outside the criterion. Attempt 1's passage P24 still stands beside P26 under 'Evaluation command', so ticket 117 has two passages there where the Notes (ticket line 38) asked for one. P24 also states the run-directory case of the positional path and WAYLINE_ARTIFACT, which the Notes said to leave out. No repeat resulted, because ticket 118's P27 (research/passages.jsonl:27) describes the tests rather than restating it. But nothing replaces P24, and the resume's proposal that 118 replace it was parked for radius. Finding t117-a1-f1 also still stands, against the Notes' 'File no finding'. A worker cannot withdraw either. (research/sections/methods.md:64-65 (## Evaluation command, P24); research/journal.jsonl:1664; research/findings.jsonl:50)
- [minor] This is a harness issue, outside the criterion. P26's third sentence opens with a backtick (`--split held_out`), and _BOUNDARY's lookahead only starts a new sentence at a quote, bracket or capital. By my reading, the linter therefore joins sentences 2 and 3 into one unit and checks the position of only that unit's last tag. Its 'every claim sentence ends with a provenance tag that resolves' pass (research/journal.jsonl:1665) could not have caught a missing tag at the end of sentence 2. What establishes that all four sentences end in a tag is reading the passage itself, at research/passages.jsonl:26. All four tags were still checked for resolution, because sentence.tags collects every tag in a unit (provenance.py:241, 870-875). (/home/bernaljp/wayline-m8/harness/wayline/provenance.py:98 (_BOUNDARY) and 850-887 (end_kinds, _Pass.read))

---
id: 158
title: Scope down a report claim its artifacts do not support
kind: writing
difficulty: 3
status: parked
blocked_by: []
touches: []
role: writer
skills: []
inputs: [research/REPORT.md, research/findings.jsonl#t6-a1-f4, tests/test_oracle.py#Calibration.test_oracle_is_calibrated_on_20000_rows]
outputs: []
acceptance:
  machine: []
  quality: [Does every claim sentence the verifier could not support now say only what its cited artifacts do?]
context_pack: [research/REPORT.md, research/findings.jsonl#t6-a1-f4, tests/test_oracle.py#Calibration.test_oracle_is_calibrated_on_20000_rows]
origin: research/REPORT.md#claim-5d06e38f7f896d69
proposed_by: verifier
demo: The general report renders the narrowed finding in place of `t6-a1-f4`, and the next run end samples it.
sections: [results]
---

## Demo

The general report renders the narrowed finding in place of `t6-a1-f4`, and the next run end samples it.

## The claim the verifier could not support

> At E1's 10^6 rows (50,000 per bin, SE <= 0.0023), the spec's <= 0.01 threshold is about 4 SE and is a meaningful test.{res:t6-a1/tests/test_oracle.py#Calibration.test_oracle_is_calibrated_on_20000_rows}

Verifier session `e28637f7-728e-424c-b482-10aadfb4c146` (claude-opus-5-5) opened the cited artifacts and found:

- [blocker] The cited test does not support the sentence. It draws 20,000 rows at seed 7 and asserts three things only: there are 20 bins, the bins hold 20,000 rows in total, and the bins' chi-square is below 45.31. Its comment covers only that size: about 1,000 rows per bin, an SE up to about 0.016, and a largest gap of 0.034 at seed 7. It says nothing about E1, 10^6 rows, 50,000 rows per bin, SE <= 0.0023, the spec's <= 0.01 threshold, a margin of about 4 SE, or the threshold being a meaningful test at 10^6 rows. None of the sentence's numbers or its judgment appear in the artifact at its locator, so the sentence says more than its tag. (tests/test_oracle.py#Calibration.test_oracle_is_calibrated_on_20000_rows (manifested t6-a1 version = commit 5885a7f, lines 128-138; same method at HEAD, lines 161-170))
- [minor] The sentence's numbers come from sources it does not cite. The 10^6-row audit draw is SPEC.md D2. The 20 equal-count bins and the <= 0.01 threshold are SPEC.md's calibration_error definition and E1 success rule. The figures 50,000 per bin, 0.5/sqrt(50,000) ≈ 0.00224 <= 0.0023, and 0.01/0.00224 ≈ 4.5 ('about 4 SE') are arithmetic on those, and no cited artifact carries it. No artifact shows that 0.01 is a meaningful test at 10^6 rows, for example a miscalibrated control failing it. The file's only miscalibrated control is in a different method (test_calibration_error_on_200000_rows_and_a_miscalibrated_control), at 200,000 rows with a 0.02 threshold. The only '4 SE' in the file is the unrelated Monte Carlo transcription test. (research/SPEC.md:114 (D2, 10^6 rows); research/SPEC.md:136 and :56 (20 bins, calibration_error <= 0.01))
- [minor] The working file at the tagged path no longer matches the recorded artifact. The manifest records tests/test_oracle.py for run t6-a1 at sha256 2bed2609… and 10,710 bytes, which is commit 5885a7f. The working file is sha256 a3d69055… and 14,557 bytes after commits 3bc54ac, a52b13e, dd89183 and 3fee2a7, and the cited method's comment was rewritten: the SE ~0.016 and seed-7 0.034 text now sits in test_largest_gap_at_20000_rows_is_sampling_noise. Neither version supports this sentence, but anyone following the tag at HEAD reads different text than the run recorded. (research/manifest.json:1120-1126 (tests/test_oracle.py, run_id t6-a1))

The sentence is a finding as its ticket recorded it (`t6-a1-f4`), and the report renders findings as recorded. Return in the result the finding narrowed to what the artifacts support, with its provenance, naming the finding it narrows in its `replaces` (`t6-a1-f4`); the ledger records it in that finding's place and the next render reads it.

A finding's provenance is the artifact's path in the project and a locator, the form the manifest resolves (`analysis/ablation/signal-4.json#paired_gain`), never a report tag such as `{res:<run>/<path>}`: the ledger refuses a provenance it cannot find in `manifest.json` or on disk.

## The artifacts the verifier opened

- `tests/test_oracle.py#Calibration.test_oracle_is_calibrated_on_20000_rows`

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 176, 177, 178, 179, 180, 181, 182, 183, 184, 185.

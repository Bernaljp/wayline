---
id: 20
title: "E4 experiment: training-size sweep at strengths 1 and 0"
kind: experiment
difficulty: 3
status: parked
blocked_by: [18]
touches: [experiments/E4/, results/runs/E4/, results/smoke/E4/]
role: experimenter
skills: []
resources: {cpu: 2, gpu: 1, ram_gb: 16, wallclock_minutes: 90}
inputs: [configs/arms.json, src/toy/train.py, src/toy/generate.py]
outputs: [results/runs/E4/m1_n1000/with/seed1/summary.json, results/runs/E4/m1_n64000/without/seed20/heldout_scores.csv, results/runs/E4/m0_n1000/with/seed1/summary.json, results/runs/E4/m0_n64000/without/seed20/heldout_scores.csv]
acceptance:
  machine: ["python3 -c \"import json; json.load(open('experiments/E4/jobs.json'))\"", "for m in 0 1; do for n in 1000 2000 4000 8000 32000 64000; do grep -q \"results/runs/E4/m${m}_n${n}/\" experiments/E4/jobs.json || exit 1; done; done; grep -rq -- '--train-rows' experiments/E4/ && grep -rq -- '--rows' experiments/E4/ && ! grep -q '_n16000/' experiments/E4/jobs.json"]
  quality: ["Do the jobs run exactly the twelve points (strength 1 and 0, sizes 1000 to 64000 without 16000), capping the default draw's training rows for the small sizes and drawing n/0.8 rows for the large ones, seeds 1-20, both arms, nothing tuned?"]
objectives: [O4]
sections: [methods]
context_pack: [configs/arms.json, research/SPEC.md#e4-claims-c6, research/SPEC.md#methods, src/toy/train.py]
origin: research/SPEC.md#e4-claims-c6
proposed_by: planner
demo: "`wayline status` shows twelve E4 jobs, one per strength 1 or 0 and training size 1000 to 64000, each running 40 paired runs into results/runs/E4/m<m>_n<n>/."
retry:
  host_oom: []
  gpu_oom: [--batch-size=64, --batch-size=16]
---

## Demo

`wayline status` shows twelve E4 jobs, one per strength 1 or 0 and training size 1000 to 64000, each running 40 paired runs into results/runs/E4/m<m>_n<n>/.

## Notes

n0 is 16000 training rows (train.py's default 20000 rows less the held-out fifth), so the sizes are 1000, 2000, 4000, 8000 (n0/16 to n0/2), 32000 and 64000 (2*n0, 4*n0); none is under 200. Write experiments/E4/point.sh and experiments/E4/jobs.json with one member per point, m in {1, 0} and n in {1000, 2000, 4000, 8000, 32000, 64000}: seeds 1-20, both arms, `--config configs/arms.json --strength m --save-scores`, plus `--train-rows n` for n up to 8000 (the default draw, held-out fifth unchanged) or `--rows 40000` / `--rows 80000` for n = 32000 / 64000 (n/0.8 rows, the last fifth held out); out results/runs/E4/m<m>_n<n>/<arm>/seed<i>/. The n0 points at m = 1 and m = 0 are E2's m1_n0 and E3's m0_n0: do not re-run them. Each member's expected_outputs lists literally every run's three files. Extra flags (--batch-size) pass through to train.py. Run train.py with /home/bernaljp/.wayline/tools/venv/bin/python and env PYTHONPATH=src. Nothing is tuned and no seed is dropped. Smoke-test on the CPU into results/smoke/E4/ and commit nothing under results/.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49.

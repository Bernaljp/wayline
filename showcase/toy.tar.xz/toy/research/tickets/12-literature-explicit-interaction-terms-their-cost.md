---
id: 12
title: "Literature: explicit interaction terms, their cost when unneeded, and paired tests of two classifiers"
kind: lit
difficulty: 2
status: parked
blocked_by: []
touches: []
role: surveyor
skills: []
acceptance:
  machine: []
  quality: []
objectives: [O1, O4]
sections: [introduction]
context_pack: [research/sections/introduction.md, research/CONCERNS.md, research/SPEC.md#e6-claims-c8, research/POSITION.md#what-the-references-lack]
origin: research/SPEC.md#e6-claims-c8
proposed_by: planner
demo: The Introduction holds passages tagged at resolved dossiers that place the paired-gain question (O1) and the null and strength/size probes (O4) against interaction detection and selection and against paired tests, and research/refs/ holds a dossier for each of D6's five DOIs.
---

## Demo

The Introduction holds passages tagged at resolved dossiers that place the paired-gain question (O1) and the null and strength/size probes (O4) against interaction detection and selection and against paired tests, and research/refs/ holds a dossier for each of D6's five DOIs.

## Notes

First check each of D6's five works with `wayline scout`, whether or not a passage cites it, since E6's placement analysis reads their dossiers: doi:10.1214/07-aoas148 (Friedman & Popescu 2008), doi:10.1145/2487575.2487579 (Lou et al. 2013), doi:10.1214/13-aos1096 (Bien et al. 2013), doi:10.2307/2531595 (DeLong et al. 1988), doi:10.1162/089976698300017197 (Dietterich 1998). Then search for work that measures the held-out gain of handing a linear or logistic model an explicit product term against the same model without it (O1), and for the cost of spurious interaction terms and how it moves with sample size and interaction strength (O4; K1, K4, K6). Passage P1 asks to be rewritten against these dossiers once resolved. Rest nothing on paper-a or paper-b (unresolved fixtures, K7). Tree ensembles, MLPs, factorization machines and GA2M as fitted competitors are out of scope (O5 parked, Q7 rejected): cite them only as what this project does not compare against.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49.

---
id: 57
title: "toy.goallog: held-out reads of the goal loop from results/E5/changes.jsonl (src/ layout)"
kind: code
difficulty: 1
status: parked
blocked_by: []
touches: [src/toy/goallog.py, tests/test_goallog.py, tests/fixtures/goallog/]
role: coder
skills: []
acceptance:
  machine: [PYTHONPATH=src python3 -B -m unittest tests.test_goallog, "PYTHONPATH=src python3 -B -m toy.goallog tests/fixtures/goallog/changes.jsonl | python3 -c \"import json, sys; d = json.load(sys.stdin); assert {'heldout_reads', 'heldout_scorings', 'candidates', 'kept', 'discarded'} <= set(d)\""]
  quality: []
objectives: [O2]
sections: [methods]
context_pack: [research/SPEC.md#e5-claims-c7, research/SPEC.md#seams]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`PYTHONPATH=src python3 -m toy.goallog tests/fixtures/goallog/changes.jsonl` prints heldout_reads and the per-candidate table."
---

## Demo

`PYTHONPATH=src python3 -m toy.goallog tests/fixtures/goallog/changes.jsonl` prints heldout_reads and the per-candidate table.

## Notes

Re-cut of ticket 33 on the kept layout (decision #50): write only src/toy/goallog.py, tests/test_goallog.py and tests/fixtures/goallog/. `toy.goallog <changes.jsonl>` reads E5's log. Each line is one held-out scoring of one seed of one candidate: candidate (a name; 'start' for the unchanged default run), seed, val_auroc (null for the start), auroc, kept (true, false, or null until keep-if-better judges it), and an optional note. Print JSON with: heldout_reads, the number of distinct candidates scored on the held-out fifth (the start plus each candidate; the spec allows at most six); heldout_scorings, the number of lines (decision #28 scores each candidate at seeds 1, 2 and 3); candidates, one row per candidate with its seeds, their aurocs, their mean, val_auroc and kept; kept and discarded, the counts. A malformed line is refused with its line number and exit 1. Fixture: tests/fixtures/goallog/changes.jsonl with a start at three seeds and two candidates. Stdlib only; run Python as python3 -B. Return one Methods passage whose claim sentences each end with a provenance tag. If a Bash command you need is refused, stop and return blocked naming it.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93.

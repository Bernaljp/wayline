---
id: 190
title: "Draw R6: Oracle audit cost on the 10^6-row draw D2"
kind: drawing
difficulty: 2
status: open
blocked_by: []
touches: [drawings/R6-3/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O3]
context_pack: []
origin: drawing R6-3 at order
proposed_by: conductor
demo: R6 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R6-3

Code opened this drawing of R6 ("Oracle audit cost on the 10^6-row draw D2") at a rest point (order), over its findings t53-a1-f1. Its brief, rendered by code at each launch, is in the prompt.

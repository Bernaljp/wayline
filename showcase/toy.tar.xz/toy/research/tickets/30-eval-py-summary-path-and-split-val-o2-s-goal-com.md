---
id: 30
title: "eval.py: --summary PATH and --split val, O2's goal command unchanged"
kind: code
difficulty: 1
status: parked
blocked_by: [50]
touches: [code/src/toy/eval.py, code/tests/test_eval.py]
role: coder
skills: []
acceptance:
  machine: [PYTHONPATH=code/src python3 -B -m unittest discover -s code/tests -p 'test_eval.py', "PYTHONPATH=code/src python3 -B -m toy.eval --split held_out --summary owner/sample-summary.json | grep -qx 'auroc: 0.8502984862625299' && WAYLINE_ARTIFACT=owner/sample-summary.json PYTHONPATH=code/src python3 -B -m toy.eval --split held_out | grep -qx 'auroc: 0.8502984862625299'"]
  quality: []
objectives: [O1, O2]
sections: [methods]
context_pack: [owner/measure.json, code/src/toy/eval.py, research/SPEC.md#seams, research/SPEC.md#metrics]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`PYTHONPATH=code/src python3 -m toy.eval --split held_out --summary owner/sample-summary.json` prints auroc: 0.8502984862625299; O2's command with WAYLINE_ARTIFACT set prints the same; --split val on a --val-fraction run prints its val_auroc."
---

## Demo

`PYTHONPATH=code/src python3 -m toy.eval --split held_out --summary owner/sample-summary.json` prints auroc: 0.8502984862625299; O2's command with WAYLINE_ARTIFACT set prints the same; --split val on a --val-fraction run prints its val_auroc.

## Notes

Paused by the layout decision; cut for its recommended answer. Under that answer the package lives at code/src/toy/ and the tests at code/tests/, with symlinks src -> code/src and tests -> code/tests so the old paths still work. Write only under code/. If the owner answers otherwise, this ticket is re-cut. Keep what O2's command does today: `PYTHONPATH=src python3 -m toy.eval --split held_out` reads the summary named by the positional path or by WAYLINE_ARTIFACT (keep-if-better exports it for each seed artifact) and prints 'auroc: <value>' with the value unformatted. That is the 'default summary' the spec's seam names. Add --summary PATH, equivalent to the positional path, also accepting a run directory (reads summary.json inside it). Add --split val, which prints 'val_auroc: <value>' from the summary's val_auroc and exits non-zero when there is none. --split held_out on a summary with no auroc (a --val-fraction run) exits non-zero, as now. code/tests/test_eval.py covers the old path (WAYLINE_ARTIFACT=owner/sample-summary.json), --summary on a file and on a run directory, and --split val on a temporary summary; resolve paths from the test file's location so it runs under `unittest discover -s code/tests`. Stdlib only; run Python as python3 -B; do not create an __init__.py in code/tests. Return one Methods passage, and end every claim sentence in it with a provenance tag such as {code:code/src/toy/eval.py#main}: tickets 6 and 16 failed acceptance on untagged sentences and on a missing Methods passage.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73.

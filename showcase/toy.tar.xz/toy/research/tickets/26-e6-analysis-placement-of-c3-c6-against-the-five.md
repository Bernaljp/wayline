---
id: 26
title: "E6 analysis: placement of C3-C6 against the five resolved works (C8)"
kind: analysis
difficulty: 3
status: parked
blocked_by: [11, 12]
touches: [analysis/E6/]
role: analyst
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 2, wallclock_minutes: 30}
inputs: [research/refs/]
outputs: [analysis/E6/placement.json, analysis/E6/placement_summary.json]
acceptance:
  machine: ["PYTHONPATH=src python3 -B -m toy.placement analysis/E6/placement.json --refs \"${WAYLINE_PROJECT:-.}/research/refs\" > /dev/null", "python3 -c \"import json; d = json.load(open('analysis/E6/placement_summary.json')); assert {'resolved_refs', 'prior_measures_gain'} <= set(d)\""]
  quality: ["Is each work's measures_paired_gain backed by a locator into its dossier, is a work the dossier cannot settle marked null rather than guessed, and does C8's verdict follow resolved_refs and prior_measures_gain with nothing resting on paper-a or paper-b?"]
objectives: [O1]
sections: [methods, results]
context_pack: [research/SPEC.md#e6-claims-c8, research/SPEC.md#anti-claims, research/refs/]
origin: research/SPEC.md#e6-claims-c8
proposed_by: planner
demo: analysis/E6/placement.json lists each of D6's five works with its dossier's existence, whether it measures the paired gain and the locator that settles it; toy.placement prints resolved_refs and prior_measures_gain, and the findings give C8's verdict.
---

## Demo

analysis/E6/placement.json lists each of D6's five works with its dossier's existence, whether it measures the paired gain and the locator that settles it; toy.placement prints resolved_refs and prior_measures_gain, and the findings give C8's verdict.

## Notes

For each D6 work (doi:10.1214/07-aoas148, doi:10.1145/2487575.2487579, doi:10.1214/13-aos1096, doi:10.2307/2531595, doi:10.1162/089976698300017197) find its dossier under $WAYLINE_PROJECT/research/refs/ (the slug the lit ticket's scout gave it), read it, and write analysis/E6/placement.json: slug, doi, existence as the dossier states it, measures_paired_gain (true when the work reports a held-out AUROC gain of an explicit product column over the same model without it, against a no-interaction control; false when the dossier shows it does not; null when the dossier cannot settle it) and the locator of the passage that settles it. Then `PYTHONPATH=src python3 -B -m toy.placement analysis/E6/placement.json --refs "$WAYLINE_PROJECT/research/refs" > analysis/E6/placement_summary.json`. C8 is supported when resolved_refs >= 4 and prior_measures_gain == 0; A9 when prior_measures_gain >= 1 (cite that work as the closest prior work and set its number beside C3's); unresolved when resolved_refs < 4, naming the works read. Rest nothing on paper-a or paper-b. The spec's results/placement.json lives here because results/ is git-ignored and an analysis's files must be committed.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49.

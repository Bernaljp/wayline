---
id: 156
title: Re-file the oracle budget finding (R6) to describe tests/test_oracle_budget.py as it is now (seed 20001), so the manifest takes its current hash
kind: analysis
difficulty: 2
status: parked
blocked_by: [152]
touches: [analysis/refile/oracle_budget.json]
role: analyst
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 1, wallclock_minutes: 10}
inputs: [tests/test_oracle_budget.py, research/findings.jsonl, research/tickets/152-tests-test-oracle-budget-py-changed-after-run-t5.md]
outputs: [analysis/refile/oracle_budget.json]
acceptance:
  machine: ["python3 -c \"import ast, hashlib, json, re; d = json.load(open('analysis/refile/oracle_budget.json')); p = 'tests/test_oracle_budget.py'; fs = {f['path']: f['sha256'] for f in d['files']}; assert fs.get(p) == hashlib.sha256(open(p, 'rb').read()).hexdigest() and all(hashlib.sha256(open(q, 'rb').read()).hexdigest() == h for q, h in fs.items()); c = {n.targets[0].id: n.value.value for n in ast.parse(open(p).read()).body if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and isinstance(n.value, ast.Constant)}; ks = ('ROWS', 'SEED', 'TIME_LIMIT_SECONDS', 'MEMORY_LIMIT_GB'); assert {k: d['limits'][k] for k in ks} == {k: c[k] for k in ks}; fd = d['findings']; assert [f['replaces'] for f in fd] == ['t53-a1-f1'] and fd[0]['negative'] is False and fd[0]['provenance'].partition('#')[0] == p; tags = re.findall(r'\\{res:(t[0-9]+-a[0-9]+)/([^#{}]+)#[^{}]+\\}', fd[0]['text']); runs = {r for r, q in tags}; assert tags and len(runs) == 1 and 't53-a1' not in runs and p in {q for r, q in tags} <= set(fs) and str(c['SEED']) in fd[0]['text']\""]
  quality: ["Does the re-filed finding describe tests/test_oracle_budget.py as it is now (a stand-in draw at seed 20001, its rows and its two limits) without saying that the audit ran or passed at seed 20001? Does it follow #152's answer, and does every number sit on a line that one of its sentence's own-run res tags names?"]
objectives: []
sections: [methods, results]
context_pack: [research/tickets/152-tests-test-oracle-budget-py-changed-after-run-t5.md#decision, research/findings.jsonl:21, research/manifest.json:1300-1307, research/tickets/139-draw-r6-oracle-audit-cost-on-the-10-6-row-draw-d.md#result, tests/test_oracle_budget.py]
origin: research/SPEC.md#e1-claims-c1-c2
proposed_by: planner
demo: analysis/refile/oracle_budget.json records tests/test_oracle_budget.py at the sha256 it has now (seed 20001), beside the t53-a1 hash the manifest still holds (seed 10001). It also records the test's ROWS, SEED, TIME_LIMIT_SECONDS and MEMORY_LIMIT_GB as the file assigns them, and one finding that replaces t53-a1-f1. That finding says the committed test holds a 1000000-row stand-in audit at seed 20001 to 3600 seconds and 4.0 GB, with res tags of this ticket's own run. Once the ticket is integrated, the manifest holds the current file, so a drawing of R6 can pass its provenance check.
---

## Demo

analysis/refile/oracle_budget.json records tests/test_oracle_budget.py at the sha256 it has now (seed 20001), beside the t53-a1 hash the manifest still holds (seed 10001). It also records the test's ROWS, SEED, TIME_LIMIT_SECONDS and MEMORY_LIMIT_GB as the file assigns them, and one finding that replaces t53-a1-f1. That finding says the committed test holds a 1000000-row stand-in audit at seed 20001 to 3600 seconds and 4.0 GB, with res tags of this ticket's own run. Once the ticket is integrated, the manifest holds the current file, so a drawing of R6 can pass its provenance check.

## Notes

Why this ticket exists: drawing R6 (#139) was blocked because research/manifest.json registers tests/test_oracle_budget.py at run t53-a1's sha256 (dea33416..., commit 017f053, seed 10001). The file on main is commit 607722b (sha256 a6204639..., seed 20001), which no manifest entry holds. Decision #152 asks whether the current file is registered again or the drawing is pinned to the t53-a1 version. This ticket waits on it and carries out its first option, the recommended one: "Register the current file again, and say in t53-a1-f1 that the audit ran on a stand-in draw at seed 20001". If #152 is answered with another option, return blocked and quote the answer, so a later cut follows it.

t53-a1-f1 (research/findings.jsonl line 21) says the test holds the audit 'of the default draw D2 (seed 10001, 1000000 rows)' and that 'the audit passed both when the test was run'. The current file runs a stand-in draw at seed 20001, outside D1's seeds and D2's seed 10001 (its docstring lines 3-5 and line 30), so that it never computes E1's own result.

1. Return one finding with:
   - `replaces` t53-a1-f1.
   - The heading "Oracle audit cost on the 10^6-row draw D2".
   - negative false.
   - Provenance tests/test_oracle_budget.py#TIME_LIMIT_SECONDS.
   - Text that states what the file holds now: 1000000 rows at seed 20001, a wall-clock limit of 3600 seconds (half the E1 job's 120-minute allowance) and a peak child memory limit of 4.0 GB (the job asks for 8 GB).
   End every sentence with tags `{res:t<this ticket's id>-a<this attempt's number>/tests/test_oracle_budget.py#L<a>-L<b>}`, using your own run id, never t53-a1. The spans must hold each number as written: lines 29-32 hold ROWS, SEED, the time limit with its 120-minute comment, and the memory limit with its 8 GB comment. Do not run the test: it is the full 10^6-row audit, about 12 minutes on one core. Do not say it passed at seed 20001. Measuring its seconds and peak memory is the separate proposal #139 filed, which admission decides.
2. Write analysis/refile/oracle_budget.json with three keys. `files` is [{path, sha256 (the file as it is now), manifest_run, manifest_sha256}]. `limits` is {ROWS, SEED, TIME_LIMIT_SECONDS, MEMORY_LIMIT_GB} as the file assigns them. `findings` is [{replaces, heading, negative, provenance, text, tests: []}]. Its text is exactly what you return.

Do not change the test file. Return no passage.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 176, 177, 178, 179, 180, 181, 182, 183, 184, 185.

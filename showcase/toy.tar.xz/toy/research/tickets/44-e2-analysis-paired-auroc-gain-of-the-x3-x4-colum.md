---
id: 44
title: "E2 analysis: paired AUROC gain of the x3*x4 column over 20 seeds (C3, C2 bound)"
kind: analysis
difficulty: 4
status: parked
blocked_by: [16, 31, 40, 41]
touches: [analysis/E2/paired.json, analysis/E2/verdict.py, analysis/E2/verdict.json]
role: analyst
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 4, wallclock_minutes: 30}
inputs: [results/runs/E2/m1_n0/, analysis/E1/summary.json]
outputs: [analysis/E2/paired.json, analysis/E2/verdict.json]
acceptance:
  machine: ["python3 -c \"import json; p = json.load(open('analysis/E2/paired.json')); v = json.load(open('analysis/E2/verdict.json')); assert p['n_pairs'] >= 20 and {'paired_gain', 'paired_gain_lo', 'paired_gain_hi', 'signed_rank_p', 'delong_rejections', 'gap_closed', 'mean_auroc_with', 'mean_auroc_without', 'mean_bayes_auroc'} <= set(p) and v['c3_supported'] == (p['paired_gain_lo'] > 0 and p['signed_rank_p'] < 0.05) and v['c2_bound_supported'] == (p['mean_bayes_auroc'] >= p['mean_auroc_with'] - 0.002 and p['mean_bayes_auroc'] >= p['mean_auroc_without'] - 0.002) and {'c2_supported', 'sd_d', 'q15_revisit'} <= set(v)\""]
  quality: ["Does every finding's number match the cited field of analysis/E2/paired.json, does C3's verdict follow paired_gain_lo > 0 and signed_rank_p < 0.05, and is 'by how much' stated as the interval and the gap share, never beyond them?"]
objectives: [O1, O3]
sections: [methods, results]
context_pack: [research/SPEC.md#e2-claims-c2-c3, research/SPEC.md#claims, research/SPEC.md#anti-claims, research/SPEC.md#methods]
origin: research/SPEC.md#e2-claims-c2-c3
proposed_by: planner
demo: analysis/E2/paired.json and the findings give the mean paired AUROC gain of the x3*x4 column over 20 seeds with its 95% CI, the signed-rank p, the DeLong rejection count, gap_closed with its CI, each arm's and the oracle's mean AUROC, and C3's and C2's verdicts.
---

## Demo

analysis/E2/paired.json and the findings give the mean paired AUROC gain of the x3*x4 column over 20 seeds with its 95% CI, the signed-rank p, the DeLong rejection count, gap_closed with its CI, each arm's and the oracle's mean AUROC, and C3's and C2's verdicts.

## Notes

Run `PYTHONPATH=code/src python3 -B -m toy.paired "$WAYLINE_PROJECT/results/runs/E2/m1_n0" --out analysis/E2/paired.json` (toy.paired lives under code/ once the layout decision is carried out). Then write analysis/E2/verdict.py and the analysis/E2/verdict.json it writes, with these fields. c3_supported = paired_gain_lo > 0 and signed_rank_p < 0.05; when it is false, A2 applies: report the CI's bounds, not a gain. c2_bound_supported = mean_bayes_auroc >= mean_auroc_with - 0.002 and mean_bayes_auroc >= mean_auroc_without - 0.002. c2_supported = c2_bound_supported and analysis/E1/summary.json's c2_ceiling_supported. sd_d, and q15_revisit = sd_d > 0.02. Give 'by how much' in AUROC points with the CI, and as gap_closed with its bootstrap CI (absent when the denominator is <= 0.005). If q15_revisit, mark C3's verdict provisional and propose an experiment adding seeds 21-50 at this point, decided on the interval's width alone (Q15). Report every seed. Record mean_auroc_with beside 0.82 for A7. The gate (analysis/E2/checks.json) has passed before this runs. A negative or null result is a finding too. Keep every number in a finding equal to the field it cites (`wayline numbers check`). Return Methods and Results passages whose claim sentences each end with a provenance tag.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73.

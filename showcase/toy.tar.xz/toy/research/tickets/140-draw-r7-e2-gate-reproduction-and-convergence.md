---
id: 140
title: "Draw R7: E2 gate: reproduction and convergence"
kind: drawing
difficulty: 2
status: done
blocked_by: []
touches: [drawings/R7-1/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O1]
context_pack: []
origin: drawing R7-1 at run_end
proposed_by: conductor
demo: R7 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R7-1

Code opened this drawing of R7 ("E2 gate: reproduction and convergence") at a rest point (run_end), over its findings t104-a2-f1, t104-a2-f2, t104-a2-f3, t104-a2-f4, t104-a2-f5, t104-a2-f6. Its brief, rendered by code at each launch, is in the prompt.

## Result

### Attempt 1

Drew R7 (E2 gate) from analysis/E2/checks.json: a headline dot plot of relative final-training-loss drop per rerun against the convergence limit, a slope chart of loss at 30 vs 60 epochs per arm, and two tables (gate checks, per-run values). Both checks pass with margin: reproduction gap 0.0 (limit 0.002); max relative drop 0.0034 = 0.34 of the 0.01 limit, 3 of 6 drops negative (mean 0.00025), so 30 epochs is converged. Fixes after the conductor's acceptance: the axis label is shortened to 40 characters or fewer, every finding number now carries its own res tag in the run-id form, and the Methods passage tag uses the run-id form.

Wrote: `drawings/R7-1/draw.py`, `drawings/R7-1/drawing.json`, `drawings/R7-1/numbers.json`, `drawings/R7-1/convergence_drop.png`, `drawings/R7-1/convergence_drop.svg`, `drawings/R7-1/loss_pinned_vs_double.png`, `drawings/R7-1/loss_pinned_vs_double.svg`, `drawings/R7-1/gate_checks.csv`, `drawings/R7-1/per_run.csv`

Ran: `wayline tools run matplotlib -- drawings/R7-1/draw.py`, `wayline accept`, `git add drawings/R7-1`, `git commit`

Passages:

- methods, E2 gate: reproduction and convergence: For each convergence rerun in analysis/E2/checks.json, the drawing script recomputes the relative drop $d = (L_{p} - L_{d})/L_{p}$ from the final training losses at the pinned and the doubled epoch counts, and checks it against the stored drop. {res:t140-a1/drawings/R7-1/numbers.json#max_recompute_error} It then reports the mean of $d$ over the runs, the count of negative $d$, the largest $d$ divided by the convergence limit, the largest $|L_{p} - L_{d}|$, and each arm's mean $L_{p}$ with their difference (without minus with). {res:t140-a1/drawings/R7-1/numbers.json#mean_drop,n_negative_drops,max_abs_drop_share_of_limit,max_abs_loss_change,mean_loss_pinned_gap_without_minus_with}

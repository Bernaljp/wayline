---
id: 77
title: "toy.sweep: strength_spearman and gain_shrink across sweep points"
kind: code
difficulty: 3
status: parked
blocked_by: [76]
touches: [src/toy/sweep.py, tests/test_sweep.py, tests/fixtures/sweep/]
role: coder
skills: []
acceptance:
  machine: [PYTHONPATH=src python3 -B -m unittest tests.test_sweep, "PYTHONPATH=src python3 -B -m toy.sweep tests/fixtures/sweep/E3 --axis strength | python3 -c \"import json, sys; d = json.load(sys.stdin); assert 'strength_spearman' in d and len(d['points']) >= 3 and all('strength' in p and 'paired_gain_lo' in p for p in d['points'])\"", "PYTHONPATH=src python3 -B -m toy.sweep tests/fixtures/sweep/rows --axis rows --strength 1 | python3 -c \"import json, sys; d = json.load(sys.stdin); assert {'gain_shrink', 'gain_shrink_lo', 'gain_shrink_hi'} <= set(d) and len(d['points']) >= 2\""]
  quality: ["Do strength_spearman and gain_shrink use exactly the points and the common seeds the spec names, read each point's strength and size from its runs' config.json, and take reused points from the directories given rather than re-running them?"]
objectives: [O4]
sections: [methods]
context_pack: [src/toy/stats.py:227-240, research/SPEC.md#e3-claims-c4-c5, research/SPEC.md#e4-claims-c6, research/SPEC.md#seams]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`PYTHONPATH=src python3 -m toy.sweep tests/fixtures/sweep/E3 --axis strength` prints a per-point table and strength_spearman; `--axis rows --strength 1` on tests/fixtures/sweep/rows prints gain_shrink with its interval."
---

## Demo

`PYTHONPATH=src python3 -m toy.sweep tests/fixtures/sweep/E3 --axis strength` prints a per-point table and strength_spearman; `--axis rows --strength 1` on tests/fixtures/sweep/rows prints gain_shrink with its interval.

## Notes

Re-cut of ticket 56, which never launched. Write only src/toy/sweep.py, tests/test_sweep.py and tests/fixtures/sweep/. `toy.sweep <exp-dir> --axis strength|rows [--strength m] [--point DIR ...] [--out PATH]`. A point is a directory holding with/ and without/. Every such directory directly under <exp-dir> is a point, and each --point adds one from another experiment: E3 reuses E2's results/runs/E2/m1_n0, and E4 reuses E2's m1_n0 at m = 1 and E3's m0_n0 at m = 0. Read each point's strength and train_rows from its runs' config.json, never from its name (m1_n0 carries no number). Each entry of the output's points list is a flat dict: dir, strength, train_rows, and every key of toy.paired.point_stats. --axis strength: the points must share one training size (an error if they differ). Sort them by strength and add strength_spearman, the Spearman correlation (average ranks, toy.stats.spearman) between strength and paired_gain. --axis rows --strength m: take only the points at strength m and sort them by train_rows. Add gain_shrink, the mean over the seeds the smallest and largest points share of (d_i at the smallest size - d_i at the largest size), with its paired 95% t-interval as gain_shrink_lo and gain_shrink_hi. It is an error when those two points share no seed. Fixtures: tests/fixtures/sweep/E3/ (at least three strength points) and tests/fixtures/sweep/rows/ (at least two sizes at strength 1), with the answers worked out by hand. Stdlib only; run Python as python3 -B. Result rules the harness checks (tickets 41, 52, 53, 58 and 65 failed on them): return one Methods passage; end every sentence of it with a provenance tag that resolves, such as {code:src/toy/sweep.py#main}, and leave out any sentence you cannot tag; a finding that states a number cites a locator holding that literal number, and a code locator is matched as a literal substring; a passage or finding that says what a current one says names it in `replaces`; leave a passage's evidence unset unless it replaces an inherited claim. If a Bash command you need is refused, stop and return blocked naming it.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113.

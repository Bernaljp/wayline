---
id: 188
title: "Draw R4: The oracle's true class probability matches the generator"
kind: drawing
difficulty: 2
status: open
blocked_by: []
touches: [drawings/R4-3/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O1, O3]
context_pack: []
origin: drawing R4-3 at order
proposed_by: conductor
demo: R4 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R4-3

Code opened this drawing of R4 ("The oracle's true class probability matches the generator") at a rest point (order), over its findings t6-a1-f1, t6-a1-f2, t6-a1-f3, t6-a1-f4, t6-a1-f5, t52-a1-f1, t52-a1-f2, t52-a4-f1. Its brief, rendered by code at each launch, is in the prompt.

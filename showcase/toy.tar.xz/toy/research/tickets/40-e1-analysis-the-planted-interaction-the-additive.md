---
id: 40
title: "E1 analysis: the planted interaction, the additive gap and the Bayes ceiling (C1, C2 ceiling)"
kind: analysis
difficulty: 3
status: parked
blocked_by: [38]
touches: [analysis/E1/]
role: analyst
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 4, wallclock_minutes: 30}
inputs: [results/E1/oracle.json]
outputs: [analysis/E1/summary.json]
acceptance:
  machine: ["python3 -c \"import json; d = json.load(open('analysis/E1/summary.json')); assert {'interaction_weight', 'interaction_weight_locator', 'additive_gap', 'calibration_error', 'bayes_auroc', 'bayes_auroc_halfwidth', 'c1_supported', 'c2_ceiling_supported', 'ceiling_below_goal'} <= set(d) and d['c1_supported'] == (d['interaction_weight'] != 0 and d['additive_gap'] > 0.005 and d['calibration_error'] <= 0.01) and d['c2_ceiling_supported'] == (d['bayes_auroc_halfwidth'] <= 0.002 and d['calibration_error'] <= 0.01) and d['ceiling_below_goal'] == (d['bayes_auroc'] < 0.82)\""]
  quality: ["Does each verdict in analysis/E1/summary.json follow the spec's success rule for C1 and C2's ceiling part from the manifested oracle.json, and does the label rule stated in the findings match generate.py at the cited line?"]
objectives: [O3]
sections: [methods, results]
context_pack: [src/toy/generate.py:28-40, research/SPEC.md#e1-claims-c1-c2, research/SPEC.md#claims, research/SPEC.md#anti-claims]
origin: research/SPEC.md#e1-claims-c1-c2
proposed_by: planner
demo: analysis/E1/summary.json and the filed findings state the label rule with its line, the weight on x3*x4, the additive gap, the calibration error and the Bayes AUROC with its half-width, with C1's and C2's ceiling verdicts.
---

## Demo

analysis/E1/summary.json and the filed findings state the label rule with its line, the weight on x3*x4, the additive gap, the calibration error and the Bayes AUROC with its half-width, with C1's and C2's ceiling verdicts.

## Notes

Read $WAYLINE_PROJECT/results/E1/oracle.json (results/ is git-ignored and not in the worktree). Write analysis/E1/summarize.py and the analysis/E1/summary.json it writes. The summary holds the oracle's fields plus three verdicts: c1_supported = interaction_weight != 0 and additive_gap > 0.005 and calibration_error <= 0.01 (A1 otherwise); c2_ceiling_supported = bayes_auroc_halfwidth <= 0.002 and calibration_error <= 0.01; ceiling_below_goal = bayes_auroc < 0.82 (A6). State how generate.py builds the label, with its line. If the ceiling is below 0.82, file a decision request for the owner: O2 cannot be met on the default generator, and the generator, the split and the goal are the owner's (objective and data classes). File findings citing the manifested result or the committed summary, with every number equal to the field it cites (`wayline numbers check`). Return Methods and Results passages whose claim sentences each end with a provenance tag. A negative result is a finding too.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73.

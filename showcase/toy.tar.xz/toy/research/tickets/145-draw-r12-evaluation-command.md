---
id: 145
title: "Draw R12: Evaluation command"
kind: drawing
difficulty: 2
status: parked
blocked_by: []
touches: [drawings/R12-1/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O2]
context_pack: []
origin: drawing R12-1 at run_end
proposed_by: conductor
demo: R12 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R12-1

Code opened this drawing of R12 ("Evaluation command") at a rest point (run_end), over its findings t118-a1-f1. Its brief, rendered by code at each launch, is in the prompt.

## Result

### Attempt 1

R12's only finding (t118-a1-f1) is a unit test of how toy.eval resolves its input. Its AUROC values are test fixtures, not measurements, so the result has nothing to plot. The drawing therefore has no plots and no tables. It records the reasons, the views left out, and what can and cannot be inferred. draw.py writes an empty numbers.json. Bash is denied in this session (don't-ask mode), so I could not run draw.py, `wayline accept`, or `git commit`. The three files are written but not checked or committed.

Wrote: `drawings/R12-1/draw.py`, `drawings/R12-1/numbers.json`, `drawings/R12-1/drawing.json`

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 176, 177, 178, 179, 180, 181, 182, 183, 184, 185.

---
id: 72
title: "E6 analysis: placement of C3-C6 against the five resolved works (C8)"
kind: analysis
difficulty: 3
status: parked
blocked_by: [58, 59]
touches: [analysis/E6/]
role: analyst
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 2, wallclock_minutes: 30}
inputs: [research/refs/]
outputs: [analysis/E6/placement.json, analysis/E6/placement_summary.json]
acceptance:
  machine: ["PYTHONPATH=src python3 -B -m toy.placement analysis/E6/placement.json --refs \"${WAYLINE_PROJECT:-.}/research/refs\" > /dev/null", "python3 -c \"import json; e = json.load(open('analysis/E6/placement.json')); s = json.load(open('analysis/E6/placement_summary.json')); want = {'10.1214/07-aoas148', '10.1145/2487575.2487579', '10.1214/13-aos1096', '10.2307/2531595', '10.1162/089976698300017197'}; assert {x['doi'].lower().replace('doi:', '') for x in e} == want and {'resolved_refs', 'prior_measures_gain'} <= set(s)\""]
  quality: ["Is each work's measures_paired_gain backed by a locator into its dossier, is a work the dossier cannot settle marked null rather than guessed, and does C8's verdict follow resolved_refs and prior_measures_gain with nothing resting on paper-a or paper-b?"]
objectives: [O1]
sections: [methods, results]
context_pack: [research/SPEC.md#e6-claims-c8, research/SPEC.md#anti-claims, research/refs/]
origin: research/SPEC.md#e6-claims-c8
proposed_by: planner
demo: analysis/E6/placement.json lists each of D6's five works with its dossier's existence, whether it measures the paired gain and the locator that settles it; toy.placement prints resolved_refs and prior_measures_gain, and the findings give C8's verdict.
---

## Demo

analysis/E6/placement.json lists each of D6's five works with its dossier's existence, whether it measures the paired gain and the locator that settles it; toy.placement prints resolved_refs and prior_measures_gain, and the findings give C8's verdict.

## Notes

For each D6 work (doi:10.1214/07-aoas148, doi:10.1145/2487575.2487579, doi:10.1214/13-aos1096, doi:10.2307/2531595, doi:10.1162/089976698300017197), find its dossier under $WAYLINE_PROJECT/research/refs/ and read it. The slug is the one the literature ticket's scout gave it; DeLong's is delong-1988-comparing-areas-under-two-more. Write analysis/E6/placement.json as a JSON list with one entry per work: slug; doi (bare, lower case); existence, as the dossier states it, or 'missing' when there is no dossier; measures_paired_gain; and the locator of the passage that settles it. measures_paired_gain is true when the work reports a held-out AUROC gain of an explicit product column over the same model without it, against a no-interaction control; false when the dossier shows the work does not; null when the dossier cannot settle it. Then run `PYTHONPATH=src python3 -B -m toy.placement analysis/E6/placement.json --refs "$WAYLINE_PROJECT/research/refs" > analysis/E6/placement_summary.json`. C8 is supported when resolved_refs >= 4 and prior_measures_gain == 0. A9 is confirmed when prior_measures_gain >= 1: cite that work as the closest prior work and set its number beside C3's. C8 is unresolved when resolved_refs < 4; name the works read. Rest nothing on paper-a or paper-b. The spec's results/placement.json lives here because results/ is git-ignored and an analysis's files must be committed. Every number in a finding must sit at the field it cites. Return a Methods passage and a Results passage whose claim sentences each end with a provenance tag.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93.

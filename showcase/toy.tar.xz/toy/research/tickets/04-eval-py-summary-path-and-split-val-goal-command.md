---
id: 4
title: "eval.py: --summary PATH and --split val, goal command unchanged"
kind: code
difficulty: 1
status: parked
blocked_by: []
touches: [src/toy/eval.py, tests/test_eval.py]
role: coder
skills: []
acceptance:
  machine: [PYTHONPATH=src python3 -B -m unittest tests.test_eval, "PYTHONPATH=src python3 -B -m toy.eval --split held_out --summary owner/sample-summary.json | grep -q '^auroc: 0.8502984862625299$'"]
  quality: []
objectives: [O1, O2]
sections: [methods]
context_pack: [owner/measure.json, src/toy/eval.py, research/SPEC.md#seams, research/SPEC.md#metrics]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`PYTHONPATH=src python3 -m toy.eval --split held_out --summary owner/sample-summary.json` prints auroc: 0.8502984862625299, the goal command with WAYLINE_ARTIFACT prints the same, and --split val reads a validation run's val_auroc."
---

## Demo

`PYTHONPATH=src python3 -m toy.eval --split held_out --summary owner/sample-summary.json` prints auroc: 0.8502984862625299, the goal command with WAYLINE_ARTIFACT prints the same, and --split val reads a validation run's val_auroc.

## Notes

Keep what O2's command does today: `PYTHONPATH=src python3 -m toy.eval --split held_out` reads the summary named by a positional path or by WAYLINE_ARTIFACT (keep-if-better exports it for each seed artifact) and prints 'auroc: <value>' with the value unformatted. That is the 'default summary' the spec's seam names. Add --summary PATH, the same as the positional path, also accepting a run directory (reads summary.json inside it). Add --split val, which prints 'val_auroc: <value>' from the summary's val_auroc and exits non-zero when there is none; --split held_out on a summary without auroc (a --val-fraction run) exits non-zero, as now. tests/test_eval.py covers the old path (WAYLINE_ARTIFACT=owner/sample-summary.json prints auroc: 0.8502984862625299), --summary on a file and a directory, and --split val. Stdlib only; run Python as python3 -B; do not create tests/__init__.py.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49.

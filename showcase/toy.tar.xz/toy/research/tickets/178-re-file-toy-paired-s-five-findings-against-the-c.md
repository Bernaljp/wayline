---
id: 178
title: Re-file toy.paired's five findings against the current paired.py and test_paired.py, re-pinning both so PinnedSettings is cited where it exists (R8)
kind: writing
difficulty: 2
status: open
blocked_by: []
touches: []
role: writer
skills: [interval-claims]
inputs: [src/toy/paired.py, tests/test_paired.py, tests/fixtures/paired/, research/findings.jsonl, research/manifest.json]
acceptance:
  machine: []
  quality: ["Do the five findings that replace t76-a1-f1, t115-a1-f1, t115-a1-f2, t116-a2-f1 and t116-a2-f2 state only what src/toy/paired.py and tests/test_paired.py hold now? Does each sentence end with own-run tags on those files at a class, symbol or line span that exists in the current file and holds every number written, with t116-a2-f2's replacement citing the PinnedSettings class?"]
objectives: []
sections: [results]
context_pack: [research/findings.jsonl:29, research/findings.jsonl:48-49, research/findings.jsonl:66-67, research/sections/results.md:100-113, research/manifest.json:1309-1361, research/tickets/155-re-file-toy-paired-s-five-findings-r8-against-th.md, research/reports/R8-1.md#open-questions, src/toy/paired.py, tests/test_paired.py]
origin: research/REPORT.md#kill-argument
proposed_by: planner
demo: The general report renders five findings in place of t76-a1-f1, t115-a1-f1, t115-a1-f2, t116-a2-f1 and t116-a2-f2 under R8's heading, each sentence tagged at this ticket's run. The refusal findings cite tests/test_paired.py's Refusals and PinnedSettings classes as they are now. Once integrated, research/manifest.json holds both files at their current sha256, and the kill argument's point 7 (a locator its pinned artifact lacks) no longer stands.
---

## Demo

The general report renders five findings in place of t76-a1-f1, t115-a1-f1, t115-a1-f2, t116-a2-f1 and t116-a2-f2 under R8's heading, each sentence tagged at this ticket's run. The refusal findings cite tests/test_paired.py's Refusals and PinnedSettings classes as they are now. Once integrated, research/manifest.json holds both files at their current sha256, and the kill argument's point 7 (a locator its pinned artifact lacks) no longer stands.

## Notes

Why: the manifest holds tests/test_paired.py only at run t76-a1 (14291 bytes, before ticket 116's commit 849de99 added the PinnedSettings class) and src/toy/paired.py only at run t115-a1 (before ticket 116 changed it). So t116-a2-f2 cites a locator its pinned artifact does not contain (the kill argument's point 7). R8's drawing could not draw its fixture views with a hash that holds (research/reports/R8-1.md, Open questions). This ticket replaces #155.

How a re-pin works: a sentence ending with `{res:t<this ticket>-a<this attempt>/<path>#<locator>}` that names a file on main makes the conductor hash that file into research/manifest.json under this run at integration, replacing the path's old entry. Older-run tags on the path then stop resolving. The current findings citing these files are exactly the five replaced here. t76-a1-f1, t116-a2-f1 and t116-a2-f2 cite t76-a1/tests/test_paired.py, and t115-a1-f1 and t115-a1-f2 cite t115-a1/src/toy/paired.py. Put own-run tags on these two files. You may also tag files under tests/fixtures/paired/, which the manifest does not hold. Tag no other manifested path. Use your run id as your prompt gives it.

What to return: five findings, each with `replaces`, the replaced finding's `heading` as research/findings.jsonl records it, `negative` false, a `provenance` at the file it is about, and text that keeps the replaced wording wherever it still holds. Use locators such as `HandWorkedAnswers`, `Interface`, `Refusals`, `PinnedSettings`, `point_stats`, `summarize`, a constant's name, or a line span `L<a>-L<b>`. Each must hold every number its sentence writes, as written; t76-a1-f1's fractions sit in the test's hand-worked answers. Say what a test asserts, not that it passed. Edit no file. Return no passage.

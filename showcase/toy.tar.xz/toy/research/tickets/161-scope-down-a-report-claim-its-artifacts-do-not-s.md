---
id: 161
title: Scope down a report claim its artifacts do not support
kind: writing
difficulty: 3
status: parked
blocked_by: []
touches: []
role: writer
skills: []
inputs: [research/REPORT.md, research/findings.jsonl#t131-a1-f2, src/toy/goallog.py#summarise]
outputs: []
acceptance:
  machine: []
  quality: [Does every claim sentence the verifier could not support now say only what its cited artifacts do?]
context_pack: [research/REPORT.md, research/findings.jsonl#t131-a1-f2, src/toy/goallog.py#summarise]
origin: research/REPORT.md#claim-8adb99d6b84363c9
proposed_by: verifier
demo: The general report renders the narrowed finding in place of `t131-a1-f2`, and the next run end samples it.
sections: [results]
---

## Demo

The general report renders the narrowed finding in place of `t131-a1-f2`, and the next run end samples it.

## The claim the verifier could not support

> `t131-a1-f2` (negative) No module in src/toy implements a keep rule. toy.goallog reads each candidate's `kept` field (true, false, or null), checks it is the same on every line of that candidate, and counts kept and discarded.{res:t131-a1/src/toy/goallog.py#summarise}

Verifier session `ccb00274-f14f-45ae-b6c1-bb5b20b3c544` (claude-opus-5-5) opened the cited artifacts and found:

- [blocker] The first sentence, 'No module in src/toy implements a keep rule.', covers all 13 modules in src/toy, but its only tag points to one function in one module. `summarise` takes `kept` from each line, refuses a candidate whose lines disagree on it, and counts True and False. That shows toy.goallog makes no keep decision itself. It says nothing about toy.eval, train, sweep, converge, paired, placement, stats, oracle, metrics or generate. toy.eval matters most here, because its docstring (eval.py:3) says the keep-if-better loop runs it, and nothing at the cited locator rules it out. So the sentence says more than its tag. I grepped src/toy for keep/kept/better/best/select/accept/reject/compare and similar and found no keep rule anywhere, so the sentence looks true. It needs to be narrowed to toy.goallog or given evidence that covers the whole package. (src/toy/goallog.py#summarise (lines 81-105; manifested t131-a1 artifact, sha256 a440344b…, 6332 bytes, identical to the working file))
- [minor] The parenthetical '(true, false, or null)' is not borne out at the cited locator. `summarise` never limits kept's values: it compares them with != and counts `is True` / `is False`. The three allowed values are enforced in parse_line (lines 69-70) and stated in the module docstring (lines 10-11) of the same file. The file supports the parenthetical, but `#summarise` does not. The rest of the second sentence holds at summarise: line 86 takes kept from the candidate's first line, lines 89-91 refuse a line whose kept differs from it, and lines 104-105 count kept (True) and discarded (False) candidates. (src/toy/goallog.py:69-70 (parse_line) and :10-11 (module docstring), versus the tag's #summarise)

The sentence is a finding as its ticket recorded it (`t131-a1-f2`), and the report renders findings as recorded. Return in the result the finding narrowed to what the artifacts support, with its provenance, naming the finding it narrows in its `replaces` (`t131-a1-f2`); the ledger records it in that finding's place and the next render reads it.

A finding's provenance is the artifact's path in the project and a locator, the form the manifest resolves (`analysis/ablation/signal-4.json#paired_gain`), never a report tag such as `{res:<run>/<path>}`: the ledger refuses a provenance it cannot find in `manifest.json` or on disk.

## The artifacts the verifier opened

- `src/toy/goallog.py#summarise`

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 176, 177, 178, 179, 180, 181, 182, 183, 184, 185.

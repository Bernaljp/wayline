---
id: 165
title: "Draw R4: toy.oracle: the generator's true P(y=1|x), Bayes ceiling, calibration and additive gap"
kind: drawing
difficulty: 2
status: failed
blocked_by: []
touches: [drawings/R4-2/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O1, O3]
context_pack: []
origin: drawing R4-2 at order
proposed_by: conductor
demo: R4 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R4-2

Code opened this drawing of R4 ("toy.oracle: the generator's true P(y=1|x), Bayes ceiling, calibration and additive gap") at a rest point (order), over its findings t6-a1-f1, t6-a1-f2, t6-a1-f3, t6-a1-f4, t6-a1-f5, t52-a1-f1, t52-a1-f2, t52-a4-f1. Its brief, rendered by code at each launch, is in the prompt.

## Result

### Attempt 1

Fixed the failed acceptance checks for drawing R4-2. (1) draw.py no longer needs figures/style.json in the clean room. It carries the house palette inline and reads the file only when it exists. (2) Text past the canvas: the link.png annotation is now on two lines inside the axes. resolution.png uses plain tick labels (10,000 / 100,000 / 1,000,000 and 0.002–0.1) in place of mathtext powers. (3) Findings and the Methods passage now tag each sentence with the numbers.json keys that hold its numbers, as {res:drawings/R4-2/numbers.json#key} before the sentence's period. The script reran, wayline accept passed, and the work is committed on ticket/165. I could not run `wayline drawing check` locally because the permission was denied. Still open, and outside this touch set: the provenance check reports that src/toy/generate.py and tests/test_oracle.py no longer match the hashes the manifest recorded for t2-a3 and t6-a1. Both files changed in later commits (ticket 131's docstrings and the test_oracle tolerance and node-count commits). The manifest has to re-record them; a drawing cannot.

Wrote: `drawings/R4-2/draw.py`, `drawings/R4-2/drawing.json`, `drawings/R4-2/numbers.json`, `drawings/R4-2/link.png`, `drawings/R4-2/link.svg`, `drawings/R4-2/resolution.png`, `drawings/R4-2/resolution.svg`, `drawings/R4-2/checks.csv`

Ran: `wayline tools run matplotlib -- drawings/R4-2/draw.py`, `wayline accept`, `git commit`

Passages:

- methods, Drawing the oracle result: The drawing evaluates the logistic-normal link $P(\mu)=\mathbb{E}[\sigma(\mu+e)]$, $e\sim N(0,1)$, with a 96-node Gauss-Hermite rule {res:drawings/R4-2/numbers.json#link_gauss_hermite_nodes}. It compares that against $\sigma(\mu)$ and reports the largest difference and where it falls {res:drawings/R4-2/numbers.json#naive_minus_true_peak}. The reachable range of the latent mean is the signal times the sum of the absolute log-odds weights {res:drawings/R4-2/numbers.json#mu_max_reachable}. The per-row difference is summarised over 200,000 features drawn uniformly on $[-1,1]^4$ {res:drawings/R4-2/numbers.json#rows_sampled_for_mu} with numpy's default_rng seeded at 20261025 {res:drawings/R4-2/numbers.json#rows_sample_seed}. The resolution of the calibration error is the per-bin standard-error bound $0.5/\sqrt{n/20}$ for $n$ rows in 20 equal-count bins {res:drawings/R4-2/numbers.json#bins}, and each threshold is divided by that bound {res:drawings/R4-2/numbers.json#test_threshold_in_se_at_20000}.

Proposed Re-record the manifest hashes of src/toy/generate.py and tests/test_oracle.py (harness) (admission decides what joins the graph).

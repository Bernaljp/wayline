---
id: 75
title: "eval.py: --summary PATH and --split val, O2's goal command unchanged"
kind: code
difficulty: 2
status: parked
blocked_by: []
touches: [src/toy/eval.py, tests/test_eval.py]
role: coder
skills: []
acceptance:
  machine: [PYTHONPATH=src python3 -B -m unittest tests.test_eval, "PYTHONPATH=src python3 -B -m toy.eval --split held_out --summary owner/sample-summary.json | grep -qx 'auroc: 0.8502984862625299' && WAYLINE_ARTIFACT=owner/sample-summary.json PYTHONPATH=src python3 -B -m toy.eval --split held_out | grep -qx 'auroc: 0.8502984862625299'", "d=$(mktemp -d) && printf '{\"seed\": 1, \"val_auroc\": 0.75}\\n' > \"$d/summary.json\" && PYTHONPATH=src python3 -B -m toy.eval --split val --summary \"$d\" | grep -qx 'val_auroc: 0.75'"]
  quality: []
objectives: [O1, O2]
sections: [methods]
context_pack: [owner/measure.json, src/toy/eval.py, src/toy/train.py:184-245, research/SPEC.md#seams, research/SPEC.md#metrics]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`PYTHONPATH=src python3 -m toy.eval --split held_out --summary owner/sample-summary.json` prints auroc: 0.8502984862625299; O2's command with WAYLINE_ARTIFACT set prints the same; `--split val --summary <run-dir>` on a --val-fraction run prints its val_auroc."
---

## Demo

`PYTHONPATH=src python3 -m toy.eval --split held_out --summary owner/sample-summary.json` prints auroc: 0.8502984862625299; O2's command with WAYLINE_ARTIFACT set prints the same; `--split val --summary <run-dir>` on a --val-fraction run prints its val_auroc.

## Notes

Re-cut of ticket 54, which never launched because the run stalled first; nothing in its design failed. Write only src/toy/eval.py and tests/test_eval.py (decision #50 kept src/toy/ and tests/). Keep what O2's command does today: `PYTHONPATH=src python3 -m toy.eval --split held_out` reads the summary named by the positional path or by WAYLINE_ARTIFACT (keep-if-better exports it for each seed artifact) and prints 'auroc: <value>' with the value unformatted. Add --summary PATH, equivalent to the positional path, also accepting a run directory (it reads summary.json inside it). Add --split val, which prints 'val_auroc: <value>' from the summary's val_auroc and exits non-zero when there is none; --split held_out on a summary with no auroc (a --val-fraction run) exits non-zero, as now. Fix the module docstring, which calls the measure O1's: it is O2's. tests/test_eval.py covers the old path (WAYLINE_ARTIFACT=owner/sample-summary.json), --summary on a file and on a run directory, and --split val on a temporary summary; it must run as `python3 -B -m unittest tests.test_eval` from the project root (tests/ has no __init__.py; do not add one). Stdlib only. Result rules the harness checks (tickets 41, 52, 53, 58 and 65 failed on them): return one Methods passage; end every sentence of it with a provenance tag that resolves, such as {code:src/toy/eval.py#main}, and leave out any sentence you cannot tag (ticket 58 failed on 'It uses the Python standard library alone.'); a finding that states a number cites a locator holding that literal number (a JSON file at its key), and a code locator is matched as a literal substring; a passage or finding that says what a current one says names it in `replaces`; leave a passage's evidence unset unless it replaces an inherited claim. If a Bash command you need (python3, wayline accept, git) is refused, stop at once and return blocked naming it; do not write files you cannot run.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113.

---
id: 18
title: "E2 gate analysis: reproduction of the owner's run and convergence at doubled epochs"
kind: analysis
difficulty: 2
status: parked
blocked_by: [4, 8, 16]
touches: [analysis/E2/checks.py, analysis/E2/checks.json]
role: analyst
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 4, wallclock_minutes: 30}
inputs: [results/runs/E2/m1_n0/, results/runs/E2/converge/, owner/sample-summary.json]
outputs: [analysis/E2/checks.json]
acceptance:
  machine: [test -f analysis/E2/checks.py, "python3 -c \"import json; d = json.load(open('analysis/E2/checks.json')); assert d['reproduction_gap'] <= 0.002 and d['convergence_drop'] <= 0.01\""]
  quality: ["Are reproduction_gap and convergence_drop computed by the committed script from the manifested E2 runs, and does each finding state its number with its threshold?"]
objectives: [O1]
sections: [methods, results]
context_pack: [owner/sample-summary.json, research/SPEC.md#e2-claims-c2-c3, src/toy/converge.py]
origin: research/SPEC.md#e2-claims-c2-c3
proposed_by: planner
demo: analysis/E2/checks.json shows replicate 1's with-term AUROC within 0.002 of the owner's 0.8503 and the largest relative loss drop at doubled epochs at or below 1%, and the two findings say so.
---

## Demo

analysis/E2/checks.json shows replicate 1's with-term AUROC within 0.002 of the owner's 0.8503 and the largest relative loss drop at doubled epochs at or below 1%, and the two findings say so.

## Notes

The runs are at $WAYLINE_PROJECT/results/runs/E2/ (results/ is not in the worktree). Write analysis/E2/checks.py, which writes analysis/E2/checks.json: run_auroc_with_seed1 (`PYTHONPATH=src python3 -B -m toy.eval --split held_out --summary $WAYLINE_PROJECT/results/runs/E2/m1_n0/with/seed1`), b3_auroc (owner/sample-summary.json: 0.8502984862625299), reproduction_gap = their absolute difference, and convergence_drop with per_run from `toy.converge $WAYLINE_PROJECT/results/runs/E2/converge`. Commit both files and file one finding per check, citing analysis/E2/checks.json. The machine criterion is the spec's gate and fails by design when a check fails: do not loosen it. Then return blocked with a decision request: a failed convergence check revisits Q14 before E3 and E4 run; a reproduction gap above 0.002 stops E2 until its cause is found and recorded. E3, E4 and C3's analysis wait on this gate.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49.

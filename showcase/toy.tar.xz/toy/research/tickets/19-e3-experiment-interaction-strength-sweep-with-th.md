---
id: 19
title: "E3 experiment: interaction-strength sweep with the zero-strength null control"
kind: experiment
difficulty: 2
status: parked
blocked_by: [18]
touches: [experiments/E3/, results/runs/E3/, results/smoke/E3/]
role: experimenter
skills: []
resources: {cpu: 2, gpu: 1, ram_gb: 8, wallclock_minutes: 60}
inputs: [configs/arms.json, src/toy/train.py, src/toy/generate.py]
outputs: [results/runs/E3/m0_n0/with/seed1/summary.json, results/runs/E3/m0_n0/without/seed20/heldout_scores.csv, results/runs/E3/m4_n0/with/seed1/summary.json, results/runs/E3/m4_n0/without/seed20/heldout_scores.csv]
acceptance:
  machine: ["python3 -c \"import json; json.load(open('experiments/E3/jobs.json'))\"", "for m in 0 0.25 0.5 2 4; do grep -q \"results/runs/E3/m${m}_n0/\" experiments/E3/jobs.json || exit 1; done; grep -rq -- '--strength' experiments/E3/ && grep -rq -- '--no-interaction' experiments/E3/ && grep -rq 'configs/arms.json' experiments/E3/ && ! grep -q 'results/runs/E3/m1_n0/' experiments/E3/jobs.json"]
  quality: ["Do the jobs run exactly the strengths 0, 0.25, 0.5, 2 and 4 at the default size, seeds 1-20, both arms, with configs/arms.json and nothing tuned, leaving m = 1 to E2's runs and the default draw unchanged?"]
objectives: [O4]
sections: [methods]
context_pack: [configs/arms.json, research/SPEC.md#e3-claims-c4-c5, research/SPEC.md#methods, src/toy/train.py]
origin: research/SPEC.md#e3-claims-c4-c5
proposed_by: planner
demo: "`wayline status` shows five E3 jobs, one per strength 0, 0.25, 0.5, 2 and 4, each running 40 paired runs into results/runs/E3/m<m>_n0/."
retry:
  host_oom: []
  gpu_oom: [--batch-size=64, --batch-size=16]
---

## Demo

`wayline status` shows five E3 jobs, one per strength 0, 0.25, 0.5, 2 and 4, each running 40 paired runs into results/runs/E3/m<m>_n0/.

## Notes

Write experiments/E3/point.sh (or call experiments/E2/point.sh if it already takes the output root, seeds and extra flags as arguments) and experiments/E3/jobs.json with one member per strength m in {0, 0.25, 0.5, 2, 4}: seeds 1-20, both arms, `--config configs/arms.json --strength m --save-scores`, out results/runs/E3/m<m>_n0/<arm>/seed<i>/ (m0_n0, m0.25_n0, m0.5_n0, m2_n0, m4_n0). m = 1 is E2's m1_n0 and is not re-run. Each member's expected_outputs lists literally every run's summary.json, heldout_scores.csv and config.json. Extra flags (the retry ladder's --batch-size) pass through to train.py. Run train.py with /home/bernaljp/.wayline/tools/venv/bin/python and env PYTHONPATH=src. The multiplier scales generate.py's weight 1.1 on x3*x4 (nonzero, so A1's absolute-weight switch does not apply). Nothing is tuned and no seed is dropped. Smoke-test on the CPU into results/smoke/E3/ and commit nothing under results/.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49.

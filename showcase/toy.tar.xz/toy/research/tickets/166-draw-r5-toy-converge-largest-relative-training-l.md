---
id: 166
title: "Draw R5: toy.converge: largest relative training-loss drop at doubled epochs"
kind: drawing
difficulty: 2
status: failed
blocked_by: []
touches: [drawings/R5-2/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O1]
context_pack: []
origin: drawing R5-2 at order
proposed_by: conductor
demo: R5 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R5-2

Code opened this drawing of R5 ("toy.converge: largest relative training-loss drop at doubled epochs") at a rest point (order), over its findings t8-a2-f1, t8-a2-f2. Its brief, rendered by code at each launch, is in the prompt.

## Result

### Attempt 1

Drew R5 on E2's real convergence reruns: a dot plot of each run's relative training-loss drop from 30 to 60 epochs, measured against the 0.01 gate (headline), a dot plot of each run's held-out AUROC change, and a per-run table. convergence_drop is 0.0034 (with arm, seed 2). All 6 runs fall under the gate. This resubmission cites every number in the findings at its own key in numbers.json, and the drawing itself is unchanged.

Wrote: `drawings/R5-2/draw.py`, `drawings/R5-2/drawing.json`, `drawings/R5-2/numbers.json`, `drawings/R5-2/per_run.csv`, `drawings/R5-2/drop_per_run.png`, `drawings/R5-2/drop_per_run.svg`, `drawings/R5-2/auroc_change_per_run.png`, `drawings/R5-2/auroc_change_per_run.svg`

Ran: `wayline tools run matplotlib -- drawings/R5-2/draw.py`, `wayline accept`, `git add drawings/R5-2 && git commit`

Passages:

- methods, Convergence check: The drawing script reads `final_train_loss` and `auroc` from each run's `summary.json`, and `epochs` from its `config.json`. It does this for the pinned point `results/runs/E2/m1_n0` and the reruns `results/runs/E2/converge`, for both arms and the three rerun seeds. For each run it computes the relative drop $(L_{\mathrm{pinned}} - L_{\mathrm{double}}) / L_{\mathrm{pinned}}$ and the AUROC change $\mathrm{AUROC}_{\mathrm{double}} - \mathrm{AUROC}_{\mathrm{pinned}}$. It then reports the maximum drop, the count of drops above the gate, the count of positive drops, and the minimum and maximum AUROC change [res:drawings/R5-2/numbers.json#convergence_drop].

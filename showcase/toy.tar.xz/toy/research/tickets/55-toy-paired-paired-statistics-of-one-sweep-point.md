---
id: 55
title: "toy.paired: paired statistics of one sweep point against the oracle ceiling (src/ layout)"
kind: code
difficulty: 4
status: parked
blocked_by: [5, 52]
touches: [src/toy/paired.py, tests/test_paired.py, tests/fixtures/paired/]
role: coder
skills: []
acceptance:
  machine: [PYTHONPATH=src python3 -B -m unittest tests.test_paired, "PYTHONPATH=src python3 -B -m toy.paired tests/fixtures/paired/point | python3 -c \"import json, sys; d = json.load(sys.stdin); assert d['n_pairs'] >= 3 and {'paired_gain', 'paired_gain_lo', 'paired_gain_hi', 'sd_d', 'signed_rank_p', 'delong_rejections', 'gap_closed', 'gap_closed_lo', 'gap_closed_hi', 'mean_auroc_with', 'mean_auroc_without', 'mean_bayes_auroc', 'strength', 'train_rows', 'per_seed'} <= set(d) and len(d['per_seed']) == d['n_pairs']\""]
  quality: ["Does toy.paired pair the arms only on identical seeds, draws and held-out rows, refuse an incomplete or mismatched pair rather than drop it, and compute every statistic the spec's Methods (Statistics) names exactly as defined there?"]
objectives: [O1, O3, O4]
sections: [methods]
context_pack: [src/toy/generate.py:43-56, src/toy/oracle.py:112-128, src/toy/train.py:224-243, src/toy/stats.py, research/SPEC.md#seams, research/SPEC.md#methods, research/SPEC.md#e2-claims-c2-c3]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`PYTHONPATH=src python3 -m toy.paired tests/fixtures/paired/point` prints the paired gain with its 95% t-interval, the signed-rank p, the DeLong rejection count, gap_closed and each arm's and the oracle's mean AUROC, matching the hand-worked answers in the test."
---

## Demo

`PYTHONPATH=src python3 -m toy.paired tests/fixtures/paired/point` prints the paired gain with its 95% t-interval, the signed-rank p, the DeLong rejection count, gap_closed and each arm's and the oracle's mean AUROC, matching the hand-worked answers in the test.

## Notes

Re-cut of ticket 31, which was blocked because it was cut for a code/ layout: decision #50 kept src/toy/ and tests/, so write only src/toy/paired.py, tests/test_paired.py and tests/fixtures/paired/. `toy.paired <point-dir> [--out PATH]` reads <point-dir>/<with|without>/seed<i>/{summary.json, heldout_scores.csv, config.json}, the run-directory layout train.py writes (src/toy/train.py:224-243). The real runs live under $WAYLINE_PROJECT/results/runs/<E>/<point>/, e.g. results/runs/E2/m1_n0/ (results/ is git-ignored). Print one flat JSON object, and write it to --out when given, with: paired_gain, paired_gain_lo, paired_gain_hi, sd_d, signed_rank_p, delong_rejections, gap_closed, gap_closed_lo, gap_closed_hi (all three null, with a gap_closed_reason, when the denominator mean(bayes - auroc_without) is <= 0.005), mean_auroc_with, mean_auroc_without, mean_bayes_auroc, n_pairs, strength, train_rows, and per_seed (seed, auroc_with, auroc_without, d, bayes, delong_p). Expose point_stats(point_dir), returning that dict, for toy.sweep. Pair only seeds present in both arms whose config.json agree on seed, signal, rows, train_rows and strength, and whose held-out labels are identical; an incomplete or mismatched pair is an error that lists the seeds (exit 2), never a silent drop, because every run is reported. run_auroc is the summary's auroc, checked against the AUROC recomputed from heldout_scores.csv (toy.metrics.auroc). d_i = auroc_with - auroc_without. From toy.stats use t_interval (95%, n-1 df), signed_rank_exact_p, delong_test on each replicate's shared held-out rows (count p < 0.05), and paired_bootstrap with ratio_of_means for gap_closed (10,000 resamples, fixed seed). bayes_i: regenerate the draw with toy.generate.generate(seed, signal, rows, strength) from config.json's values, passing signal explicitly (generate() defaults to signal 1.0 and toy.oracle to 4.0; the runs record 4.0), take the held-out rows the CSV indexes, check their labels match, score them with toy.oracle.true_prob(rows, m=strength, signal=signal) and take the AUROC; latent_mean ranks rows identically and is faster if speed matters. gap_closed = mean(d) / mean(bayes - auroc_without). It must work for 20 to 50 seeds and held-out sets of up to 16,000 rows (E4's 4*n0 point). Fixture: tests/fixtures/paired/point/ with at least three seeds of tiny held-out sets drawn by toy.generate (e.g. rows=50), its statistics worked out by hand in the test's comments. Stdlib only; run Python as python3 -B. Waits on #52 because #52 is still changing src/toy/oracle.py. Return one Methods passage whose every claim sentence ends with a provenance tag ({code:src/toy/paired.py#point_stats} and the like). If a Bash command you need is refused, stop and return blocked naming it.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93.

---
id: 84
title: "E5 experiment: goal starting run of the default train.py at seeds 1-3 for O2"
kind: experiment
difficulty: 2
status: parked
blocked_by: [28]
touches: [experiments/E5/, results/E5/, results/smoke/E5/]
role: experimenter
skills: []
resources: {cpu: 2, gpu: 1, ram_gb: 8, wallclock_minutes: 30}
inputs: [src/toy/train.py, owner/measure.json]
outputs: [results/E5/start/seed1/summary.json, results/E5/start/seed2/summary.json, results/E5/start/seed3/summary.json]
acceptance:
  machine: ["python3 -c \"import json; t = open('experiments/E5/jobs.json').read(); json.loads(t); assert 'results/E5/start/seed1/summary.json' in t and 'configs/arms.json' not in t and '--val-fraction' not in t\"", "python3 -c \"import json; s = json.load(open('experiments/E5/jobs.json')); outs = [o for m in (s.get('members') or [s]) for o in (m.get('expected_outputs') or s.get('expected_outputs') or [])]; assert outs and all(o.endswith('summary.json') for o in outs)\""]
  quality: ["Do the jobs run train.py at its project-start defaults (no --config, no tuned flag) at the seeds decision #28 settled, and name only those summary.json files as outputs, so keep-if-better scores nothing else?"]
objectives: [O2]
sections: [methods]
goal: O2
context_pack: [owner/measure.json, owner/sample-summary.json, experiments/E2/point.sh, src/toy/train.py:156-245, research/SPEC.md#e5-claims-c7]
origin: research/SPEC.md#e5-claims-c7
proposed_by: planner
demo: The goal job trains the default train.py at seeds 1, 2 and 3; after it exits, the conductor's keep-if-better runs O2's command on each summary, prints the three auroc readings and journals the judgment for O2.
retry:
  host_oom: []
  gpu_oom: [--batch-size=64, --batch-size=16]
---

## Demo

The goal job trains the default train.py at seeds 1, 2 and 3; after it exits, the conductor's keep-if-better runs O2's command on each summary, prints the three auroc readings and journals the judgment for O2.

## Notes

Re-cut of ticket 63, which never launched. Decision #28 settled the seeds: the default train.py run at seeds 1, 2 and 3, with keep-if-better keeping on their mean. Seed 1 (B3's seed, D5) is the spec's goal run. Run train.py as it stands, with no flag beyond --seed and --out: `PYTHONPATH=src /home/bernaljp/.wayline/tools/venv/bin/python -B -m toy.train --seed <s> --out results/E5/start/seed<s>/summary.json` for s = 1, 2, 3. A .json --out is a summary file, never a run directory. No --config, no --val-fraction, no other flag: this is the goal loop's starting value, not a candidate. Write experiments/E5/run.sh and experiments/E5/jobs.json: one job that runs the three seeds in turn and passes extra flags (the retry ladder's --batch-size) through to train.py. After each seed, the script appends one line to results/E5/changes.jsonl: {"candidate": "start", "seed": s, "val_auroc": null, "auroc": <the summary's auroc>, "kept": null}. Because the ticket names goal O2, the conductor runs `PYTHONPATH=src python3 -m toy.eval --split held_out` on every path in outputs and in each job's expected_outputs. So list ONLY the three summary.json paths there, never changes.jsonl, which the eval command cannot read. Candidates (E5 steps 2-4) are not this ticket; the E5 analysis proposes them if the start falls short. Smoke-test on the CPU into results/smoke/E5/ and commit nothing under results/. Return one Methods passage, every sentence ending with a provenance tag that resolves, and leave out any sentence you cannot tag. File no finding that states a number. If a Bash command you need (python3, wayline, git) is refused, stop at once and return blocked naming it.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113.

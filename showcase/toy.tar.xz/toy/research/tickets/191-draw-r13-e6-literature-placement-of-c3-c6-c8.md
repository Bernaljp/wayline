---
id: 191
title: "Draw R13: E6: literature placement of C3-C6 (C8)"
kind: drawing
difficulty: 2
status: open
blocked_by: []
touches: [drawings/R13-3/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O1]
context_pack: []
origin: drawing R13-3 at order
proposed_by: conductor
demo: R13 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R13-3

Code opened this drawing of R13 ("E6: literature placement of C3-C6 (C8)") at a rest point (order), over its findings t112-a1-f2, t112-a1-f3, t112-a1-f5, t112-a2-f1, t112-a2-f2. Its brief, rendered by code at each launch, is in the prompt.

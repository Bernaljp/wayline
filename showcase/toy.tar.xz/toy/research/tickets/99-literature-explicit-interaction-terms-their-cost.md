---
id: 99
title: "Literature: explicit interaction terms, their cost when unneeded, and paired tests of two classifiers (O1, O4)"
kind: lit
difficulty: 2
status: done
blocked_by: []
touches: []
role: surveyor
skills: []
acceptance:
  machine: []
  quality: []
objectives: [O1, O4]
sections: [introduction]
context_pack: [research/sections/introduction.md, research/CONCERNS.md, research/SPEC.md#e6-claims-c8, research/POSITION.md#what-the-references-lack]
origin: research/SPEC.md#e6-claims-c8
proposed_by: planner
demo: The Introduction holds passages tagged at resolved dossiers. They place the paired-gain question (O1), and the null and strength/size probes (O4), against interaction detection and selection and against paired tests. research/refs/ holds a dossier for each of D6's five DOIs.
---

## Demo

The Introduction holds passages tagged at resolved dossiers. They place the paired-gain question (O1), and the null and strength/size probes (O4), against interaction detection and selection and against paired tests. research/refs/ holds a dossier for each of D6's five DOIs.

## Notes

Re-cut of #80, which never launched; nothing in its design failed. Start by checking each of D6's five works with `wayline scout`, whether or not a passage cites it, because E6's placement analysis reads their dossiers. The five are doi:10.1214/07-aoas148 (Friedman & Popescu 2008), doi:10.1145/2487575.2487579 (Lou et al. 2013), doi:10.1214/13-aos1096 (Bien et al. 2013), doi:10.2307/2531595 (DeLong et al. 1988, already verified as delong-1988-comparing-areas-under-two-more) and doi:10.1162/089976698300017197 (Dietterich 1998). Then search with `wayline scout search` on two questions. First, has any work measured the held-out gain from giving a linear or logistic model an explicit product term, against the same model without it (O1)? Second, what do spurious interaction terms cost, and how does that cost move with sample size and interaction strength (O4; K1, K4, K6)? Passage P1 of research/sections/introduction.md is to be rewritten against these dossiers once they resolve, and a passage that rewrites it names P1 in `replaces`. Every sentence of a passage ends with a {ref:<slug>#...} tag at a dossier the scout verified; leave out any sentence you cannot tag. Rest nothing on paper-a or paper-b (unresolved fixtures, K7). Tree ensembles, MLPs, factorization machines and GA2M as fitted competitors are out of scope (O5 parked, Q7 rejected): cite them only as what this project does not compare against. Your Bash runs only `wayline scout ...`, `wayline consult ...` and `wayline accept`: run one scout command per call, with nothing piped or chained.

## Result

### Attempt 1

Scouted all five D6 DOIs; each resolved. Reworked the two Introduction passages so every claim sentence ends with a ref tag, and dropped the untagged sentences that stated the project's own open questions. Only abstracts were checked, so a full read of the five works is proposed.

Passages:

- introduction, Interaction detection and selection: what the literature offers: Rule ensembles give techniques for identifying which variables interact with others, and the strength and degree of those interactions {ref:friedman-2008-predictive-learning-rule-ensembles#abstract}. Generalized additive models that sum univariate terms are reported to be significantly less accurate than more complex models that permit interactions {ref:lou-2013-accurate-intelligible-models-pairwise-interactions#abstract}. The lasso with a hierarchy constraint selects sparse interaction models, including an interaction only if one or both of its variables are marginally important, and the paper reports an empirical study of the method {ref:bien-2013-lasso-hierarchical-interactions#abstract}. The abstract of the rule-ensemble work states no gain over a no-interaction control {ref:friedman-2008-predictive-learning-rule-ensembles#abstract}. The abstract of the hierarchical lasso likewise states no such gain, nor the cost of added terms when none is needed {ref:bien-2013-lasso-hierarchical-interactions#abstract}.
- introduction, Paired tests of two classifiers: For two or more AUROCs computed on the same individuals, a nonparametric approach based on generalized U-statistics gives an estimated covariance matrix that accounts for the correlation {ref:delong-1988-comparing-areas-under-two-more#abstract}. A paired-differences t test over several random train-test splits is reported to have a high probability of type I error and should never be used {ref:dietterich-1998-approximate-statistical-tests-comparing-supervised#abstract}. McNemar's test has low type I error, and the 5x2 cv test also has acceptable type I error and directly measures variation due to the choice of training set {ref:dietterich-1998-approximate-statistical-tests-comparing-supervised#abstract}.

Proposed Read the five D6 works in full to settle measures_paired_gain (dossier) (admission decides what joins the graph).

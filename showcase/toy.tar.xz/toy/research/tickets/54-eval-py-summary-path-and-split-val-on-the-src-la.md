---
id: 54
title: "eval.py: --summary PATH and --split val on the src/ layout, O2's goal command unchanged"
kind: code
difficulty: 1
status: parked
blocked_by: []
touches: [src/toy/eval.py, tests/test_eval.py]
role: coder
skills: []
acceptance:
  machine: [PYTHONPATH=src python3 -B -m unittest tests.test_eval, "PYTHONPATH=src python3 -B -m toy.eval --split held_out --summary owner/sample-summary.json | grep -qx 'auroc: 0.8502984862625299' && WAYLINE_ARTIFACT=owner/sample-summary.json PYTHONPATH=src python3 -B -m toy.eval --split held_out | grep -qx 'auroc: 0.8502984862625299'", "d=$(mktemp -d) && printf '{\"seed\": 1, \"val_auroc\": 0.75}\\n' > \"$d/summary.json\" && PYTHONPATH=src python3 -B -m toy.eval --split val --summary \"$d\" | grep -qx 'val_auroc: 0.75'"]
  quality: []
objectives: [O1, O2]
sections: [methods]
context_pack: [owner/measure.json, src/toy/eval.py, research/SPEC.md#seams, research/SPEC.md#metrics]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`PYTHONPATH=src python3 -m toy.eval --split held_out --summary owner/sample-summary.json` prints auroc: 0.8502984862625299; O2's command with WAYLINE_ARTIFACT set prints the same; `--split val --summary <run-dir>` on a --val-fraction run prints its val_auroc."
---

## Demo

`PYTHONPATH=src python3 -m toy.eval --split held_out --summary owner/sample-summary.json` prints auroc: 0.8502984862625299; O2's command with WAYLINE_ARTIFACT set prints the same; `--split val --summary <run-dir>` on a --val-fraction run prints its val_auroc.

## Notes

Re-cut of ticket 30, which was cut for a code/ layout the owner did not take: decision #50 kept the package at src/toy/ and the tests at tests/, so write only src/toy/eval.py and tests/test_eval.py. Keep what O2's command does today: `PYTHONPATH=src python3 -m toy.eval --split held_out` reads the summary named by the positional path or by WAYLINE_ARTIFACT (keep-if-better exports it for each seed artifact) and prints 'auroc: <value>' with the value unformatted. That is the 'default summary' the spec's seam names. Add --summary PATH, equivalent to the positional path, also accepting a run directory (it reads summary.json inside it). Add --split val, which prints 'val_auroc: <value>' from the summary's val_auroc and exits non-zero when there is none; --split held_out on a summary with no auroc (a --val-fraction run) exits non-zero, as now. Fix the module docstring, which calls the measure O1's: it is O2's. tests/test_eval.py covers the old path (WAYLINE_ARTIFACT=owner/sample-summary.json), --summary on a file and on a run directory, and --split val on a temporary summary; it must run as `python3 -B -m unittest tests.test_eval` from the project root (tests/ has no __init__.py; do not add one). Stdlib only. Return one Methods passage, every claim sentence ending with a provenance tag such as {code:src/toy/eval.py#main}. If a Bash command you need (python3, wayline accept, git) is refused, stop and return blocked naming it; tickets 34 and 38 lost their windows writing files they could not run.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93.

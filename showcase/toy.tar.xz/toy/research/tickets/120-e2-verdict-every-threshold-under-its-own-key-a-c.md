---
id: 120
title: "E2 verdict: every threshold under its own key, a citation checker, and C2's and A7's five findings re-filed"
kind: analysis
difficulty: 3
status: accepted
blocked_by: [16, 103, 115, 116]
touches: [analysis/E2/verdict.py, analysis/E2/verdict.json, analysis/E2/paired.json, analysis/E2/cite_check.py, analysis/E2/findings_c2.json]
role: analyst
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 4, wallclock_minutes: 30}
inputs: [results/runs/E2/m1_n0/, analysis/E1/summary.json, analysis/E2/checks.json, research/manifest.json]
outputs: [analysis/E2/paired.json, analysis/E2/verdict.json]
acceptance:
  machine: ["python3 -B analysis/E2/verdict.py --check && PYTHONPATH=src python3 -B -c \"import json; import toy.paired as tp; p = json.load(open('analysis/E2/paired.json')); v = json.load(open('analysis/E2/verdict.json')); assert (v['bound_slack'], v['p_limit'], v['delong_alpha'], v['gap_denominator_min'], v['confidence'], v['bootstrap_resamples'], v['sd_rule'], v['goal']) == (0.002, 0.05, tp.DELONG_ALPHA, tp.GAP_DENOMINATOR_MIN, tp.CONFIDENCE, tp.BOOTSTRAP_RESAMPLES, tp.SD_RULE, 0.82); assert (v['seed_first'], v['seed_last'], v['revisit_seed_first'], v['revisit_seed_last']) == (1, 20, 21, 50) and v['n_pairs'] == p['n_pairs'] == 20 and p['seeds'] == list(range(1, 21)); assert v['c3_supported'] == (p['paired_gain_lo'] > 0 and p['signed_rank_p'] < v['p_limit']) and v['c2_bound_supported'] == (p['mean_bayes_auroc'] >= p['mean_auroc_with'] - v['bound_slack'] and p['mean_bayes_auroc'] >= p['mean_auroc_without'] - v['bound_slack']) and v['q15_revisit'] == (v['sd_d'] > v['sd_rule']); assert p['paired_gain'] == 0.08716535526499543 and v['sd_d'] == 0.006032219084153099 and v['bayes_minus_with'] == 0.0009144939855112444 and {'c2_supported', 'a2_confirmed', 'a7_mean_with_below_goal', 'n_positive_d', 'min_d', 'max_d', 'n_with_above_bayes', 'max_with_minus_bayes'} <= set(v)\"", "d=$(mktemp -d) && t='{\"findings\": [{\"replaces\": \"t108-a1-f1\", \"heading\": \"E2\", \"sentences\": [{\"text\": \"%s\", \"cites\": [\"%s\"]}]}], \"passages\": []}\\n' && printf \"$t\" 'The mean gain is 0.08716535526499543 over 20 pairs.' 'analysis/E2/paired.json#paired_gain\", \"analysis/E2/paired.json#n_pairs' > \"$d/ok.json\" && python3 -B analysis/E2/cite_check.py \"$d/ok.json\" && printf \"$t\" 'The mean gain is positive.' 'analysis/E2/paired.json#no_such_key' > \"$d/key.json\" && { python3 -B analysis/E2/cite_check.py \"$d/key.json\" > /dev/null 2>&1; test $? -eq 1; } && for bad in 'The mean gain is 0.0872.' 'The mean gain is 0.08716535526499543 over 20 pairs.' 'The mean gain is 0.08716535526499543 at 95% confidence.'; do printf \"$t\" \"$bad\" 'analysis/E2/paired.json#paired_gain' > \"$d/bad.json\" && { python3 -B analysis/E2/cite_check.py \"$d/bad.json\" > /dev/null 2>&1; test $? -eq 1; } || exit 1; done", "python3 -B analysis/E2/cite_check.py analysis/E2/findings_c2.json && python3 -c \"import json; t = json.load(open('analysis/E2/findings_c2.json')); assert sorted(f['replaces'] for f in t['findings']) == sorted('t108-a1-f%d' % i for i in (9, 11, 12, 13, 15)); assert [x['replaces'] for x in t['passages'] if x['section'] == 'methods'] == ['P38']; c = {k for f in t['findings'] if f['replaces'] == 't108-a1-f11' for s in f['sentences'] for k in s['cites']}; assert {'analysis/E2/verdict.json#c2_bound_supported', 'analysis/E2/verdict.json#bound_slack'} <= c\""]
  quality: ["Does each of the five findings and the Methods passage state only numbers held at keys its sentence cites, written as stored, with each finding replacing exactly the t108-a1 finding it corrects and holding only what that finding held, and does verdict.py take every new key from the constant its rule uses while leaving every existing value unchanged?"]
objectives: [O3, O1]
sections: [methods, results]
context_pack: [research/sections/methods.md:34-35, research/findings.jsonl:68-82, analysis/E2/verdict.json, src/toy/paired.py:60-79, analysis/E2/verdict.py, research/tickets/108-e2-analysis-paired-auroc-gain-of-the-x3-x4-colum.md#result, research/SPEC.md#e2-claims-c2-c3, research/SPEC.md#methods, research/SPEC.md#anti-claims]
origin: research/SPEC.md#e2-claims-c2-c3
proposed_by: planner
demo: "`python3 -B analysis/E2/verdict.py --check` exits 0, and verdict.json now holds bound_slack 0.002, p_limit 0.05, delong_alpha, gap_denominator_min, confidence 0.95, and seeds 21 to 50 for Q15's revisit rule, each under its own key. `analysis/E2/cite_check.py` rejects a rounded value, an uncited count, a percentage and a missing key. Five findings on C2's ceiling bound and on A7 replace t108-a1-f9, f11, f12, f13 and f15, and every number in them sits at a key its sentence cites."
---

## Demo

`python3 -B analysis/E2/verdict.py --check` exits 0, and verdict.json now holds bound_slack 0.002, p_limit 0.05, delong_alpha, gap_denominator_min, confidence 0.95, and seeds 21 to 50 for Q15's revisit rule, each under its own key. `analysis/E2/cite_check.py` rejects a rounded value, an uncited count, a percentage and a missing key. Five findings on C2's ceiling bound and on A7 replace t108-a1-f9, f11, f12, f13 and f15, and every number in them sits at a key its sentence cites.

## Notes

Cut from ticket 108 by the planner's split.

This is the first half of the split of #108. #108's computation stands, and its findings failed their quality verdict. analysis/E2/verdict.py, paired.json and verdict.json are on main, and `python3 -B analysis/E2/verdict.py --check` recomputes both JSON files from the manifested E2 runs. Every blocker the verifier raised was about citation. f10 and f5 stated 0.05, and f11 stated 0.002, but no key held either number. f14 stated the count 20 without citing it, and 'seeds 21-50', which no key held. f1 and f2 wrote '95%'. Several findings gave rounded values. This ticket creates the missing keys, adds a checker that catches those faults mechanically, and re-files the five findings on C2 and A7. The second half of the split re-files C3's ten findings with the same checker and waits on this ticket.

(1) verdict.py. Add these keys to verdict.json. Take each from the constant its rule uses, so that no threshold is typed twice:
- bound_slack (BOUND_SLACK)
- p_limit (P_LIMIT)
- delong_alpha (toy.paired.DELONG_ALPHA)
- gap_denominator_min (toy.paired.GAP_DENOMINATOR_MIN)
- confidence (toy.paired.CONFIDENCE)
- bootstrap_resamples (toy.paired.BOOTSTRAP_RESAMPLES)
- seed_first and seed_last (the ends of SEEDS)
- revisit_seed_first and revisit_seed_last (21 and 50). Take both from one new constant for the seeds that Q15's revisit rule would add (SPEC Methods, Paired seeds).
Keep every existing key at its value, and keep --check. Run `python3 -B analysis/E2/verdict.py`, then `python3 -B analysis/E2/verdict.py --check`. Commit verdict.py, verdict.json and paired.json; paired.json should come out byte-identical. If any existing value changes, return blocked and name the keys. The numbers are not this ticket's to change.

(2) analysis/E2/cite_check.py, standard library only. `python3 -B analysis/E2/cite_check.py TABLE` reads a findings table. The table is a JSON object {"findings": [...], "passages": [...]}:
- A finding is {"replaces", "heading", "sentences"}.
- A passage is {"section", "heading", "replaces", "sentences"}, with replaces null for a new passage.
- A sentence is {"text", "cites"}. The text carries no tags. Each cite is "<path>#<name>", where the path is relative to the checkout two directories above the script.
The rules:
- R1: every sentence has at least one cite.
- R2: every cite resolves. A .json path holds a top-level key <name>. A .py path defines <name> at top level (def, class or assignment, read with ast).
- R3: this rule covers findings, and passages whose section is not methods. A numeric token is a match of (?<![A-Za-z0-9_.])\d+(?:\.\d+)?(?:[eE][-+]?\d+)?(?![A-Za-z0-9_]). Every numeric token in a sentence must equal json.dumps(v), character for character, for some value v at one of that sentence's .json cites. v is a number that is not a bool, or an element of a list.
- R4: no sentence contains '%'.
- R5: no two findings replace the same id.
The checker prints every violation with its entry and rule and exits 1. It exits 2 when the table cannot be read or lacks a field, and 0 otherwise. Give it a docstring that states this format and these rules, because the second half reads it. The machine criteria test the checker on a rounded value, an uncited count, a percentage and a missing key.

(3) analysis/E2/findings_c2.json. This is the table of what this ticket returns, and cite_check.py must pass it. It holds five findings under the heading 'E2: Bayes ceiling bound and A7', each replacing one t108-a1 finding:
- t108-a1-f9: mean_bayes_auroc over n_pairs.
- t108-a1-f11: c2_bound_supported, with bayes_minus_with, bayes_minus_without and bound_slack.
- t108-a1-f12: n_with_above_bayes of n_pairs, and max_with_minus_bayes.
- t108-a1-f13: c2_supported, from the bound part and E1's c2_ceiling_supported.
- t108-a1-f15: a7_mean_with_below_goal, mean_auroc_with, goal and n_pairs.
Each finding holds what the finding it replaces held, and no more. Ticket 104's second attempt was flagged when one replacement took in another finding's content. The table also holds one Methods passage replacing P38, whose first sentence had no tag. The passage covers the manifest hash check (verify_sources), the point statistics from toy.paired.point_stats, C2's bound rule and c2_supported, A7's comparison, and the fact that verdict.json now records each threshold under its own key. Every sentence cites analysis/E2/verdict.py#<function>. Write counts in digits ('1 of the 20', never 'only one'). Write every value as stored, with no percentage, no rounding and no 'about'.

Return exactly the table's sentences. End each with one tag per cite: {res:<run>/<path>#<key>} for a .json cite, and {code:<path>#<name>} for a .py cite. <run> is the run id in research/manifest.json's last entry for that path. For paired.json and verdict.json, which this ticket rewrites, that is this ticket's own run (t<id>-a<attempt>, as #108 used t108-a1). Leave evidence unset. List cite_check.py, render, project_root and main under Not methods.

Bash: this role runs a command only when every part of it begins with a program on its allow list: python3, git add, git commit, git status, git diff, git log, ls, cat and wayline accept. A `PYTHONPATH=` prefix, mkdir, bash, heredocs and `>` redirects are refused, and those refusals blocked tickets 16, 76 and 83. Write files with the Write or Edit tool, and run one plain command per Bash call. Retry a refused command in an allowed form before you return blocked. results/ is git-ignored and not in the worktree, so verdict.py reads it under the project root. Commit only the five analysis/E2/ files of the touch set.

## Result

### Attempt 1

I fixed the repeat the conductor's check flagged. The A7 finding, which replaces t108-a1-f15, no longer states the with arm's mean AUROC 0.8552220917946025. That value belongs to t108-a1-f7, which ticket 121 re-files. The finding still cites verdict.json#mean_auroc_with, and it holds only f15's content: a7_mean_with_below_goal, the comparison with goal 0.82, and n_pairs. Nothing else changed. verdict.json now holds bound_slack, p_limit, delong_alpha, gap_denominator_min, confidence, bootstrap_resamples, seed_first, seed_last, revisit_seed_first and revisit_seed_last, each taken from the constant its rule uses. Every existing value is unchanged, paired.json is byte-identical, and `verdict.py --check` exits 0. analysis/E2/cite_check.py enforces R1-R5 and rejects a rounded value, an uncited count, a percentage and a missing key. findings_c2.json holds the five replacement findings and the Methods passage that replaces P38, and it passes the checker. `wayline accept` passes, and the work is committed on ticket/120 (add528f).

Wrote: `analysis/E2/verdict.py`, `analysis/E2/verdict.json`, `analysis/E2/cite_check.py`, `analysis/E2/findings_c2.json`

Ran: `python3 -B analysis/E2/verdict.py /home/bernaljp/wayline-m8/toy`, `python3 -B analysis/E2/verdict.py --check`, `python3 -B analysis/E2/cite_check.py analysis/E2/findings_c2.json`, `python3 -B -c <cite_check negative cases>`, `python3 -B -c <ticket acceptance assertions>`, `git add`, `git commit`, `wayline accept`

Passages:

- methods, Statistics, replacing P38: The E2 analysis reads the paired replicates of seeds 1 to 20 only after every run file's hash matches the sha256 of its last manifest entry, and only when both arms hold exactly those seeds {code:analysis/E2/verdict.py#verify_sources} {res:t120-a1/analysis/E2/verdict.json#seed_first} {res:t120-a1/analysis/E2/verdict.json#seed_last}. It computes the point's paired statistics with toy.paired.point_stats, and it reads the claims only when the reproduction and convergence gate has passed {code:analysis/E2/verdict.py#compute} {res:t120-a1/analysis/E2/verdict.json#gate_passed}. C2's bound part is supported when the oracle's mean AUROC is at least each arm's mean AUROC minus a bound slack of 0.002, and C2 is supported when its bound part holds and E1 found its ceiling part supported {code:analysis/E2/verdict.py#compute} {res:t120-a1/analysis/E2/verdict.json#bound_slack} {res:t120-a1/analysis/E2/verdict.json#c2_ceiling_supported}. A7 is read by comparing the with arm's mean AUROC over the replicates with O2's goal of 0.82 {code:analysis/E2/verdict.py#compute} {res:t120-a1/analysis/E2/verdict.json#goal}. verdict.json records each threshold and seed range these rules read under its own key, taken from the constant the rule uses: bound_slack, p_limit, delong_alpha, gap_denominator_min, confidence, bootstrap_resamples, sd_rule, goal, seed_first, seed_last, revisit_seed_first and revisit_seed_last {code:analysis/E2/verdict.py#compute}.

Parameters:

- `compute` `REVISIT_SEEDS`: SPEC Methods (Paired seeds, Q15) names seeds 21 to 50 as the ones added when the SD of d_i exceeds 0.02; this constant holds them once so that revisit_seed_first and revisit_seed_last come from it.
- `compute` `BOUND_SLACK`: SPEC E2's success rule lets an arm's mean AUROC sit up to 0.002 above the oracle's mean before C2's bound part fails; it is now also written to verdict.json as bound_slack.
- `compute` `P_LIMIT`: SPEC E2's success rule requires signed_rank_p below 0.05 for C3; it is now also written to verdict.json as p_limit.

Not methods:

- `code/analysis/E2/cite_check.py#main`: It checks that a findings table's sentences cite keys holding their numbers, and computes nothing the paper reports.
- `code/analysis/E2/cite_check.py#check`: It applies the citation rules R1-R5 to a findings table, which is a check on the writing, not an analysis.
- `code/analysis/E2/cite_check.py#cite_values`: It resolves a cite to the numbers its JSON key holds, or to a top-level Python name, for the citation check only.
- `code/analysis/E2/cite_check.py#load_table`: It only reads and validates the findings table's JSON structure.
- `code/analysis/E2/cite_check.py#top_level_names`: It lists a Python file's top-level definitions so a code cite can be resolved.
- `code/analysis/E2/cite_check.py#is_number`: It only tells a JSON number from a bool.
- `analysis/E2/verdict.py#render`: It only serialises JSON with sorted keys.
- `analysis/E2/verdict.py#project_root`: It only locates the project directory that holds results/.
- `analysis/E2/verdict.py#main`: It is the command-line wrapper that writes the files or compares them under --check.

**Verdict (result): passed** by claude-opus-5-5, session `89f66789-3261-4f9a-98fd-727c088c01df`.

- [minor] The last Methods sentence says verdict.json records every threshold and seed range 'these rules read', each 'taken from the constant the rule uses', and lists revisit_seed_first and revisit_seed_last among them. No rule in verdict.py reads REVISIT_SEEDS: q15_revisit (line 118) compares sd_d with SD_RULE only, and the constant exists only to be written out (lines 140-141). p_limit and sd_rule are read by the C3 and Q15 rules, which this passage does not describe. The sentence would be accurate if it said the revisit keys are the seeds Q15's rule would add. (analysis/E2/findings_c2.json line 77 (passages[0], sentence 4); analysis/E2/verdict.py lines 40, 118, 140-141)
- [minor] The diff adds a public class, TableError, to cite_check.py. It is named in no Methods passage and is missing from the result's not_methods list, which otherwise covers every other cite_check.py definition. It is plainly not a method (an exception type), so only the list's completeness is affected. (analysis/E2/cite_check.py line 41; research/sessions/120/1/methods.json lines 19-56)
- [minor] The six cite_check.py not-method entries begin with 'code/' (code/analysis/E2/cite_check.py#...), but this checkout has no code/ directory. The three verdict.py entries in the same list have no such prefix, so a reader following the cite_check paths finds no file. (research/sessions/120/1/methods.json lines 21-42; research/tickets/120-e2-verdict-every-threshold-under-its-own-key-a-c.md, ## Result, 'Not methods' (lines 92-97))
- [minor] This session was refused permission to run python3, so I did not re-run `verdict.py --check`, the checker on findings_c2.json, or the checker's negative cases myself. Those exit codes rest on my reading of the code and the regex, and on the harness's acceptance records. Those records show every machine criterion at exit 0 in the worktree, after rebase, and on main. verdict.json's sha256 matching its manifest entry, and paired.json's sha256 matching ticket 108's commit 592ee3d, I did check directly. (research/journal.jsonl lines 3138-3140 (acceptance events for ticket 120); research/manifest.json lines 12208-12221)

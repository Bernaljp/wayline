---
id: 185
title: Scope t122-a2-f5 to the single unneeded column K4 measured, and give R7's two drawing findings one tag per key
kind: writing
difficulty: 2
status: open
blocked_by: []
touches: []
role: writer
skills: [interval-claims]
inputs: [research/findings.jsonl, drawings/R7-1/numbers.json, analysis/E3/verdict.json, src/toy/train.py]
acceptance:
  machine: []
  quality: ["Does t122-a2-f5's replacement say that its cost is that of the one unneeded x3·x4 column, the only product the work adds, and claim nothing about other spurious pairwise terms? Do the replacements of t140-a1-f1 and t140-a1-f2 keep their text and end each sentence with one {res:t140-a1/drawings/R7-1/numbers.json#<key>} tag per key whose value it writes?"]
objectives: []
sections: [results]
context_pack: [research/findings.jsonl:128, research/findings.jsonl:178-179, research/sections/results.md:92-96, research/sections/results.md:318-319, research/tickets/162-scope-down-the-general-report-s-claims-the-kill.md, drawings/R7-1/numbers.json, src/toy/train.py]
origin: research/REPORT.md#kill-argument
proposed_by: planner
demo: The general report renders t122-a2-f5's replacement, which scopes the m = 0 cost to the single x3·x4 column, and R7's two drawing findings with one tag per number. R7's headline in section 2 now carries a footnote.
---

## Demo

The general report renders t122-a2-f5's replacement, which scopes the m = 0 cost to the single x3·x4 column, and R7's two drawing findings with one tag per number. R7's headline in section 2 now carries a footnote.

## Notes

Why, from the kill argument (part of the re-cut of #162):
- Point 6 stands for K4. K4 asks what spurious pairwise terms cost through overfitting, but the only unneeded term the work ever adds is the single x3·x4 column at m = 0. All-pairs arms are out of scope (SPEC Out of scope; Q14).
- Point 9 stands for R7. R7's headline renders with no provenance tag, because t140-a1-f1 and t140-a1-f2 each end with one tag whose locator is a comma-separated list of keys (`#n_runs,mean_drop,...`) rather than one key per tag.

Return three findings.

1. Replacing t122-a2-f5: keep its sentence and its tags at t122-a2 exactly as recorded. Add one sentence saying that this is the cost of the one unneeded column the work adds, x3·x4, and that the cost of other spurious pairwise products is not measured. Tag that sentence with `{code:src/toy/train.py#featurize}` (a code tag resolves against main), or with a manifested artifact at the run that holds it. Use no tag of your own run: analysis/E3/verdict.json is cited at t122-a2 by O1's and O4's answers. Keep its `heading`, `provenance` and `negative` as research/findings.jsonl records them.

2 and 3. Replacing t140-a1-f1 and t140-a1-f2: keep the text. End each sentence, right after its full stop, with one `{res:t140-a1/drawings/R7-1/numbers.json#<key>}` tag per key whose value it writes. The keys are the ones the old tags list, each checked against drawings/R7-1/numbers.json. Keep run t140-a1, which the manifest holds, and keep each finding's `heading`, `provenance` and `negative` as recorded.

Edit no file. Return no passage.

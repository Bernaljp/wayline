---
id: 138
title: "Draw R5: toy.converge: largest relative training-loss drop at doubled epochs"
kind: drawing
difficulty: 2
status: failed
blocked_by: []
touches: [drawings/R5-1/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O1]
context_pack: []
origin: drawing R5-1 at run_end
proposed_by: conductor
demo: R5 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R5-1

Code opened this drawing of R5 ("toy.converge: largest relative training-loss drop at doubled epochs") at a rest point (run_end), over its findings t8-a2-f1, t8-a2-f2. Its brief, rendered by code at each launch, is in the prompt.

## Result

### Attempt 1

Drew R5 (toy.converge) from the E2 run files: the relative training-loss drop for each run against the gate (headline), paired final training loss at the pinned and doubled epochs, the change in held-out AUROC for each run, and a table of every run. The largest drop on the real runs is 0.003441 (with arm, seed 2), below the gate. No rerun crosses the gate, and in half of them the loss rose slightly. AUROC moves by at most 0.002051. The value that finding t8-a2-f1 quotes comes from the test fixture. This resubmission fixes the provenance tags and the number citations.

Wrote: `drawings/R5-1/draw.py`, `drawings/R5-1/drawing.json`, `drawings/R5-1/numbers.json`, `drawings/R5-1/per_run.csv`, `drawings/R5-1/drop_per_run.png`, `drawings/R5-1/drop_per_run.svg`, `drawings/R5-1/loss_pinned_vs_double.png`, `drawings/R5-1/loss_pinned_vs_double.svg`, `drawings/R5-1/auroc_change_per_run.png`, `drawings/R5-1/auroc_change_per_run.svg`

Ran: `wayline tools run matplotlib -- drawings/R5-1/draw.py`, `wayline accept`, `git add drawings/R5-1`, `git commit`

Passages:

- methods, Convergence check: For each E2 run that was rerun at doubled epochs, the drawing script reads `final_train_loss` and `auroc` from the pinned run's `summary.json` and from the rerun's, and `epochs` from each `config.json` {res:drawings/R5-1/numbers.json#n_runs}. It computes the signed relative drop $d = (L_{\mathrm{pinned}} - L_{\mathrm{doubled}}) / L_{\mathrm{pinned}}$ and reports its maximum over the runs {res:drawings/R5-1/numbers.json#convergence_drop}. It also counts the runs whose drop exceeds the gate and the runs whose loss rose {res:drawings/R5-1/numbers.json#n_runs_over_gate} {res:drawings/R5-1/numbers.json#n_runs_loss_rose}. Finally it reports the largest absolute change in held-out AUROC {res:drawings/R5-1/numbers.json#max_abs_auroc_change}.

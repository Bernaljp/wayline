---
id: 119
title: Promote lou-2013-accurate-intelligible-models-pairwise-interactions to level 2?
kind: decision
difficulty: 1
status: done
blocked_by: []
blocking: null
human_only: false
touches: []
role: decider
acceptance: {}
proposed_by: worker:112
context_pack: [refs/lou-2013-accurate-intelligible-models-pairwise-interactions/dossier.json]
origin: a consultant question L1 cannot answer; phase P5, 2 of 2 L2 slot(s) already used; question b00ae49c017a
demo: Read refs/lou-2013-accurate-intelligible-models-pairwise-interactions/dossier.json and decide whether it earns a full level-2 read.
---

## Decision

Promote `lou-2013-accurate-intelligible-models-pairwise-interactions` to level 2 (a full read)?

Trigger: a consultant question L1 cannot answer.

Budget: phase P5 allows 2 level-2 read(s) at a time; 2 of 2 L2 slot(s) already used.

## Answer

yes: promote it to level 2 (a full read)

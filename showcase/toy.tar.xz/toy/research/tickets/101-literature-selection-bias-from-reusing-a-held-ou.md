---
id: 101
title: "Literature: selection bias from reusing a held-out set, and tuning on a validation split (O2)"
kind: lit
difficulty: 2
status: done
blocked_by: []
touches: []
role: surveyor
skills: []
acceptance:
  machine: []
  quality: []
objectives: [O2]
sections: [introduction]
context_pack: [research/sections/introduction.md, research/CONCERNS.md, research/SPEC.md#e5-claims-c7, research/SPEC.md#methods, research/POSITION.md#what-the-references-lack]
origin: research/SPEC.md#e5-claims-c7
proposed_by: planner
demo: "The Introduction holds passages tagged at resolved dossiers on two points: why a held-out score chosen over several reads is biased upward, and why tuning belongs on a validation split cut from the training rows (K3). That is the discipline the goal loop for 0.82 follows."
---

## Demo

The Introduction holds passages tagged at resolved dossiers on two points: why a held-out score chosen over several reads is biased upward, and why tuning belongs on a validation split cut from the training rows (K3). That is the discipline the goal loop for 0.82 follows.

## Notes

Re-cut of #82, which never launched; nothing in its design failed. Search with `wayline scout search` for three topics. First, over-fitting in model selection (Cawley & Talbot 2010, JMLR). Second, adaptive reuse of a holdout and the bias it causes: Dwork et al. 2015 ('The reusable holdout'), Recht et al. 2019, and Roelofs et al. 2019 on Kaggle holdouts. Third, nested or split-sample validation for tuning (Varma & Simon 2006). Check each work you cite with `wayline scout`. Every sentence of a passage ends with a {ref:<slug>#...} tag at a dossier the scout verified; leave out any sentence you cannot tag. A passage that says what a current one says names it in `replaces`. Rest nothing on paper-a or paper-b. Your Bash runs only `wayline scout ...`, `wayline consult ...` and `wayline accept`: run one scout command per call, with nothing piped or chained.

## Result

### Attempt 1

Four works scouted on adaptive reuse of held-out data and on model selection; one Introduction passage, every claim sentence tagged.

Passages:

- introduction, Reusing a held-out set and tuning on a validation split: Statistical inference theory assumes the hypotheses or learning algorithms are selected before the data are gathered, whereas in practice data are reused and new analyses are generated from the outcomes of earlier ones {ref:dwork-2014-preserving-statistical-validity-adaptive-data#abstract}. The same line of work names parameter tuning on the basis of obtained results as part of this adaptive practice, and gives a method for reusing a holdout set to validate the accuracy of hypotheses a learning algorithm produces adaptively {ref:dwork-2017-guilt-free-data-reuse#abstract}. A review of model evaluation covers the holdout method for evaluation and selection, k-fold and nested cross-validation, and the bias-variance trade-off in choosing k {ref:raschka-2018-model-evaluation-model-selection-algorithm#abstract}. Another review separates model assessment from model selection and presents cross-validation as the generic way to estimate the quantities needed for selection {ref:emmert-streib-2019-evaluation-regression-models-model-assessment#abstract}. These abstracts state no size for the upward bias of a held-out score chosen over several reads {ref:dwork-2017-guilt-free-data-reuse#abstract} {ref:raschka-2018-model-evaluation-model-selection-algorithm#abstract}.

Proposed Read Dwork et al. 2017 in full for the size of held-out bias under adaptive reads (dossier) (admission decides what joins the graph).

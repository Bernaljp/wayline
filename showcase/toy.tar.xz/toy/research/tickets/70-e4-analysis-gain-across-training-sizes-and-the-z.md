---
id: 70
title: "E4 analysis: gain across training sizes and the zero-strength cost per size (C6)"
kind: analysis
difficulty: 3
status: parked
blocked_by: [16, 56, 66, 67]
touches: [analysis/E4/]
role: analyst
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 4, wallclock_minutes: 60}
inputs: [results/runs/E4/, results/runs/E2/m1_n0/, results/runs/E3/m0_n0/]
outputs: [analysis/E4/sweep_m1.json, analysis/E4/sweep_m0.json, analysis/E4/verdict.json]
acceptance:
  machine: ["python3 -c \"import json; a = json.load(open('analysis/E4/sweep_m1.json')); b = json.load(open('analysis/E4/sweep_m0.json')); v = json.load(open('analysis/E4/verdict.json')); want = [1000, 2000, 4000, 8000, 16000, 32000, 64000]; assert sorted(int(p['train_rows']) for p in a['points']) == want and sorted(int(p['train_rows']) for p in b['points']) == want and v['c6_supported'] == (a['gain_shrink'] <= 0.005) and v['a5'] == (a['gain_shrink_lo'] > 0.005) and 'unresolved' in v\""]
  quality: ["Does C6's verdict follow gain_shrink and gain_shrink_lo as the spec defines them, is the m = 0 difference at each size reported as K4's cost rather than claimed, and does every finding's number sit at the field it cites?"]
objectives: [O4]
sections: [methods, results]
context_pack: [research/SPEC.md#e4-claims-c6, research/SPEC.md#claims, research/SPEC.md#anti-claims]
origin: research/SPEC.md#e4-claims-c6
proposed_by: planner
demo: analysis/E4/sweep_m1.json and sweep_m0.json and the findings show the paired gain with its CI at each training size from 1000 to 64000 rows at strength 1 and 0, gain_shrink with its CI, and C6's verdict.
---

## Demo

analysis/E4/sweep_m1.json and sweep_m0.json and the findings show the paired gain with its CI at each training size from 1000 to 64000 rows at strength 1 and 0, gain_shrink with its CI, and C6's verdict.

## Notes

Run toy.sweep twice, seven sizes each. First: `PYTHONPATH=src python3 -B -m toy.sweep "$WAYLINE_PROJECT/results/runs/E4" --axis rows --strength 1 --point "$WAYLINE_PROJECT/results/runs/E2/m1_n0" --out analysis/E4/sweep_m1.json`. Second: the same with `--strength 0 --point "$WAYLINE_PROJECT/results/runs/E3/m0_n0" --out analysis/E4/sweep_m0.json`. Then write analysis/E4/verdict.py and the analysis/E4/verdict.json it writes, with: c6_supported = gain_shrink <= 0.005 at m = 1; a5 = gain_shrink_lo > 0.005 (when it holds, C3's gain is partly a small-sample effect); unresolved = neither holds; and the thresholds you state under their own keys. At m = 0, report the paired difference at each size as the overfitting cost K4 asks about, not as a claim. A8: the claims reach only across these grids. Propose seeds 21-50 where Q15's rule calls for them (SD above 0.02, or an interval too wide at m = 0 or at the smallest size). Every number in a finding must sit at the field it cites, written as stored, with no percentage or derived number (ticket 41 failed `wayline numbers check` that way). Return a Methods passage and a Results passage whose claim sentences each end with a provenance tag.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93.

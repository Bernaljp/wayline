---
id: 58
title: "toy.placement: resolved_refs and prior_measures_gain from a placement record and the dossiers (src/ layout)"
kind: code
difficulty: 2
status: parked
blocked_by: []
touches: [src/toy/placement.py, tests/test_placement.py, tests/fixtures/placement/]
role: coder
skills: []
acceptance:
  machine: [PYTHONPATH=src python3 -B -m unittest tests.test_placement, "PYTHONPATH=src python3 -B -m toy.placement tests/fixtures/placement/placement.json --refs tests/fixtures/placement/refs | python3 -c \"import json, sys; d = json.load(sys.stdin); assert {'resolved_refs', 'prior_measures_gain', 'entries', 'mismatches'} <= set(d)\""]
  quality: []
objectives: [O1]
sections: [methods]
context_pack: [research/refs/paper-a/dossier.json, research/refs/delong-1988-comparing-areas-under-two-more/dossier.json, research/SPEC.md#e6-claims-c8, research/SPEC.md#seams]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`PYTHONPATH=src python3 -m toy.placement tests/fixtures/placement/placement.json --refs tests/fixtures/placement/refs` prints resolved_refs and prior_measures_gain, and the tests show it exits 1 on an entry whose existence disagrees with its dossier."
---

## Demo

`PYTHONPATH=src python3 -m toy.placement tests/fixtures/placement/placement.json --refs tests/fixtures/placement/refs` prints resolved_refs and prior_measures_gain, and the tests show it exits 1 on an entry whose existence disagrees with its dossier.

## Notes

Re-cut of ticket 34, which was blocked twice over: it was cut for a code/ layout the owner did not take (decision #50 kept src/toy/ and tests/), and its session was refused Bash, so nothing it wrote was ever run. Write only src/toy/placement.py, tests/test_placement.py and tests/fixtures/placement/. `toy.placement <placement.json> [--refs research/refs]`. placement.json is a JSON list of entries: slug; doi (bare, lower case, no 'doi:' prefix); existence; measures_paired_gain (true, false, or null when the dossier cannot settle it); and locator. For each entry read <refs>/<slug>/dossier.json; its top-level 'existence' is 'unresolved' until the scout resolves it, and 'verified' or another value after (see the two dossiers in the context pack). An entry with no dossier must say existence 'missing' and counts as unresolved; a missing dossier is not an error, so an unscouted work makes C8 unresolved instead of failing the command. An entry whose existence differs from its dossier's, or that says 'missing' when a dossier exists, is listed under mismatches and makes the command exit 1. Print JSON with resolved_refs (entries whose dossier exists and is not 'unresolved'), prior_measures_gain (resolved entries with measures_paired_gain true), entries, and mismatches. Fixtures under tests/fixtures/placement/: a placement.json with no mismatch (the acceptance pipeline runs it) and a refs/ tree with one resolved, one unresolved and one missing dossier; test the mismatch exit on a temporary copy. Stdlib only; run Python as python3 -B. Return one Methods passage whose claim sentences each end with a provenance tag. If a Bash command you need is refused, stop at once and return blocked naming it; do not write files you cannot run.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Result

### Attempt 1

The code is unchanged and already committed on ticket/58. This result fixes the two failures the conductor reported. I added a Methods passage for toy.placement, and I replaced the numeric finding with one that cites a single dossier and gives no counts or years. Both ticket acceptance commands still pass under `wayline accept`. I did not re-run the conductor's `wayline numbers check` or the Methods-sections check myself.

Wrote: `src/toy/placement.py`, `tests/test_placement.py`, `tests/fixtures/placement/`

Ran: `wayline accept`

Passages:

- methods, Literature placement: The literature placement reads results/placement.json, one entry per D6 work, and cross-checks each entry's existence and DOI against the dossier at research/refs/<slug>/dossier.json, reporting any disagreement or missing dossier as a mismatch and exiting 1 {code:src/toy/placement.py#check_entry}. resolved_refs counts the entries whose dossier states existence "verified", and prior_measures_gain counts those resolved entries whose measures_paired_gain is true, so a work that was never resolved and read cannot count toward either number {code:src/toy/placement.py#place}. It uses the Python standard library alone.

Not methods:

- `toy.placement`: Bookkeeping over dossier fields; the Methods passage describes its counting rule, but the helpers (load_entries, _read_json, _norm_doi, main) are plumbing.

Escalated one rung up: the next attempt launches on rung 5 (r5 opus medium), in a new session.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93.

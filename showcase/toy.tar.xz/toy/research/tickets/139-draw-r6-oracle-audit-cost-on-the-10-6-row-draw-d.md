---
id: 139
title: "Draw R6: Oracle audit cost on the 10^6-row draw D2"
kind: drawing
difficulty: 2
status: parked
blocked_by: []
touches: [drawings/R6-1/]
resources: {gpu: 0, cpu: 1}
role: plotter
skills: []
acceptance: {}
objectives: [O3]
context_pack: []
origin: drawing R6-1 at run_end
proposed_by: conductor
demo: R6 explored in every useful plot, each explained, with a synthesis after them
---

## Drawing R6-1

Code opened this drawing of R6 ("Oracle audit cost on the 10^6-row draw D2") at a rest point (run_end), over its findings t53-a1-f1. Its brief, rendered by code at each launch, is in the prompt.

## Result

### Attempt 1

I fixed the numbers failures. Each finding sentence now carries a res tag for every number it quotes. I dropped the seed claim because its truth depends on which version of the file counts. The drawing check fails for a reason I can't fix inside drawings/R6-1/. The manifest registers tests/test_oracle_budget.py at sha256 dea33416…, which is git commit 017f053 (the seed-10001 version from run t53-a1). The file in the project is the later commit 607722b (seed 20001, sha256 a6204639…), and no manifest entry holds that hash. My script must read the project's file, so its provenance can never match while the manifest is stale. I changed draw.py to parse both versions of the file; the limits it reads (3600 s, 4.0 GB, 8 GB, 120 min) are the same in both. Once the file is registered again, the drawing should pass unchanged. The drawing is one table, budget.csv, and no plots, because the artifact holds limits only and no measured usage.

Wrote: `drawings/R6-1/draw.py`, `drawings/R6-1/numbers.json`, `drawings/R6-1/budget.csv`, `drawings/R6-1/drawing.json`

Ran: `wayline tools run matplotlib -- drawings/R6-1/draw.py`, `sha256sum tests/test_oracle_budget.py`, `git log -- tests/test_oracle_budget.py`, `git show 017f053:tests/test_oracle_budget.py | sha256sum`, `wayline accept`, `git commit`

Passages:

- methods, Oracle and Bayes ceiling: The drawing script for R6 reads tests/test_oracle_budget.py as text and does not import or run it. It parses the constants ROWS, TIME_LIMIT_SECONDS and MEMORY_LIMIT_GB, and from the test's own text it takes the E1 job allowances (wall-clock minutes and GB of RAM). It reports each limit as a share of its allowance, with time compared in seconds. `res:drawings/R6-1/numbers.json#time_limit_share_of_job`

Proposed Save the oracle budget test's measured seconds and peak memory as an artifact (code) (admission decides what joins the graph).

Asked tests/test_oracle_budget.py changed after run t53-a1 (commit 607722b moved it to seed 20001), but the manifest still holds the old hash. Should the current file be registered again, or should drawing R6 be pinned to the t53-a1 version?.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 153, 154, 155, 156.

---
id: 97
title: "toy.goallog: held-out reads of the goal loop from results/E5/changes.jsonl"
kind: code
difficulty: 2
status: accepted
blocked_by: []
touches: [src/toy/goallog.py, tests/test_goallog.py, tests/fixtures/goallog/]
role: coder
skills: []
outputs: [src/toy/goallog.py, tests/test_goallog.py, tests/fixtures/goallog/changes.jsonl]
acceptance:
  machine: [PYTHONPATH=src python3 -B -m unittest tests.test_goallog, "PYTHONPATH=src python3 -B -m toy.goallog tests/fixtures/goallog/changes.jsonl | python3 -c \"import json, sys; d = json.load(sys.stdin); assert {'heldout_reads', 'heldout_scorings', 'candidates', 'kept', 'discarded'} <= set(d) and d['heldout_reads'] == 3 and d['heldout_scorings'] == 9\"", "PYTHONPATH=src python3 -B -c \"from toy.goallog import read_log; d = read_log('tests/fixtures/goallog/changes.jsonl'); assert d['heldout_reads'] == 3 and len(d['candidates']) == 3\""]
  quality: []
objectives: [O2]
sections: [methods]
context_pack: [research/SPEC.md#e5-claims-c7, research/SPEC.md#seams]
origin: research/SPEC.md#seams
proposed_by: planner
demo: "`PYTHONPATH=src python3 -m toy.goallog tests/fixtures/goallog/changes.jsonl` prints heldout_reads and the per-candidate table."
---

## Demo

`PYTHONPATH=src python3 -m toy.goallog tests/fixtures/goallog/changes.jsonl` prints heldout_reads and the per-candidate table.

## Notes

Re-cut of #78, which never launched; nothing in its design failed. Write only src/toy/goallog.py, tests/test_goallog.py and tests/fixtures/goallog/. `toy.goallog <changes.jsonl>` reads E5's log, and read_log(path) returns the dict it prints, for the E5 analysis. Each line is one held-out scoring of one seed of one candidate, with these fields: candidate (a name; 'start' for the unchanged default run), seed, val_auroc (null for the start), auroc, kept (true, false, or null until keep-if-better judges it), and an optional note. Print JSON with these keys. heldout_reads is the number of distinct candidates scored on the held-out fifth: the start plus each candidate (the spec allows at most six). heldout_scorings is the number of lines (decision #28 scores each candidate at seeds 1, 2 and 3). candidates holds one row per candidate: its seeds, their aurocs, their mean, val_auroc and kept. kept and discarded are the counts. A malformed line is refused with its line number and exit 1. Fixture: tests/fixtures/goallog/changes.jsonl, holding the start and two candidates, each at seeds 1, 2 and 3: nine lines, so heldout_reads is 3 and heldout_scorings is 9. Stdlib only. Bash: this role runs a command only when every part of it begins with a program on its allow list: python3, git add, git commit, git status, git diff, git log, ls, cat and wayline accept. These are refused: a `PYTHONPATH=src` prefix, mkdir, bash, a heredoc or a `>` redirect into a file, and the venv's python called by its path. Those refusals blocked tickets 16, 76 and 83. So write every file with the Write tool, and run one plain command per Bash call. Let `wayline accept` run the tests and the criteria. For a check of your own, run `python3 -B -c "import sys; sys.path.insert(0, 'src'); ..."`. Retry a refused command in an allowed form, and return blocked only when that form is refused too. The harness checks the Result against these rules (tickets 41, 52, 53, 58 and 65 failed on them). Return one Methods passage. End every sentence of it with a provenance tag that resolves, such as {code:src/toy/goallog.py#read_log}, and leave out any sentence you cannot tag. A finding that states a number cites a locator holding that literal number. A passage that says what a current one says names it in `replaces`. Leave a passage's evidence unset.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Result

### Attempt 1

Added toy.goallog (src/toy/goallog.py): read_log(path) parses E5's results/E5/changes.jsonl, one line per held-out scoring of one seed of one candidate ({candidate, seed, val_auroc, auroc, kept, note?}), and returns heldout_reads (distinct candidates, the start included), heldout_scorings (lines), candidates (one row per candidate in log order: seeds ascending, their aurocs, mean_auroc, val_auroc as the mean of its seeds', kept) and the kept/discarded counts (the start, kept null, is neither). The CLI prints that dict as JSON and exits 1 with the line number on a malformed line: not JSON, not an object, a missing field, a bad type or range, a non-null val_auroc on the start, a null val_auroc on any other candidate, a seed scored twice, or a candidate's lines disagreeing on kept. Fixture tests/fixtures/goallog/changes.jsonl holds the start and two candidates (l2_1e-3, which is kept, and epochs_60, which is discarded) at seeds 1-3, so heldout_reads is 3 and heldout_scorings is 9. tests/test_goallog.py has 15 tests: the hand-worked fixture answers and the refusals. All three acceptance commands pass under `wayline accept`. Committed as ec7e5e7 on ticket/97.

Wrote: `src/toy/goallog.py`, `tests/test_goallog.py`, `tests/fixtures/goallog/changes.jsonl`

Ran: `python3 -B -m unittest tests.test_goallog (failed: no PYTHONPATH, toy not importable; re-run via sys.path below)`, `wayline accept`, `python3 -B -c "import sys; sys.path.insert(0, 'src'); ... unittest tests.test_goallog; goallog.main(['tests/fixtures/goallog/changes.jsonl'])"`, `git add src/toy/goallog.py tests/test_goallog.py tests/fixtures/goallog/changes.jsonl`, `git commit`

Passages:

- methods, Goal loop and held-out reads: E5's log holds one line per held-out scoring of one seed of one candidate, giving the candidate's name (`start` for the unchanged default run), the seed, the validation AUROC the candidate was chosen by (null for the start and required for every other candidate), its held-out AUROC, and whether keep-if-better kept it {code:src/toy/goallog.py#parse_line}. toy.goallog counts heldout_reads as the number of distinct candidates scored on the held-out fifth, the start included, and heldout_scorings as the number of logged scorings {code:src/toy/goallog.py#summarise}. For each candidate it reports its seeds, their held-out AUROCs and their mean, the mean of its seeds' validation AUROCs, and its keep decision, and it counts the kept and discarded candidates {code:src/toy/goallog.py#summarise}. It refuses the log when a line is malformed, when a candidate scores the same seed twice, or when a candidate's lines disagree on the keep decision, and it names the offending line {code:src/toy/goallog.py#read_log}.

Not methods:

- `src/toy/goallog.py#main`: Command-line wrapper that prints read_log's dict as JSON and maps a refusal to exit code 1.
- `src/toy/goallog.py#_is_number`: Type guard used in validating input lines; it computes nothing.
- `src/toy/goallog.py#_is_auroc`: Range guard (a finite number in [0, 1]) used in validating input lines.
- `src/toy/goallog.py#_mean`: Arithmetic mean helper used by summarise.

Proposed docs: document toy.goallog's log format and output (docs) (admission decides what joins the graph).

**Verdict (result): passed** by claude-opus-5-5, session `deb3342e-d084-4e93-a345-d59fd050e8cf`.

- [minor] The Methods passage says each line records 'whether keep-if-better kept it' and that toy.goallog 'counts the kept and discarded candidates'. It leaves out two facts: kept may be null (the start, or a candidate not yet judged; accepted at src/toy/goallog.py:69), and a null-kept candidate counts as neither kept nor discarded (lines 104-105). So kept + discarded falls short of heldout_reads (1 + 1 against 3 on the fixture) and Methods never says why. The Result's own prose at line 39 says it ('the start, kept null, is neither'), but the passage does not. (research/tickets/97-toy-goallog-held-out-reads-of-the-goal-loop-from.md:47 (## Result > ### Attempt 1 > Passages, sentences 1 and 3))
- [minor] I could not re-run the tests or the three acceptance commands: this verifier session refused every python3 invocation. The claims of 15 tests and of all three acceptance commands passing therefore rest on two things. One is the harness's record at research/sessions/97/1/acceptance.json (three exit codes of 0, 'Ran 15 tests ... OK', pass true). The other is my hand-trace of the fixture through summarise and each test: 3 reads, 9 scorings, kept 1, discarded 1, held-out means 0.80/0.82/0.80, val_auroc None/0.83/0.81. Every number matches what the tests assert. (research/tickets/97-toy-goallog-held-out-reads-of-the-goal-loop-from.md:39 (## Result > ### Attempt 1, 'All three acceptance commands pass under `wayline accept`'))

---
id: 88
title: "E2 analysis: paired AUROC gain of the x3*x4 column over 20 seeds (C3, C2 bound)"
kind: analysis
difficulty: 4
status: parked
blocked_by: [16, 65, 76, 85]
touches: [analysis/E2/paired.json, analysis/E2/verdict.py, analysis/E2/verdict.json]
role: analyst
skills: []
resources: {cpu: 1, gpu: 0, ram_gb: 4, wallclock_minutes: 30}
inputs: [results/runs/E2/m1_n0/, analysis/E1/summary.json, analysis/E2/checks.json]
outputs: [analysis/E2/paired.json, analysis/E2/verdict.json]
acceptance:
  machine: ["python3 -c \"import json; p = json.load(open('analysis/E2/paired.json')); v = json.load(open('analysis/E2/verdict.json')); assert p['n_pairs'] >= 20 and {'paired_gain', 'paired_gain_lo', 'paired_gain_hi', 'signed_rank_p', 'delong_rejections', 'gap_closed', 'mean_auroc_with', 'mean_auroc_without', 'mean_bayes_auroc'} <= set(p) and v['c3_supported'] == (p['paired_gain_lo'] > 0 and p['signed_rank_p'] < 0.05) and v['c2_bound_supported'] == (p['mean_bayes_auroc'] >= p['mean_auroc_with'] - 0.002 and p['mean_bayes_auroc'] >= p['mean_auroc_without'] - 0.002) and {'c2_supported', 'sd_d', 'q15_revisit'} <= set(v)\""]
  quality: ["Does every finding's number match the cited field of analysis/E2/paired.json or verdict.json, does C3's verdict follow paired_gain_lo > 0 and signed_rank_p < 0.05, and is 'by how much' stated as the interval and the gap share, never beyond them?"]
objectives: [O1, O3]
sections: [methods, results]
context_pack: [research/SPEC.md#e2-claims-c2-c3, research/SPEC.md#claims, research/SPEC.md#anti-claims, research/SPEC.md#methods]
origin: research/SPEC.md#e2-claims-c2-c3
proposed_by: planner
demo: analysis/E2/paired.json and the findings give the mean paired AUROC gain of the x3*x4 column over 20 seeds with its 95% CI, the signed-rank p, the DeLong rejection count, gap_closed with its CI, each arm's and the oracle's mean AUROC, and C3's and C2's verdicts.
---

## Demo

analysis/E2/paired.json and the findings give the mean paired AUROC gain of the x3*x4 column over 20 seeds with its 95% CI, the signed-rank p, the DeLong rejection count, gap_closed with its CI, each arm's and the oracle's mean AUROC, and C3's and C2's verdicts.

## Notes

Re-cut of ticket 68, which never launched. Run `PYTHONPATH=src python3 -B -m toy.paired "$WAYLINE_PROJECT/results/runs/E2/m1_n0" --out analysis/E2/paired.json`. Then write analysis/E2/verdict.py and the analysis/E2/verdict.json it writes, with these keys. c3_supported = paired_gain_lo > 0 and signed_rank_p < 0.05; when false, A2 applies: report the CI's bounds, not a gain. c2_bound_supported = mean_bayes_auroc >= mean_auroc_with - 0.002 and mean_bayes_auroc >= mean_auroc_without - 0.002. c2_supported = c2_bound_supported and analysis/E1/summary.json's c2_ceiling_supported. sd_d. q15_revisit = sd_d > 0.02. And the thresholds (0.002, 0.02, 0.005, 0.05, 0.82), each under its own key, so findings can cite them. Give 'by how much' in AUROC points with the CI, and as gap_closed with its bootstrap CI (null when the denominator is <= 0.005). If q15_revisit holds, mark C3's verdict provisional and propose an experiment adding seeds 21-50 at this point, decided on the interval's width alone (Q15). Report every seed. Record mean_auroc_with beside 0.82 for A7. The gate (#65, analysis/E2/checks.json) has passed before this runs; do not write its files. A negative or null result is a finding too. Result rules the harness checks (tickets 41, 52, 58 and 65 failed on them): return one Methods passage and one Results passage; end every sentence of each with a provenance tag that resolves, and leave out any sentence you cannot tag. Every number in a finding sits literally at a key of analysis/E2/paired.json or verdict.json that the finding cites (path#key), written as stored, with no percentage, rounding or derived count the cited keys do not hold; put any number you want to state into verdict.json first. Ticket 65 cited a raw run summary for numbers it did not hold. A finding that says what a current one says names it in `replaces`. Leave a passage's evidence unset unless it replaces an inherited claim. results/ is git-ignored and not in the worktree: read it under $WAYLINE_PROJECT and commit only your analysis/E2/ files. If a Bash command you need is refused, stop and return blocked naming it.

## Superseded

Re-cut by the planner after a stall; its replacements are tickets 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113.

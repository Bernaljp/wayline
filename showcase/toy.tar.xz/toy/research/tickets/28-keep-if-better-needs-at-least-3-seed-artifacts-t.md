---
id: 28
title: Keep-if-better needs at least 3 seed artifacts to judge a goal ticket....
kind: decision
difficulty: 1
status: done
blocked_by: []
blocking: subgraph
human_only: false
touches: []
role: decider
skills: []
acceptance: {}
context_pack: [research/SPEC.md]
origin: "plan 2421e19b5b96: research/SPEC.md#e5-claims-c7"
proposed_by: planner
demo: "The owner or the decider answers: Keep-if-better needs at least 3 seed artifacts to judge a goal ticket. O2's measure sets no min_seeds and harness.json sets no policy.goal.min_seeds, so the harness default of 3 applies. But SPEC E5 and Q15 make the goal the single run its command measures. How does the E5 starting run (T16) give keep-if-better its seeds?"
---

## Decision

Keep-if-better needs at least 3 seed artifacts to judge a goal ticket. O2's measure sets no min_seeds and harness.json sets no policy.goal.min_seeds, so the harness default of 3 applies. But SPEC E5 and Q15 make the goal the single run its command measures. How does the E5 starting run (T16) give keep-if-better its seeds?

- options:
  - three seeds: the default train.py run at seeds 1, 2 and 3, each summary a seed artifact. Keep-if-better keeps on their mean, and the harness reads the goal as reached on that mean. The report gives seed 1 (B3's seed, D5) as the goal run, with the other two and the mean beside it. O2's measure stays as recorded
  - one seed: the owner sets min_seeds to 1 in O2's measure, a change to a goal's measure and so the owner's. The ticket names only seed 1's summary
  - one seed: the owner sets policy.goal.min_seeds to 1 in harness.json. The ticket names only seed 1's summary
- recommended: three seeds: the default train.py run at seeds 1, 2 and 3, each summary a seed artifact. Keep-if-better keeps on their mean, and the harness reads the goal as reached on that mean. The report gives seed 1 (B3's seed, D5) as the goal run, with the other two and the mean beside it. O2's measure stays as recorded
- evidence:
  - harness wayline/goal.py: DEFAULT_MIN_SEEDS = 3, and judge() returns `short` and fails the ticket when fewer seeds are read
  - research/objectives.json: O2's measure has min_seeds null; harness.json: policy is {}
  - research/SPEC.md#e5-claims-c7 and Methods, Goal keep rule: the goal 'stays the single run its command measures; it is never redefined as a mean over seeds (Q15)'
  - owner/sample-summary.json: the seed-1 with-term run reads auroc 0.8503, above the 0.82 target
  - options two and three change a goal's measure or the owner's settings, so they belong to the owner (human-only objective class); the recommended option changes neither
- blocking: `subgraph`, so ticket 17 and whatever waits on it wait for the answer
- human-only: no, so under autonomy `autonomous` the decider may answer it
- asked by: plan 2421e19b5b96: research/SPEC.md#e5-claims-c7

<!-- wayline:decision {"ticket":28,"question":"Keep-if-better needs at least 3 seed artifacts to judge a goal ticket. O2's measure sets no min_seeds and harness.json sets no policy.goal.min_seeds, so the harness default of 3 applies. But SPEC E5 and Q15 make the goal the single run its command measures. How does the E5 starting run (T16) give keep-if-better its seeds?","options":["three seeds: the default train.py run at seeds 1, 2 and 3, each summary a seed artifact. Keep-if-better keeps on their mean, and the harness reads the goal as reached on that mean. The report gives seed 1 (B3's seed, D5) as the goal run, with the other two and the mean beside it. O2's measure stays as recorded","one seed: the owner sets min_seeds to 1 in O2's measure, a change to a goal's measure and so the owner's. The ticket names only seed 1's summary","one seed: the owner sets policy.goal.min_seeds to 1 in harness.json. The ticket names only seed 1's summary"],"recommended":"three seeds: the default train.py run at seeds 1, 2 and 3, each summary a seed artifact. Keep-if-better keeps on their mean, and the harness reads the goal as reached on that mean. The report gives seed 1 (B3's seed, D5) as the goal run, with the other two and the mean beside it. O2's measure stays as recorded","evidence":["harness wayline/goal.py: DEFAULT_MIN_SEEDS = 3, and judge() returns `short` and fails the ticket when fewer seeds are read","research/objectives.json: O2's measure has min_seeds null; harness.json: policy is {}","research/SPEC.md#e5-claims-c7 and Methods, Goal keep rule: the goal 'stays the single run its command measures; it is never redefined as a mean over seeds (Q15)'","owner/sample-summary.json: the seed-1 with-term run reads auroc 0.8503, above the 0.82 target","options two and three change a goal's measure or the owner's settings, so they belong to the owner (human-only objective class); the recommended option changes neither"],"human_only":false,"reversible":true,"answer":null,"rationale":null,"confidence":null,"decided_by":null,"timestamp":null,"blocking":"subgraph"} -->

## How to answer

`wayline answer 28 "<answer>"`, from the command line or from a session; the answer form in the dashboard's decisions view; or the answer written under an `## Answer` heading at the end of this file. Each is journaled as the owner's decision, and the conductor closes this ticket at its next wave.

## Result

- the decider could not answer it: the decider on decision ticket 28 could not decide: the result carries no structured_output (subtype success); the worker stopped without returning it

## Answer

three seeds: the default train.py run at seeds 1, 2 and 3, each summary a seed artifact. Keep-if-better keeps on their mean, and the harness reads the goal as reached on that mean. The report gives seed 1 (B3's seed, D5) as the goal run, with the other two and the mean beside it. O2's measure stays as recorded

---
id: 100
title: "Literature: Bayes-optimal AUROC of a known generator and the precision of an AUROC estimate (O3)"
kind: lit
difficulty: 2
status: done
blocked_by: []
touches: []
role: surveyor
skills: []
acceptance:
  machine: []
  quality: []
objectives: [O3]
sections: [introduction]
context_pack: [research/sections/introduction.md, research/CONCERNS.md, research/SPEC.md#e1-claims-c1-c2, research/SPEC.md#methods, research/POSITION.md#what-the-references-lack]
origin: research/SPEC.md#e1-claims-c1-c2
proposed_by: planner
demo: "The Introduction holds passages tagged at resolved dossiers on three points: why ranking by the true P(y=1|x) gives the highest attainable ROC curve, how an AUROC's standard error is estimated, and why a gain is read as a share of the gap to that ceiling (K5)."
---

## Demo

The Introduction holds passages tagged at resolved dossiers on three points: why ranking by the true P(y=1|x) gives the highest attainable ROC curve, how an AUROC's standard error is estimated, and why a gain is read as a share of the gap to that ceiling (K5).

## Notes

Re-cut of #81, which never launched; nothing in its design failed. Search with `wayline scout search` for four things. (1) Why ranking by the true class probability, or the likelihood ratio, gives the best ROC curve (Neyman-Pearson), so the Bayes classifier's AUROC is the ceiling no model beats in expectation. (2) The variance of an AUROC estimate: Hanley & McNeil 1982; DeLong et al. 1988, already verified as delong-1988-comparing-areas-under-two-more; and Sun & Xu 2014, verified as sun-2014-fast-implementation-delong-s-algorithm. (3) The logistic-normal integral that the generator's latent noise creates (finding t6-a1-f1: P(y=1|x) = E[sigmoid(mu(x) + e)]), for example the probit approximation, or Gauss-Hermite quadrature, which toy.oracle uses. (4) Simulation studies that report a learned model's AUROC against the ceiling of a known generator. Check each work you cite with `wayline scout`. Every sentence of a passage ends with a {ref:<slug>#...} tag at a dossier the scout verified; leave out any sentence you cannot tag. A passage that says what a current one says names it in `replaces`. Rest nothing on paper-a or paper-b. Your Bash runs only `wayline scout ...`, `wayline consult ...` and `wayline accept`: run one scout command per call, with nothing piped or chained.

## Result

### Attempt 1

Scouted four works on the Bayes-optimal scorer for ranking, the AUROC standard error, and reading gains against the optimum. I rewrote the two Introduction passages so every sentence ends in a provenance tag. The abstracts do not state the ROC dominance theorem itself, so a dossier read is proposed for it.

Passages:

- introduction, The Bayes-optimal ceiling for AUROC: Work on bipartite ranking asks which scorer is Bayes-optimal for a ranking risk, and shows that the answer is non-trivial in general but easily determined in special cases through the theory of proper losses; it ties minimising a suitable class-probability estimation risk to minimising bipartite ranking risks {ref:menon-2014-bayes-optimal-scorers-bipartite-ranking#abstract}. The ranking problem has also been put in a statistical framework in which the natural risk estimates are U-statistics {ref:cl-men-on-2008-ranking-empirical-minimization-u-statistics#abstract}. For a task where soft labels (true class probabilities) and the class prior are known, soft-label-based estimators of the optimal AUC have been proposed, so that the irreducible part of the error can be told from a model's deficiency and the room left for improvement read off {ref:ushio-2026-bayes-optimal-ber-auc-estimation#abstract}.
- introduction, Precision of an AUROC estimate: The area under an ROC curve is the probability that a randomly chosen diseased subject is ranked above a randomly chosen non-diseased one, and equals the Wilcoxon statistic; this gives closed-form approximate standard errors, guidance on the sample size needed for a reliable area, and on the size needed to detect differences between techniques {ref:hanley-1982-meaning-use-area-under-receiver#abstract}. For AUROCs computed on the same individuals, a generalized U-statistics approach gives a covariance matrix that accounts for the correlation {ref:delong-1988-comparing-areas-under-two-more#abstract}.

Proposed Read Menon & Williamson (2014) in full for the ROC-dominance statement (dossier), Literature on uncertainty of a ratio of AUROC differences (gap closed) (lit) (admission decides what joins the graph).

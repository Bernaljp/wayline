---
id: 164
title: Tell the analyst every number a finding states sits at a key it cites
kind: harness
difficulty: 2
status: open
blocked_by: []
touches: [.claude/agents/analyst.md, fixtures/role/analyst-cites-every-number/]
role: coder
skills: []
acceptance:
  machine: ["python3 -B -c \"import pathlib; t = pathlib.Path('.claude/agents/analyst.md').read_text(encoding='utf-8'); assert 'name: analyst' in t and 'under its own key' in t and 'replaces' in t and 'manifest' in t\"", test -f fixtures/role/analyst-cites-every-number/fixture.json]
  quality: []
context_pack: [research/changes/007-tell-the-analyst-every-number-a-finding-states.json, research/feedback/retro-20261025T065614444Z.md]
proposed_by: evolve
demo: "`.claude/agents/analyst.md` holds the harness's analyst words (roles/analyst/agent.md, with its frontmatter `name: analyst`) plus a section, \"Every number a finding states\"."
origin: change 007-tell-the-analyst-every-number-a-finding-states
---

## Demo

`.claude/agents/analyst.md` holds the harness's analyst words (roles/analyst/agent.md, with its frontmatter `name: analyst`) plus a section, "Every number a finding states". It says:

1. Every number a finding's text states sits unaltered at the key its provenance names, or at a `{res:<run-id>/<path>#<key>}` tag ending that sentence. That includes counts (six reruns, 3 of the 6), thresholds and limits (0.05, 0.01, 0.002), confidence levels, seed ranges, and settings.
2. A number no key holds is first written by your analysis script under its own key: a threshold under its own key, never only inside a rule string. The finding then cites that key. A count you worked out by hand is not stored, so it is not stated.
3. Write numbers as the file stores them: no rounding and no percentages.
4. A finding that corrects one already filed names it in `replaces`. When the ticket gives a number of findings, file that many.
5. Before you return, reread each finding against the keys it cites, and cut or re-cite any number they do not hold.

The rest of the role is unchanged.

## Change record

`research/changes/007-tell-the-analyst-every-number-a-finding-states.json` is the record this ticket makes real, in the project, in your worktree.

- observed: The analyst's words say a finding's provenance is "where in the file the number sits", in the singular (roles/analyst/agent.md:13-18). Its protocol says only "Keep every number traceable to a manifested file" (prompts/roles/analyst.md:7). Nothing says that every number a finding states, thresholds and counts included, must sit at a key the finding cites. The quality verdicts of three analysis tickets failed on exactly that: - 65: findings cited raw run summaries, and stated limits 0.002 and 0.01, "six reruns" and a derived "Three of the six" at no cited key (L927). - 108: findings stated the slack 0.002, the level 0.05, the count 20 and seeds 21-50 while citing only verdict keys that hold booleans; the thresholds appeared only inside rule strings (L2664). - 109: the same with 0.9, 0.05, 0.005, 0.01 and 0.02 (L3177). The planner had asked for this in 108's and 109's Notes, which never reached the workers (see the Notes record). The role itself carries no such rule, so tickets without those Notes meet it too. The analyst role has 16 assignments, 2 first-time passes and 12 failures.
  - evidence: research/journal.jsonl#L927
  - evidence: research/journal.jsonl#L2664
  - evidence: research/journal.jsonl#L3177
- desired: `.claude/agents/analyst.md` holds the harness's analyst words (roles/analyst/agent.md, with its frontmatter `name: analyst`) plus a section, "Every number a finding states". It says: 1. Every number a finding's text states sits unaltered at the key its provenance names, or at a `{res:<run-id>/<path>#<key>}` tag ending that sentence. That includes counts (six reruns, 3 of the 6), thresholds and limits (0.05, 0.01, 0.002), confidence levels, seed ranges, and settings. 2. A number no key holds is first written by your analysis script under its own key: a threshold under its own key, never only inside a rule string. The finding then cites that key. A count you worked out by hand is not stored, so it is not stated. 3. Write numbers as the file stores them: no rounding and no percentages. 4. A finding that corrects one already filed names it in `replaces`. When the ticket gives a number of findings, file that many. 5. Before you return, reread each finding against the keys it cites, and cut or re-cite any number they do not hold. The rest of the role is unchanged.
- mechanism: `role`, local, risk low
- target: `.claude/agents/analyst.md`
- notes: The override replaces the harness role's words, so start from the full text of roles/analyst/agent.md and add the section. Record the fixture from session 6a2b65ff-053e-4ea7-ba42-06807a40b09a: ticket 108, attempt 1, files in research/sessions/108/1, journaled at L2443. Its prompt carries no Notes, so the role is the only thing that differs between the old run and the new one. Pin the harness's analyst as the old subject. Structural `python` check, run with cwd=root: for each finding in the output, every number wayline.numbers.numbers_in finds in its text matches wayline.numbers.values_at at the finding's provenance keys or at a tag in the same sentence, read from the analysis/E2/verdict.json that the run wrote. On the recorded output it fails on t108-a1-f10, f11 and f14: 0.05, 0.002, 20 and 21-50 are at no cited key. Rubric line: "Does every number in each finding, thresholds and counts included, sit at a key the finding cites?" Ticket 65's worker session a6d0d390-6729-455e-b763-8f00e5bd8a8d (research/sessions/65/1, L817) is a second sample.

## The fixture

The change ships with the fixture `role/analyst-cites-every-number`, under `fixtures/role/analyst-cites-every-number/`. It encodes the desired behaviour: record it from the journaled session that showed the observed one (`wayline fixture record --session <id> --kind role --slug analyst-cites-every-number --root . --no-baseline`), then prune its structural checks and write the checks or the rubric that say what must now hold. Before this ticket is integrated the conductor runs it twice: it passes on your change, and it fails on the subject as it is today. A fixture that passes on both proves nothing, and the ticket fails on it.

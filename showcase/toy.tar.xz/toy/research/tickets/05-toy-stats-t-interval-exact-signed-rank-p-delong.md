---
id: 5
title: "toy.stats: t-interval, exact signed-rank p, DeLong covariance, Spearman and paired bootstrap"
kind: code
difficulty: 3
status: accepted
blocked_by: []
touches: [src/toy/stats.py, tests/test_stats.py, tests/test_stats_scipy.py]
role: coder
skills: []
acceptance:
  machine: [PYTHONPATH=src python3 -B -m unittest tests.test_stats, PYTHONPATH=src /home/bernaljp/.wayline/tools/venv/bin/python -B -m unittest tests.test_stats_scipy]
  quality: ["Do the t-interval, the exact signed-rank p (zeros dropped, ties given average ranks), DeLong's covariance of correlated AUROCs and the paired bootstrap follow their textbook definitions, as the hand-worked and scipy cross-check tests show?"]
objectives: [O1, O3, O4]
sections: [methods]
context_pack: [src/toy/metrics.py, research/SPEC.md#methods, research/SPEC.md#metrics]
origin: research/SPEC.md#methods
proposed_by: planner
demo: The unit tests print OK for hand-worked t-intervals, exact signed-rank p-values, DeLong covariances, Spearman and the paired bootstrap, and agree with scipy in the tools venv.
---

## Demo

The unit tests print OK for hand-worked t-intervals, exact signed-rank p-values, DeLong covariances, Spearman and the paired bootstrap, and agree with scipy in the tools venv.

## Notes

src/toy/stats.py, stdlib only (the package keeps everything but train.py importable by plain python3): t_quantile(p, df) and t_interval(values, level=0.95) -> (mean, lo, hi); signed_rank_p(diffs), the exact two-sided Wilcoxon signed-rank p, dropping zero differences (Wilcoxon's rule), giving tied |d| average ranks and enumerating the exact null distribution over the observed ranks; delong(labels, score_lists) -> AUROCs and their covariance matrix (DeLong, DeLong & Clarke-Pearson 1988 structural components), delong_halfwidth(labels, scores, level=0.95), delong_test(labels, a, b) -> (z, two-sided p) for two correlated AUROCs on the same rows; spearman(x, y) with average ranks; bootstrap_ratio_ci(numerators, denominators, n=10000, level=0.95, seed=0), the paired percentile bootstrap over replicates of mean(num)/mean(den). Use toy.metrics.auroc for AUROC. tests/test_stats.py: hand-worked cases, e.g. t_quantile(0.975, 19) = 2.093024 to 1e-5, signed_rank_p of 5 positive differences = 0.0625 and of 20 = 2/2**20, a 3-positive/3-negative DeLong case worked by hand in a comment. tests/test_stats_scipy.py runs under /home/bernaljp/.wayline/tools/venv/bin/python (scipy 1.18) and cross-checks t quantiles, scipy.stats.wilcoxon(method='exact') on tie-free differences, and spearmanr. All must run on 10^6 rows in seconds (sort-based DeLong). Run Python with -B; do not create tests/__init__.py.

## Public API

This ticket adds public API, so a `docs` ticket follows it.

## Result

Escalated one rung up: the next attempt launches on rung 6 (r6 opus high), in a new session.

### Attempt 3

Added src/toy/stats.py, a module that uses only the Python standard library. It provides t_cdf, t_quantile and t_interval; signed_rank_exact_p (exact two-sided Wilcoxon p; zeros are dropped and ties are enumerated exactly with average ranks); delong_covariance and delong_test (placement values from midranks in O(N log N)); spearman; and paired_bootstrap with ratio_of_means (a seeded percentile bootstrap that resamples whole replicates). tests/test_stats.py has 20 hand-worked tests run under python3. tests/test_stats_scipy.py has 7 tests run against scipy in the tools venv. `wayline accept` passes both commands (20 OK, 7 OK). This resubmission changes no code. The failed finding claimed one shared tolerance and a scipy version that its cited test does not show. It is split into one finding per test, each giving the tolerance that test actually checks. Code is in commits eb2b968 and 9061f9b on ticket/5.

Wrote: `src/toy/stats.py`, `tests/test_stats.py`, `tests/test_stats_scipy.py`

Ran: `wayline accept`, `wayline scout 10.2307/2531595`, `wayline scout 10.1109/LSP.2014.2337313`, `git commit`

Passages:

- methods, Statistics: The paired statistics are computed with the Python standard library alone. The mean of the per-replicate differences $d_i$ has a two-sided 95% t-interval on $n-1$ degrees of freedom, with the t quantile found by bisection on Student's t CDF through the regularized incomplete beta function {code:src/toy/stats.py#t_interval}. The Wilcoxon signed-rank p is exact and two-sided, $p = \min(1, 2\min(P(R^+\le r^+), P(R^+\ge r^+)))$. Zero differences are dropped, absolute differences get average ranks, and the null distribution is enumerated over all $2^n$ sign assignments {code:src/toy/stats.py#signed_rank_exact_p}. The DeLong covariance of correlated AUROCs is $S_{10}/m + S_{01}/n$, built from the sample covariances of the positives' and negatives' placement values {ref:delong-1988-comparing-areas-under-two-more#abstract}. The placement values are computed from midranks in linearithmic time {ref:sun-2014-fast-implementation-delong-s-algorithm#abstract} {code:src/toy/stats.py#delong_covariance}. The DeLong test refers $z = (A-B)/\sqrt{\mathrm{var}A + \mathrm{var}B - 2\,\mathrm{cov}(A,B)}$ to the standard normal, two-sided {code:src/toy/stats.py#delong_test}. Spearman's correlation is Pearson's correlation of average ranks {code:src/toy/stats.py#spearman}. gap_closed is the ratio of means {code:src/toy/stats.py#ratio_of_means}, and its CI is a percentile bootstrap that resamples whole replicates with replacement, keeping each replicate's pair together, and interpolates linearly between order statistics {code:src/toy/stats.py#paired_bootstrap}.

Parameters:

- `t_interval` `confidence`: SPEC.md#methods asks for a 95% t-interval of the mean d_i.
- `paired_bootstrap` `resamples`: SPEC.md#methods fixes gap_closed's paired bootstrap at 10,000 resamples.
- `paired_bootstrap` `confidence`: The CI's level is 95%, the same as the t-interval in SPEC.md#methods.
- `paired_bootstrap` `seed`: The resampling draw is seeded (random.Random(0) by default) so that a rerun of toy.paired reproduces the same CI.

Not methods:

- `src/toy/stats.py#mean`: This is the arithmetic mean, a helper.
- `src/toy/stats.py#sd`: This is the sample standard deviation on n-1, a helper of t_interval.
- `src/toy/stats.py#t_cdf`: This is Student's t CDF, a numerical primitive behind t_interval; it is described through t_interval.
- `src/toy/stats.py#t_quantile`: This inverts t_cdf by bisection to get t_interval's critical value; it is described through t_interval.
- `src/toy/stats.py#_betainc`: This is the regularized incomplete beta function, the numerical primitive behind t_cdf.
- `src/toy/stats.py#_beta_continued_fraction`: This is the Lentz continued fraction inside _betainc.
- `src/toy/stats.py#_average_ranks`: This assigns tie-averaged ranks, which signed_rank_exact_p, spearman and the DeLong placements share.
- `src/toy/stats.py#_placements`: This computes DeLong placement values by midranks; it is described in the delong_covariance passage.
- `src/toy/stats.py#_covariance`: This is the sample covariance on n-1, a helper.
- `src/toy/stats.py#_quantile`: This is a linear-interpolation quantile of the sorted bootstrap draws; it is described in the paired_bootstrap passage.

**Verdict (diff): passed** by claude-opus-5-5, session `4e4182ff-208c-40bd-a1e1-ae7371ddd12c`.

- [minor] I could not execute either acceptance command or time delong_covariance at 10^6 rows: this session refused all Python. Instead I checked correctness by hand. I derived the identities: midrank among all cases minus midrank within the case's class equals #(other class below) plus half of #(other class equal), which gives V10 = (T_Z - T_X)/n and V01 = 1 - (T_Z - T_Y)/m. I checked the overall[i] / overall[m+j] indexing, and I worked tests/test_stats.py's DeLong cases through the new _placements: V10 = [1, 0.5] and [1, 0], V01 = [0.5, 1] and [0.5, 0.5], AUROC 0.8125 equal to toy.metrics.auroc. The Notes require 'All must run on 10^6 rows in seconds (sort-based DeLong)'. Only the O(N log N) shape of the code supports that (three _average_ranks sorts and linear passes); no test in the diff runs a large N. (research/tickets/05-toy-stats-t-interval-exact-signed-rank-p-delong.md ## Notes; src/toy/stats.py line 168 (_placements) at ca48d6a)
- [minor] The diff moves tie handling from the explicit 1/2 for x == y to midranks. Both hand-worked DeLong scorings (a and b) have no tied scores. Under plain python3, the only check on the tie path is test_aurocs_agree_with_metrics, which checks the AUROC (the mean of V10) but not V01 or the covariance. Tied V01 and covariance are checked only by tests/test_stats_scipy.py test_against_pairwise_kernel_and_mann_whitney, in the tools venv (rounded scores, atol 1e-12). That test is part of the machine acceptance, so this is a coverage gap, not a defect. (tests/test_stats.py line 55 (class DeLong) and line 68 (test_aurocs_agree_with_metrics))

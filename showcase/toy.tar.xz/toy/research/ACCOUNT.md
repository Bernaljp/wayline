Code writes this file from the journal and the ledger and never reads it back: the research is in [REPORT.md](REPORT.md), and anything you want to tell the project goes to the conversation.

## Where the project stands

The last run (run 4) ended 2026-10-25 15:21Z: the objectives the stopping rule waits on closed. Objectives: O1 answered, O2 answered, O3 answered, O4 answered, O5 parked. Stopping rule: objectives (the run ends when no objective is open). Budgets: wall clock 27.5 of 24 hours, spent; GPU 3.9 of 8 hours.

## Decided for you

- D18, 2026-10-24 12:01Z, ticket 28, *Keep-if-better needs at least 3 seed artifacts to judge a goal ticket....*: **three seeds: the default train.py run at seeds 1, 2 and 3, each summary a seed artifact. Keep-if-better keeps on their mean, and the harness reads the goal as reached on that mean. The report gives seed 1 (B3's seed, D5) as the goal run, with the other two and the mean beside it. O2's measure stays as recorded** (by the decider, confidence 0.8). Rationale: [tickets/28-keep-if-better-needs-at-least-3-seed-artifacts-t.md](tickets/28-keep-if-better-needs-at-least-3-seed-artifacts-t.md)
- D19, 2026-10-24 12:44Z, parked proposal 4754eafc8596: **keep parked** (by the decider, confidence 0.85). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 12:44Z
- D20, 2026-10-24 12:50Z, parked proposal ae4c3a23ad9d: **keep parked** (by the decider, confidence 0.7). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 12:50Z
- D22, 2026-10-24 13:42Z, ticket 51, *Confirm the graph*: **confirm** (by the decider, confidence 0.8). Rationale: [tickets/51-confirm-the-graph.md](tickets/51-confirm-the-graph.md)
- D23, 2026-10-24 14:15Z, parked proposal 0fbbee4006e7: **keep parked** (by the decider, confidence 0.9). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 14:15Z
- D24, 2026-10-24 15:22Z, ticket 74, *Confirm the graph*: **confirm** (by the decider, confidence 0.85). Rationale: [tickets/74-confirm-the-graph.md](tickets/74-confirm-the-graph.md)
- D25, 2026-10-24 15:25Z, parked proposal a9944944ae02: **keep parked** (by the decider, confidence 0.85). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 15:25Z
- D26, 2026-10-24 16:01Z, ticket 94, *Confirm the graph*: **confirm** (by the decider, confidence 0.85). Rationale: [tickets/94-confirm-the-graph.md](tickets/94-confirm-the-graph.md)
- D27, 2026-10-24 16:30Z, ticket 114, *Confirm the graph*: **confirm** (by the decider, confidence 0.85). Rationale: [tickets/114-confirm-the-graph.md](tickets/114-confirm-the-graph.md)
- D28, 2026-10-24 16:55Z, parked proposal 553ea22a5d61: **keep parked** (by the decider, confidence 0.9). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 16:55Z
- D29, 2026-10-24 17:00Z, parked proposal cfac9a08144f: **keep parked** (by the decider, confidence 0.9). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 17:00Z
- D30, 2026-10-24 17:03Z, parked proposal e313ae83b398: **keep parked** (by the decider, confidence 0.85). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 17:03Z
- D31, 2026-10-24 17:27Z, parked proposal 660e782d532d: **keep parked** (by the decider, confidence 0.8). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 17:27Z
- D32, 2026-10-24 18:02Z, parked proposal 11af1272cc9a: **keep parked** (by the decider, confidence 0.85). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 18:02Z
- D33, 2026-10-24 18:06Z, parked proposal 2f47ee740c53: **keep parked** (by the decider, confidence 0.85). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 18:06Z
- D34, 2026-10-24 18:09Z, parked proposal 889beed0dce4: **keep parked** (by the decider, confidence 0.9). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 18:09Z
- D35, 2026-10-24 18:31Z, parked proposal 23f895b940b6: **admit** (by the decider, confidence 0.7). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 18:31Z
- D36, 2026-10-24 18:33Z, parked proposal dbeebd25e875: **keep parked** (by the decider, confidence 0.9). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 18:33Z
- D37, 2026-10-24 19:01Z, parked proposal 5a18485a69a5: **keep parked** (by the decider, confidence 0.8). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 19:01Z
- D38, 2026-10-24 19:04Z, parked proposal 76545d72cf3d: **keep parked** (by the decider, confidence 0.75). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 19:04Z
- D39, 2026-10-24 19:15Z, parked proposal b819e8e400f7: **keep parked** (by the decider, confidence 0.93). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 19:15Z
- D40, 2026-10-24 19:26Z, parked proposal 768b88733155: **keep parked** (by the decider, confidence 0.93). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 19:26Z
- D41, 2026-10-24 19:42Z, parked proposal 55c68e773fdf: **keep parked** (by the decider, confidence 0.8). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 19:42Z
- D42, 2026-10-24 19:46Z, parked proposal a9a9acb1dee9: **keep parked** (by the decider, confidence 0.9). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 19:46Z
- D43, 2026-10-24 19:54Z, ticket 119, *Promote lou-2013-accurate-intelligible-models-pairwise-interactions to level 2?*: **yes: promote it to level 2 (a full read)** (by the decider, confidence 0.75). Rationale: [tickets/119-promote-lou-2013-accurate-intelligible-models-pa.md](tickets/119-promote-lou-2013-accurate-intelligible-models-pa.md)
- D44, 2026-10-24 20:34Z, parked proposal 282e6b64742c: **keep parked** (by the decider, confidence 0.85). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 20:34Z
- D45, 2026-10-24 20:39Z, parked proposal 741a44dbba62: **keep parked** (by the decider, confidence 0.87). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 20:39Z
- D46, 2026-10-24 20:45Z, parked proposal a3cb05e94b44: **keep parked** (by the decider, confidence 0.7). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 20:45Z
- D47, 2026-10-24 20:49Z, parked proposal a5474dcd4cfa: **keep parked** (by the decider, confidence 0.75). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 20:49Z
- D48, 2026-10-24 20:54Z, parked proposal 32e598d6ec4f: **keep parked** (by the decider, confidence 0.8). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 20:54Z
- D49, 2026-10-24 20:58Z, parked proposal 753459b9820e: **keep parked** (by the decider, confidence 0.85). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 20:58Z
- D50, 2026-10-24 21:36Z, parked proposal 1df593319dd8: **keep parked** (by the decider, confidence 0.9). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 21:36Z
- D51, 2026-10-24 22:33Z, parked proposal 6e156fdbbd9c: **keep parked** (by the decider, confidence 0.9). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 22:33Z
- D52, 2026-10-24 22:36Z, parked proposal 99ca7b84909d: **keep parked** (by the decider, confidence 0.8). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 22:36Z
- D53, 2026-10-24 23:36Z, parked proposal 1a40e2d12dbd: **admit** (by the decider, confidence 0.75). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-24 23:36Z
- D54, 2026-10-25 00:21Z, parked proposal db3af965d03b: **keep parked** (by the decider, confidence 0.8). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-25 00:21Z
- D55, 2026-10-25 00:35Z, parked proposal febdd88db342: **keep parked** (by the decider, confidence 0.95). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-25 00:35Z
- D56, 2026-10-25 01:05Z, parked proposal 32e9b6f9df54: **keep parked** (by the decider, confidence 0.95). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-25 01:05Z
- D57, 2026-10-25 02:08Z, parked proposal 9007e2d5aed3: **keep parked** (by the decider, confidence 0.75). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-25 02:08Z
- D58, 2026-10-25 02:34Z, ticket 125, *The frontier is empty with O1 open*: **replan for it** (by the decider, confidence 0.7). Rationale: [tickets/125-the-frontier-is-empty-with-o1-open.md](tickets/125-the-frontier-is-empty-with-o1-open.md)
- D59, 2026-10-25 02:34Z, ticket 126, *The frontier is empty with O3 open*: **answer it as it stands** (by the decider, confidence 0.7). Rationale: [tickets/126-the-frontier-is-empty-with-o3-open.md](tickets/126-the-frontier-is-empty-with-o3-open.md)
- D60, 2026-10-25 02:34Z, ticket 127, *The frontier is empty with O4 open*: **answer it as it stands** (by the decider, confidence 0.7). Rationale: [tickets/127-the-frontier-is-empty-with-o4-open.md](tickets/127-the-frontier-is-empty-with-o4-open.md)
- D61, 2026-10-25 02:52Z, ticket 132, *Confirm the graph*: **confirm** (by the decider, confidence 0.85). Rationale: [tickets/132-confirm-the-graph.md](tickets/132-confirm-the-graph.md)
- D62, 2026-10-25 03:15Z, parked proposal 26568bda158d: **keep parked** (by the decider, confidence 0.8). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-25 03:15Z
- D63, 2026-10-25 03:47Z, parked proposal 322d54f62d4e: **keep parked** (by the decider, confidence 0.8). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-25 03:47Z
- D64, 2026-10-25 03:52Z, parked proposal 53d5ec575f93: **keep parked** (by the decider, confidence 0.75). Rationale: [journal.jsonl](journal.jsonl), at 2026-10-25 03:52Z
- D65, 2026-10-25 03:58Z, ticket 133, *The frontier is empty with O1 open*: **answer it as it stands** (by the decider, confidence 0.8). Rationale: [tickets/133-the-frontier-is-empty-with-o1-open.md](tickets/133-the-frontier-is-empty-with-o1-open.md)

## Waiting on you

- Decision ticket 124 (human only): Is the parked proposal c3a0b19879a6, "E5: set the goal run's auroc beside E2's 20-seed mean inside E5's result (A7)", admitted to the run? Answer it in the dashboard's chat, or in any conversation with the project.
- Global change `001-hold-launches-on-a-401-login-failure-instead`, *Hold launches on a 401 login failure instead of failing the ticket* (`code` at `wayline/`, risk medium): proposed, not applied; `wayline evolve --apply 001-hold-launches-on-a-401-login-failure-instead` applies it.
- Global change `002-name-the-cli-s-api-error-in-a`, *Name the CLI's API error in a session's failure reason* (`code` at `wayline/worker.py`, risk low): proposed, not applied; `wayline evolve --apply 002-name-the-cli-s-api-error-in-a` applies it.
- Global change `003-carry-the-ticket-s-notes-into-the-worker`, *Carry the ticket's Notes into the worker prompt* (`code` at `wayline/`, risk medium): proposed, not applied; `wayline evolve --apply 003-carry-the-ticket-s-notes-into-the-worker` applies it.
- Global change `005-keep-the-manifest-current-when-an-integration-changes`, *Keep the manifest current when an integration changes a manifested file* (`code` at `wayline/`, risk medium): proposed, not applied; `wayline evolve --apply 005-keep-the-manifest-current-when-an-integration-changes` applies it.
- Global change `006-send-back-a-new-passage-the-confirmer-labels`, *Send back a new passage the confirmer labels contradicting* (`code` at `wayline/repeats.py`, risk medium): proposed, not applied; `wayline evolve --apply 006-send-back-a-new-passage-the-confirmer-labels` applies it.
- Global change `008-state-the-role-s-bash-allow-list-in`, *State the role's Bash allow list in the worker contract* (`code` at `wayline/worker.py`, risk low): proposed, not applied; `wayline evolve --apply 008-state-the-role-s-bash-allow-list-in` applies it.
- Global change `009-run-a-local-change-s-harness-ticket-before`, *Run a local change's harness ticket before the tickets of the role it rewrites, at a paper order and at a rest* (`code` at `wayline/conductor.py`, risk medium): proposed, not applied; `wayline evolve --apply 009-run-a-local-change-s-harness-ticket-before` applies it.
- Global change `010-strip-the-mixed-data-marker-from-a-caption`, *Strip the [[mixed-data]] marker from a caption copied into the paper* (`code` at `wayline/paper_figures.py`, risk low): proposed, not applied; `wayline evolve --apply 010-strip-the-mixed-data-marker-from-a-caption` applies it.
- The outline has 1 open proposal (merges of results to take or decline, inherited headings no objective checks, subsections to open as objectives): research/OUTLINE.md, under "Proposed, not settled".
- The paper (version 2, paper order 2) is not passed: build 1 left 24 point(s) standing (research/paper/PAPER.md). Choose three more builds, keep it as it is, or the points as objectives: say which in the dashboard's chat, or in any conversation with the project.

## Runs

### Run 4, the latest

Started 2026-10-25 14:03Z, ended 2026-10-25 15:21Z: the objectives the stopping rule waits on closed (`objectives_closed`); 0 wave(s). Wall clock 1.3 hours; GPU 0.00 hours. Peak utilization: fable 0, five_hour 0.27, seven_day 0.64.

No pause and no hold.

The documentation site, part of done because ticket(s) 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 30, 31, 32, 33, 34, 54, 55, 56, 57, 58, 75, 76, 77, 78, 79, 95, 96, 97, 98, 115 added public API:

- Ticket 27, *Documentation site for the toy package and its new modules and flags* (docs): parked
- Ticket 49, *Documentation site for the toy package and its new modules and flags* (docs): parked
- Ticket 73, *Documentation site for the toy package and its new modules and flags* (docs): parked
- Ticket 93, *Documentation site for the toy package and its new modules and flags* (docs): parked
- Ticket 113, *Documentation site for the toy package and its new modules and flags* (docs): parked
- Ticket 131, *Documentation site for the toy package, with the docstrings its build checks for* (docs): accepted
- The site `research/.cache/docs/html/index.html`, built 2026-10-25T03:21:43.389Z: every machine check passed.
- Owed: ticket 4 added public API and no closed docs ticket documents it.
- Owed: ticket 6 added public API and no closed docs ticket documents it.
- Owed: ticket 7 added public API and no closed docs ticket documents it.
- Owed: ticket 9 added public API and no closed docs ticket documents it.
- Owed: ticket 10 added public API and no closed docs ticket documents it.
- Owed: ticket 11 added public API and no closed docs ticket documents it.
- Owed: ticket 30 added public API and no closed docs ticket documents it.
- Owed: ticket 31 added public API and no closed docs ticket documents it.
- Owed: ticket 32 added public API and no closed docs ticket documents it.
- Owed: ticket 33 added public API and no closed docs ticket documents it.
- Owed: ticket 34 added public API and no closed docs ticket documents it.
- Owed: ticket 54 added public API and no closed docs ticket documents it.
- Owed: ticket 55 added public API and no closed docs ticket documents it.
- Owed: ticket 56 added public API and no closed docs ticket documents it.
- Owed: ticket 57 added public API and no closed docs ticket documents it.
- Owed: ticket 58 added public API and no closed docs ticket documents it.
- Owed: ticket 75 added public API and no closed docs ticket documents it.
- Owed: ticket 76 added public API and no closed docs ticket documents it.
- Owed: ticket 77 added public API and no closed docs ticket documents it.
- Owed: ticket 78 added public API and no closed docs ticket documents it.
- Owed: ticket 79 added public API and no closed docs ticket documents it.
- Owed: ticket 95 added public API and no closed docs ticket documents it.

Earlier runs:

| Run | Started | Ended | Reason | Waves | Tickets closed | Turns | Wall clock (h) | GPU (h) |
|---|---|---|---|---|---|---|---|---|
| 1 | 2026-10-24 11:53Z | 2026-10-24 11:54Z | stopped | 6 | 0 | 8 | 0.0 | 0.00 |
| 2 | 2026-10-24 11:55Z | 2026-10-25 06:56Z | objectives_closed | 60 | 35 | 1850 | 19.0 | 3.89 |
| 3 | 2026-10-25 07:39Z | 2026-10-25 12:58Z | objectives_closed | 4 | 1 | 168 | 5.3 | 0.00 |

## Not pursued

- Proposal `4754eafc8596` from ticket 3 (review): parked, reason `cap`
- Proposal `ae4c3a23ad9d` from ticket 5 (code): parked, reason `touches`
- Proposal `0fbbee4006e7` from ticket 31 (harness): parked, reason `touches`
- Proposal `a9944944ae02` from ticket 52 (docs): parked, reason `touches`
- Proposal `553ea22a5d61` from ticket 76 (analysis): parked, reason `cap`
- Proposal `e313ae83b398` from ticket 52 (harness): parked, reason `cap`
- Proposal `cfac9a08144f` from ticket 52 (harness): parked, reason `cap`
- Proposal `660e782d532d` from ticket 76 (code): parked, reason `cap`
- Proposal `889beed0dce4` from ticket 97 (docs): parked, reason `radius`
- Proposal `11af1272cc9a` from ticket 98 (docs): parked, reason `cap`
- Proposal `2f47ee740c53` from ticket 98 (code): parked, reason `cap`
- Proposal `23f895b940b6` from ticket 99 (dossier): parked, reason `radius`
- Proposal `dbeebd25e875` from ticket 115 (code): parked, reason `cap`
- Proposal `76545d72cf3d` from ticket 103 (analysis): parked, reason `cap`
- Proposal `5a18485a69a5` from ticket 115 (code): parked, reason `cap`
- Proposal `b819e8e400f7` from ticket 117 (harness): parked, reason `cap`
- Proposal `768b88733155` from ticket 115 (code): parked, reason `duplicate`
- Proposal `a9a9acb1dee9` from ticket 117 (writing): parked, reason `radius`
- Proposal `55c68e773fdf` from ticket 118 (writing): parked, reason `cap`
- Proposal `a3cb05e94b44` from ticket 100 (dossier): parked, reason `radius`
- Proposal `282e6b64742c` from ticket 112 (analysis): parked, reason `radius`
- Proposal `741a44dbba62` from ticket 112 (analysis): parked, reason `cap`
- Proposal `a5474dcd4cfa` from ticket 116 (code): parked, reason `cap`
- Proposal `753459b9820e` from ticket 100 (lit): parked, reason `radius`
- Proposal `32e598d6ec4f` from ticket 101 (dossier): parked, reason `radius`
- Proposal `1df593319dd8` from ticket 112 (analysis): parked, reason `duplicate`
- Proposal `99ca7b84909d` from ticket 96 (code): parked, reason `cap`
- Proposal `6e156fdbbd9c` from ticket 108 (analysis): parked, reason `cap`
- Proposal `1a40e2d12dbd` from ticket 113 (code): parked, reason `cap`
- Proposal `db3af965d03b` from ticket 121 (analysis): parked, reason `cap`
- Proposal `febdd88db342` from ticket 122 (analysis): parked, reason `cap`
- Proposal `32e9b6f9df54` from ticket 122 (analysis): parked, reason `duplicate`
- Proposal `9007e2d5aed3` from ticket 110 (analysis): parked, reason `cap`
- Proposal `c3a0b19879a6` from ticket 111 (analysis): parked, reason `cap`
- Proposal `26568bda158d` from ticket 131 (code): parked, reason `cap`
- Proposal `322d54f62d4e` from ticket 131 (code): parked, reason `cap`
- Proposal `53d5ec575f93` from ticket 131 (docs): parked, reason `cap`
- Proposal `0fec1341e2b7` from ticket 134 (analysis): parked, reason `cap`
- Proposal `ee844677c54f` from ticket 136 (code): parked, reason `cap`
- Proposal `23d8827d9875` from ticket 139 (code): parked, reason `radius`
- Proposal `9d40ae3d2214` from ticket 141 (harness): parked, reason `radius`
- Proposal `f0947de17b2b` from ticket 142 (harness): parked, reason `radius`
- Proposal `57ae087b7cae` from ticket 143 (harness): parked, reason `touches`
- Proposal `52e6efaaee2e` from ticket 167 (code): parked, reason `duplicate`
- Proposal `d1acdac9fb7a` from ticket 169 (code): parked, reason `cap`
- Proposal `65c7111f4fd5` from ticket 168 (harness): parked, reason `radius`
- Proposal `1027cea82cfc` from ticket 169 (code): parked, reason `duplicate`
- Proposal `922d8a0c137a` from ticket 165 (harness): parked, reason `radius`
- Ticket 4, *eval.py: --summary PATH and --split val, goal command unchanged* (code): parked
- Ticket 6, *toy.oracle: the generator's true P(y=1|x), Bayes ceiling, calibration and additive gap* (code): parked
- Ticket 7, *toy.paired: paired statistics of one sweep point against the oracle ceiling* (code): parked
- Ticket 9, *toy.sweep: strength_spearman and gain_shrink across sweep points* (code): parked
- Ticket 10, *toy.goallog: held-out reads of the goal loop from results/E5/changes.jsonl* (code): parked
- Ticket 11, *toy.placement: resolved_refs and prior_measures_gain from a placement record and the dossiers* (code): parked
- Ticket 12, *Literature: explicit interaction terms, their cost when unneeded, and paired tests of two classifiers* (lit): parked
- Ticket 13, *Literature: Bayes-optimal AUROC of a known generator and the precision of an AUROC estimate* (lit): parked
- Ticket 14, *Literature: selection bias from reusing a held-out set, and tuning on a validation split* (lit): parked
- Ticket 15, *E1 experiment: oracle audit of the default generator on the 10^6-row draw D2* (experiment): parked
- Ticket 17, *E5 experiment: goal starting run of the default train.py for O2* (experiment): parked
- Ticket 18, *E2 gate analysis: reproduction of the owner's run and convergence at doubled epochs* (analysis): parked
- Ticket 19, *E3 experiment: interaction-strength sweep with the zero-strength null control* (experiment): parked
- Ticket 20, *E4 experiment: training-size sweep at strengths 1 and 0* (experiment): parked
- Ticket 21, *E1 analysis: the planted interaction, the additive gap and the Bayes ceiling (C1, C2 ceiling)* (analysis): parked
- Ticket 22, *E2 analysis: paired AUROC gain of the x3*x4 column over 20 seeds (C3, C2 bound)* (analysis): parked
- Ticket 23, *E3 analysis: gain across interaction strengths and at zero strength (C4, C5)* (analysis): parked
- Ticket 24, *E4 analysis: gain across training sizes and the zero-strength cost per size (C6)* (analysis): parked
- Ticket 25, *E5 analysis: whether the goal of 0.82 is met without tuning on held-out data (C7)* (analysis): parked
- Ticket 26, *E6 analysis: placement of C3-C6 against the five resolved works (C8)* (analysis): parked
- Ticket 27, *Documentation site for the toy package and its new modules and flags* (docs): parked
- Ticket 30, *eval.py: --summary PATH and --split val, O2's goal command unchanged* (code): parked
- Ticket 31, *toy.paired: paired statistics of one sweep point against the oracle ceiling* (code): parked
- Ticket 32, *toy.sweep: strength_spearman and gain_shrink across sweep points* (code): parked
- Ticket 33, *toy.goallog: held-out reads of the goal loop from results/E5/changes.jsonl* (code): parked
- Ticket 34, *toy.placement: resolved_refs and prior_measures_gain from a placement record and the dossiers* (code): parked
- Ticket 35, *Literature: explicit interaction terms, their cost when unneeded, and paired tests of two classifiers (O1, O4)* (lit): parked
- Ticket 36, *Literature: Bayes-optimal AUROC of a known generator and the precision of an AUROC estimate (O3)* (lit): parked
- Ticket 37, *Literature: selection bias from reusing a held-out set, and tuning on a validation split (O2)* (lit): parked
- Ticket 38, *E1 experiment: oracle audit of the default generator on the 10^6-row draw D2* (experiment): parked
- Ticket 39, *E5 experiment: goal starting run of the default train.py at seeds 1-3 for O2* (experiment): parked
- Ticket 40, *E1 analysis: the planted interaction, the additive gap and the Bayes ceiling (C1, C2 ceiling)* (analysis): parked
- Ticket 41, *E2 gate analysis: reproduction of the owner's run and convergence at doubled epochs* (analysis): parked
- Ticket 42, *E3 experiment: interaction-strength sweep with the zero-strength null control* (experiment): parked
- Ticket 43, *E4 experiment: training-size sweep at strengths 1 and 0* (experiment): parked
- Ticket 44, *E2 analysis: paired AUROC gain of the x3*x4 column over 20 seeds (C3, C2 bound)* (analysis): parked
- Ticket 45, *E3 analysis: gain across interaction strengths and at zero strength (C4, C5)* (analysis): parked
- Ticket 46, *E4 analysis: gain across training sizes and the zero-strength cost per size (C6)* (analysis): parked
- Ticket 47, *E5 analysis: whether the goal of 0.82 is met without tuning on held-out data (C7)* (analysis): parked
- Ticket 48, *E6 analysis: placement of C3-C6 against the five resolved works (C8)* (analysis): parked
- Ticket 49, *Documentation site for the toy package and its new modules and flags* (docs): parked
- Ticket 52, *toy.oracle: unrounded interaction weight, and tests that back the tolerances and calibration numbers its comments state* (code): parked
- Ticket 53, *toy.oracle: a committed test that the 10^6-row audit fits E1's hour and memory* (code): parked
- Ticket 54, *eval.py: --summary PATH and --split val on the src/ layout, O2's goal command unchanged* (code): parked
- Ticket 55, *toy.paired: paired statistics of one sweep point against the oracle ceiling (src/ layout)* (code): parked
- Ticket 56, *toy.sweep: strength_spearman and gain_shrink across sweep points (src/ layout)* (code): parked
- Ticket 57, *toy.goallog: held-out reads of the goal loop from results/E5/changes.jsonl (src/ layout)* (code): parked
- Ticket 58, *toy.placement: resolved_refs and prior_measures_gain from a placement record and the dossiers (src/ layout)* (code): parked
- Ticket 59, *Literature: explicit interaction terms, their cost when unneeded, and paired tests of two classifiers (O1, O4)* (lit): parked
- Ticket 60, *Literature: Bayes-optimal AUROC of a known generator and the precision of an AUROC estimate (O3)* (lit): parked
- Ticket 61, *Literature: selection bias from reusing a held-out set, and tuning on a validation split (O2)* (lit): parked
- Ticket 62, *E1 experiment: oracle audit of the default generator on the 10^6-row draw D2* (experiment): parked
- Ticket 63, *E5 experiment: goal starting run of the default train.py at seeds 1-3 for O2* (experiment): parked
- Ticket 64, *E1 analysis: the planted interaction, the additive gap and the Bayes ceiling (C1, C2 ceiling)* (analysis): parked
- Ticket 65, *E2 gate analysis: reproduction of the owner's run and convergence at doubled epochs, with citable findings* (analysis): parked
- Ticket 66, *E3 experiment: interaction-strength sweep with the zero-strength null control* (experiment): parked
- Ticket 67, *E4 experiment: training-size sweep at strengths 1 and 0* (experiment): parked
- Ticket 68, *E2 analysis: paired AUROC gain of the x3*x4 column over 20 seeds (C3, C2 bound)* (analysis): parked
- Ticket 69, *E3 analysis: gain across interaction strengths and at zero strength (C4, C5)* (analysis): parked
- Ticket 70, *E4 analysis: gain across training sizes and the zero-strength cost per size (C6)* (analysis): parked
- Ticket 71, *E5 analysis: whether the goal of 0.82 is met without tuning on held-out data (C7)* (analysis): parked
- Ticket 72, *E6 analysis: placement of C3-C6 against the five resolved works (C8)* (analysis): parked
- Ticket 73, *Documentation site for the toy package and its new modules and flags* (docs): parked
- Ticket 75, *eval.py: --summary PATH and --split val, O2's goal command unchanged* (code): parked
- Ticket 76, *toy.paired: paired statistics of one sweep point against the oracle ceiling* (code): parked
- Ticket 77, *toy.sweep: strength_spearman and gain_shrink across sweep points* (code): parked
- Ticket 78, *toy.goallog: held-out reads of the goal loop from results/E5/changes.jsonl* (code): parked
- Ticket 79, *toy.placement: resolved_refs and prior_measures_gain, tolerating unscouted works and unsettled entries* (code): parked
- Ticket 80, *Literature: explicit interaction terms, their cost when unneeded, and paired tests of two classifiers (O1, O4)* (lit): parked
- Ticket 81, *Literature: Bayes-optimal AUROC of a known generator and the precision of an AUROC estimate (O3)* (lit): parked
- Ticket 82, *Literature: selection bias from reusing a held-out set, and tuning on a validation split (O2)* (lit): parked
- Ticket 83, *E1 experiment: oracle audit of the default generator on the 10^6-row draw D2* (experiment): parked
- Ticket 84, *E5 experiment: goal starting run of the default train.py at seeds 1-3 for O2* (experiment): parked
- Ticket 85, *E1 analysis: the planted interaction, the additive gap and the Bayes ceiling (C1, C2 ceiling)* (analysis): parked
- Ticket 86, *E3 experiment: interaction-strength sweep with the zero-strength null control* (experiment): parked
- Ticket 87, *E4 experiment: training-size sweep at strengths 1 and 0* (experiment): parked
- Ticket 88, *E2 analysis: paired AUROC gain of the x3*x4 column over 20 seeds (C3, C2 bound)* (analysis): parked
- Ticket 89, *E3 analysis: gain across interaction strengths and at zero strength (C4, C5)* (analysis): parked
- Ticket 90, *E4 analysis: gain across training sizes and the zero-strength cost per size (C6)* (analysis): parked
- Ticket 91, *E5 analysis: whether the goal of 0.82 is met without tuning on held-out data (C7)* (analysis): parked
- Ticket 92, *E6 analysis: placement of C3-C6 against the five resolved works (C8)* (analysis): parked
- Ticket 93, *Documentation site for the toy package and its new modules and flags* (docs): parked
- Ticket 95, *eval.py: --summary PATH and --split val, O2's goal command unchanged* (code): parked
- Ticket 108, *E2 analysis: paired AUROC gain of the x3*x4 column over 20 seeds (C3, C2 bound)* (analysis): parked
- Ticket 109, *E3 analysis: gain across interaction strengths and at zero strength (C4, C5)* (analysis): parked
- Ticket 113, *Documentation site for the toy package and its new modules and flags* (docs): parked
- Ticket 128, *Read friedman-2008-predictive-learning-rule-ensembles in full: the level-2 read E6 needs (C8)* (dossier): parked
- Ticket 129, *Read bien-2013-lasso-hierarchical-interactions in full: the level-2 read E6 needs (C8)* (dossier): parked
- Ticket 130, *E6 re-read: settle Friedman 2008 and Bien 2013 from their full reads and place C3-C6 against the resolved works (C8, K7)* (analysis): parked
- Ticket 139, *Draw R6: Oracle audit cost on the 10^6-row draw D2* (drawing): parked
- Ticket 142, *Draw R9: eval.py: --summary PATH and --split val, O2's goal command unchanged* (drawing): parked
- Ticket 143, *Draw R10: toy.placement: resolved_refs and prior_measures_gain, tolerating unscouted works and unsettled entries* (drawing): parked
- Ticket 145, *Draw R12: Evaluation command* (drawing): parked
- Ticket 146, *Draw R13: E6: literature placement of C3-C6 (C8)* (drawing): parked
- Ticket 147, *Draw R14: E2: paired AUROC gain of the x3*x4 column over 20 seeds* (drawing): parked
- Ticket 148, *Draw R15: E3: paired gain across interaction strengths (C4, C5)* (drawing): parked
- Ticket 149, *Draw R16: E4: paired gain across training sizes (C6)* (drawing): parked
- Ticket 150, *Draw R17: E5: the goal run against O2's 0.82 (C7)* (drawing): parked
- Ticket 151, *Draw R18: Documentation site for the toy package, with the docstrings its build checks for* (drawing): parked
- Ticket 153, *Re-file toy.eval's four findings (R9, R12) against the current eval.py and test_eval.py, so the manifest takes their current hashes* (analysis): parked
- Ticket 154, *Re-file toy.placement's and E6's seven findings (R10, R13) against the current placement.py and placement_summary.json, so the manifest takes their current hashes* (analysis): parked
- Ticket 155, *Re-file toy.paired's five findings (R8) against the current paired.py and test_paired.py, so the manifest takes their current hashes* (analysis): parked
- Ticket 156, *Re-file the oracle budget finding (R6) to describe tests/test_oracle_budget.py as it is now (seed 20001), so the manifest takes its current hash* (analysis): parked
- Ticket 158, *Scope down a report claim its artifacts do not support* (writing): parked
- Ticket 159, *Scope down a report claim its artifacts do not support* (writing): parked
- Ticket 160, *Scope down a report claim its artifacts do not support* (writing): parked
- Ticket 161, *Scope down a report claim its artifacts do not support* (writing): parked
- Ticket 162, *Scope down the general report's claims the kill argument left standing* (writing): parked
- Ticket 167, *Draw R6: Oracle audit cost on the 10^6-row draw D2* (drawing): parked
- Ticket 170, *Draw R13: E6: literature placement of C3-C6 (C8)* (drawing): parked
- Ticket 171, *Draw R14: E2: paired AUROC gain of the x3*x4 column over 20 seeds* (drawing): parked
- Ticket 172, *Draw R15: E3: paired gain across interaction strengths (C4, C5)* (drawing): parked
- Ticket 173, *Draw R16: E4: paired gain across training sizes (C6)* (drawing): parked
- Ticket 174, *Draw R17: E5: the goal run against O2's 0.82 (C7)* (drawing): parked
- Ticket 175, *Draw R18: Documentation site for the toy package, with the docstrings its build checks for* (drawing): parked
- Objective proposal `t111-a1/1` from ticket 111, answer O2: not upheld, not upheld by code: it would answer O2, which is answered; only an open objective is answered

## Library

- 2 cited reference(s) not yet resolved: [References](sections/references.md#not-yet-resolved), under Not yet resolved.
- Level 0 (15): `cl-men-on-2008-ranking-empirical-minimization-u-statistics`, `delong-1988-comparing-areas-under-two-more`, `dietterich-1998-approximate-statistical-tests-comparing-supervised`, `dwork-2014-preserving-statistical-validity-adaptive-data`, `dwork-2017-guilt-free-data-reuse`, `emmert-streib-2019-evaluation-regression-models-model-assessment`, `hanley-1982-meaning-use-area-under-receiver`, `lou-2013-accurate-intelligible-models-pairwise-interactions`, `menon-2014-bayes-optimal-scorers-bipartite-ranking`, `paper-a` (unresolved), `paper-b` (unresolved), `raschka-2018-model-evaluation-model-selection-algorithm`, `sun-2014-fast-implementation-delong-s-algorithm`, `ushio-2026-bayes-optimal-ber-auc-estimation`, `ziegel-1987-numerical-recipes-art-scientific-computing`
- Level 1 (0): none
- Level 2 (2): `bien-2013-lasso-hierarchical-interactions`, `friedman-2008-predictive-learning-rule-ensembles`

Promotions not read in full:

- `friedman-2008-predictive-learning-rule-ensembles`: promoted to level 2 on `consultant_question` (2026-10-24 19:29Z), and no level-2 read is journaled
- `bien-2013-lasso-hierarchical-interactions`: promoted to level 2 on `consultant_question` (2026-10-24 19:29Z), and no level-2 read is journaled

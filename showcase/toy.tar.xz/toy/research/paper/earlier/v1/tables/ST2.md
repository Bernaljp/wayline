**Supplementary Table S2.** the six agreement checks behind R3: what each holds toy.stats to, against which reference, on how many cases, and to what tolerance

| finding | quantity | reference | cases | tolerance_kind | tolerance | line |
|---|---|---|---|---|---|---|
| t5-a3-f1 | exact signed-rank p (no ties) | scipy.stats.wilcoxon exact | 10 | decimal places | 12 | L38 |
| t5-a3-f2 | exact signed-rank p (tied) | scipy wilcoxon PermutationMethod | 1 | decimal places | 12 | L42-L43 |
| t5-a3-f3 | 95% t-interval bounds | scipy.stats.t.interval | 5 | decimal places | 10 | L29-L30 |
| t5-a3-f4 | DeLong AUROCs and covariance (tied) | literal pairwise DeLong kernel | 5 | absolute | 1e-12 | L68-L69 |
| t5-a3-f5 | Spearman rho (tied integers) | scipy.stats.spearmanr | 5 | decimal places | 12 | L84 |
| t5-a3-f6 | paired percentile bootstrap CI, ratio of means | scipy.stats.bootstrap paired percentile | 1 | fraction of CI width | 0.05 | L98-L106 |

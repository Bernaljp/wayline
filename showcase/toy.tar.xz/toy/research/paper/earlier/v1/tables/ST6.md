**Supplementary Table S6.** E1's criteria: measured value against limit

| criterion | quantity | value | limit | passes |
|---|---|---|---|---|
| C1 | interaction_weight | 4.4 | != 0 | True |
| C1 | additive_gap | 0.0882 | > 0.005 | True |
| C1, C2 | calibration_error | 0.0039 | <= 0.01 | True |
| C2 | bayes_auroc_halfwidth | 0.00072 | <= 0.002 | True |
| A6 | bayes_auroc - goal | 0.0355 | < 0 for A6 | False |

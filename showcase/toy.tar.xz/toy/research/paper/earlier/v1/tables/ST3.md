**Supplementary Table S3.** the 6 convergence reruns: arm, seed, epochs and final training loss at the pinned and doubled counts, and the relative drop

| arm | seed | epochs_pinned | loss_pinned | epochs_double | loss_double | relative_drop |
|---|---|---|---|---|---|---|
| with | 1 | 30 | 0.4723849892616272 | 60 | 0.4724302291870117 | -9.576918490834106e-05 |
| with | 2 | 30 | 0.4777405858039856 | 60 | 0.47609663009643555 | 0.0034411053956896914 |
| with | 3 | 30 | 0.47309911251068115 | 60 | 0.4736323356628418 | -0.0011270855050454275 |
| without | 1 | 30 | 0.5749234557151794 | 60 | 0.5743612051010132 | 0.000977957341237443 |
| without | 2 | 30 | 0.5817123055458069 | 60 | 0.5813217759132385 | 0.0006713449738731841 |
| without | 3 | 30 | 0.5729799866676331 | 60 | 0.5743486285209656 | -0.0023886381464950255 |

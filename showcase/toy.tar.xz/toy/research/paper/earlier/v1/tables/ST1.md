**Supplementary Table S1.** The recorded constants and assertions of the training-flag tests: the smoke-run configuration, its pinned held-out AUROC, and the two weight assertions on the arms.

| finding | quantity | value | source |
|---|---|---|---|
| t3-a1-f1 | seed | 1 | tests/test_train.py#SMALL |
| t3-a1-f1 | rows | 2000 | tests/test_train.py#SMALL |
| t3-a1-f1 | epochs | 2 | tests/test_train.py#SMALL |
| t3-a1-f1 | device | cpu | tests/test_train.py#SMALL |
| t3-a1-f1 | held-out AUROC at base commit and after change | 0.8352720450281426 | tests/test_train.py#BASE_AUROC |
| t3-a1-f2 | without-arm interaction weight: final equals initial | asserted | tests/test_train.py#test_arms_share_initial_weights_and_without_never_moves_the_interaction_weight |
| t3-a1-f2 | both arms: identical initial weights | asserted | tests/test_train.py#test_arms_share_initial_weights_and_without_never_moves_the_interaction_weight |

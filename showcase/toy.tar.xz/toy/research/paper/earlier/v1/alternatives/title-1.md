An explicit product column recovers a planted interaction: paired AUROC gains against the Bayes ceiling on one synthetic generator

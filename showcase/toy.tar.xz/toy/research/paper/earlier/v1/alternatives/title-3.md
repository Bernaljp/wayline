A paired, ceiling-referenced test of an interaction column, with a zero-strength control

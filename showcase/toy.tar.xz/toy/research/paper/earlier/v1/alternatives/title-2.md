Interaction terms on one synthetic generator: the gain tracks the planted strength and vanishes without it

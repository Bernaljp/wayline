# Front matter

## Authors

[TO BE GIVEN: the authors and their affiliations]

## Acknowledgments

[TO BE GIVEN: acknowledgments]

## Funding

[TO BE GIVEN: funding]

## Competing interests

[TO BE GIVEN: competing interests]

## Data availability

The data this study analysed: `research/intake/paper-c-source.tar.gz` (a file, 632 bytes); The synthetic two-class set is made by src/toy/generate.py from one seeded stream; the held-out split is the last fifth of the rows drawn (HELD_OUT_FRACTION = 0.2) and is used for evaluation only. The results it reports were produced by the project's own runs, 2210 artifact(s) recorded with their SHA-256 in the project's manifest. [TO BE GIVEN: where the data are deposited]

## Code availability

[TO BE GIVEN: the code repository, which setup has not settled]
The code repository does not reproduce: {'passage': 'P60', 'heading': 'Drawing R11-1', 'named': 'AUROC', 'why': 'no code under `code/` calls area under the ROC curve (roc_auc_score)', 'reproduced_by_repository': False}.

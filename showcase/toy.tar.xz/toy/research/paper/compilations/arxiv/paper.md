# An explicit product column on one synthetic generator: a paired AUROC gain that follows the planted interaction and nearly reaches the Bayes ceiling

\[TO BE GIVEN: the authors and their affiliations\]

## Abstract

We ask whether giving a logistic model an explicit product column, $x_3x_4$, raises its held-out AUROC on two-class data drawn by one synthetic generator, and by how much, reading the gain against the generator's Bayes-optimal AUROC and against a control with no planted interaction. At signal 4.0 and strength 1.0, the generator's label rule puts a log-odds weight of 4.4 on $x_3x_4$. On a draw of 1000000 rows, an additive logistic model fit to one half reaches an AUROC of 0.7681 on the other half, 500000 rows, against 0.8563 for the generator's own probabilities on the same rows. The Bayes-optimal AUROC on the whole draw is 0.8555, with a DeLong half-width of 0.00072. Over 20 paired seeds at 16000 training rows, the column lifts the mean held-out AUROC from 0.7681 to 0.8552, a mean paired gain of 0.0872 with a 95% t-interval from 0.0843 to 0.0900. All 20 per-seed differences are positive. The gain closes 0.990 of the gap that the model without the column leaves to the Bayes ceiling. With no planted interaction, the mean paired gain is -0.000319 and its 95% t-interval lies inside a harmlessness band of -0.01 to 0.01, though 16 of the 20 seeds score slightly lower with the column. Across six strengths the gain rises at every step, to 0.3143 at four times the default strength. At the default strength it stays between 0.0871 and 0.0879 across 7 training sizes from 1000 to 64000 rows. The project's default run meets the owner's goal of a held-out AUROC of at least 0.82, at 0.8503, and no setting was chosen on held-out data. Of five works found by search, two could be settled from their abstracts and neither measures this gain, so the placement of these results against prior work is unresolved. Only a model linear in its inputs was tested. The gain is about zero when nothing is planted and grows with the planted strength, so it restates what the generator puts into the labels and says nothing about interaction terms on data from outside this generator.

# Introduction

This paper measures one thing on one synthetic generator: whether a logistic model given the explicit product column $x_3x_4$ scores a higher held-out AUROC than the same model without it, and by how much. It asks four questions. Does the generator plant an interaction in the label, and what is the best AUROC the generator allows? Does the column help, and by how much, when the comparison is paired over seeds and tested? Does the gain vanish when nothing is planted, and how does it move with the planted strength and with the training size? And can the owner's goal of a held-out AUROC of at least 0.82 be met without choosing any setting on held-out data? The sections below set out what prior work offers on each point.

## No verified prior work anchors the effect size

Two references were handed over when the project began. No DOI or arXiv identifier could be read from the first, materials/paper-a.pdf, and it has not been verified (to be resolved). \[to be resolved\] The second, materials/paper-b.pdf, is in the same state (to be resolved). \[to be resolved\] Read directly, each file describes itself in its abstract as one of two papers written for a test fixture and never submitted anywhere, so neither could anchor an expected effect size even if its identity were settled. The project therefore takes no expected effect size from prior work. In their place, five works found by search, on detecting and selecting interactions and on paired AUROC tests, were scouted, and only two of them could be settled from their abstracts.

## Interaction detection and selection: what the literature offers

Rule ensembles give techniques for finding which variables interact with others, and how strong and of what degree those interactions are. ([Friedman and Popescu 2008](#ref-friedman-2008-predictive-learning-rule-ensembles)) Generalized additive models built from univariate terms are reported to be significantly less accurate than more complex models that permit interactions. ([Lou et al. 2013](#ref-lou-2013-accurate-intelligible-models-pairwise-interactions)) The lasso with a hierarchy constraint selects sparse interaction models, admitting an interaction only if one or both of its variables are marginally important, and its paper reports an empirical study of the method. ([Bien et al. 2013](#ref-bien-2013-lasso-hierarchical-interactions)) The abstract of the rule-ensemble work states no gain over a control without interactions. ([Friedman and Popescu 2008](#ref-friedman-2008-predictive-learning-rule-ensembles)) The abstract of the hierarchical lasso states no such gain either, nor the cost of added terms when none is needed. ([Bien et al. 2013](#ref-bien-2013-lasso-hierarchical-interactions)) What this paper measures, the held-out gain of one explicit product column against a no-interaction control, is therefore not given by these abstracts.

## Paired tests of two classifiers

For two or more AUROCs computed on the same individuals, a nonparametric approach based on generalized U-statistics gives an estimated covariance matrix that accounts for their correlation. ([DeLong et al. 1988](#ref-delong-1988-comparing-areas-under-two-more)) A paired-differences t test over several random train-test splits is reported to have a high probability of type I error and should never be used. ([Dietterich 1998](#ref-dietterich-1998-approximate-statistical-tests-comparing-supervised)) McNemar's test has low type I error, and the 5x2 cv test also has acceptable type I error and directly measures the variation due to the choice of training set. ([Dietterich 1998](#ref-dietterich-1998-approximate-statistical-tests-comparing-supervised)) This paper draws a fresh data set for each seed rather than resampling one, so its per-seed differences come from separate draws, and it pairs the two arms on each seed's held-out rows.

## The Bayes-optimal ceiling for AUROC

Work on bipartite ranking asks which scorer is Bayes-optimal for a ranking risk, shows that the answer is non-trivial in general but easily found in special cases through the theory of proper losses, and ties minimising a suitable class-probability estimation risk to minimising bipartite ranking risks. ([Menon and Williamson 2014](#ref-menon-2014-bayes-optimal-scorers-bipartite-ranking)) The ranking problem has also been set in a statistical framework in which the natural risk estimates are U-statistics. ([Clémençon et al. 2008](#ref-cl-men-on-2008-ranking-empirical-minimization-u-statistics)) When the true class probabilities and the class prior are known, estimators of the optimal AUC based on those soft labels have been proposed, so that the irreducible part of the error can be told apart from a model's deficiency and the room left for improvement read off. ([Ushio et al. 2026](#ref-ushio-2026-bayes-optimal-ber-auc-estimation)) A synthetic generator is such a case: its label rule gives the true probability of each row, so a gain can be read as a share of the gap that was there to close.

## Precision of an AUROC estimate

The area under an ROC curve is the probability that a randomly chosen positive is ranked above a randomly chosen negative, and it equals the Wilcoxon statistic; this gives closed-form approximate standard errors and guidance on the sample size needed for a reliable area and for detecting differences between techniques. ([Hanley and McNeil 1982](#ref-hanley-1982-meaning-use-area-under-receiver)) For AUROCs computed on the same individuals, the generalized U-statistics approach gives a covariance matrix that accounts for their correlation. ([DeLong et al. 1988](#ref-delong-1988-comparing-areas-under-two-more)) This paper reports the Bayes AUROC of its large draw with a DeLong half-width, and compares the two arms seed by seed with the DeLong test.

## Reusing a held-out set and tuning on a validation split

Statistical inference theory assumes that hypotheses or learning algorithms are chosen before the data are gathered, while in practice data are reused and new analyses grow out of the outcomes of earlier ones. ([Dwork et al. 2014](#ref-dwork-2014-preserving-statistical-validity-adaptive-data)) The same line of work names parameter tuning on the basis of results already obtained as part of this adaptive practice, and gives a method for reusing a holdout set to validate the accuracy of hypotheses that a learning algorithm produces adaptively. ([Dwork et al. 2017](#ref-dwork-2017-guilt-free-data-reuse)) A review of model evaluation covers the holdout method for evaluation and selection, k-fold and nested cross-validation, and the bias-variance trade-off in choosing k. ([Raschka 2018](#ref-raschka-2018-model-evaluation-model-selection-algorithm)) Another review separates model assessment from model selection and presents cross-validation as the generic way to estimate the quantities that selection needs. ([Emmert-Streib and Dehmer 2019](#ref-emmert-streib-2019-evaluation-regression-models-model-assessment)) These abstracts state no size for the upward bias of a held-out score chosen over several reads. ([Dwork et al. 2017](#ref-dwork-2017-guilt-free-data-reuse); [Raschka 2018](#ref-raschka-2018-model-evaluation-model-selection-algorithm)) The goal loop in this paper therefore chooses any change on a validation split and counts every read of the held-out set against a fixed limit.

# Results

## Do the interaction terms help, and by how much? (whether adding feature interaction terms improves held-out AUROC on a synthetic two-class set)

The answer rests on two experiments. E2 compares the two arms, with and without the $x_3x_4$ column, over 20 paired seeds at the pinned settings. E6 places the claims against the literature. Before E2's numbers, this section reports the checks on the code that trains the two arms, computes their paired statistics, and gates the experiment. Estimates here and below are rounded to the precision their intervals support, and the analysis files hold them at full floating-point precision. A value that a check compares for exact equality is given in full.

### Adding the interaction flags leaves the default training run unchanged

At the base commit 4a72047, `toy.train --seed 1 --rows 2000 --epochs 2 --device cpu` gives a held-out AUROC of 0.8352720450281426. After the change that added the flags, the same command with no new flag gives exactly the same value on CPU. In the without arm (`--no-interaction`), the weight on the zeroed $x_3x_4$ column keeps its initial value through training, since Adam sees a zero gradient and the weight decay is 0. Both arms draw identical initial weights from the shared seed. Supplementary Table S1 lists the smoke run's configuration, its pinned AUROC, and the two weight assertions.

### The statistics code agrees with independent reference implementations

Each statistic that toy.stats computes was checked against an independent reference (Supplementary Table S2). The exact two-sided signed-rank p agrees with `scipy.stats.wilcoxon(method='exact')` to 12 decimal places on ten 20-replicate draws without ties. On tied differences, it agrees to 12 decimal places with `scipy.stats.wilcoxon` under an exhaustive `PermutationMethod` (n_resamples=10000). The bounds of the 95% t-interval agree with `scipy.stats.t.interval` to 10 decimal places. On tied scores, the midrank DeLong AUROCs and covariance agree with a literal pairwise DeLong kernel to an absolute tolerance of 1e-12. Spearman's rho agrees with `scipy.stats.spearmanr` on tied integer data to 12 decimal places. The paired percentile bootstrap CI for a ratio of means lies within 0.05 times the interval's width of `scipy.stats.bootstrap(paired=True, method='percentile')`, each with 10000 resamples.

Taken together, the 5 deterministic checks hold toy.stats to between 10 and 12 decimal places, or an absolute 1e-12, on 26 cases. The sixth check, the paired bootstrap interval, is held only to 0.05 of the interval's width. What is recorded is that each assertion passed, not how large the observed differences were. The checks on ties are small: the tied signed-rank p is checked on a single vector of 10 differences with 5 distinct magnitudes, and DeLong and Spearman on ties on 5 draws each.

### The oracle's true class probability matches the generator

generate.py builds the latent log-odds as signal times $(0.6x_1 - 0.4x_2 + 1.1\,m\,x_3x_4)$, adds Gaussian noise with mean 0.0 and sd 1.0, and draws the label as a coin flip whose probability is the logistic of that latent. Because the noise enters before the logistic, $P(y=1\mid x)$ is the logistic-normal integral $\mathbb{E}[\sigma(\mu(x)+\varepsilon)]$, not $\sigma(\mu(x))$. Run at its defaults, the oracle's command line reports an interaction_weight of 4.4 and an interaction_coefficient of 1.1 for the log-odds weight the generator puts on $x_3x_4$.

The oracle's true_prob matches labels drawn by generate.row itself at fixed features to within 4 binomial standard errors over $10^5$ draws each. The test covers six $(x, m)$ cases, including $m = 0$ and $m = 2.5$. At $m = 0$ the probability does not change with $x_3x_4$. Leaving out the latent noise miscalibrates the oracle: on 200,000 rows at seed 101, the 20-bin calibration error is at most 0.02 for true_prob, while for $\sigma(\mu(x))$ it exceeds 0.03.

At 20,000 rows the 20-bin calibration error is mostly sampling noise, even for the exact $P(y=1\mid x)$. With about 1,000 rows per bin, a bin's mean label has a standard error of up to about 0.016, and at seed 7 the largest gap is 0.034. The bins' chi-square on 20 degrees of freedom stays below 45.31, its 0.999 quantile, so a 0.02 threshold on the largest gap is not a test at that size. E1's calibration error on its own draw is reported under R11.

### The convergence check flags only a training loss that still falls

toy.converge's convergence_drop is the largest signed relative drop in final training loss at doubled epochs, so a run whose training loss rose counts as a negative drop. The E2 gate compares that largest drop with a convergence limit of 0.01, so only a loss that still falls by more than 1% can fail it. toy.converge needs `epochs` in each run's config.json and `final_train_loss` in each summary.json, at both the pinned point and the doubled-epoch reruns, and it exits with status 2 when the run directories lack those keys.

### E2 gate: reproduction and convergence

E2's claims are read only after two checks pass, one on reproduction and one on convergence. The first replicate's with-arm run_auroc is 0.8502984862625299. The owner's baseline B3 has the same AUROC, 0.8502984862625299, so the reproduction gap is 0.0, within the limit of 0.002, and the reproduction check passes.

For convergence, replicates 1 to 3 were rerun in both arms at 60 epochs, twice the pinned 30, and Supplementary Table S3 lists the six reruns. The with arm at seed 2 ends at a final training loss of 0.4777 at 30 epochs and 0.4761 at 60. That is the largest relative drop over the 6 reruns, a convergence_drop of 0.0034, below the limit of 0.01, so the convergence check passes. Because the gate bounds only the largest drop, a loss that rose at doubled epochs could not fail it. Three of the 6 reruns do have a negative drop, their loss rising slightly: the with arm at seed 1 (-0.000096) and at seed 3 (-0.0011), and the without arm at seed 3 (-0.0024).

Doubling the epochs moves the final training loss by noise rather than by a steady fall: the 6 relative drops average 0.00025, 3 of them are negative, and the largest is 0.34 of the convergence limit (Supplementary Figure S1). The largest absolute change in final training loss from 30 to 60 epochs, 0.0016, is small next to the 0.1021 gap in mean final training loss at 30 epochs between the without arm (0.5765) and the with arm (0.4744). The check reads final training loss alone and never reads held-out AUROC, so it does not show whether the AUROC comparisons would move with longer training.

### The paired statistics of a sweep point, checked by hand and against their records

On a fixture worked by hand (three replicates, 10 held-out rows each), toy.paired reproduces every answer: paired_gain 2/15 with a t-interval half-width of $t_{0.975,2}\sqrt{79}/75$, sd_d $\sqrt{237}/75$, signed_rank_p 0.5, one DeLong rejection (seed 2 only), mean Bayes AUROC 2.8/3, and gap_closed 10/17 with a paired-bootstrap CI of exactly (-1/3, 0.9). It refuses a point, with exit 2, when the arms ran different seeds, when the two arms of a seed disagree on seed, strength, signal, rows or training rows, when they scored different held-out labels, when the saved labels are not the held-out rows the generator draws from the run's config.json, or when a summary's AUROC is not the AUROC of its own saved scores. toy.paired also checks the training settings and the feature lists that the two runs record, as Methods describes from the code. The version of the test file the manifest recorded predates the tests of those further checks, so this paper reports them from the code alone.

point_stats(point_dir) is toy.paired's one-point entry point, with paired kept as an alias of the same function, and its command line writes the printed JSON to `--out PATH` when given. When the gap left by the without arm is at most 0.005, gap_closed and its CI are set to null and gap_closed_reason carries a sentence; when gap_closed is reported, gap_closed_reason is null.

At the E2 point (Supplementary Figure S2, Supplementary Table S5), the summary toy.paired reports can be rebuilt from its own per-seed records. Recomputed from those records, the paired gain, its sd, gap_closed and the mean AUROCs of both arms and of the oracle all equal the reported summary values. A seeded paired bootstrap of gap_closed, redrawn from the same records, gives percentile bounds within 0.00004 of the reported CI. At this point the with arm's held-out AUROC falls short of the oracle's AUROC on the same rows by 0.0009 on average over the seeds.

### The evaluation command never reads the held-out score when selecting on validation

toy.eval keeps the goal command unchanged: with no `--summary`, `--split held_out` reads the summary named by WAYLINE_ARTIFACT and prints `auroc: 0.8502984862625299` for owner/sample-summary.json. Named with `--summary owner/sample-summary.json`, the same summary prints the same value. `--split val` fails on a summary that has no `val_auroc` rather than falling back to the held-out `auroc`. Likewise, `--split held_out` fails on a `--val-fraction` summary, which has no `auroc`. Selecting by validation score therefore never reads the held-out metric through this command.

### How a prior work counts as settled in the literature placement

toy.placement counts an entry toward resolved_refs only when its dossier says existence 'verified' and its measures_paired_gain is true or false. An entry whose measures_paired_gain is null counts toward neither number, and its slug is listed as unsettled. An entry with no dossier agrees only when its existence is 'missing', and it then counts as unresolved. An entry marked 'verified' or 'unresolved' with no dossier, or 'missing' when a dossier exists, is a mismatch and makes the command exit 1.

### E6: literature placement of C3-C6 (C8)

C8 holds that none of the works found by search measures what C3 to C6 measure: the paired held-out AUROC gain of an explicit product column, read against a known ceiling and a zero-strength control. All five placement entries agree with their dossiers' existence ('verified') and DOI, so toy.placement lists no mismatches. Only two of the five works can be settled from their abstracts: DeLong 1988, a test for correlated ROC areas, and Dietterich 1998, tests for comparing learning algorithms. Neither measures a held-out AUROC gain from an explicit product column, so resolved_refs is 2. No resolved work measures the paired gain against a no-interaction control (prior_measures_gain = 0), so A9, under which such a prior measurement would make C8 wrong, is not confirmed by the current reading. Friedman 2008, Lou 2013 and Bien 2013, the three works about interaction models, are still unsettled. Their abstracts report no held-out AUROC against a no-interaction control. Friedman's and Bien's dossiers are at level 2 but still hold only the abstract, and Lou's is at level 0. The recorded verdict on C8 is 'unresolved', with resolved_refs at 2. The rule E6 applies reports C8 unresolved whenever fewer than 4 works are resolved. An unresolved C8 is neither supported nor contradicted by prior work, and settling it needs the three interaction papers read past their abstracts.

### E2: paired AUROC gain of the x3\*x4 column over 20 seeds {#R14}

Over the 20 paired replicates of E2, each with 16000 training rows, the $x_3x_4$ column raises held-out AUROC by a mean paired gain of 0.0872, with a 95% t-interval from 0.0843 to 0.0900. The interval lies wholly above zero, so A2 is not confirmed; under A2 the project would not have claimed that the column helps. All 20 per-seed differences $d_i$ are positive, from 0.0772 to 0.0977. The exact two-sided Wilcoxon signed-rank p over the 20 differences is $1.9 \times 10^{-6}$. The DeLong test of the two correlated AUROCs rejects at 0.05 on 20 of the 20 replicates. The SD of the 20 per-seed differences is 0.0060, not above the 0.02 rule that would add seeds 21 to 50, so no seeds were added. C3 is supported: the interval's lower bound is above zero, the signed-rank p is below the limit of 0.05, and the E2 gate passed.

The with arm's mean held-out AUROC over the 20 replicates is 0.8552. The without arm's is 0.7681. The oracle's mean AUROC on the same held-out rows is 0.8561. The column therefore closes a fraction gap_closed of 0.990 of the without arm's gap to the Bayes ceiling, with a 95% paired bootstrap CI from 0.986 to 0.994 over 10000 resamples. The denominator of that ratio, the mean over replicates of the oracle's AUROC minus the without arm's, is 0.0881, above the floor of 0.005 below which gap_closed is not reported.

The oracle's mean AUROC lies 0.0009 above the with arm's mean and 0.0881 above the without arm's, so neither arm exceeds the oracle by more than the slack of 0.002 and C2's bound part is supported. The oracle's AUROC on a seed's own held-out rows is not a strict ceiling for that seed: one of the 20 replicates has a with-arm AUROC above it, by 0.00009. With E1's ceiling part also holding, C2 is supported as a whole. E2's mean with-arm AUROC, 0.8552, is above the goal of 0.82, so A7 does not hold; under A7 the goal would have been met by its single seeded run while the 20-seed mean fell short.

## held-out AUROC of at least 0.82, measured on the held-out split with src/toy/eval.py

The goal is measured by the project's own evaluation command on the held-out fifth. E5 is the loop that would try to reach it, choosing any change on a validation split and counting every read of the held-out fifth.

### Evaluation command

O2's measure is the command `PYTHONPATH=src python3 -m toy.eval --split held_out`, which prints the held-out AUROC of the toy.train summary that WAYLINE_ARTIFACT names (R9, Methods). Every summary source accepts a run directory, not only `--summary`: read_metric passes every artifact through summary_path, so a positional path or a WAYLINE_ARTIFACT that names a directory has its summary.json read. A test of the WAYLINE_ARTIFACT and positional cases was added after the manifest recorded tests/test_eval.py. The recorded test file does not hold that test, so this paper rests the behavior on the recorded code alone.

### E5: the goal run against O2's 0.82 (C7)

The goal run, toy.train at its project-start defaults with seed 1, scores a held-out AUROC of 0.8503, so the goal of 0.82 is met by its own measure. It lies 0.0303 above the goal. At the default settings the start run's held-out AUROC is 0.8503 at seed 1, 0.8488 at seed 2 and 0.8632 at seed 3, with a mean of 0.8541. The conductor's keep-if-better judgment kept the start at that three-seed mean, 0.8541, while the goal itself is read from the single seed-1 run.

Because the start run already meets the goal, E5 tried 0 candidate changes and kept none, so no setting was chosen on held-out data. The held-out fifth was read by 1 candidate, the unchanged start run, over 3 seeded scorings, within the limit of 6 held-out reads. E1's Bayes ceiling of 0.8555 is not below the goal, so A6 does not hold, and the goal run lies 0.0052 below that ceiling; under A6 no model could have met the goal on this generator. C7 is supported: the goal run's AUROC is at least 0.82, the held-out reads are within 6, and every kept change was chosen by val_auroc, which holds trivially because no change was kept.

## Does generate.py plant a feature interaction in the label, and what is the Bayes-optimal held-out AUROC it allows?

The strength parameter that the sweeps need was added to the generator without moving its default draw (R1). E1 then read the planted interaction, the additive gap and the Bayes ceiling off D2, a draw of $10^6$ rows (R11).

### Default draw stays fixed under the strength parameter

At strength 1.0, generate(1, signal=4.0, rows=20000), serialised as sorted-key JSON lines (training rows, then held-out), has SHA-256 2ab2d229839a4c61ebe9c3b61c23bf04170f59e889c3839293acafd5a180ae55. This digest was measured on the code before the change and is unchanged after it. The feature columns, the `interaction` column and the random stream do not depend on the strength, because the Gaussian noise draw is made regardless. Only the label can change, so the sweep points share common random numbers.

### Oracle audit cost on the 10\^6-row draw D2

No recorded artifact holds the time or memory the audit of D2 took, or the outcome of a run of the budget test, so this part reports only the limits the test set and no cost. The budget test, as the manifest recorded it at run t53-a1, held an audit of 1000000 rows at seed 10001, the seed of D2, to a wall-clock limit of 3600 seconds and a peak child memory limit of 4.0 GB. The test now in the repository runs a stand-in draw of 1000000 rows at seed 20001 instead, outside the seeds of D1 and D2, so it never computes E1's own audit.

### E1: planted interaction, additive gap and Bayes ceiling on D2

At signal 4.0 and strength 1.0, the label rule puts a weight of $4.0 \cdot 1.1 \cdot 1.0 = 4.4$ on $x_3x_4$ in the latent log-odds (R4). D2 is a draw of 1000000 rows at seed 10001, made at signal 4.0 and strength 1.0. The audit of D2 reports an interaction_weight of 4.4 and an interaction_coefficient of 1.1. An unpenalised additive logistic model on $x_1..x_4$ was fit to the first half of D2, 500000 rows. It was scored on the second half, another 500000 rows. On that scored half its AUROC is 0.7681. The oracle's AUROC on the same rows is 0.8563. The additive gap, the oracle's AUROC minus the additive model's on the scored half, is 0.0882, far above C1's threshold of 0.005.

The additive model's coefficients on $x_3$ and $x_4$ are about zero (-0.0035 and 0.0020), against 1.61 and -1.07 on $x_1$ and $x_2$. The interaction leaves no marginal linear trace that an additive model could use. The additive fit keeps the generator's $x_1{:}x_2$ ratio of -1.5. The interaction therefore costs the additive model signal without biasing the relative weights of its linear terms.

The oracle's 20-bin calibration error on D2 is 0.0039, within the limit of 0.01. Each equal-count bin holds 50000 rows. The generator's Bayes-optimal AUROC on all of D2 is 0.8555. Its DeLong 95% half-width is 0.00072, inside C2's precision of ±0.002. The oracle's AUROC on the scored half and the Bayes AUROC on all of D2 differ by 0.0008. C1 is supported: the interaction weight is not zero, the additive gap is above 0.005, and the calibration error is at most 0.01. C2's ceiling part is supported, since the half-width is at most 0.002 and the calibration error at most 0.01. Its bound part is tested on E2 (R14).

The goal sits between the additive model and the ceiling (Supplementary Figure S3, Supplementary Table S6). The ceiling lies 0.0355 above the goal of 0.82, so A6 does not hold and the goal is not out of reach by construction. The goal lies 0.0519 above the additive model's AUROC on D2, so the additive logistic model falls short of it on this generator. Reaching the goal requires closing 0.59 of the distance between the additive model's AUROC and the Bayes ceiling.

## Does the AUROC gain from interaction terms vanish when the generator plants no interaction, and how does it grow with interaction strength and shrink with sample size?

E3 repeats E2's paired protocol at six interaction strengths, at 16000 training rows. E4 repeats it at seven training sizes, at the default strength and with no planted interaction.

### E3: paired gain across interaction strengths (C4, C5)

Table 1 gives the mean paired gain and gap_closed at each strength. At $m = 0$ (no planted interaction, 16000 training rows, 20 paired seeds), the column's mean paired gain is -0.000319, with a 95% t-interval from -0.000597 to -0.000041. That interval lies inside -0.01 to 0.01, so C4 is supported. Its lower bound is above -0.01, so A4 does not hold: at 16000 rows the unneeded column does not cost more than C4's tolerance. The cost is small but detectable: 16 of the 20 per-seed differences are negative, and the exact signed-rank p is 0.0049. In size it is about 31 times smaller than C4's tolerance of 0.01. The DeLong test rejects at 0.05 on 2 of the 20 replicates. gap_closed is not reported at $m = 0$, because the without arm's mean gap to the oracle, 0.0008, is not above the floor of 0.005. There the with arm's mean held-out AUROC is 0.8128, the without arm's 0.8131, and the oracle's 0.8139.

The planted strengths follow. At $m = 0.25$ the mean paired gain is 0.0069, with a 95% t-interval from 0.0061 to 0.0077. There gap_closed is 0.870, with a CI from 0.833 to 0.905, and the DeLong test rejects on 20 of the 20 replicates. At $m = 0.5$ the gain is 0.0267 (0.0254 to 0.0280), and gap_closed is 0.959 (0.946 to 0.971). At $m = 1$, which reuses E2's runs, the gain is 0.0872 (0.0843 to 0.0900), and gap_closed is 0.990. At $m = 2$ it is 0.2031 (0.1991 to 0.2070), and gap_closed is 0.997. At $m = 4$ it is 0.3143, with an interval from 0.3110 to 0.3177, wholly above zero. At $m = 4$ the with arm's mean held-out AUROC is 0.9570, against the oracle's 0.9574 and the without arm's 0.6426, and gap_closed is 0.999.

The mean paired gain rises strictly at every step of the strength grid. strength_spearman, Spearman's correlation between $m$ and the mean paired gain over the 6 points, is 1.0. C5 is supported: strength_spearman is at least 0.9, and the lower bound of the $m = 4$ interval, 0.3110, is above zero. A3 is confirmed: the gain is about zero at strength 0 and rises with the planted strength, so it restates what generate.py plants and is not a finding about interaction terms apart from the generator. No point's SD of $d_i$ exceeds the 0.02 rule, so seeds 21 to 50 are not added at any strength. The largest SD of $d_i$ over the 6 points is 0.0085.

### E4: paired gain across training sizes (C6)

Table 2 gives the mean paired gain and its 95% t-interval at each training size, for $m = 1$ and $m = 0$; the two points at 16000 rows are E2's and E3's runs. At $m = 1$ with 1000 training rows the mean paired gain over 20 seeds is 0.0875, with an interval from 0.0843 to 0.0907. At 64000 rows it is 0.0879, with an interval from 0.0863 to 0.0894. The gains at 2000, 4000, 8000 and 32000 rows are 0.0872, 0.0871, 0.0873 and 0.0874. Over all 7 sizes the gain stays between 0.0871 and 0.0879, a range of 0.0007, and it neither strictly falls nor strictly rises with size.

gain_shrink at $m = 1$, the mean over the 20 shared seeds of the per-seed gain at 1000 rows minus the per-seed gain at 64000, is -0.00036, with a paired 95% t-interval from -0.0037 to 0.0029. C6 is supported: gain_shrink is at most the limit of 0.005, and so is the upper bound of its interval. A5, the expectation that the gain falls as training rows grow, is not confirmed, because the interval's lower bound is not above 0.005, and C6's verdict is not unresolved. At 1000 rows the with arm's mean held-out AUROC is 0.8550, against the oracle's 0.8561 and the without arm's 0.7675, so the column already closes a fraction 0.987 of the gap to the Bayes ceiling. At 64000 rows the same three are 0.8540, 0.8548 and 0.7661, and gap_closed is 0.990.

Table 2 also gives the gain at each size with no planted interaction. At 1000 rows it is -0.000247, with an interval from -0.000509 to 0.000016; 12 of the per-seed differences are negative and the exact signed-rank p is 0.076. At 32000 rows, 14 of the differences are negative and the exact signed-rank p is 0.024. The interval lies inside -0.01 to 0.01 at all 7 of the 7 sizes, so the unneeded column costs less than C4's tolerance at every size from 1000 to 64000 rows. The interval lies wholly below zero at 4 of the 7 sizes (8000, 16000, 32000 and 64000 rows) and wholly above zero at none, and the most negative mean, -0.000319, is at 16000 rows. At $m = 0$, gain_shrink between 1000 and 64000 rows is -0.000124, with an interval from -0.000416 to 0.000167 that spans zero; it is reported, not claimed. No point of either size sweep has an SD of $d_i$ above the 0.02 rule, so no seeds beyond 20 are added; the largest SD over the 14 points is 0.0068.

## Documentation site for the toy package, with the docstrings its build checks for

This result answers none of the four questions. It is reported because building the documentation found a docstring that described code the experiments never ran. train.py's module docstring and the docstring of ready_interactions had said that a batch_size by batch_size gram tensor down-weights interaction terms for rows that look duplicated. The code allocates a tensor of zeros and deletes it before training without reading it. Training draws its minibatches at a fixed size of 256. So `--batch-size` changes neither the fit nor the scores, and both docstrings now say so.

  --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  finding           quantity                                               value                source
  ----------------- ------------------------------------------------------ -------------------- ----------------------------------------------------------------------------------------------------
  t3-a1-f1          seed                                                   1                    tests/test_train.py#SMALL

  t3-a1-f1          rows                                                   2000                 tests/test_train.py#SMALL

  t3-a1-f1          epochs                                                 2                    tests/test_train.py#SMALL

  t3-a1-f1          device                                                 cpu                  tests/test_train.py#SMALL

  t3-a1-f1          held-out AUROC at base commit and after change         0.8352720450281426   tests/test_train.py#BASE_AUROC

  t3-a1-f2          without-arm interaction weight: final equals initial   asserted             tests/test_train.py#test_arms_share_initial_weights_and_without_never_moves_the_interaction_weight

  t3-a1-f2          both arms: identical initial weights                   asserted             tests/test_train.py#test_arms_share_initial_weights_and_without_never_moves_the_interaction_weight
  --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  --------------------------------------------------------------------------------------------------------------------------------------------------------------
  finding    quantity                                         reference                                 cases      tolerance_kind         tolerance   line
  ---------- ------------------------------------------------ ----------------------------------------- ---------- ---------------------- ----------- ----------
  t5-a3-f1   exact signed-rank p (no ties)                    scipy.stats.wilcoxon exact                10         decimal places         12          L38

  t5-a3-f2   exact signed-rank p (tied)                       scipy wilcoxon PermutationMethod          1          decimal places         12          L42-L43

  t5-a3-f3   95% t-interval bounds                            scipy.stats.t.interval                    5          decimal places         10          L29-L30

  t5-a3-f4   DeLong AUROCs and covariance (tied)              literal pairwise DeLong kernel            5          absolute               1e-12       L68-L69

  t5-a3-f5   Spearman rho (tied integers)                     scipy.stats.spearmanr                     5          decimal places         12          L84

  t5-a3-f6   paired percentile bootstrap CI, ratio of means   scipy.stats.bootstrap paired percentile   1          fraction of CI width   0.05        L98-L106
  --------------------------------------------------------------------------------------------------------------------------------------------------------------

  --------------------------------------------------------------------------------------------------------------------------
  arm        seed       epochs_pinned   loss_pinned           epochs_double   loss_double           relative_drop
  ---------- ---------- --------------- --------------------- --------------- --------------------- ------------------------
  with       1          30              0.4723849892616272    60              0.4724302291870117    -9.576918490834106e-05

  with       2          30              0.4777405858039856    60              0.47609663009643555   0.0034411053956896914

  with       3          30              0.47309911251068115   60              0.4736323356628418    -0.0011270855050454275

  without    1          30              0.5749234557151794    60              0.5743612051010132    0.000977957341237443

  without    2          30              0.5817123055458069    60              0.5813217759132385    0.0006713449738731841

  without    3          30              0.5729799866676331    60              0.5743486285209656    -0.0023886381464950255
  --------------------------------------------------------------------------------------------------------------------------

  --------------------------------------------------------------------------------------------------------------------------
  arm        seed       epochs_pinned   loss_pinned           epochs_double   loss_double           relative_drop
  ---------- ---------- --------------- --------------------- --------------- --------------------- ------------------------
  with       1          30              0.4723849892616272    60              0.4724302291870117    -9.576918490834106e-05

  with       2          30              0.4777405858039856    60              0.47609663009643555   0.0034411053956896914

  with       3          30              0.47309911251068115   60              0.4736323356628418    -0.0011270855050454275

  without    1          30              0.5749234557151794    60              0.5743612051010132    0.000977957341237443

  without    2          30              0.5817123055458069    60              0.5813217759132385    0.0006713449738731841

  without    3          30              0.5729799866676331    60              0.5743486285209656    -0.0023886381464950255
  --------------------------------------------------------------------------------------------------------------------------

  --------------------------------------------------------------------------------------------------------------------------------------
  seed    auroc_without   auroc_with   bayes_auroc   d          gap_without   shortfall_with   ratio_d_over_gap   delong_z   delong_p
  ------- --------------- ------------ ------------- ---------- ------------- ---------------- ------------------ ---------- -----------
  1       0.767194        0.850298     0.850748      0.083105   0.083554      0.000449         0.994622           14.4172    4.033e-47

  2       0.771301        0.848753     0.849677      0.077452   0.078376      0.000924         0.988213           13.6924    1.127e-42

  3       0.784683        0.863155     0.863371      0.078472   0.078687      0.000216         0.997260           13.8754    8.933e-44

  4       0.771641        0.861392     0.863687      0.089750   0.092045      0.002295         0.975063           16.4395    9.980e-61

  5       0.778581        0.860869     0.860906      0.082289   0.082325      0.000037         0.999557           14.7127    5.346e-49

  6       0.770654        0.855428     0.856174      0.084774   0.085520      0.000746         0.991281           15.1453    8.133e-52

  7       0.767882        0.856436     0.856936      0.088554   0.089054      0.000500         0.994387           15.5372    1.944e-54

  8       0.753696        0.847417     0.848923      0.093722   0.095228      0.001506         0.984184           17.1706    4.408e-66

  9       0.770779        0.860207     0.861861      0.089428   0.091082      0.001654         0.981838           16.5703    1.142e-61

  10      0.764887        0.857875     0.858464      0.092988   0.093577      0.000589         0.993711           14.9749    1.071e-50

  11      0.767354        0.844597     0.845147      0.077243   0.077793      0.000550         0.992929           13.8855    7.753e-44

  12      0.769233        0.856366     0.856412      0.087133   0.087179      0.000046         0.999469           15.1255    1.100e-51

  13      0.767709        0.854022     0.854280      0.086313   0.086571      0.000258         0.997026           15.4393    8.911e-54

  14      0.773388        0.859313     0.860894      0.085925   0.087505      0.001581         0.981938           14.1066    3.457e-45

  15      0.765872        0.861595     0.864612      0.095722   0.098739      0.003017         0.969447           17.5249    9.253e-69

  16      0.765056        0.848202     0.848112      0.083146   0.083056      -0.000091        1.001090           14.5957    2.993e-48

  17      0.761641        0.853160     0.854322      0.091519   0.092681      0.001162         0.987465           15.7782    4.394e-56

  18      0.773618        0.857269     0.857614      0.083651   0.083996      0.000345         0.995898           15.4504    7.493e-54

  19      0.762064        0.856515     0.856707      0.094450   0.094642      0.000192         0.997971           16.0737    3.898e-58

  20      0.753901        0.851572     0.853888      0.097671   0.099986      0.002316         0.976837           17.7859    9.088e-71
  --------------------------------------------------------------------------------------------------------------------------------------

  criterion   quantity                value     limit         passes
  ----------- ----------------------- --------- ------------- --------
  C1          interaction_weight      4.4       != 0          True
  C1          additive_gap            0.0882    \> 0.005      True
  C1, C2      calibration_error       0.0039    \<= 0.01      True
  C2          bayes_auroc_halfwidth   0.00072   \<= 0.002     True
  A6          bayes_auroc - goal      0.0355    \< 0 for A6   False

  m      mean paired gain   95% CI low   95% CI high   gap_closed
  ------ ------------------ ------------ ------------- --------------
  0      -0.000319          -0.000597    -0.000041     not reported
  0.25   0.0069             0.0061       0.0077        0.870
  0.5    0.0267             0.0254       0.0280        0.959
  1      0.0872             0.0843       0.0900        0.990
  2      0.2031             0.1991       0.2070        0.997
  4      0.3143             0.3110       0.3177        0.999

  : Table 1: E3: mean paired AUROC gain of the x3·x4 column at each interaction strength m, at 16000 training rows with 20 paired seeds per point, with its 95% t-interval and gap_closed. gap_closed is not reported at m = 0, where the without arm's mean gap to the oracle is not above 0.005. The m = 1 point is E2's runs. Values are rounded to the precision the intervals support; analysis/E3/verdict.json holds them at full precision. {#tbl:T1}

  -------------------------------------------------------------------------------------------------------
  training rows   m = 1 gain   m = 1 CI low   m = 1 CI high   m = 0 gain   m = 0 CI low   m = 0 CI high
  --------------- ------------ -------------- --------------- ------------ -------------- ---------------
  1000            0.0875       0.0843         0.0907          -0.000247    -0.000509      0.000016

  2000            0.0872       0.0842         0.0902          -0.000129    -0.000276      0.000017

  4000            0.0871       0.0840         0.0903          -0.000111    -0.000274      0.000052

  8000            0.0873       0.0843         0.0902          -0.000153    -0.000291      -0.000016

  16000           0.0872       0.0843         0.0900          -0.000319    -0.000597      -0.000041

  32000           0.0874       0.0857         0.0891          -0.000156    -0.000302      -0.000010

  64000           0.0879       0.0863         0.0894          -0.000122    -0.000238      -0.000006
  -------------------------------------------------------------------------------------------------------

  : Table 2: E4: mean paired AUROC gain of the x3·x4 column at each training size, at the default strength (m = 1) and with no planted interaction (m = 0), 20 paired seeds per point, with 95% t-intervals. The 16000-row points are E2's (m = 1) and E3's (m = 0) runs. Values are rounded to the precision the intervals support; analysis/E4/verdict.json and analysis/E3/verdict.json hold them at full precision. {#tbl:T2}

# Discussion

## How much the column helps

On the default generator, the $x_3x_4$ column lifts the same logistic model from a mean held-out AUROC of 0.7681 to 0.8552 over 20 paired replicates. The mean paired gain is 0.0872, with a 95% t-interval from 0.0843 to 0.0900. All 20 seeds gain, and the DeLong test of each seed's two correlated AUROCs rejects at 0.05 on all 20. A difference of a point or two from one seeded split could have been noise. A gain of this size, seen on every seed, is not. Read against the ceiling, the gain closes 0.990 of the gap the model without the column leaves, with a paired bootstrap CI from 0.986 to 0.994. The model with the column ends 0.0009 below the oracle's mean AUROC on the same rows.

## What the gain does and does not show

The strength sweep is the test set in advance for the objection that the effect is planted, and A3 is confirmed. With no planted interaction, at $m = 0$, the column's mean paired gain is -0.000319 AUROC. As the planted weight on $x_3x_4$ grows, the gain rises at every step of the strength grid, reaching 0.3143 at $m = 4$, and its Spearman correlation with strength is 1.0. The gain therefore restates what generate.py plants and is not a finding about interaction terms apart from the generator. As a null control, the zero-strength point shows that the unneeded column has a measurable cost: 16 of 20 seeds score lower with it, and the exact signed-rank p is 0.0049. That cost is about 31 times smaller in size than C4's harmlessness tolerance of 0.01. These readings come from a single training size, 16000 rows.

## Sample size

Over a 64-fold range of training rows, from 1000 to 64000, the gain at the default strength does not shrink: gain_shrink's t-interval, -0.0037 to 0.0029, lies wholly below C6's limit of 0.005. C6 was stated in advance as what one would expect if train.py's model, linear in its inputs, cannot represent $x_3x_4$ without the column at any size. The result agrees with that expectation, though it does not test the model's capacity directly. It holds only across E4's size grid at the generator's default signal, feature count and noise: the with arm already closes 0.987 of the gap to the Bayes ceiling at 1000 rows, so on this generator sample size does not change the answer.

With nothing planted, the column's cost stays inside C4's tolerance of 0.01 at every size, and its most negative mean, -0.000319 at 16000 rows, is about 31 times smaller in size than that tolerance. The cost shows no sign of falling as training rows grow: at $m = 0$, gain_shrink between 1000 and 64000 rows is -0.000124, with an interval from -0.000416 to 0.000167 that spans zero. A cost from overfitting one unneeded weight would be expected to fall as rows are added. These runs therefore do not support reading the cost as overfitting, and they do not show what causes it. For K4's question about what spurious terms cost, they give a size and no mechanism: the cost is detectable at some sizes, and in mean it is never larger than 0.000319 AUROC.

## Does generate.py plant a feature interaction in the label, and what is the Bayes-optimal held-out AUROC it allows?

Yes. generate.py builds the latent log-odds as signal times $(0.6x_1 - 0.4x_2 + 1.1\,m\,x_3x_4)$, adds Gaussian noise with sd 1.0, and draws the label as a coin flip whose probability is the logistic of that latent. On D2, drawn at signal 4.0 and strength 1.0, the oracle reports an interaction_weight of 4.4 from an interaction_coefficient of 1.1. D2 holds 1000000 rows at seed 10001; an additive logistic model fit to 500000 of them and scored on the other 500000 reaches 0.7681, while the oracle reaches 0.8563 on the same scored rows, an additive gap of 0.0882, far above C1's limit of 0.005. The additive model puts almost no weight on the two features that form the product, so the interaction leaves no straight-line trace that a model without the product column could use. The oracle's probabilities fit D2's labels, with a calibration error of 0.0039 over equal-count bins, inside the limit of 0.01. The generator's Bayes-optimal AUROC on all of D2 is 0.8555, with a DeLong half-width of 0.00072, inside C2's precision of 0.002. C1 and the ceiling part of C2 are therefore supported. E2's held-out rows give a matching figure, a mean oracle AUROC of 0.8561 over 20 replicates. The ceiling is set by the planted strength: in E3's sweep the oracle's mean held-out AUROC is 0.8139 at $m = 0$ and 0.9574 at $m = 4$, so the figure of 0.8555 holds only for strength 1.0. At these settings the ceiling sits 0.0355 above the goal of 0.82, so the generator itself does not put the goal out of reach.

The goal itself, O2, was met by the default run, and only with the column. The goal run, toy.train at its defaults with seed 1, scores 0.8503 against the goal of 0.82. That is 0.0052 below the ceiling. Without the column the model falls short of the goal: E2's without arm averages 0.7681, and on D2 the goal lies 0.0519 above the additive model's AUROC. E2's with arm averages 0.8552 over 20 seeds, so the goal is met by the 20-seed mean as well as by the one seeded run that measures it, and A7 does not hold. The conductor's keep-if-better record holds the start run's three-seed mean, 0.8541, while the goal is read from the seed-1 run alone. On the leakage concern, no setting was chosen on held-out data: the start run already met the goal, E5 tried 0 candidate changes, and the held-out fifth was read by 1 candidate over 3 seeded scorings, within the limit of 6. C7 is supported, but its condition that every kept change was chosen on validation AUROC holds only because none was kept. The validation path that would guard a tuned change (R9) was therefore built and tested but never used by the goal loop.

## Does the AUROC gain from interaction terms vanish when the generator plants no interaction, and how does it grow with interaction strength and shrink with sample size?

It vanishes for practical purposes. With no planted interaction and 16000 training rows, the mean paired gain over 20 seeds is -0.000319, and its 95% t-interval, -0.000597 to -0.000041, lies inside the harmlessness band of -0.01 to 0.01, so C4 is supported. It does not vanish exactly: 16 of the 20 per-seed differences are negative, with an exact signed-rank p of 0.0049, but the cost is about 31 times smaller than the tolerance. The same holds at every training size tried: with nothing planted, the interval lies inside the band at 7 of the 7 sizes from 1000 to 64000 rows, and wholly below zero at 4 of them.

The gain grows with the planted strength, from 0.0069 at $m = 0.25$ to 0.3143 at $m = 4$, rising strictly at every step, so C5 is supported. At the strongest setting the column recovers almost all that the generator allows, a gap_closed of 0.999. The gain does not shrink with sample size: at $m = 1$ it stays between 0.0871 and 0.0879 across the 7 sizes, and gain_shrink, -0.00036, has an interval wholly below the limit of 0.005, so C6 is supported and A5 is not confirmed. With the gap already 0.987 closed at 1000 rows, there was little left for more data to change. These readings describe what this one generator plants, not interaction terms in general. The strength sweep was run at a single training size of 16000 rows, and the size sweep only at $m = 1$ and $m = 0$.

## Do the interaction terms help, and by how much? (whether adding feature interaction terms improves held-out AUROC on a synthetic two-class set)

Yes, on this generator. At its default settings the $x_3x_4$ column raises held-out AUROC by a mean paired gain of 0.0872. It helped on every seed: all 20 per-seed differences are positive, the exact signed-rank p is $1.9 \times 10^{-6}$, and C3 is supported. How much it helps depends on how strong an interaction generate.py plants: about nothing when none is planted, and more at every step of the strength grid. Training size barely changes it: across 7 sizes the gain moves within a range of 0.0007. The answer is therefore a yes for this generator only: the gain repeats what generate.py puts into the labels and says nothing about interaction terms on data outside it.

Four limits follow. First, the whole study uses one generator at one signal, one feature count and one noise level, so it cannot support a general claim about interaction terms on tabular data. Second, the literature placement could not settle the three works on interaction models from their abstracts, so the paper's claims are neither supported nor contradicted by prior work yet. Third, the only model tested is linear in its inputs; whether an explicit product column still helps a model that can learn interactions unaided, such as gradient-boosted trees or an MLP, is left for future work. Fourth, the recorded hashes pin every run's outputs but not all of the code that produced them (Methods), so this paper's descriptions of the code are of the code at its commit.

# Methods

The code locators cited in this section name source files as they stand at the paper's commit. The project's manifest records the SHA-256 of every run output, and of the source and test files that particular runs used, but not of all the code behind the results. It has no entry for src/toy/stats.py, src/toy/sweep.py, or the scripts under experiments/ and analysis/. It records src/toy/train.py and src/toy/oracle.py only as they stood at the documentation run, after the experiments had run. Its one record of src/toy/paired.py predates the checks on training settings and feature lists described under Statistics, and that file changed again before the E2, E3 and E4 analyses ran. The descriptions below are therefore of the code at the commit, and the recorded hashes alone do not show that each result was produced by exactly that code.

## Synthetic generator

Each row's label is drawn from the latent log-odds $\text{signal}\cdot(0.6x_1 - 0.4x_2 + 1.1\,m\,x_3x_4) + \varepsilon$, with $\varepsilon\sim N(0,1)$ and $m$ an opt-in interaction strength multiplier: the default $m = 1$ leaves the default draw unchanged, and $m = 0$ plants no interaction. The label is a coin flip whose probability is the logistic of that latent.

## Arms and pinned settings

Both arms fit the same five-column design, $x_1..x_4$ and $x_3x_4$. In the baseline arm, `without`, the $x_3x_4$ column is filled with 0.0, so its weight gets no gradient and the fitted function is the $x_1..x_4$ model, while both arms draw the same initial weights and the same minibatch order from the shared seed. Each arm is a `torch.nn.Linear` logistic regression trained with `BCEWithLogitsLoss` and the Adam optimiser in shuffled minibatches of 256. After the last epoch it is scored by held-out AUROC and by its final training loss, the mean BCE over the rows it was fitted on, computed in eval mode. A training size $n$ keeps the first $n$ training rows of the draw. A validation fraction $f$ holds out the last $f$ of those rows, trains on the rest, and scores only the validation rows, so the held-out fifth is never read. The pinned settings, recorded in `configs/arms.json` from the base commit, are Adam with learning rate 0.1, 30 epochs, minibatch 256, weight decay 0, signal 4.0, 20000 rows, a held-out fraction of 0.2, and seeds 1 to 20. A `--config` file sets the signal, rows, epochs and learning rate, and is refused if it pins any other setting that differs from what the code runs.

In E2, replicate $i = 1..20$ uses seed $i$ for both the generator and torch, and is trained twice on the same draw with the pinned settings: once with the $x_3x_4$ column (the `with` arm) and once with `--no-interaction` (the `without` arm). Each run saves its held-out scores to its own directory, `<root>/<arm>/seed<i>/`. To check convergence, replicates 1 to 3 are rerun in both arms at 60 epochs, twice the pinned 30, and any extra flag given to the runner is passed through to every run.

## Statistics

The paired statistics use the Python standard library alone. The mean of the per-replicate differences $d_i$ has a two-sided 95% t-interval on $n-1$ degrees of freedom, with the t quantile found by bisection on Student's t CDF through the regularized incomplete beta function. The Wilcoxon signed-rank p is exact and two-sided, $p = \min(1, 2\min(P(R^+\le r^+), P(R^+\ge r^+)))$; zero differences are dropped, absolute differences get average ranks, and the null distribution is enumerated over all $2^n$ sign assignments. For AUROCs computed on the same rows, a nonparametric approach based on generalized U-statistics gives an estimated covariance matrix that accounts for their correlation. ([DeLong et al. 1988](#ref-delong-1988-comparing-areas-under-two-more)) toy.stats computes that covariance as $S_{10}/m + S_{01}/n$ from the sample covariances of the positives' and negatives' placement values, which it builds from midranks in linearithmic time. ([Sun and Xu 2014](#ref-sun-2014-fast-implementation-delong-s-algorithm)) The DeLong test refers $z = (A-B)/\sqrt{\mathrm{var}A + \mathrm{var}B - 2\,\mathrm{cov}(A,B)}$ to the standard normal, two-sided. Spearman's correlation is Pearson's correlation of average ranks. gap_closed is a ratio of means. Its CI is a percentile bootstrap that resamples whole replicates with replacement, keeping each replicate's pair together, and interpolates linearly between order statistics. The paper reports estimates rounded to the precision their intervals support.

For each seed at a sweep point, toy.paired pairs the two arms' runs and takes $d_i = \text{AUROC}_{\text{with},i} - \text{AUROC}_{\text{without},i}$ on the held-out rows both arms scored. It redraws those rows from the run's recorded seed, signal, rows and strength, and scores them with the oracle's $P(y=1\mid x)$, at the strength and signal recorded in the run's config.json, to give $\text{bayes}_i$. Over the replicates it reports the mean of $d_i$ with its 95% t-interval, the SD of $d_i$ against a rule of 0.02, the exact two-sided signed-rank p, and the number of replicates whose DeLong test rejects at 0.05. It also reports $\text{gap\_closed} = \overline{d} / \overline{(\text{bayes}_i - \text{AUROC}_{\text{without},i})}$ with a 10,000-resample paired percentile bootstrap CI, but only when that denominator exceeds 0.005; otherwise gap_closed and its CI are null and gap_closed_reason states the mean gap and the threshold. The bootstrap CI is set at 95% to match the t-interval, because the spec gives it no level of its own. point_stats returns the statistics of one point as one record, the same record the command line prints and writes to `--out` when given.

toy.paired pairs the two arms of a seed only when both runs record the same draw (seed, strength, signal, rows and training rows) and the same training settings (validation fraction, epochs, learning rate, minibatch size and the content of the pinned settings file). A with run must record the features $x_1..x_4$ and the interaction, a without run $x_1..x_4$ alone, and a run that records other features, or lacks a compared key, is refused. It also refuses a replicate whose arms scored different labels, whose labels are not the held-out rows the generator draws from the recorded settings, or whose summary AUROC is not the AUROC of its own saved scores. Four recorded keys are not compared, and the spec's list of what the arms share names none of them. The batch size only sizes a scratch matrix that training allocates and frees before the fit. The number of data-loading workers sets how many processes load the seeded minibatches, not which rows they hold, and the device is whichever of CUDA and CPU the job's machine had, so a pair run on different devices is paired only at the precision the two agree to. The settings file's path is not compared because its content is. A point is refused when its two arms ran different sets of seeds. It is also refused when its replicates disagree on any compared draw or training setting.

toy.sweep takes each point's paired statistics from toy.paired, reads the point's strength and training size from its runs' config.json rather than from the directory name, and refuses a sweep whose points disagree on the signal or on the pinned training settings. Points reused from another experiment, E2's $m = 1$ point in E3 and E3's $m = 0$ point in E4, join the sweep from their own directories and are not rerun. Along the strength axis, strength_spearman is Spearman's correlation, with average ranks, between $m$ and the mean paired gain over the points. Along the training-size axis at one strength, gain_shrink is the mean, over the seeds that both the smallest and the largest point ran, of $e_i = d_i^{\text{smallest}} - d_i^{\text{largest}}$, with its paired 95% t-interval; a seed run at only one of the two points does not enter.

The E2 analysis reads the replicates of seeds 1 to 20 only after every run file's hash matches the sha256 of its last manifest entry, and only when both arms hold exactly those seeds. It computes the point's statistics with toy.paired.point_stats, and reads the claims only when the reproduction and convergence gate has passed. C3 is read as supported when the lower bound of the mean gain's 95% t-interval is above zero and the exact signed-rank p is below 0.05. C2's bound part is read as supported when the oracle's mean AUROC is at least each arm's mean minus a slack of 0.002, and C2 as supported when its bound part holds and E1 found its ceiling part supported. A7 is read by comparing the with arm's mean AUROC with the goal of 0.82. The revisit rule is read as sd_d \> sd_rule: an SD of the per-seed differences above 0.02 would add seeds 21 to 50 at the point. verdict.json records each threshold and seed range these rules read under its own key, taken from the constant the rule uses.

## Oracle and Bayes ceiling

The oracle transcribes the generator's label rule term for term, giving the noise-free log-odds $\mu(x)=\text{signal}\cdot(0.6x_1-0.4x_2+1.1\,m\,x_3x_4)$ from the constants `toy.generate` exports. The rows record neither the signal nor the strength they were drawn at, so the caller passes both; the signal defaults to 4.0. Because the generator adds $\varepsilon\sim N(0,1)$ to $\mu(x)$ before the logistic, the probability each label is drawn from is $P(y=1\mid x)=\mathbb{E}_\varepsilon[\sigma(\mu(x)+\varepsilon)]$, which the oracle integrates by 48-node Gauss--Hermite quadrature, dropping nodes whose normalised weight is below $10^{-17}$. The nodes are found by Newton's method on the orthonormal Hermite recurrence; each node's iteration stops once a step is at most $10^{-14}\max(1,|z|)$, an absolute tolerance for $|z|<1$, including the middle node of an odd rule at $z=0$, and a relative one beyond. Since $P(y=1\mid x)$ is strictly increasing in $\mu(x)$, the Bayes-optimal AUROC is computed by ranking rows on $\mu(x)$. Its 95% half-width is $z_{0.975}\sqrt{V}$, with $V$ DeLong's variance and $z_{0.975}$ from Python's `statistics.NormalDist`. The weight reported on $x_3x_4$ is the floating-point product $\text{signal}\cdot(1.1\,m)$, with no rounding. The command line reads that weight, with the line of `generate.py` it is set on, from the source.

Calibration error sorts rows by oracle probability, cuts them into 20 contiguous bins of equal count (sizes differ by at most one), and reports the largest absolute difference between a bin's mean label and its mean probability. The additive baseline is an unpenalised logistic regression with intercept on $x_1..x_4$, fitted by Newton--Raphson from zero on the first half of the rows and stopped when no coefficient moves by more than $10^{-10}$. The additive gap is the oracle's AUROC on the second half minus that regression's AUROC on the same rows. The audit runs on all rows of the draw, training and held-out together, and reports the seed, row count, signal and strength next to the Bayes AUROC with its half-width, the calibration error, the weight on $x_3x_4$ with its source locator, and the additive gap.

The cost of the audit is checked by running the oracle command line as a child process on a 1000000-row draw at default settings with seed 20001, outside the seeds of D1 and D2. The run is timed against a one-hour wall-clock bound that the test sets itself, and the child's peak resident memory, read from the operating system's resource usage for waited-for children, must stay under 4 GB.

The E1 analysis reads the D2 audit only after the audit file's SHA-256 matches its manifest entry. It checks that the label-rule line the audit names in generate.py is the latent log-odds line. It recomputes the calibration error as the largest per-bin gap and the additive gap as the oracle's AUROC minus the additive model's on the held half, before applying C1's and C2's thresholds.

## Convergence check

For each arm and seed rerun at twice the pinned epochs, the convergence check takes the relative drop $(L_{\text{pinned}} - L_{2\times})/L_{\text{pinned}}$ in final training loss against the same arm and seed at the pinned epochs, and reports the largest as convergence_drop. It refuses a rerun whose configured epochs are not exactly twice the pinned ones, and it never reads held-out AUROC. The check is one-sided: it bounds the largest drop at 0.01, so a loss that rose at doubled epochs cannot fail it.

The E2 gate script reads replicate 1's with-arm run_auroc and the owner's sample summary (B3), takes their absolute difference as the reproduction gap, and passes it if the gap is at most 0.002. It takes the convergence drop over the reruns of replicates 1 to 3 in both arms and passes it if the drop is at most 0.01, and the gate passes only if both checks pass. The script also lists and counts the reruns whose final training loss rose at doubled epochs. Its `--check` mode recomputes the gate from the E2 runs and the owner's sample summary without writing, and succeeds only when the recomputed record equals the committed one and the gate passed.

## Evaluation command

eval.py reads one toy.train summary and prints one metric from it. The summary is named by `--summary`, which takes a summary file or a run directory holding summary.json, or else by the positional path or WAYLINE_ARTIFACT. `--split held_out` prints the held-out `auroc`, and `--split val` prints the `val_auroc` of a `--val-fraction` run. Whichever source names the summary, eval.py reads the named file, or the summary.json inside it when the path is a run directory. A summary without the requested split's metric is an error and is never answered from the other split. At the paper's commit, a unittest case for each summary source checks the run-directory reading. The version of that test file recorded in the manifest predates the WAYLINE_ARTIFACT and positional cases (R12).

## Goal loop and held-out reads

The goal loop's starting value is toy.train run at seeds 1, 2 and 3 with its own defaults, given no pinned settings file and no validation split; each seed's held-out AUROC is logged as a `start` line with a null val_auroc and a null keep decision. E5's log holds one line per held-out scoring of one seed of one candidate, giving the candidate's name, the seed, the validation AUROC the candidate was chosen by (null for the start and required for every other candidate), its held-out AUROC, and whether keep-if-better kept it. toy.goallog counts heldout_reads as the number of distinct candidates scored on the held-out fifth, the start included, and heldout_scorings as the number of logged scorings. It reports each candidate's seeds, held-out AUROCs and their mean, mean validation AUROC and keep decision. It refuses a log with a malformed line, a candidate that scores the same seed twice, or a candidate whose lines disagree on the keep decision, and names the offending line.

The E5 analysis takes the goal value from one seeded run, the start run at seed 1, reads that run's held-out AUROC with the function the goal command prints, and never averages over seeds. It counts held-out reads as the distinct candidates in E5's log and checks each start line against its manifest-hashed summary. It reads C7 as supported when the goal run's AUROC is at least 0.82, the held-out reads are at most 6, and every kept change was chosen by val_auroc.

## Literature placement

The placement reads one entry per scouted work and cross-checks each entry's existence and DOI against the dossier at `research/refs/<slug>/dossier.json`; an entry for a work with no dossier must state existence 'missing', and any disagreement is listed as a mismatch. Each work's measures_paired_gain is entered as true, as false, or as null when its dossier's text cannot show whether the work reports a held-out AUROC gain of an explicit product column against a no-interaction control. Only an entry whose dossier says existence 'verified' and whose measures_paired_gain is true or false counts toward resolved_refs, prior_measures_gain counts the resolved entries marked true, and null entries are listed as unsettled and count toward neither. C8's verdict follows the spec's rule: A9 is confirmed when prior_measures_gain is at least 1, C8 is unresolved when resolved_refs is below 4, and C8 is supported otherwise.

## Sweeps

The E3 strength sweep runs E2's paired runner once per strength $m \in \{0, 0.25, 0.5, 2, 4\}$ over seeds 1 to 20, passing `--strength` $m$ and writing each point under `results/runs/E3/`. For each seed the runner trains the `with` arm and then the `without` arm with the pinned settings and saves each run's held-out scores. The generator multiplies the log-odds weight on $x_3x_4$ by $m$, so $m = 0$ plants no interaction and serves as the null control. The point $m = 1$ is not rerun, since it is E2's default draw.

The E3 analysis reads 6 points, $m \in \{0, 0.25, 0.5, 1, 2, 4\}$, with $m = 1$ from E2's runs. It reads them only after every run file's sha256 matches its last manifest entry and each point holds seeds 1 to 20 in both arms. It reads C4 as supported when the $m = 0$ 95% t-interval lies inside $[-0.01, 0.01]$, A4 as holding when that interval's lower bound is below $-0.01$, and C5 as supported when strength_spearman is at least 0.9 and the $m = 4$ interval's lower bound is above zero. It reads A3 as confirmed when C4 and C5 are both supported, reads the gain as monotone in strength when the mean gain rises strictly at every step of the grid, and lists every strength whose SD of $d_i$ exceeds 0.02.

E4 runs twelve points, one per strength $m \in \{1, 0\}$ and training size $n \in \{1000, 2000, 4000, 8000, 32000, 64000\}$. For sizes below the default 16000 training rows, the run passes `--train-rows` $n$ and keeps the first $n$ training rows of the default draw. For 32000 and 64000 it passes `--rows` $n/0.8$, so the generator draws 40000 or 80000 rows and holds out the last fifth. At each point, seeds 1 to 20 each train both arms with the pinned settings, saving each run's held-out scores. The E4 analysis reads 14 points, after every run file's hash matches its last manifest entry; the 2 points at 16000 rows reuse E2's and E3's runs. It reads C6 as supported when gain_shrink at $m = 1$ is at most 0.005, A5 as confirmed when gain_shrink's 95% lower bound is above 0.005, and the verdict as unresolved otherwise; at $m = 0$ the gain at each size is reported as the column's cost, not claimed.

## Verification of the statistics code

To summarize the agreement checks on toy.stats, a drawing script parses the text of tests/test_stats_scipy.py with Python's ast module, without importing or running it. For each check it extracts the tolerance (the `places` argument of assertAlmostEqual, the `atol` of assert_allclose, or the 0.05 fraction of the bootstrap interval's width), the number of random draws its loop covers, and the number of resamples. It counts as deterministic every check whose tolerance is not a fraction of the interval's width, and reports the number of those checks, their total cases, and the smallest and largest decimal-place tolerance.

## E2 gate: reproduction and convergence

For each convergence rerun recorded in analysis/E2/checks.json, a drawing script recomputes the relative drop $d = (L_{p} - L_{d})/L_{p}$ from the final training losses at the pinned and doubled epoch counts and checks it against the stored drop. It then reports the mean of $d$ over the runs, the count of negative $d$, the largest $d$ as a share of the convergence limit, the largest $|L_{p} - L_{d}|$, and each arm's mean $L_{p}$ with their difference, without minus with.

## Drawing the paired statistics of one sweep point

The drawing reads toy.paired's per-seed records for one point and recomputes the mean paired difference, its sample standard deviation, the mean AUROC of each arm and of the oracle, and gap_closed, the mean gain divided by the mean gap that the without arm leaves to the Bayes AUROC. It redraws the interval for gap_closed with a paired bootstrap that resamples seeds with replacement, keeps each seed's gain and gap together, and takes the percentile bounds of the resampled ratios under a fixed random seed.

## Drawing R11-1

The drawing script reads results/E1/oracle.json and computes four derived quantities. The share of the gap the goal requires is $(0.82 - \mathrm{AUROC}_{add})/(\mathrm{AUROC}_{Bayes} - \mathrm{AUROC}_{add})$. The goal's margin over the additive model is $0.82 - \mathrm{AUROC}_{add}$. The fitted $x_1{:}x_2$ ratio is the ratio of the additive model's $x_1$ and $x_2$ coefficients. The oracle-minus-Bayes difference is the oracle's AUROC on the scored half minus the Bayes AUROC on the whole draw.

\label{wayline-main-end}

# Acknowledgments

\[TO BE GIVEN: acknowledgments\]

# Funding

\[TO BE GIVEN: funding\]

# Competing interests

\[TO BE GIVEN: competing interests\]

# Data availability

The data this study analysed: `research/intake/paper-c-source.tar.gz` (a file, 632 bytes); The synthetic two-class set is made by src/toy/generate.py from one seeded stream; the held-out split is the last fifth of the rows drawn (HELD_OUT_FRACTION = 0.2) and is used for evaluation only. The results it reports were produced by the project's own runs, 2210 artifact(s) recorded with their SHA-256 in the project's manifest. \[TO BE GIVEN: where the data are deposited\]

# Code availability

\[TO BE GIVEN: the code repository, which setup has not settled\] The code repository does not reproduce: {'passage': 'P60', 'heading': 'Drawing R11-1', 'named': 'AUROC', 'why': 'no code under `code/` calls area under the ROC curve (roc_auc_score)', 'reproduced_by_repository': False}.

# References

Bien, Jacob, Jonathan Taylor, and Robert Tibshirani. 2013. "A Lasso for Hierarchical Interactions." *The Annals of Statistics*, ahead of print. <https://doi.org/10.1214/13-aos1096>.

Clémençon, Stéphan, Gábor Lugosi, and Nicolas Vayatis. 2008. "Ranking and Empirical Minimization of U-Statistics." *The Annals of Statistics*, ahead of print. <https://doi.org/10.1214/009052607000000910>.

DeLong, Elizabeth R., David M. DeLong, and Daniel L. Clarke-Pearson. 1988. "Comparing the Areas Under Two or More Correlated Receiver Operating Characteristic Curves: A Nonparametric Approach." *Biometrics*, ahead of print. <https://doi.org/10.2307/2531595>.

Dietterich, Thomas G. 1998. "Approximate Statistical Tests for Comparing Supervised Classification Learning Algorithms." *Neural Computation*, ahead of print. <https://doi.org/10.1162/089976698300017197>.

Dwork, Cynthia, Vitaly Feldman, Moritz Hardt, Toniann Pitassi, Omer Reingold, and Aaron Roth. 2014. "Preserving Statistical Validity in Adaptive Data Analysis." In *arXiv*. Preprint. <http://arxiv.org/abs/1411.2664v3>.

Dwork, Cynthia, Vitaly Feldman, Moritz Hardt, Toniann Pitassi, Omer Reingold, and Aaron Roth. 2017. "Guilt-Free Data Reuse." *Communications of the ACM*, ahead of print. <https://doi.org/10.1145/3051088>.

Emmert-Streib, Frank, and Matthias Dehmer. 2019. "Evaluation of Regression Models: Model Assessment, Model Selection and Generalization Error." *Machine Learning and Knowledge Extraction*, ahead of print. <https://doi.org/10.3390/make1010032>.

Friedman, Jerome H., and Bogdan E. Popescu. 2008. "Predictive Learning via Rule Ensembles." *The Annals of Applied Statistics*, ahead of print. <https://doi.org/10.1214/07-aoas148>.

Hanley, J A, and B J McNeil. 1982. "The Meaning and Use of the Area Under a Receiver Operating Characteristic (ROC) Curve." *Radiology*, ahead of print. <https://doi.org/10.1148/radiology.143.1.7063747>.

Lou, Yin, Rich Caruana, Johannes Gehrke, and Giles Hooker. 2013. "Accurate Intelligible Models with Pairwise Interactions." *Proceedings of the 19th ACM SIGKDD International Conference on Knowledge Discovery and Data Mining*. <https://doi.org/10.1145/2487575.2487579>.

Menon, Aditya Krishna, and Robert Charles Williamson. 2014. "Bayes-Optimal Scorers for Bipartite Ranking." *ANU Open Research (Australian National University)*.

Raschka, Sebastian. 2018. "Model Evaluation, Model Selection, and Algorithm Selection in Machine Learning." In *arXiv*. Preprint. <http://arxiv.org/abs/1811.12808v3>.

Sun, Xu, and Weichao Xu. 2014. "Fast Implementation of DeLong's Algorithm for Comparing the Areas Under Correlated Receiver Operating Characteristic Curves." *IEEE Signal Processing Letters*, ahead of print. <https://doi.org/10.1109/LSP.2014.2337313>.

Ushio, Ryota, Takashi Ishida, and Masashi Sugiyama. 2026. "Bayes-Optimal BER and AUC: Estimation and Evaluation of Estimators." In *arXiv*. Preprint. <http://arxiv.org/abs/2609.02304v1>.

# Supplementary information

The supplement holds the figures and tables behind the checks on the code and on the experiments. The main answers are in the Results. Supplementary Table S1 goes with the training-flag tests (R2): the smoke run's configuration, its pinned held-out AUROC, and the two weight assertions on the arms. Supplementary Table S2 goes with the agreement checks on toy.stats (R3): what each check holds the code to, against which reference, on how many cases, and to what tolerance. Supplementary Figure S1 and Supplementary Table S3 go with the E2 gate (R7): the final training loss of each of the six convergence reruns at 30 and at 60 epochs, and its relative drop. The gate's reproduction check is given in the text of R7. Supplementary Figure S2 and Supplementary Table S5 go with the paired statistics of the E2 sweep point (R8): each seed's held-out AUROC in both arms, its oracle AUROC, its paired difference and DeLong statistic, and the bootstrap of gap_closed redrawn from those per-seed records. Supplementary Figure S3 and Supplementary Table S6 go with E1 (R11): the additive model, the oracle and the Bayes ceiling on D2 against the 0.82 goal, the additive model's fitted coefficients, the oracle's calibration bins, and E1's criteria against their limits.

![Figure 1: **Doubling training from 30 to 60 epochs leaves final training loss essentially unchanged in all six convergence reruns.** Both panels are drawn from one artifact, the E2 gate checks (run t104-a2): three seeds each for the arm with the x3·x4 interaction column (blue) and the arm without it (orange). Marker shape gives the seed (circle 1, square 2, triangle 3) in both panels. (a) Relative drop in final training loss for each rerun, (loss at 30 epochs minus loss at 60 epochs) divided by loss at 30 epochs, so a positive value means the loss fell. The black dashed line at +0.01 is the gate's convergence limit, which the gate tests against the largest drop. The gray dashed line at −0.01 is its mirror, drawn for scale only, and the dotted line marks zero. The largest drop, +0.0034 (with x3·x4, seed 2), is 0.34 of the limit. Three of the six drops are negative, meaning the loss rose slightly at 60 epochs, and the mean drop is 0.00025. (b) Final training loss at 30 and at 60 epochs for each rerun, joined per rerun, one axes per arm. The two axes cover the same loss range (0.0114), so equal slopes mean equal changes in both, but each axis is offset to its own runs: read the levels from the tick values. The mean loss at 30 epochs is 0.4744 with the column and 0.5765 without it. The largest change from 30 to 60 epochs is 0.0016 (with x3·x4, seed 2), smaller than the spread between seeds within either arm. In the without arm, seeds 1 and 3 end within 0.00002 of each other at 60 epochs, so their markers overlap.](figures/S1.pdf)

![Figure 2: **At this sweep point the interaction column adds 0.087 held-out AUROC on every one of 20 paired seeds and closes 0.99 of the gap to the Bayes ceiling.** Every panel is drawn from one artifact, toy.paired's summary of the E2 sweep point at strength 1.0 and signal 4.0 (run t120-a1): 20 paired seeds, each trained on 16000 rows and scored on 4000 held-out rows. Orange marks the arm without the interaction column, blue the arm with it, and black the seed's Bayes AUROC from the oracle. Green marks one seed's paired statistic, and vermilion marks a summary toy.paired reported. All 20 seeds appear in every panel. (a) Held-out AUROC of the two arms for each seed (circles without, squares with), joined by a gray stem, with a black tick at the seed's Bayes AUROC. The mean AUROCs are 0.768 without the column, 0.855 with it, and 0.856 for the ceiling. The with arm's mean shortfall from its ceiling is 0.0009 (at most 0.003). On seed 16 it scores 0.00009 above its finite-sample Bayes AUROC, too little to see at this scale. (b) The paired difference d = AUROC with minus AUROC without for each seed (top), jittered vertically with a seeded draw only so the dots separate, and the mean gain with the 95% t-interval toy.paired reported (bottom). Every seed gains, by 0.077 to 0.098. The mean gain is 0.087 (sd 0.006, interval 0.084 to 0.090), and the exact Wilcoxon signed-rank p is 1.9e-06. (c) Each seed's gain d against the gap its without arm left, gap = Bayes AUROC minus AUROC without, on equal axes. The gray dotted line is d = gap (gap fully closed). The vermilion line through the origin has slope gap_closed = mean d / mean gap = 0.990, with a mean gap of 0.088. The per-seed ratio d / gap runs from 0.969 to 1.001. Both axes subtract the same without-arm AUROC, so part of the tight line-up is built in: a weaker without arm both widens the gap and leaves more to gain. (d) Distribution of gap_closed over 10000 paired-bootstrap resamples of the 20 seeds, redrawn here from the per-seed records with an independent seeded generator (not toy.paired's own draws, which are not saved). The black dashed lines are the 2.5% and 97.5% quantiles of these resamples, 0.986 and 0.994. The vermilion diamond and bar are gap_closed and the 95% bootstrap CI toy.paired reported, 0.986 to 0.994. The redrawn quantiles differ from the reported ends by +0.00004 (low) and +0.00001 (high), printed in the panel because the two pairs of lines would coincide. The gray dotted line marks full closure, 1.0, which lies outside the whole distribution. (e) The DeLong z statistic of each seed's paired AUROC comparison, with against without, jittered vertically for legibility. The gray dashed line is z = 1.96, the two-sided 0.05 bound. Every z lies between 13.7 and 17.8, so all 20 seeds reject equal AUROCs on their own, matching the 20 rejections toy.paired reports.](figures/S2.pdf)

![Figure 3: **An additive model on D2 sees none of the planted x3·x4 interaction and falls well short of a calibrated ceiling, with the 0.82 goal in between.** Panel (a) is drawn from the E1 analysis summary (run t103-a1). Panel (b) is drawn from the E1 oracle results (run t102-a1). Panel (c) draws from two data files: the calibration bins come from the E1 oracle results (run t102-a1) and the ±0.01 calibration limit comes from the E1 analysis summary (run t103-a1). The summary restates the oracle results, and the two files agree on every value they share. (a) Held-out AUROC on D2 of the additive logistic model on x1 to x4 with no x3·x4 column (blue, 0.7681), of the generator's oracle (orange, 0.8563), both scored on the second half of D2 (500,000 rows), and of the Bayes ceiling on all of D2 (black, 0.8555), with its 95% interval (0.8548 to 0.8562, half-width 0.00072). The interval is drawn but is narrower than the dot. The green arrow is the additive gap, oracle minus additive on the scored half: 0.0882, 17.6 times the 0.005 threshold. Measured to the Bayes ceiling instead, the additive model is 0.0874 below. The dashed vermilion line is the 0.82 goal, which lies 0.0519 above the additive model and 0.0355 below the ceiling, so reaching it means closing 0.59 of the distance from the additive model to the ceiling. The oracle on the scored half sits 0.0008 above the ceiling's point estimate, just outside its interval (by 0.00008), as expected of an estimate from half the rows. (b) The five fitted coefficients (log-odds) of the unpenalized additive logistic model, fit on the first 500,000 rows of D2. Dark blue marks x1 and x2, which the generator weights linearly. Orange marks x3 and x4, which enter the label only through their product. Light blue marks the intercept. x1 (1.61) and x2 (−1.07) carry all the weight, in a fitted ratio of −1.50 against −1.50 for the generator's linear weights (2.4 and −1.6). x3 (−0.0035), x4 (0.0020), and the intercept (−0.0032) sit at zero, although the interaction's generator weight, 4.4, is the largest in the label rule. (c) \[\[mixed-data\]\] Two data files: bins from the E1 oracle results, the limit from the E1 analysis summary. Calibration of the oracle's predicted probability in 20 equal-count bins of 50,000 rows each, ordered by predicted probability (bin means from 0.021 to 0.979). Left: each bin's observed positive rate against its mean predicted probability; the dotted gray line is perfect calibration. Right: observed minus predicted rate per bin, with the shaded band and dashed lines marking the ±0.01 limit. Ten of the 20 residuals are positive, the median absolute residual is 0.0009, and the largest, +0.0039 in bin 13 (vermilion in both plots), is 0.39 of the limit.](figures/S3.pdf)

An explicit product column on one synthetic generator: a paired AUROC gain that follows the planted interaction and nearly reaches the Bayes ceiling

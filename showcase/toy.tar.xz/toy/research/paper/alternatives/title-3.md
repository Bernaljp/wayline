The gain from an interaction term restates its generator: paired AUROC comparisons across interaction strength and training size

Does an x3·x4 column help a logistic model? Paired held-out AUROC gains against a Bayes ceiling and a zero-interaction control

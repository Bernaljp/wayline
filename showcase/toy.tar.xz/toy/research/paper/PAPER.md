# The paper, version 2

Composed by code at paper order 2 (owner) from commit 49fd84e53d0ff039957b67f6bccf16075c47e895 of main, at 2026-10-25T14:16:00.380Z. The code repository's tag is `paper-2`, at commit 49fd84e53d0ff039957b67f6bccf16075c47e895. The writer was one read-only session on claude-opus-5-5.

<!-- wayline:builds -->
## Builds and their gates

### Build 1: failed

- the kill argument: failed (verifier session 7973676e-4c66-4f0f-9f60-cd2bd88f527c, claude-opus-5-5)
  - standing: Memo point 1's premises all check out. The label log-odds are linear in x1, x2 and x3x4 (methods l.5), the with arm is linear in x1..x4 and x3x4 (l.9), P(y=1|x) rises with mu(x) (l.27), and E2's without arm (0.7681, gain 0.0872) re-measures E1's additive model (0.7681, gap 0.0882). As a blocker it does not stand: the paper concedes that the gain restates the generator and scopes every claim to it (title; the abstract's last two sentences; results l.109; discussion l.7, l.29, l.31). What still stands is narrower. The paper never says the with arm has the label rule's own functional form, so near-ceiling AUROC is expected by construction, yet the title headlines 'nearly reaches the Bayes ceiling' and Discussion l.3 and l.25 read gap_closed 0.990 and 0.999 as findings. (Point 2, by contrast, is answered: Discussion l.11 and l.25 concede that C6 is what a linear without arm implies and that sample size could not change the answer.) (research/paper/title.md line 1; research/paper/discussion.md lines 3 and 25 (read against research/paper/methods.md lines 5, 9, 27))
  - standing: Memo point 3 stands only for wording. Its headline, 'O2 provides no evidence', does not stand: the goal is evidenced (goal run 0.8503 ≥ 0.82, results l.73), and R17 (l.75) and Discussion l.19 say plainly that 0 changes were tried and the validation path was never used. Still, the abstract gives 'no setting was chosen on held-out data' without saying that no change was tried at all, and Introduction l.25 says the goal loop 'chooses any change on a validation split' when it chose none. (research/paper/abstract.md line 1 ('no setting was chosen on held-out data'); research/paper/introduction.md line 25)
  - standing: Memo point 4 stands for K7. The concern ledger still closes K7 ('no real prior work to stand on') as answered, citing the O1 answer, which never mentions prior work, and OUTLINE l.41 has O1 'answers K2, K7'. Meanwhile R13 reports C8 unresolved (resolved_refs 2 of 5), with Friedman, Lou and Bien unread past their abstracts. The novelty sub-point does not stand: the paper claims no novelty, and the abstract, R13 and Discussion l.31 all call the placement unresolved. (research/CONCERNS.md ## K7 (lines 53-59); research/OUTLINE.md line 41; research/paper/results.md line 53)
  - standing: Memo point 5 stands, but only as a disclosed weakness that contradicts no claim. train.py and oracle.py are pinned only at t131-a1 (02:59Z and 03:21Z on 2026-10-25), after the E2, E3 and E4 analyses (23:38Z, 00:49Z, 01:47Z). The one pinned paired.py (t115-a1, sha af5c54…) is the file as of commit 7e948f8, and commits 73a8efc, f2e541d and 849de99 changed it before E2's analysis. Methods l.1 and Discussion l.31 say all of this, so the run outputs stay hashed while the code that produced them stays unpinned. (research/manifest.json lines 1354-1361 and 19831-19856 (no src/toy/stats.py, src/toy/sweep.py, experiments/ or analysis/*.py entry anywhere); research/paper/methods.md line 1)
  - standing: Memo point 6 stands. Authors, acknowledgments, funding, competing interests, the data deposit and the code repository all read '[TO BE GIVEN]'. Line 26 prints a raw Python dict declaring that 'The code repository does not reproduce' P60. That is a false positive: the project has no code/ directory (no files match code/**; PAPER.md lines 58 and 70), its AUROC comes from src/toy/metrics.py's own auroc rather than roc_auc_score, and the flagged passage (methods.md l.77) only reads oracle.json. Line 21 calls research/intake/paper-c-source.tar.gz (632 bytes) 'The data this study analysed', but INTAKE.md line 31 records it as a reference paper's code repository, and the data are generate.py draws. (research/paper/front.md lines 5-26)
  - standing: Memo point 7 stands. Figure S3(c) carries a literal '[[mixed-data]]' token. The supplementary tables run ST1, ST2, ST3, ST5, ST6 with no ST4, because PAPER.md line 24 numbers both R7 tables ST3. The Methods heading 'Drawing R11-1' is an internal label, 'K4' is never defined in the paper, and the O2 Results heading is a measure string rather than a question. (research/paper/figures/S3/caption.md line 7; research/paper/supplement.md line 1 and research/paper/tables/ (no ST4); research/paper/methods.md line 75; research/paper/discussion.md line 13; research/paper/results.md line 63)
  - standing: Memo point 8 stands. The introduction cites {ref:paper-a#existence} and {ref:paper-b#existence}, but none of references.json's 14 entries is paper-a or paper-b, so two cited works have no bibliography entry. (research/paper/introduction.md line 5; research/paper/references.json (14 entries))
  - standing: Memo point 9 stands. Discussion l.13 says the runs 'give a size' for K4's question on what spurious terms cost. K4 asks about spurious pairwise terms, plural, and their cost through overfitting, but the only unneeded term ever tested is the single x3x4 column at m = 0. The paragraph does say 'one unneeded weight' and declines the overfitting reading, yet CONCERNS.md still closes K4 as answered. (research/paper/discussion.md line 13; research/CONCERNS.md ## K4 (lines 29-35))
  - standing: Memo point 10 stands. The pinned tests/test_paired.py (sha 58fe8c…, byte-identical to git 2a754fc) tests a disagreement between arms only on strength (test_arms_that_disagree_on_a_setting_are_refused sets strength=0.0). R8 still cites that Refusals class for disagreements on seed, strength, signal, rows and training rows; the pinned code compares all five keys, but the cited test shows only one. HandWorkedAnswers was pinned at 17:04Z against paired.py 2a754fc, and the file changed four more times before E2's analysis at 23:38Z, so 'reproduces every answer' is shown only for that earlier version. (research/paper/results.md line 37 (R8); research/manifest.json lines 1309-1316; research/findings.jsonl line 30 (t76-a1-f2))
- the independent read: failed (verifier session bea6ec88-ec4d-4041-acbb-b397ec1b883b, claude-opus-5-5)
  - standing: Data availability says 'The data this study analysed: research/intake/paper-c-source.tar.gz (a file, 632 bytes)'. SPEC.md line 171 says no experiment needs that file and its contents are unread, INTAKE.md line 31 takes it as another paper's code, and no finding or manifest entry touches it. The study analysed only draws from src/toy/generate.py, so this statement of the paper's data is false and nothing carries it. (research/paper/front.md line 21 (## Data availability))
  - standing: 'The cost shows no sign of falling as training rows grow' rests on m = 0 gain_shrink = -0.000124, the gain at 1000 rows minus the gain at 64000. That sign means the cost fell in point estimate, from 0.000247 to 0.000122 (tables/T2.md lines 5 and 11). Its interval, -0.000416 to 0.000167, fits both no change and the cost vanishing, and findings.jsonl line 161 marks it 'reported, not claimed'. So the sentence misreads the statistic, and the overfitting inference built on it goes past it. Only the per-size pattern could carry a narrower reading: the cost is detectable at 8000 to 64000 rows (findings.jsonl line 163). (research/paper/discussion.md line 13 (## Sample size, second paragraph))
  - standing: No part of the paper says how x1..x4 are drawn: independently uniform on [-1, 1] (src/toy/generate.py lines 29 and 34). Methods gives only the label rule. Yet the Bayes ceiling, the additive gap and the 'no marginal linear trace' reading (results.md line 93) all depend on that distribution, so a reader cannot rebuild the one generator the paper is about. (research/paper/methods.md line 5 (## Synthetic generator))
  - standing: The outline holds a 'Parameter table: 72 parameters, generated at the end of Methods', but the paper's methods.md ends at '## Drawing R11-1' with none. The table exists only in the ledger's research/sections/methods.md (## Parameters, line 137), and the one compilation (compilations/plain/compilation.json, paper_version 1) lacks it too. Its row at research/sections/methods.md line 169 ('round(interaction_weight, 12)', with a reason for rounding) also contradicts methods.md line 27 ('with no rounding') and src/toy/oracle.py line 269. I could not tell whether a v2 compilation would append it. (research/OUTLINE.md line 124 against research/paper/methods.md line 77 (end of file))
  - standing: The outline's Gaps list says 'O2 is answered and its Discussion passage is not written yet', and the order is complete only when that list is empty. In the paper, the goal, the held-out discipline and C7 are discussed in the second paragraph (line 19) of the O3 section headed 'Does generate.py plant a feature interaction...' (line 15). So O2 has no Discussion part of its own; PAPER.md line 140 records the writer's proposal to add one, which was never made. (research/OUTLINE.md line 18 (## Gaps) against research/paper/discussion.md lines 15-19)
  - standing: Authors, acknowledgments, funding, competing interests, the data deposit and the code repository are all '[TO BE GIVEN]' (owner inputs). The Code availability statement at line 26 is a raw Python dict literal ({'passage': 'P60', ... 'reproduced_by_repository': False}) rather than a sentence, and PAPER.md line 58 says code/ holds nothing at the tag. (research/paper/front.md lines 5-26 (## Code availability, line 26))
  - standing: The heading names the audit's cost, but the body says no recorded artifact holds its time, its memory or a run of the test, and reports only the test's limits and its move to seed 20001. The text is honest, but the part carries no result under a heading that names one; PAPER.md line 136 proposes a rename that was not made. (research/paper/results.md lines 85-87 (### Oracle audit cost on the 10^6-row draw D2 {#R6}))
  - standing: The caveat on what the manifest does not record names stats.py, sweep.py, experiments/ and analysis/. It leaves out src/toy/metrics.py, which computes every AUROC (imported at src/toy/train.py line 41, src/toy/paired.py line 56 and src/toy/oracle.py line 31) and has no manifest entry. (research/paper/methods.md line 1)
  - standing: Methods says a --config file 'is refused if it pins any other setting that differs from what the code runs'. read_config (src/toy/train.py lines 143-149) checks only the four CONFIG_FIXED keys (optimizer, weight_decay, minibatch, held_out_fraction; line 50) and lets any other key through. (research/paper/methods.md line 9 (## Arms and pinned settings))
  - standing: There is no Supplementary Table S4, so the numbering jumps from S3 to S5. PAPER.md lines 24 and 35-36 give both R7 tables (R7.T1 and R7.T2) the id ST3, and only the reruns table survives. (research/paper/supplement.md line 1 and research/paper/tables/ (ST1-ST3, ST5, ST6))
  - standing: A raw '[[mixed-data]]' build marker is left at the start of panel (c)'s caption. (research/paper/figures/S3/caption.md line 7)
  - standing: The paper says a paired t test over random train-test splits 'is reported to have a high probability of type I error and should never be used'. That drops the abstract's qualifier 'in certain situations' (research/refs/dietterich-1998-approximate-statistical-tests-comparing-supervised/dossier.json line 25). (research/paper/introduction.md line 13 (## Paired tests of two classifiers))
  - standing: 'At m = 0 the probability does not change with x3x4' is tagged to Transcription.test_true_prob_matches_generate_row_by_monte_carlo, which only compares probabilities with drawn labels. In the recorded tests/test_oracle.py (t6-a1, git 5885a7f) the check is test_no_interaction_at_m_zero (line 90), so the claim is carried, but at a different locator. (research/paper/results.md line 19 (### The oracle's true class probability matches the generator {#R4}))
  - standing: The scope names the verifications, but no verifications file exists under research/. I checked for failed claims against the report's run-end gate list instead, and none of its five failed claims is restated in the paper. (research/REPORT.md lines 8-14 (run-end gates); no research/**/verifications*.json exists)
- the sampled verdicts on claims never sampled: failed; 22 claim(s) never sampled, 10 drawn, 10 judged now
  - standing: the claim "The check is one-sided: it bounds the largest drop at 0.01, so a loss that rose at doubled epochs cannot fail it." is not supported: The sentence says the check 'bounds the largest drop at 0.01', but the cited `convergence` function has no 0.01 bound and no pass/fail outcome. It computes each run's signed drop with `relative_drop` (lines 64-68; the docstring says it is negative if the loss rose) and returns `convergence_drop = max(...)` (line 91). The only comparison in the file is the `loss_pinned <= 0` guard at line 66, and the only ways it fails are ValueErrors for a missing file or key or for epochs that are not doubled (lines 85-86). The 0.01 bound, and the pass/fail that a rising loss 'cannot fail', are in analysis/E2/checks.py: `CONVERGENCE_LIMIT = 0.01` at line 33 and `convergence_passed = convergence_drop <= CONVERGENCE_LIMIT` at line 67 in `gate`. This sentence does not cite that file, so it claims more than its tag shows. The version recorded in the manifest (commit 3b2931d, sha256 8552c821…, 4383 bytes) differs from the current file only by docstrings and has no bound either. (src/toy/converge.py:71-91 (def convergence; return at line 91), cited by research/paper/methods.md, section 'Convergence check {#methods-convergence-check}'); The subject path the harness listed, `code/src/toy/converge.py#convergence`, does not exist: there is no `code/` directory in the project. I read the file at the path the tag itself names, `src/toy/converge.py`. That matches the manifest entry `src/toy/converge.py` (sha256 8552c821…, ticket 8) at commit 3b2931d; the only later change is the docstrings added in b008f0a. The harness's `code:` tag resolution adds a prefix that doesn't exist here. (research/manifest.json:1129 (entry path src/toy/converge.py); listed subject path code/src/toy/converge.py)

The paper is **not passed**: its last build left the points above standing. Choose three more builds, keep it as it is, or the points as objectives (say so in the conversation). Nothing was submitted anywhere.
<!-- /wayline:builds -->

## Parts

| Part | File | Version | This order |
|---|---|---|---|
| title | title.md | 2 | made afresh |
| abstract | abstract.md | 2 | made afresh |
| introduction | introduction.md | 1 | unchanged |
| results | results.md | 2 | made afresh |
| discussion | discussion.md | 1 | unchanged |
| methods | methods.md | 1 | unchanged |
| supplement | supplement.md | 2 | made afresh |
| front | front.md | 1 | unchanged |

Tables: ST1, ST2, ST3, ST3, ST5, ST6, T1, T2. Alternatives: alternatives/title-1.md, alternatives/title-2.md, alternatives/title-3.md.

## Figures

Code's figure plan, from the outline and the owner's marks on the plots: each figure's plan line and how it stands.

- S1 (R7): R7.1, R7.2 (its other plots): verified, reused from the last version (the figure role's figures/paper-r7-supplement/)
- S2 (R8): R8.1, R8.2, R8.3, R8.4, R8.5 (its other plots): verified, reused from the last version (the figure role's figures/paper-r8-supplement/)
- S3 (R11): R11.1, R11.2, R11.3 (its other plots): verified, reused from the last version (the figure role's figures/paper-r11-supplement/)
- ST1 (R2): R2.T1, from its CSV
- ST2 (R3): R3.T1, from its CSV
- ST3 (R7): R7.T1, from its CSV
- ST3 (R7): R7.T2, from its CSV
- ST5 (R8): R8.T1, from its CSV
- ST6 (R11): R11.T1, from its CSV
- no figure for R2, R3, R4, R5, R7, R8, R9, R10, R13, R14, R12, R17, R1, R6, R11, R15, R16, R18: no plot kept or cited, and none asked for from nothing

The figures' points for the text, for the writer of the next build:

- S1: The convergence gate is one-sided: it tests only the largest relative drop against +0.01, so a rerun whose training loss rose substantially at 60 epochs would still pass. Here the most negative drop is -0.0024 (without arm, seed 3), and 3 of 6 drops are negative, so it does not matter in this run, but the text should state the gate as 'largest relative drop <= 0.01' rather than '|change| <= 0.01'.
- S1: The reproduction half of the E2 gate (gap 0.0 against a 0.002 limit; run_auroc_with_seed1 = b3_auroc = 0.8503) is not drawn in this figure, because two identical values collapse to one mark. The text or the gate table (R7.T1) has to carry that number.
- S1: Convergence is established on final training loss only. No held-out AUROC was recorded at 60 epochs, so the text should not say that the AUROC comparisons are unchanged by longer training. It should say only that the training loss has plateaued (largest change 0.0016 absolute, 0.34 of the relative limit).
- S2: The finite-sample Bayes AUROC is not a strict ceiling: on seed 16 the with arm scores 0.00009 above it (d/gap = 1.0011). The text should call it the oracle's held-out AUROC, which holds up to held-out noise, so per-seed gap_closed can slightly exceed 1.
- S2: The tight per-seed association between gain d and gap (both are minus AUROC_without) is partly built in by the shared without term. The text should not cite that line-up as independent evidence. The load-bearing number is gap_closed = mean d / mean gap = 0.990 (bootstrap CI 0.986 to 0.994).
- S2: toy.paired's bootstrap draws for the gap_closed CI are not saved. An independent seeded numpy bootstrap of the 20 per-seed records (10000 resamples) reproduces the reported CI to within 0.00004 at the low end and 0.00001 at the high end, which is worth one sentence in the methods or supplement.
- S2: The with arm's mean shortfall from the Bayes ceiling is 0.0009 (at most 0.003), against 0.088 for the without arm, and the smallest per-seed DeLong z (13.7) is 7.0 times the 1.96 bound. Both are reportable numbers for the claim that the column recovers nearly all of the planted signal at strength 1.0.
- S3: The claim says the additive model 'sits 0.0882 AUROC below a well-calibrated Bayes ceiling of 0.8555', but 0.0882 is the additive gap measured to the oracle on the scored half (0.8563 minus 0.7681). Measured to the Bayes ceiling (0.8555), the additive model is 0.0874 below. Either say '0.0882 below the oracle (Bayes ceiling 0.8555)' or use 0.0874 against the ceiling.
- S3: The oracle's AUROC on the scored half (0.85629) lies 0.00008 above the upper bound of the Bayes ceiling's 95% interval (0.85620). That is expected of a half-sample estimate with its own sampling error, but the text should not say the oracle falls within the ceiling's interval.
- S3: The 0.82 goal sits 0.0519 above the additive model and 0.0355 below the Bayes ceiling, so reaching it means closing 0.59 of the distance from the additive model to the ceiling. The oracle's largest calibration residual, 0.0039 in bin 13, is 0.39 of the 0.01 limit, and the median absolute residual is 0.0009.

## Code at the order

Code's steps before the writer: the tag, the stale results re-run at it, the scripts behind the figures, the environment, and the code-to-Methods check over all of code/.

The code repository is tagged `paper-2` at commit 49fd84e53d0ff039957b67f6bccf16075c47e895 of main; not pushed: code/ holds nothing at the tag, so there is no code repository to tag.

### Re-runs at the tag

No result's code changed since its run: nothing was re-run.

### The scripts behind the figures

No figure or cited drawing number has a script to copy.

### The environment

Nothing rendered: the project has no code/.

### The code-to-Methods check over all of code/

0 file(s) checked: passed.
- note: no code/ at the order: nothing to check

## The batch's answers

No batch was asked under `autonomous`: code's defaults were followed until the decider answers it.
- reference:paper-a: to be resolved (by code)
- reference:paper-b: to be resolved (by code)
- outline:B29#1: decline (by code)
- nothing:R2: no figure (by code)
- nothing:R3: no figure (by code)
- nothing:R7: no figure (by code)
- nothing:R8: no figure (by code)
- nothing:R1: no figure (by code)
- nothing:R11: no figure (by code)

## Inherited results

Either an inherited result was verified, or the project inherited none.

## Left out, and why

- Findings t52-a1-f1 and t52-a1-f2 (R4): the seed-7 calibration error of 0.034 to within 0.0005, below three times 0.0158, with the worst bin's gap below sqrt(45.31) of its own standard errors; and the unrounded interaction_weight, 3.3000000000000003 at signal 3.0.: Their tests (Calibration.test_largest_gap_at_20000_rows_is_sampling_noise, Cli.test_interaction_weight_is_the_unrounded_product) are missing from the version of tests/test_oracle.py the manifest pins (run t6-a1). Ticket 180, which re-files them, is still open. The seed-7 gap of 0.034 is kept, from t6-a1-f4.
- Finding t52-a4-f1 (R4): the 48-node Gauss-Hermite estimate agrees with the 96-node estimate within 1e-10, and with a trapezoid rule within 1e-9.: Ticket 180 records that its test, Quadrature.test_logistic_normal_integral_is_converged, is missing from the pinned tests/test_oracle.py bytes, although its tag names that file at run t6-a1. Methods describes the quadrature from the code.
- The last sentence of finding t6-a1-f4: that at E1's 10^6 rows the 0.01 threshold is about 4 SE and a meaningful test. Also R4's framing in version 1 that the calibration check 'needs many rows to mean anything'.: Its sampled verdict failed at the run-end gate, and build 2 found that the framing implied the same judgment. R4 now only points to R11 for E1's calibration error.
- Finding t116-a2-f2, and the refusals in t116-a2-f1 beyond those the pinned test file shows (a run filed under the wrong arm, missing or out-of-order scores, replicates that disagree on a compared setting) (R8).: The PinnedSettings class and those refusal tests are missing from the version of tests/test_paired.py the manifest pins (run t76-a1), and re-file ticket 155/178 is open. Methods describes these checks from the code, and R8 says it reports them from the code alone.
- Finding t118-a1-f1 (R12): that tests cover WAYLINE_ARTIFACT and positional paths naming a run directory.: Its cited test is missing from the version of tests/test_eval.py the manifest pins (run t95-a1). R12 states the behavior from the pinned eval.py (t117-a1-f1) instead.
- The clause of finding t53-a1-f1 (R6) that the audit passed both limits when the test was run.: Its sampled verdict failed, and no manifested artifact records a run of the test. Ticket 179 is open and waits on decision 152.
- The second sentence of finding t8-a2-f1: that on the fixture the maximum drop is 0.05, from the without arm at seed 2.: Its sampled verdict failed at the run-end gate.
- Finding t131-a1-f2 (R18): that no module in src/toy implements a keep rule.: Its sampled verdict failed at the run-end gate.
- The second sentence of finding t117-a1-f1: that eval.py's module docstring and the positional argument's help now say every source takes a run directory.: Its locator, read_metric, does not reach the module docstring or the argument's help.
- The 'prints val_auroc' clause of finding t95-a1-f2 (R9).: The test it cites checks only the refusal to fall back to the held-out auroc. Methods states from the code that --split val prints val_auroc.
- The second sentence of finding t8-a2-f2: that tickets 3 and 16 must write the key names.: It records how the project's tickets depended on each other, which tells a reader nothing. The R5 text keeps the keys and the exit status.
- The 0.01 gate attributed to toy.converge alone (t8-a2-f1's 'cannot trip the 0.01 gate', and the Methods sentence whose sampled verdict failed in build 2).: converge.py computes the drop but holds no 0.01 bound. R5 and R7 now give the limit with E2's checks.json#convergence_limit and analysis/E2/checks.py#gate, where the bound is.
- Full floating-point precision of the estimates (for example 0.08716535526499543, and a band-to-cost ratio of 31.38076743038538).: Printed to 16 or 17 digits, they imply a precision that intervals of about plus or minus 0.003 do not have. The Results round them to the intervals' precision. They keep full digits only where a check compares values for exact equality: the base-commit AUROC, the reproduction check, eval.py's printed output, and the default draw's SHA-256.
- The m = 0 per-size counts of negative differences and signed-rank p at 2000, 4000, 8000 and 64000 rows, and the m = 1 interval bounds at 2000 to 32000 rows, from the text.: Table 2 carries the intervals. The text keeps the endpoints, and the counts that bear on the claims.
- O5 (whether explicit terms still help models that learn interactions unaided).: The owner parked it and it has no result. The abstract says only that a model linear in its inputs was tested.
- a figure of R2: no plot of it is marked keep or cited by its synthesis; a figure from nothing only on request
- a figure of R3: no plot of it is marked keep or cited by its synthesis; a figure from nothing only on request
- a figure of R4: no plot of it is marked keep or cited by its synthesis; a figure from nothing only on request
- a figure of R5: no plot of it is marked keep or cited by its synthesis; a figure from nothing only on request
- a figure of R7: no plot of it is marked keep or cited by its synthesis; a figure from nothing only on request
- a figure of R8: no plot of it is marked keep or cited by its synthesis; a figure from nothing only on request
- a figure of R9: no plot of it is marked keep or cited by its synthesis; a figure from nothing only on request
- a figure of R10: no plot of it is marked keep or cited by its synthesis; a figure from nothing only on request
- a figure of R13: no plot of it is marked keep or cited by its synthesis; a figure from nothing only on request
- a figure of R14: no plot of it is marked keep or cited by its synthesis; a figure from nothing only on request
- a figure of R12: no plot of it is marked keep or cited by its synthesis; a figure from nothing only on request
- a figure of R17: no plot of it is marked keep or cited by its synthesis; a figure from nothing only on request
- a figure of R1: no plot of it is marked keep or cited by its synthesis; a figure from nothing only on request
- a figure of R6: no plot of it is marked keep or cited by its synthesis; a figure from nothing only on request
- a figure of R11: no plot of it is marked keep or cited by its synthesis; a figure from nothing only on request
- a figure of R15: no plot of it is marked keep or cited by its synthesis; a figure from nothing only on request
- a figure of R16: no plot of it is marked keep or cited by its synthesis; a figure from nothing only on request
- a figure of R18: no plot of it is marked keep or cited by its synthesis; a figure from nothing only on request

## The owner's passages whose wording changed

None.

## Proposed by the writer, never made

- Rename R6 'Oracle audit cost on the 10^6-row draw D2' to 'Oracle audit budget test', or move it to the Supplement. No artifact records the audit's time, its memory, or a run of the test, and the test in the repository now runs seed 20001, not D2. So the part can report only the limits the test set. Both builds of version 1 left this point standing.
- Add a Results group heading 'Beyond the objectives' for R18, or move R18 to the Supplement. This version puts R18 at the objectives' heading level (##), so it no longer reads as part of O4, but the outline has no heading that says it answers no objective.
- Merge R12 'Evaluation command' into R9. R12's only finding (t118-a1-f1) cites a test that the pinned tests/test_eval.py lacks. What R12 can say is the eval.py behavior of t117-a1-f1, which is filed under R9.
- Move the code-verification results (R2, R3, R5, R9, R10, R12) to the Supplement and keep the experiments (R7, R13, R14, R17, R1, R6, R11, R15, R16) in the main Results, so a reader gets to E2's answer without first reading six test summaries.
- Add a Discussion heading for O2, the 0.82 goal and the held-out discipline. The outline's Gaps list still names this passage as missing. For now O2's discussion is the second paragraph of the O3 Discussion section.

## The writer's notes

This order recomposes the title, abstract, Results and Supplement. The Introduction, Discussion and Methods stand as in version 1. What changed from version 1's Results: (1) Headings now follow the current outline's wording. For example, R2 is 'Adding the interaction flags leaves the default training run unchanged', not the old 'train.py: opt-in arm ...'. (2) R18 is set at the objectives' level (##), not as a ### under O4. This answers build 2's point that it read as O4 evidence. If code's heading check wants ### for every R heading, put it back. (3) The 0.01 convergence bound in R5 and R7 now cites analysis/E2/checks.py#gate and E2's checks.json#convergence_limit, not converge.py alone. This answers build 2's failed sampled verdict on the same statement in Methods. (4) R4 drops the quadrature finding t52-a4-f1, because ticket 180 says its test is not in the pinned bytes. R4 also drops the framing that implied E1's 10^6-row calibration check is a meaningful test. (5) Two lead-in sentences in R15 and R16 that made claims without tags are now plain transitions. (6) R7's statement that no held-out AUROC was measured at 60 epochs is now tagged to converge.py, which never reads held-out AUROC. (7) R6 opens by saying no artifact records a cost, so its heading's promise is answered in its first line. Tables T1 and T2 are resubmitted unchanged, with captions reworded. Points standing in parts this order did not recompose, which the owner may want recomposed next: - Discussion, 'Sample size': 'The cost shows no sign of falling' goes past the m = 0 gain_shrink, which is reported, not claimed, and whose interval spans zero (build 2). - Methods, 'Arms and pinned settings': the --config refusal is overstated. read_config refuses only the four CONFIG_FIXED keys. - Methods, 'Synthetic generator': it never says how x1..x4 are drawn (uniform on [-1, 1]). - Methods, 'Convergence check': the 0.01 bound is cited to converge.py. - Introduction: the Dietterich sentence drops 'in certain situations', and {ref:paper-a#existence} and {ref:paper-b#existence} are not in references.json. - The O2 Discussion passage is still missing (Gaps list). Code's parts: - The figure and table plan again lists two R7 tables under the one name 'Supplementary Table S3' (the gate checks, and the six reruns). Only the reruns table exists under research/paper/tables, and numbering then jumps from S3 to S5. The text cites S3 only for the reruns and gives the gate's numbers in prose. Renumbering them S3 and S4 would fix both problems. - Supplementary Figure S3's caption still carries a raw '[[mixed-data]]' marker in panel (c). - The front matter's Data availability statement names research/intake/paper-c-source.tar.gz as the data analysed. It is another paper's released code, and the data are draws from src/toy/generate.py. Code availability prints a raw Python dict. Re-pinning: tickets 153/176 (test_eval.py), 155/178 (test_paired.py) and 180 (test_oracle.py) are open, and 179 (R6) waits on decision 152. Once those files are pinned, the dropped R4, R8 and R12 claims can come back. R6 keeps version 1's {res:t53-a1/tests/test_oracle_budget.py#L26-L29} span, taken from ticket 179's notes, next to the passage's TIME_LIMIT_SECONDS tag, because that locator reaches only the 3600 line. If the span is wrong in git 017f053, that sentence will fail. CONCERNS.md still marks K7 (no real prior work) as answered by the O1 answer, which says nothing about prior work. The owner should re-answer K7 against R13 and the Introduction's first section. No concerns were kept for this order, so the concerns list is empty.

## Checks

On every part as it stands, an owner's edit included.

- The headings follow the outline's order and placement, each carrying its outline id, and no part carries a reference list: passed.
- No inherited title, abstract, or caption is in any part: passed.

## Cost

The writer session cd7fe146-a907-469b-8fe3-4f831ffa5337: 46 input and 93768 output token(s), 54 turn(s), 747297 ms.
The card's estimate for an order: about $35 to $40 for six figures when the first build passes, and about $10 more for each build that fails (the writer, the figures, and the gates, at API prices).

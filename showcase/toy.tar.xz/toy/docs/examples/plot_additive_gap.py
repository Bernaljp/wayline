"""Bayes AUROC against an x1..x4 model, across interaction strengths m.

For each interaction strength m, draws one seeded set with toy.generate and runs toy.oracle.audit
on it: `additive_auroc` is the AUROC of an x1..x4 logistic regression fitted to the first half of
the rows and scored on the second, and `oracle_auroc_second_half` is the AUROC on that same second
half of the generator's own scorer (its latent mean, which ranks rows as P(y=1|x) does). Their
difference, `additive_gap`, estimates from this one split how far a model without the x3*x4
column falls below the ceiling at that strength; it is not a bound on the paired gain. Saves the figure to a temporary directory; the gallery page draws it again.
"""

import sys
import tempfile
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

# `__file__` is unset when Sphinx's plot directive runs this; it sets sys.argv[0] to the path instead.
HERE = Path(globals().get("__file__") or sys.argv[0]).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / "src"))

from toy.generate import generate  # noqa: E402
from toy.oracle import audit  # noqa: E402

STRENGTHS = (0.0, 0.5, 1.0, 2.0, 4.0)
SEED, ROWS, SIGNAL = 1, 4000, 4.0

bayes, additive = [], []
for m in STRENGTHS:
    train, held_out = generate(SEED, signal=SIGNAL, rows=ROWS, strength=m)
    report = audit(train + held_out, m=m, signal=SIGNAL)
    # Both curves on the second half of the rows, the half the additive model is scored on.
    bayes.append(report["oracle_auroc_second_half"])
    additive.append(report["additive_auroc"])
    print("m=%-4g oracle_auroc_second_half=%.4f additive_auroc=%.4f additive_gap=%.4f"
          % (m, report["oracle_auroc_second_half"], report["additive_auroc"], report["additive_gap"]))

fig, ax = plt.subplots(figsize=(5.5, 3.6))
ax.plot(STRENGTHS, bayes, marker="o", color="#000000", label="Bayes ceiling (toy.oracle)")
ax.plot(STRENGTHS, additive, marker="s", color="#E69F00", label="x1..x4 logistic regression")
ax.fill_between(STRENGTHS, additive, bayes, color="#56B4E9", alpha=0.3, label="additive_gap")
ax.set_xlabel("interaction strength m")
ax.set_ylabel("AUROC")
ax.set_title("seed %d, %d rows, signal %g" % (SEED, ROWS, SIGNAL), fontsize=9)
ax.legend(frameon=False, fontsize=8)
fig.tight_layout()

with tempfile.TemporaryDirectory() as tmp:
    fig.savefig(Path(tmp) / "additive_gap.png", dpi=100)

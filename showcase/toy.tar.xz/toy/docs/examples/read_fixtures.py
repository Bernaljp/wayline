"""The analysis modules on the test suite's fixture directories, which need no training run.

Reads tests/fixtures/ (found from this file's own location) with toy.paired, toy.sweep,
toy.converge, toy.goallog and toy.placement, and prints each one's headline numbers. Writes nothing.
"""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))
FIXTURES = ROOT / "tests" / "fixtures"

from toy.converge import convergence  # noqa: E402
from toy.goallog import read_log  # noqa: E402
from toy.paired import point_stats  # noqa: E402
from toy.placement import place  # noqa: E402
from toy.sweep import sweep  # noqa: E402

point = point_stats(FIXTURES / "paired" / "point")
print("toy.paired:    n_pairs=%d paired_gain=%.4f [%.4f, %.4f] signed_rank_p=%.4f"
      % (point["n_pairs"], point["paired_gain"], point["paired_gain_lo"], point["paired_gain_hi"],
         point["signed_rank_p"]))

strength = sweep(FIXTURES / "sweep" / "E3", "strength", points=[FIXTURES / "sweep" / "E2" / "m1_n0"])
print("toy.sweep:     strength_spearman=%s over strengths %s"
      % (strength["strength_spearman"], [p["strength"] for p in strength["points"]]))

rows = sweep(FIXTURES / "sweep" / "rows", "rows", strength=1)
print("toy.sweep:     gain_shrink=%.4f [%.4f, %.4f] from train_rows %d to %d"
      % (rows["gain_shrink"], rows["gain_shrink_lo"], rows["gain_shrink_hi"],
         rows["smallest_train_rows"], rows["largest_train_rows"]))

drop = convergence(FIXTURES / "converge" / "E2" / "converge")
print("toy.converge:  convergence_drop=%.4f over %d runs" % (drop["convergence_drop"], drop["n_runs"]))

log = read_log(FIXTURES / "goallog" / "changes.jsonl")
print("toy.goallog:   heldout_reads=%d kept=%d discarded=%d" % (log["heldout_reads"], log["kept"], log["discarded"]))

placed = place(FIXTURES / "placement" / "placement.json", FIXTURES / "placement" / "refs")
print("toy.placement: resolved_refs=%d prior_measures_gain=%d mismatches=%d"
      % (placed["resolved_refs"], placed["prior_measures_gain"], len(placed["mismatches"])))

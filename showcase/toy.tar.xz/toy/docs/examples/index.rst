Examples
========

Scripts the documentation build runs; each one here runs as it is shown. Each reaches the project
by its own path, so it runs from any directory with ``python3 docs/examples/<name>.py``, and
writes nothing outside a temporary directory.

oracle_ceiling.py
-----------------

Draws a seeded dataset and computes its Bayes AUROC with its half-width, and the additive model's
gap below it on a half split
(used in :doc:`../tutorials/first-paired-comparison`). Standard library only.

.. literalinclude:: oracle_ceiling.py
   :language: python

paired_comparison.py
--------------------

Trains both arms at two seeds and reads the point with ``toy.eval --summary`` and
``toy.paired`` (used in :doc:`../how-to/run-a-paired-comparison`). Needs torch.

.. literalinclude:: paired_comparison.py
   :language: python

read_fixtures.py
----------------

Runs :mod:`toy.paired`, :mod:`toy.sweep`, :mod:`toy.converge`, :mod:`toy.goallog` and
:mod:`toy.placement` on the test fixtures (used in :doc:`../how-to/sweep-strength-or-rows`).

.. literalinclude:: read_fixtures.py
   :language: python

plot_additive_gap.py
--------------------

Draws the :doc:`gallery <../gallery/index>`'s figure. Needs matplotlib.

.. literalinclude:: plot_additive_gap.py
   :language: python

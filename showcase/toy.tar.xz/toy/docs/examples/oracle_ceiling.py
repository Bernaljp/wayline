"""The generator's Bayes ceiling: draw rows with toy.generate and score them with toy.oracle.

`true_prob` is P(y=1|x) as the generator defines it, so its AUROC is the ceiling in expectation:
no model beats it on average over draws, though a trained model can edge above it on one finite
held-out set. `audit` reports that AUROC with its DeLong 95% half-width, and fits an x1..x4
logistic regression (no interaction column) to the first half of the rows, reporting how far its
AUROC on the second half lies below the oracle's there (`additive_gap`). Writes nothing.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "src"))

from toy.generate import generate  # noqa: E402
from toy.metrics import auroc  # noqa: E402
from toy.oracle import audit, true_prob  # noqa: E402

train, held_out = generate(seed=1, signal=4.0, rows=4000, strength=1.0)
print("train rows %d, held-out rows %d" % (len(train), len(held_out)))

labels = [row["y"] for row in held_out]
print("Bayes AUROC on the held-out rows: %.4f" % auroc(labels, true_prob(held_out, m=1.0, signal=4.0)))

report = audit(train + held_out, m=1.0, signal=4.0)
for key in ("bayes_auroc", "bayes_auroc_halfwidth", "calibration_error", "interaction_weight",
            "additive_auroc", "additive_gap"):
    print("%-22s %.4f" % (key, report[key]))

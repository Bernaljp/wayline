"""One paired comparison: both arms of toy.train at two seeds, read with toy.paired and toy.eval.

Trains the `with` arm (x1..x4 plus x3*x4) and the `without` arm (`--no-interaction`) at seeds 1
and 2, each into the run-directory layout `<point>/<with|without>/seed<i>/`, then prints the
point's paired statistics. The pinned settings come from configs/arms.json; `--rows` and
`--epochs` are lowered on the command line (a flag given there wins) so the example runs on a CPU
in seconds. Everything is written under a temporary directory, which is removed at the end.
"""

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]  # docs/examples/ -> the project root
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

from toy.paired import point_stats  # noqa: E402

env = dict(os.environ, PYTHONPATH=str(SRC), PYTHONDONTWRITEBYTECODE="1")


def toy(module, *args):
    """Run `python -m toy.<module> args...` and return what it printed."""
    done = subprocess.run([sys.executable, "-B", "-m", "toy." + module, *args], env=env,
                          capture_output=True, text=True, check=False)
    if done.returncode != 0:
        sys.exit("toy.%s exited %d: %s" % (module, done.returncode, done.stderr.strip().splitlines()[-1]))
    return done.stdout


with tempfile.TemporaryDirectory() as tmp:
    point = Path(tmp) / "m1_n0"
    for seed in (1, 2):
        for arm in ("with", "without"):
            flags = ["--no-interaction"] if arm == "without" else []
            print(toy("train", "--config", str(ROOT / "configs" / "arms.json"), "--seed", str(seed),
                      "--rows", "4000", "--epochs", "10", "--device", "cpu", *flags,
                      "--save-scores", "--out", str(point / arm / ("seed%d" % seed))).strip(),
                  "<-", arm, "seed", seed)

    # One run's held-out AUROC, read back the way O2's measure reads a summary.
    print(toy("eval", "--summary", str(point / "without" / "seed1")).strip())

    # The command line prints the whole JSON; point_stats returns the same object as a dict.
    printed = json.loads(toy("paired", str(point), "--out", str(Path(tmp) / "paired.json")))
    stats = point_stats(point)
    assert printed["paired_gain"] == stats["paired_gain"]
    for key in ("n_pairs", "mean_auroc_with", "mean_auroc_without", "mean_bayes_auroc",
                "paired_gain", "paired_gain_lo", "paired_gain_hi", "signed_rank_p",
                "delong_rejections", "gap_closed"):
        print("%-20s %s" % (key, stats[key]))

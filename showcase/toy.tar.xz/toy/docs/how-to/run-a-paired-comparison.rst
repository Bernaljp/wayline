Run one paired comparison and read it
=====================================

**Task:** train the ``with`` and ``without`` arms at several seeds, check one run's AUROC with
``toy.eval --summary``, and read the point's paired statistics with :mod:`toy.paired`.

1. For each seed ``i``, train the ``with`` arm, then the ``without`` arm with
   ``--no-interaction``, both with ``--save-scores`` and an ``--out`` under the same point
   directory::

       export PYTHONPATH=src
       for i in 1 2 3; do
         python3 -m toy.train --config configs/arms.json --seed $i \
             --save-scores --out runs/E2/m1_n0/with/seed$i
         python3 -m toy.train --config configs/arms.json --seed $i --no-interaction \
             --save-scores --out runs/E2/m1_n0/without/seed$i
       done

   ``experiments/E2/point.sh <out-root> <first-seed> <last-seed>`` runs the same loop.

2. Read one run's held-out AUROC back from its summary::

       python3 -m toy.eval --summary runs/E2/m1_n0/without/seed1

   It prints ``auroc: <value>``. ``--summary`` takes a run directory or its ``summary.json``;
   ``--split val`` prints the ``val_auroc`` of a ``--val-fraction`` run instead.

3. Read the point::

       python3 -m toy.paired runs/E2/m1_n0 --out results/E2/paired.json

   It prints the JSON object :func:`toy.paired.point_stats` returns and, with ``--out``, writes it
   too. Read ``paired_gain`` with ``paired_gain_lo`` and ``paired_gain_hi`` for the size of the
   gain, ``signed_rank_p`` and ``delong_rejections`` for whether it is there at all, and
   ``gap_closed`` for how much of the gap to ``mean_bayes_auroc`` it closes.

If the two arms of a seed were not trained alike (different seeds, rows, strength, epochs or
pinned config, or a ``with`` run that lacks the ``interaction`` column), ``toy.paired`` refuses
with exit status 2 and names the disagreement; nothing is written.

The same task as a script
-------------------------

The documentation build runs this script. It trains two seeds at 4,000 rows and 10 epochs on the
CPU, overriding the pinned ``rows`` and ``epochs`` on the command line (a flag given there wins
over ``--config``), and writes everything under a temporary directory:

.. literalinclude:: ../examples/paired_comparison.py
   :language: python

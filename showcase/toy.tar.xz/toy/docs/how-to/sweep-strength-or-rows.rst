Follow the gain across a sweep
==============================

**Task:** given several sweep points, ask whether the paired gain grows with the interaction
strength ``m``, or shrinks as the training set grows.

A sweep point is a directory holding ``with/`` and ``without/`` (see
:doc:`run-a-paired-comparison`). Train each point with its own ``--strength m`` or
``--train-rows n``; the conventional name is ``m<m>_n<n>``, but :mod:`toy.sweep` reads the
strength and training size from each run's ``config.json``, never from the name.

Across strengths
----------------

Put the points at one training size under one experiment directory and run::

    PYTHONPATH=src python3 -m toy.sweep runs/E3 --axis strength --point runs/E2/m1_n0

``--point`` adds a point from another experiment without re-running it (repeatable). The output's
``strength_spearman`` is Spearman's correlation between ``strength`` and ``paired_gain`` over the
points; ``points`` is the per-point table.

Across training sizes
---------------------

::

    PYTHONPATH=src python3 -m toy.sweep runs/E4 --axis rows --strength 1

This takes the points at ``m = 1``, sorted by ``train_rows``, and reports ``gain_shrink``: the mean
over the seeds the smallest and largest points share of :math:`d_i` at the smallest size minus
:math:`d_i` at the largest, with its 95% t-interval ``gain_shrink_lo`` to ``gain_shrink_hi``.

Both refuse (exit 2) points that disagree on the signal or on the training settings, or two points
at the same place on the axis.

The other records
-----------------

Three more modules read the records an experiment leaves:

- ``PYTHONPATH=src python3 -m toy.converge runs/E2/converge`` prints ``convergence_drop``, the largest relative
  drop in final training loss when the epochs are doubled (against the sibling ``m1_n0`` unless
  ``--pinned`` names another point).
- ``PYTHONPATH=src python3 -m toy.goallog results/E5/changes.jsonl`` prints ``heldout_reads``, how many
  candidates were scored on the held-out split.
- ``PYTHONPATH=src python3 -m toy.placement results/placement.json`` prints ``resolved_refs`` and
  ``prior_measures_gain``, checking each entry against ``research/refs/<slug>/dossier.json``
  (``--refs`` for another directory).

The script below, which the documentation build runs, calls each of these on the test suite's
fixture directories under ``tests/fixtures/``:

.. literalinclude:: ../examples/read_fixtures.py
   :language: python

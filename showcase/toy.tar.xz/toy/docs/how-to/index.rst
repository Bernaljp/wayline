How-to guides
=============

Recipes for one task each, for a reader who already knows what they want to do.

.. toctree::
   :maxdepth: 1
   :glob:

   *

Your first paired comparison
============================

This lesson takes you from an empty shell to the answer ``toy`` exists for: how much the
``x3 * x4`` column raises held-out AUROC, with a confidence interval. It takes a few minutes on a
CPU.

Set up
------

``toy`` is not installed as a distribution; it is run from the project's checkout with ``src/``
on the path. Every command below is run from the project root::

    export PYTHONPATH=src

:mod:`toy.train` needs `PyTorch <https://pytorch.org>`_; every other module needs only Python 3.
A GPU is used when one is available, the CPU otherwise.

Step 1: look at the data and its ceiling
----------------------------------------

:func:`toy.generate.generate` draws ``rows`` labelled rows from one seeded random stream and
returns them as ``(train, held_out)``; the held-out split is the last fifth drawn
(``HELD_OUT_FRACTION = 0.2``). Because the label rule is known, :func:`toy.oracle.true_prob` gives
the exact :math:`P(y=1 \mid x)` of every row. Its AUROC is the Bayes ceiling: no model beats it in
expectation, but it is measured on a finite sample, so on one particular held-out set a trained
model can come out slightly above it. ``bayes_auroc_halfwidth`` is its DeLong 95% half-width:

.. literalinclude:: ../examples/oracle_ceiling.py
   :language: python

``additive_gap`` is the oracle's AUROC minus that of an ``x1..x4`` logistic regression, which is
fitted to the first half of the rows and scored on the second half. It is an estimate from one
half split of how far a model without the interaction column falls below the ceiling, not a
bound: a paired gain measured on a different held-out set can be larger.

Step 2: train both arms
-----------------------

An *arm* is one way of training. The ``with`` arm sees ``x1..x4`` and ``x3 * x4``; the
``without`` arm is the same command plus ``--no-interaction``. Train both at the same seed, each
into its own run directory::

    python3 -m toy.train --config configs/arms.json --seed 1 \
        --save-scores --out runs/demo/m1_n0/with/seed1
    python3 -m toy.train --config configs/arms.json --seed 1 --no-interaction \
        --save-scores --out runs/demo/m1_n0/without/seed1

``--config configs/arms.json`` reads the settings every arm shares. Its ``signal``, ``rows``,
``epochs`` and ``lr`` become the flags' defaults (a flag on the command line still wins). Its
``optimizer``, ``weight_decay``, ``minibatch`` and ``held_out_fraction`` are not applied: they are
only checked against the values the code fixes (Adam, 0.0, 256, 0.2), and the run is refused if
they differ. Other keys in the file are not read. An ``--out`` that does not end in ``.json`` is a run directory: it gets
``summary.json``, ``config.json`` and, with ``--save-scores``, ``heldout_scores.csv``. Each run
prints its held-out AUROC; read it back later with :mod:`toy.eval`::

    python3 -m toy.eval --summary runs/demo/m1_n0/without/seed1

Repeat for more seeds (``--seed 2``, ``--seed 3``, ...): the paired statistics need at least two.

Step 3: read the point
----------------------

The directory ``runs/demo/m1_n0`` holding ``with/`` and ``without/`` is one *sweep point*.
:mod:`toy.paired` pairs the two arms' runs of each seed and prints one JSON object::

    python3 -m toy.paired runs/demo/m1_n0

The headline is ``paired_gain``: the mean over seeds of
:math:`d_i = \mathrm{AUROC}_{\text{with},i} - \mathrm{AUROC}_{\text{without},i}`, with its 95%
t-interval ``paired_gain_lo`` to ``paired_gain_hi``. ``gap_closed`` says what fraction of the
distance from the ``without`` arm to the Bayes ceiling the interaction column closes.

The whole lesson as one script, run by the documentation build on two seeds with fewer rows and
epochs so it is quick, is :doc:`../how-to/run-a-paired-comparison`.

Where next
----------

- Compare points along a sweep: :doc:`../how-to/sweep-strength-or-rows`.
- What every field of ``toy.paired``'s output means: :mod:`toy.paired`.
- Why the arms are built the way they are: :doc:`../explanation/design`.

"""Sphinx configuration, laid out by `wayline docs init`.

The theme is recorded in harness.json.docs and chosen once per project: `wayline docs build` fails
while this file names another.

The package's docstrings follow a plain-text convention rather than reStructuredText: single
backticks mark code, an indented block after a blank line is a formula or a table shown as it is
typed, and `|x|` is an absolute value. `default_role` and `_read_plain_docstring` below render
that convention as it was meant, without changing what a docstring says.
"""

import os
import re
import sys

sys.path.insert(0, os.path.abspath("../src"))

project = "toy"
extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
    "sphinx.ext.viewcode",
    "matplotlib.sphinxext.plot_directive",  # draws the gallery's figures by running docs/examples/plot_*.py
]
autodoc_mock_imports = []  # imports the package needs and the docs environment does not install
autodoc_default_options = {"members": True, "undoc-members": True}
default_role = "code"  # `x` in a docstring is code, as the package writes it
highlight_language = "none"  # a `::` block is a formula, a table or a shell command; examples name python
exclude_patterns = ["_build"]
html_theme = "furo"
plot_formats = ["png"]
plot_html_show_source_link = False
plot_html_show_formats = False

_BULLET = re.compile(r"^(\s*)([-*]|\d+\.)\s+")


def _indent(line):
    return len(line) - len(line.lstrip())


def _content_indent(line):
    """Where a line's text starts: after the marker when it is a list item."""
    bullet = _BULLET.match(line)
    return bullet.end() if bullet else _indent(line)


def _read_plain_docstring(app, what, name, obj, options, lines):
    """Turn indented blocks into literal blocks and escape `|` outside them, in place."""
    out, literal_at = [], None
    previous = ""  # the last non-blank line outside a literal block
    for index, line in enumerate(lines):
        blank = not line.strip()
        if literal_at is not None:
            if blank or _indent(line) > literal_at:
                out.append(line)
                continue
            literal_at = None
        if (not blank and previous and index > 0 and not lines[index - 1].strip()
                and _indent(line) > _content_indent(previous) and not previous.rstrip().endswith("::")):
            base = _content_indent(previous)
            out.extend([" " * base + "::", ""])
            literal_at = base
            out.append(line)
            continue
        if not blank:
            previous = line
        out.append(line.replace("|", r"\|"))
    lines[:] = out


def setup(app):
    app.connect("autodoc-process-docstring", _read_plain_docstring)

How the comparison is built, and its limits
===========================================

The data has a known answer
---------------------------

:func:`toy.generate.row` draws ``x1..x4`` uniform on :math:`[-1, 1]` and labels each row by a coin
flip with probability :math:`\sigma(\text{latent})`, where

.. math::

   \text{latent} = s\,(0.6\,x_1 - 0.4\,x_2 + 1.1\,m\,x_3 x_4) + e, \qquad e \sim N(0, 1),

with ``signal`` :math:`s` and interaction strength :math:`m`. A model that sees only ``x1..x4``
misses exactly the term the label depends on; at :math:`m = 0` there is nothing to miss. Because
the rule is known, :mod:`toy.oracle` computes :math:`P(y=1 \mid x)` by Gauss-Hermite quadrature,
and its AUROC is the ceiling against which both arms are measured. That ceiling holds in
expectation. On one finite held-out set the oracle's AUROC is itself an estimate (reported with a
DeLong 95% half-width, ``bayes_auroc_halfwidth``), and a trained arm can come out slightly above
it.

One random stream draws every row in order, and the held-out rows are the last fifth drawn. Asking
for more rows extends the draw instead of reshuffling it, so a larger run never changes what an
earlier held-out split measured.

The arms differ in one column
-----------------------------

The ``without`` arm (``toy.train --no-interaction``) keeps the ``x3 * x4`` column but fills it
with zeros (:func:`toy.train.featurize`). Its weight then gets no gradient, so the fitted function
is an ``x1..x4`` model's, while both arms have the same shape, start from the same initial weights
and see the same minibatch order from the shared ``--seed``. The only difference between a seed's
two runs is the column's content.

:mod:`toy.paired` checks that this holds before it computes anything, and refuses (exit 2) when it
does not: both arms ran the same seeds; the runs of a seed agree on the draw (seed, strength,
signal, rows, training rows) and on the training settings (``val_fraction``, epochs, learning
rate, minibatch, the pinned config); the ``with`` run's features include ``interaction`` and the
``without`` run's do not; both scored the same held-out labels, which are the ones
:func:`toy.generate.generate` draws from that config; and each summary's ``auroc`` is the AUROC
of its own saved scores.

Four recorded settings are deliberately not compared (``toy.paired.NOT_COMPARED``):
``batch_size`` and ``dataloader_workers``, which the out-of-memory retry ladders shrink and which
do not change which rows are fitted or in what order; ``device``; and the ``--config`` path, whose
content is compared as ``pinned``.

``--batch-size`` does not size the minibatch. The training loop always uses minibatches of
``DEFAULT_MINIBATCH`` (256) rows; ``--batch-size`` only sizes one square tensor of zeros that
:func:`toy.train.ready_interactions` allocates on the device before training and that is freed
unread. It exists so an oversized setting runs a GPU out of memory, for the retry ladder to step
down from, and it changes neither the fit nor the scores.

Why paired statistics
---------------------

Both arms of seed :math:`i` see the same rows, so their AUROCs are correlated, and the analysis
works with the per-seed difference :math:`d_i` rather than comparing two independent samples.
Pairing does not guarantee that :math:`d_i` is less variable than either arm's AUROC alone; how
much it helps depends on how strongly the two arms' AUROCs move together across seeds.
:mod:`toy.paired` reports the mean of
:math:`d_i` with a t-interval on :math:`n-1` degrees of freedom, the exact Wilcoxon signed-rank
p-value, and per seed a DeLong test of the two correlated AUROCs. ``gap_closed``, the ratio
:math:`\overline{d} / \overline{(\text{bayes}_i - \mathrm{AUROC}_{\text{without},i})}`, comes with a
paired bootstrap interval (10,000 resamples, seed 0) and is reported only when that denominator
exceeds 0.005: when the ``without`` arm is already at the ceiling there is no gap to close.

The run directory is the interface
----------------------------------

:mod:`toy.paired`, :mod:`toy.sweep` and :mod:`toy.converge` read only the layout
``<point>/<with|without>/seed<i>/`` with ``summary.json``, ``config.json`` and (for the first
two) ``heldout_scores.csv``. The other two read their own records: :mod:`toy.goallog` reads a
``changes.jsonl`` log, and :mod:`toy.placement` reads a placement record and the
``<slug>/dossier.json`` files under ``research/refs``. A point's strength and training
size are read from ``config.json``, never from its directory name, so renaming a directory cannot
mislabel a point.

The held-out split stays held out
---------------------------------

``toy.train --val-fraction f`` trains on the first part of the training rows, scores the last
``f`` of them as ``val_auroc``, and never scores the held-out rows at all. ``toy.eval --split
val`` reads only ``val_auroc``, and a summary without it is an error, never a fallback to the
held-out AUROC. ``toy.train`` also refuses any ``--out`` under ``owner/``.

A tuning loop chooses its candidates by ``val_auroc`` and logs each held-out scoring to
``results/E5/changes.jsonl``. :mod:`toy.goallog` reads that log: it requires every candidate but
the unchanged ``start`` run to carry the ``val_auroc`` it was chosen by, and counts
``heldout_reads``, the number of distinct candidates scored on the held-out split. Whether a
candidate was kept is recorded in its ``kept`` field (true, false, or null until judged);
:mod:`toy.goallog` counts the kept and the discarded candidates but does not itself apply a keep
rule.

Limits
------

- The model is a single linear layer (logistic regression); the interaction column is exactly
  the generator's term. The gain measured here is for a model handed the right feature, not one
  that has to discover it.
- A pair run on different devices is paired only to the precision at which CPU and CUDA
  arithmetic agree.
- :func:`toy.oracle.latent_mean` and :func:`toy.oracle.true_prob` default to ``signal=4.0``
  (``toy.train``'s default), not to :func:`toy.generate.generate`'s ``1.0``: rows do not record
  the signal or the strength they were drawn at, so pass both.
- ``gap_closed`` is null when the ``without`` arm leaves a gap of 0.005 or less.

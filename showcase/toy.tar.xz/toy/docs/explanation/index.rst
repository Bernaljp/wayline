Explanation
===========

Why the package is built the way it is: the design, the choices, and their limits.

.. toctree::
   :maxdepth: 1
   :glob:

   *

toy.stats
=========

.. automodule:: toy.stats
   :members:

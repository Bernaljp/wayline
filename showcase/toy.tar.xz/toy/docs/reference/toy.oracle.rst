toy.oracle
==========

.. automodule:: toy.oracle
   :members:

toy.placement
=============

.. automodule:: toy.placement
   :members:

Reference
=========

Every public module, class, and function, generated from the docstrings.

.. toctree::
   :maxdepth: 1
   :glob:

   *

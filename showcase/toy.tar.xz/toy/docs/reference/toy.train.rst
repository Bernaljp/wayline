toy.train
=========

.. automodule:: toy.train
   :members:

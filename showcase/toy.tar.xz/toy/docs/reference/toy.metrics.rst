toy.metrics
===========

.. automodule:: toy.metrics
   :members:

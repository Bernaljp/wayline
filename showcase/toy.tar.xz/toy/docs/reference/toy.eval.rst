toy.eval
========

.. automodule:: toy.eval
   :members:

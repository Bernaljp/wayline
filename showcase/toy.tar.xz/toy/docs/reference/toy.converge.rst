toy.converge
============

.. automodule:: toy.converge
   :members:

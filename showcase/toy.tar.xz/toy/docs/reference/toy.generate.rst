toy.generate
============

.. automodule:: toy.generate
   :members:

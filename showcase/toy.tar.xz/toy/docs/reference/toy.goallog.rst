toy.goallog
===========

.. automodule:: toy.goallog
   :members:

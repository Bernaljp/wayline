toy.sweep
=========

.. automodule:: toy.sweep
   :members:

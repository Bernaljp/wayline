toy.paired
==========

.. automodule:: toy.paired
   :members:

Gallery
=======

The figures the package makes, each with the example or the result it comes from.

How much the interaction column can buy
---------------------------------------

.. plot:: examples/plot_additive_gap.py
   :alt: AUROC against interaction strength m for the Bayes ceiling and an x1..x4 logistic regression

   AUROC against the interaction strength :math:`m`, at seed 1, 4,000 rows and signal 4. Black:
   the generator's own scorer (:mod:`toy.oracle`, the Bayes ceiling). Orange: a logistic
   regression on ``x1..x4`` only, fitted to the first half of the rows. Both are scored on the
   second half. The shaded band is ``additive_gap``, the oracle's AUROC minus the regression's on
   that one half split. It estimates how far a model without the ``x3 * x4`` column falls below
   the ceiling, and it is not a bound on the paired gain, which is measured on other held-out rows
   and can exceed it. At :math:`m = 0` the generator plants no interaction, so
   whatever gap is left there is the half-sample regression's own fitting error. Drawn by
   ``docs/examples/plot_additive_gap.py`` (shown on :doc:`../examples/index`) from
   :func:`toy.oracle.audit`; no model is trained.

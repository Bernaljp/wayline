toy
===

``toy`` asks one question on a synthetic two-class dataset: **does giving a model the feature
interaction term** ``x3 * x4`` **improve its held-out AUROC, and by how much?**

The package has three kinds of module:

- **The experiment.** :mod:`toy.generate` draws the seeded dataset (four features ``x1..x4``, the
  label depending on ``x1``, ``x2`` and ``x3 * x4``); :mod:`toy.train` fits a logistic regression
  in one of two *arms*, ``with`` the ``x3 * x4`` column or ``without`` it (``--no-interaction``);
  :mod:`toy.eval` prints the AUROC a run wrote (``--summary``).
- **The ceiling.** :mod:`toy.oracle` computes the generator's own :math:`P(y=1 \mid x)`. Its AUROC
  on a sample is the Bayes ceiling, reported with a DeLong 95% half-width: no model beats it in
  expectation, though a trained arm can edge above it on one finite held-out set.
- **The analysis.** :mod:`toy.paired` compares the two arms seed by seed at one sweep point;
  :mod:`toy.sweep` follows that comparison across interaction strengths or training sizes;
  :mod:`toy.converge`, :mod:`toy.goallog` and :mod:`toy.placement` check the training length, the
  number of held-out reads, and the literature placement. :mod:`toy.stats` and
  :mod:`toy.metrics` are the standard-library statistics underneath.

Everything but :mod:`toy.train` runs on the Python standard library alone.

Start with the :doc:`tutorial <tutorials/first-paired-comparison>`; for one task go to the
:doc:`how-to guides <how-to/index>`; to look a function up, the :doc:`reference <reference/index>`;
for why it is built this way, the :doc:`explanation <explanation/index>`.

.. toctree::
   :maxdepth: 2

   tutorials/index
   how-to/index
   reference/index
   explanation/index
   gallery/index
   examples/index
